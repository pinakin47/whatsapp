# VGRUPS Connect

Imported healthcare CRM, sales, recruitment, and WhatsApp application. The
requested change is MongoDB to PostgreSQL, preserving the supplied UI,
authentication, features, and record formats—not a redesign.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — original FastAPI API on the injected `PORT` (8080 in preview).
- `pnpm --filter @workspace/vgrups-connect run dev` — original frontend, served at `/`.
- `WhatsApp Gateway` workflow / `bash scripts/run-whatsapp.sh` — separate internal gateway on 3001, using the user-approved Baileys v7 compatibility upgrade.
- Production starts both the API and private gateway through `scripts/run_production.py`. Use Reserved VM publishing for always-on WhatsApp replies; Autoscale can suspend idle connections.
- API routes retain `/api`; the preview router forwards that prefix to FastAPI.
- `uv sync --frozen` — restore the managed Python dependencies.
- Database schema: `original-app/1212-main/backend/postgres_schema.sql`, mirrored in `lib/db/src/schema/app-documents.ts`. Apply development schema separately, not during startup.
- Required runtime configuration: `DATABASE_URL` and `SESSION_SECRET`. The launcher uses `SESSION_SECRET` for the original JWT signing key unless `JWT_SECRET` is supplied.
- Production requires `PRODUCTION_ADMIN_EMAIL` and `PRODUCTION_ADMIN_PASSWORD` (at least 16 characters, not a public demo password). Development retains optional `ADMIN_EMAIL`, `ADMIN_PASSWORD`, and `ADMIN_NAME`; the demo hint is development-only.
- Email OTP sign-in uses the connected Brevo account. Shared configuration: `BREVO_USE_CONNECTOR=true`, `BREVO_SENDER_EMAIL` (verified in Brevo), and optional `BREVO_SENDER_NAME`. Replit manages the API key; it is not copied into application secrets.
- Original external providers (storage, AI, payments, ads, and connected WhatsApp accounts) require their existing configuration. No provider credentials or MongoDB export came with the ZIP; Brevo was subsequently connected.

## Stack

- Frontend: supplied React 19 source, Vite runtime, original Tailwind 3 styles.
- API: supplied Python FastAPI routes, bcrypt, and JWT authentication.
- Gateway: supplied Node/Express/Baileys service.
- Persistence: PostgreSQL JSONB, with parameterized filtering and transactional writes shared by Python and Node.
- pnpm workspaces and managed Python dependencies.
- The original TypeScript API scaffold and generated OpenAPI packages are not the running API.

## Where things live

- `original-app/1212-main/` — uploaded app, including backend, gateway, original frontend reference, and Chrome extension.
- `artifacts/vgrups-connect/` — frontend used in preview; source and HTML retained from the upload.
- `artifacts/api-server/` — API artifact registration and launch scripts.
- `scripts/run-backend.sh`, `scripts/run-whatsapp.sh` — runtime entry points.

## Architecture decisions

- Preserve document shapes in PostgreSQL JSONB rather than rewriting every business route into a new relational API. This keeps the database migration within the user's requested compatibility scope.
- Both runtimes share the same storage schema and collection-scoped transaction locks, including atomic counters/upserts.
- Keep the existing authentication; do not replace it with a new provider.
- Do not copy old live data without an export or an explicitly supplied source connection.

## Product

The supplied app includes contacts and leads, conversations, campaigns,
automations, orders and quotations, recruitment, field sales, ads, and settings.
The user requires IVR to reply when anyone sends “hi” to the linked WhatsApp
number, including senders who are not existing CRM contacts.
The Inbox must show new sent and received WhatsApp messages without a manual
page refresh, including messages sent directly from the linked phone.
The user requested removal of demo contacts and a page-by-page PDF user guide in
the header. Demo contacts are reversibly deleted using their explicit `is_demo`
flag; automatic demo seeding is disabled. Other record types and real contacts
are not part of that cleanup.

The packaged guide is `artifacts/vgrups-connect/public/vgrups-connect-user-guide.pdf`.
Its editable source is `docs/user-guide.json`; regenerate with
`uv run python scripts/build_user_guide.py --base-url <verified-production-url>`
and validate with `uv run python scripts/check_user_guide.py`. Keep instructions
honest about placeholder pages and unwired controls, and never include credentials.

## Gotchas

- Do not change source UI, styling, navigation, or behavior as part of this migration.
- Existing provider configuration is not mocked; missing configuration can leave those services unavailable.
- Production blocks public demo passwords and does not display demo login credentials or OTP codes. Use the configured production admin account after publishing.
- Email OTP login signs in existing active accounts only; codes expire after five minutes, allow five verification attempts, and are consumed atomically. Delivery errors do not fall back to displayed codes.
- Preview and production have separate users, WhatsApp pairing, and IVR configuration. Pair the number on the live site; do not copy pairing credentials between databases. New setups have IVR enabled with the standard menu; saved disabled settings are respected.
- With IVR enabled, a direct “hi”, “hello”, “hey”, “menu”, or “0” opens the menu, including after human handoff. Replies preserve the original WhatsApp peer address for LID contacts.
- Start the API through its workspace package script so it is independent of the workflow's working directory.
- The gateway stays loopback-only and is reached through authenticated FastAPI routes. Its console workflow does not wait for a publicly detectable port.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
