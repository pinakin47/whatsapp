import React, { useEffect, useState, useRef } from "react";
import api, { apiError } from "../lib/api";
import { toast } from "sonner";
import { Input } from "../components/ui/input";
import { Button } from "../components/ui/button";
import { Avatar, AvatarFallback } from "../components/ui/avatar";
import { DemoBadge, StatusBadge } from "../components/common";
import {
  Search, Send, Phone, Building2, MapPin, Star, Archive, UserPlus,
  CheckSquare, MessageSquare, ArrowLeft, Paperclip, Info, Check, CheckCheck,
} from "lucide-react";

const FOLDERS = [
  { key: "all", label: "All" }, { key: "unread", label: "Unread" },
  { key: "assigned_me", label: "Assigned to Me" }, { key: "unassigned", label: "Unassigned" },
  { key: "customer", label: "Customers" }, { key: "lead", label: "Leads" },
  { key: "distributor", label: "Distributors" }, { key: "medical_shop", label: "Medical Shops" },
  { key: "hospital", label: "Hospitals" }, { key: "doctor", label: "Doctors" },
  { key: "starred", label: "Starred" }, { key: "archived", label: "Archived" },
];

function Tick({ status }) {
  if (status === "read") return <CheckCheck className="inline h-3.5 w-3.5 text-sky-300" />;
  if (status === "delivered") return <CheckCheck className="inline h-3.5 w-3.5 text-white/70" />;
  if (status === "sent") return <Check className="inline h-3.5 w-3.5 text-white/70" />;
  return <span className="text-white/50">· {status}</span>;
}

function timeAgo(iso) {
  if (!iso) return "";
  const d = (Date.now() - new Date(iso).getTime()) / 60000;
  if (d < 60) return `${Math.floor(d)}m`;
  if (d < 1440) return `${Math.floor(d / 60)}h`;
  return `${Math.floor(d / 1440)}d`;
}

export default function Inbox() {
  const [folder, setFolder] = useState("all");
  const [convos, setConvos] = useState([]);
  const [search, setSearch] = useState("");
  const [active, setActive] = useState(null);
  const [thread, setThread] = useState(null);
  const [text, setText] = useState("");
  const [showProfile, setShowProfile] = useState(false);
  const endRef = useRef(null);

  const loadConvos = () => api.get(`/whatsapp/conversations?folder=${folder}&search=${encodeURIComponent(search)}`).then((r) => setConvos(r.data.items));
  useEffect(() => { const t = setTimeout(loadConvos, 200); return () => clearTimeout(t); }, [folder, search]);

  const openConvo = async (c) => {
    setActive(c);
    const { data } = await api.get(`/whatsapp/conversations/${c.id}/messages`);
    setThread(data);
    setTimeout(() => endRef.current?.scrollIntoView(), 50);
    loadConvos();
  };

  const send = async () => {
    if (!text.trim() || !active) return;
    try {
      const { data } = await api.post(`/whatsapp/conversations/${active.id}/send`, { body: text });
      setThread((t) => ({ ...t, messages: [...t.messages, data] }));
      setText("");
      setTimeout(() => endRef.current?.scrollIntoView(), 50);
    } catch (e) { toast.error(apiError(e)); }
  };

  const flag = async (action) => {
    if (!active) return;
    try { await api.post(`/whatsapp/conversations/${active.id}/flag?action=${action}`); toast.success(`Done: ${action}`); loadConvos(); }
    catch (e) { toast.error(apiError(e)); }
  };

  return (
    <div className="flex h-[calc(100vh-4rem)] md:h-[calc(100vh-4rem)]">
      {/* Pane 1: folders + list */}
      <div className={`${active ? "hidden md:flex" : "flex"} flex-col w-full md:w-96 border-r border-border`}>
        <div className="p-3 border-b border-border space-y-2">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input data-testid="inbox-search-input" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search chats…" className="pl-9 h-9" />
          </div>
          <div className="flex gap-1.5 overflow-x-auto pb-1">
            {FOLDERS.map((f) => (
              <button
                key={f.key}
                data-testid={`inbox-folder-${f.key}`}
                onClick={() => setFolder(f.key)}
                className={`shrink-0 text-xs rounded-full px-3 py-1.5 transition-colors ${folder === f.key ? "bg-[#3B5B2A] text-white" : "bg-muted text-muted-foreground hover:bg-muted/70"}`}
              >
                {f.label}
              </button>
            ))}
          </div>
        </div>
        <div className="flex-1 overflow-y-auto">
          {convos.map((c) => (
            <button
              key={c.id}
              data-testid={`inbox-convo-${c.id}`}
              onClick={() => openConvo(c)}
              className={`w-full flex items-start gap-3 px-3 py-3 border-b border-border/60 text-left hover:bg-muted/50 ${active?.id === c.id ? "bg-muted" : ""}`}
            >
              <Avatar className="h-10 w-10 shrink-0"><AvatarFallback className="bg-[#6E8B5B] text-white text-xs">{(c.name || "?").slice(0, 2).toUpperCase()}</AvatarFallback></Avatar>
              <div className="min-w-0 flex-1">
                <div className="flex items-center justify-between gap-2">
                  <span className="text-sm font-medium truncate flex items-center gap-1">{c.name} {c.is_demo && <DemoBadge />}</span>
                  <span className="text-[11px] text-muted-foreground shrink-0">{timeAgo(c.last_message_at)}</span>
                </div>
                <div className="flex items-center justify-between gap-2 mt-0.5">
                  <span className="text-xs text-muted-foreground truncate">{c.last_message}</span>
                  {c.unread > 0 && <span className="shrink-0 h-5 min-w-5 px-1 rounded-full bg-[#3B5B2A] text-white text-[10px] flex items-center justify-center">{c.unread}</span>}
                </div>
                <span className="inline-block mt-1 text-[10px] rounded bg-muted px-1.5 py-0.5 capitalize text-muted-foreground">{(c.contact_type || "").replace(/_/g, " ")}</span>
              </div>
            </button>
          ))}
          {convos.length === 0 && <div className="p-10 text-center text-sm text-muted-foreground">No conversations</div>}
        </div>
      </div>

      {/* Pane 2: chat */}
      <div className={`${active ? "flex" : "hidden md:flex"} flex-col flex-1 bg-[#F7F9F6] dark:bg-[#0B120C]`}>
        {active ? (
          <>
            <div className="flex items-center justify-between gap-2 h-16 px-4 border-b border-border bg-background">
              <div className="flex items-center gap-3 min-w-0">
                <button className="md:hidden" onClick={() => { setActive(null); setThread(null); }}><ArrowLeft className="h-5 w-5" /></button>
                <Avatar className="h-9 w-9"><AvatarFallback className="bg-[#6E8B5B] text-white text-xs">{(active.name || "?").slice(0, 2).toUpperCase()}</AvatarFallback></Avatar>
                <div className="min-w-0">
                  <div className="text-sm font-semibold truncate">{active.name}</div>
                  <div className="text-xs text-muted-foreground font-mono">{active.phone}</div>
                </div>
              </div>
              <div className="flex items-center gap-1">
                <Button variant="ghost" size="icon" data-testid="inbox-star-btn" onClick={() => flag(active.starred ? "unstar" : "star")}><Star className={`h-4 w-4 ${active.starred ? "fill-[#D97706] text-[#D97706]" : ""}`} /></Button>
                <Button variant="ghost" size="icon" data-testid="inbox-archive-btn" onClick={() => flag("archive")}><Archive className="h-4 w-4" /></Button>
                <Button variant="ghost" size="icon" className="lg:hidden" onClick={() => setShowProfile(true)}><Info className="h-4 w-4" /></Button>
              </div>
            </div>

            <div className="flex-1 overflow-y-auto p-4 space-y-2">
              {thread?.messages.map((m) => (
                <div key={m.id} className={`flex ${m.direction === "outbound" ? "justify-end" : "justify-start"}`}>
                  <div className={`max-w-[75%] rounded-2xl px-3.5 py-2 text-sm ${m.direction === "outbound" ? "bg-[#3B5B2A] text-white rounded-br-sm" : "bg-card border border-border rounded-bl-sm"}`}>
                    <div>{m.body}</div>
                    <div className={`text-[10px] mt-1 flex items-center gap-1 ${m.direction === "outbound" ? "text-white/70 justify-end" : "text-muted-foreground"}`}>
                      {timeAgo(m.created_at)} {m.direction === "outbound" && <Tick status={m.status} />}
                    </div>
                  </div>
                </div>
              ))}
              <div ref={endRef} />
            </div>

            <div className="p-3 border-t border-border bg-background">
              <div className="flex items-center gap-2">
                <Button variant="ghost" size="icon"><Paperclip className="h-4 w-4" /></Button>
                <Input
                  data-testid="inbox-message-input"
                  value={text}
                  onChange={(e) => setText(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && send()}
                  placeholder="Type a message…"
                  className="flex-1"
                />
                <Button data-testid="inbox-send-btn" onClick={send} className="bg-[#3B5B2A] hover:bg-[#2D4720]"><Send className="h-4 w-4" /></Button>
              </div>
              <p className="text-[11px] text-muted-foreground mt-1.5 text-center">Live sending activates once WhatsApp Cloud API is connected in Integrations.</p>
            </div>
          </>
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center text-muted-foreground">
            <MessageSquare className="h-12 w-12 mb-3 opacity-40" />
            <p>Select a conversation to start</p>
          </div>
        )}
      </div>

      {/* Pane 3: profile */}
      {active && thread && (
        <div className={`${showProfile ? "fixed inset-0 z-50 bg-background lg:static lg:inset-auto" : "hidden"} lg:flex flex-col w-full lg:w-80 border-l border-border overflow-y-auto`}>
          <div className="flex items-center justify-between h-16 px-4 border-b border-border lg:hidden">
            <span className="font-semibold">Profile</span>
            <Button variant="ghost" size="icon" onClick={() => setShowProfile(false)}><ArrowLeft className="h-5 w-5" /></Button>
          </div>
          <div className="p-5 text-center border-b border-border">
            <Avatar className="h-16 w-16 mx-auto"><AvatarFallback className="bg-[#3B5B2A] text-white">{(active.name || "?").slice(0, 2).toUpperCase()}</AvatarFallback></Avatar>
            <div className="font-semibold mt-3">{active.name}</div>
            <div className="text-xs text-muted-foreground font-mono">{active.phone}</div>
            <span className="inline-block mt-2 text-xs rounded-full bg-[#F0F4EE] text-[#3B5B2A] px-2.5 py-1 capitalize">{(active.contact_type || "").replace(/_/g, " ")}</span>
          </div>
          <div className="p-4 space-y-3 text-sm">
            {thread.contact && (
              <>
                {thread.contact.company && <div className="flex items-center gap-2 text-muted-foreground"><Building2 className="h-4 w-4" /> {thread.contact.company}</div>}
                {thread.contact.city && <div className="flex items-center gap-2 text-muted-foreground"><MapPin className="h-4 w-4" /> {thread.contact.city}, {thread.contact.state}</div>}
                {thread.contact.email && <div className="flex items-center gap-2 text-muted-foreground"><Phone className="h-4 w-4" /> {thread.contact.email}</div>}
              </>
            )}
            <div className="grid grid-cols-2 gap-2 pt-2">
              <Button variant="outline" size="sm" data-testid="profile-create-task"><CheckSquare className="h-4 w-4 mr-1" /> Task</Button>
              <Button variant="outline" size="sm" data-testid="profile-assign"><UserPlus className="h-4 w-4 mr-1" /> Assign</Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
