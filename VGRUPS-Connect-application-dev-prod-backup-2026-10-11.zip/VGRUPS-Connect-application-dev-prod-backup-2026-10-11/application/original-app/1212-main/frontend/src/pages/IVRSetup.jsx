import React, { useEffect, useState, useCallback } from "react";
import api, { apiError } from "../lib/api";
import { toast } from "sonner";
import { PageHeader } from "../components/common";
import { Card } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { Textarea } from "../components/ui/textarea";
import { Switch } from "../components/ui/switch";
import { Phone, Loader2, Plus, Trash2, UserCog, Send } from "lucide-react";

export default function IVRSetup() {
  const [ivr, setIvr] = useState(null);
  const [saving, setSaving] = useState(false);
  const [sim, setSim] = useState([]);

  const load = useCallback(() => { api.get("/ivr").then((r) => setIvr(r.data)).catch((e) => toast.error(apiError(e))); }, []);
  useEffect(() => { load(); }, [load]);

  const setOpt = (i, patch) => setIvr((v) => ({ ...v, options: v.options.map((o, j) => j === i ? { ...o, ...patch } : o) }));
  const addOpt = () => setIvr((v) => ({ ...v, options: [...v.options, { label: "New option", response: "", handoff: false }] }));
  const rmOpt = (i) => setIvr((v) => ({ ...v, options: v.options.filter((_, j) => j !== i) }));

  const save = async () => {
    setSaving(true);
    try { await api.put("/ivr", ivr); toast.success("IVR saved"); } catch (e) { toast.error(apiError(e)); } finally { setSaving(false); }
  };

  const menuText = () => `${ivr.greeting}\n\n${ivr.options.map((o, i) => `${i + 1}. ${o.label || `Option ${i + 1}`}`).join("\n")}\n\n${ivr.footer || "Reply with a number."}`;
  const simStart = () => setSim([{ from: "bot", text: menuText() }]);
  const simPick = (i) => {
    const o = ivr.options[i];
    const replies = [{ from: "user", text: String(i + 1) }, { from: "bot", text: o.response || "(no response set)" }];
    if (!o.handoff) replies.push({ from: "bot", text: "_Reply 0 for the main menu._" });
    else replies.push({ from: "sys", text: "✓ Handed off to a human agent" });
    setSim((s) => [...s, ...replies]);
  };

  if (!ivr) return <div className="p-10 text-center"><Loader2 className="h-5 w-5 animate-spin mx-auto" /></div>;

  return (
    <div className="p-4 md:p-6 animate-fade-up">
      <PageHeader title="WhatsApp IVR Setup" subtitle="Build a 'Press 1 for Sales' style menu that replies on WhatsApp" testId="ivr-header"
        actions={
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2 text-sm"><span className="text-muted-foreground">Live</span><Switch checked={ivr.enabled} onCheckedChange={(v) => setIvr({ ...ivr, enabled: v })} data-testid="ivr-enabled-toggle" /></div>
            <Button onClick={save} disabled={saving} className="bg-[#3B5B2A] hover:bg-[#2D4720]" data-testid="ivr-save-button">{saving ? <Loader2 className="h-4 w-4 animate-spin" /> : "Save IVR"}</Button>
          </div>
        } />

      <div className="mb-4 text-xs rounded-lg bg-blue-50 dark:bg-blue-500/10 text-blue-700 dark:text-blue-300 border border-blue-200 dark:border-blue-500/20 px-3 py-2" data-testid="ivr-info">
        This IVR runs over <b>WhatsApp messages</b> (not phone calls). Customers reply with a number to navigate the menu.
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-4">
          <Card className="p-4 space-y-3">
            <div><Label>Greeting message</Label><Textarea rows={2} value={ivr.greeting} onChange={(e) => setIvr({ ...ivr, greeting: e.target.value })} data-testid="ivr-greeting-input" /></div>
            <div><Label>Footer / prompt</Label><Input value={ivr.footer} onChange={(e) => setIvr({ ...ivr, footer: e.target.value })} data-testid="ivr-footer-input" /></div>
          </Card>

          <div className="space-y-2">
            {ivr.options.map((o, i) => (
              <Card key={i} className="p-4" data-testid={`ivr-option-${i}`}>
                <div className="flex items-center gap-2 mb-2">
                  <span className="h-7 w-7 rounded-lg bg-[#3B5B2A] text-white flex items-center justify-center text-sm font-bold">{i + 1}</span>
                  <Input className="flex-1" placeholder="Option label e.g. Sales" value={o.label} onChange={(e) => setOpt(i, { label: e.target.value })} data-testid={`ivr-option-label-${i}`} />
                  <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => rmOpt(i)} data-testid={`ivr-option-delete-${i}`}><Trash2 className="h-3.5 w-3.5 text-destructive" /></Button>
                </div>
                <Textarea rows={2} placeholder="Auto-reply sent when the customer picks this option" value={o.response} onChange={(e) => setOpt(i, { response: e.target.value })} data-testid={`ivr-option-response-${i}`} />
                <label className="flex items-center gap-2 mt-2 text-xs text-muted-foreground cursor-pointer">
                  <Switch checked={!!o.handoff} onCheckedChange={(v) => setOpt(i, { handoff: v })} data-testid={`ivr-option-handoff-${i}`} /><UserCog className="h-3.5 w-3.5" /> Hand off to a human agent after replying
                </label>
              </Card>
            ))}
            <Button size="sm" variant="outline" onClick={addOpt} data-testid="ivr-add-option"><Plus className="h-3.5 w-3.5 mr-1" /> Add option</Button>
          </div>
        </div>

        <div>
          <Card className="p-4 sticky top-20" data-testid="ivr-preview">
            <div className="flex items-center justify-between mb-3"><div className="flex items-center gap-2 font-semibold text-sm"><Phone className="h-4 w-4 text-[#3B5B2A]" /> WhatsApp Preview</div><Button size="sm" variant="outline" onClick={simStart} data-testid="ivr-sim-start">Start</Button></div>
            <div className="rounded-xl bg-[#E5DDD5] dark:bg-[#0B141A] p-3 space-y-2 h-[360px] overflow-y-auto" data-testid="ivr-sim-messages">
              {sim.length === 0 && <div className="text-center text-xs text-muted-foreground py-10">Press Start to preview the menu</div>}
              {sim.map((m, i) => (
                m.from === "sys"
                  ? <div key={i} className="text-center"><span className="text-[10px] bg-[#3B5B2A]/10 text-[#3B5B2A] dark:text-[#8BAA78] rounded-full px-2 py-0.5">{m.text}</span></div>
                  : <div key={i} className={`flex ${m.from === "user" ? "justify-end" : ""}`}><div className={`rounded-lg px-3 py-2 text-sm max-w-[85%] whitespace-pre-line ${m.from === "user" ? "bg-[#DCF8C6] dark:bg-[#005C4B] text-gray-800 dark:text-gray-50" : "bg-white dark:bg-[#202C33] text-gray-800 dark:text-gray-100"}`}>{m.text}</div></div>
              ))}
            </div>
            {sim.length > 0 && (
              <div className="flex flex-wrap gap-1.5 mt-2">
                {ivr.options.map((o, i) => <Button key={i} size="sm" variant="outline" className="text-xs" onClick={() => simPick(i)} data-testid={`ivr-sim-pick-${i}`}><Send className="h-3 w-3 mr-1" />{i + 1}</Button>)}
              </div>
            )}
          </Card>
        </div>
      </div>
    </div>
  );
}
