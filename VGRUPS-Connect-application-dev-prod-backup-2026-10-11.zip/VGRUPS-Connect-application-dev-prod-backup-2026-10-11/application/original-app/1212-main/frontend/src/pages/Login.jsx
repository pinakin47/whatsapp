import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth, apiError } from "../context/AuthContext";
import api from "../lib/api";
import { toast } from "sonner";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "../components/ui/tabs";
import { InputOTP, InputOTPGroup, InputOTPSlot } from "../components/ui/input-otp";
import { ShieldCheck, Loader2, Activity } from "lucide-react";

export default function Login() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState("vgdisposables@gmail.com");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  // OTP demo state
  const [otpId, setOtpId] = useState("");
  const [otpSent, setOtpSent] = useState(false);
  const [otp, setOtp] = useState("");
  const [demoCode, setDemoCode] = useState("");

  const submit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await login(email, password);
      toast.success("Welcome back!");
      navigate("/dashboard");
    } catch (err) {
      toast.error(apiError(err));
    } finally {
      setLoading(false);
    }
  };

  const sendOtp = async () => {
    setLoading(true);
    try {
      const { data } = await api.post("/auth/send-otp", { identifier: email, channel: "email", purpose: "login" });
      setOtpSent(true);
      if (data.demo_mode) { setDemoCode(data.demo_code); toast.info("Demo mode: OTP shown below (email provider not configured)"); }
      else toast.success("OTP sent to your email");
    } catch (err) { toast.error(apiError(err)); } finally { setLoading(false); }
  };

  const verifyOtp = async () => {
    setLoading(true);
    try {
      await api.post("/auth/verify-otp", { identifier: email, code: otp, purpose: "login" });
      toast.success("OTP verified. Signing in…");
      // After OTP verification, still authenticate session via password for this demo flow
      toast.info("Enter password to complete login, or OTP-only login requires provider setup.");
    } catch (err) { toast.error(apiError(err)); } finally { setLoading(false); }
  };

  return (
    <div className="min-h-screen flex">
      {/* Left brand panel */}
      <div className="hidden lg:flex flex-col justify-between w-[45%] bg-[#122013] p-12 relative overflow-hidden">
        <div className="absolute inset-0 opacity-[0.07]" style={{ backgroundImage: "radial-gradient(circle at 20% 30%, #fff 1px, transparent 1px)", backgroundSize: "28px 28px" }} />
        <div className="relative flex items-center gap-3">
          <div className="h-11 w-11 rounded-xl bg-[#3B5B2A] text-white flex items-center justify-center font-bold text-xl font-heading">V</div>
          <div>
            <div className="text-white font-bold font-heading text-lg">VGRUPS HEALTHCARE</div>
            <div className="text-[#8BAA78] text-xs tracking-wide">CONNECT Enterprise Platform</div>
          </div>
        </div>
        <div className="relative">
          <h2 className="text-white text-3xl font-bold font-heading leading-tight">WhatsApp automation,<br />CRM & sales — unified.</h2>
          <p className="text-[#C3D4B8] mt-4 text-sm leading-relaxed max-w-md">
            One platform for conversations, leads, campaigns, orders, payments and field sales.
            Built for VGRUPS Healthcare distributors, MRs, pharmacies and institutions.
          </p>
          <div className="flex gap-3 mt-8">
            {["Unified Inbox", "Lead Kanban", "WhatsApp OTP", "Campaigns"].map((f) => (
              <span key={f} className="text-[11px] rounded-full bg-white/10 text-[#E1EAD9] px-3 py-1.5">{f}</span>
            ))}
          </div>
        </div>
        <div className="relative text-[#6F826B] text-xs">© 2026 VGRUPS Healthcare. Enterprise SaaS.</div>
      </div>

      {/* Right form */}
      <div className="flex-1 flex items-center justify-center p-6 bg-background">
        <div className="w-full max-w-md animate-fade-up">
          <div className="lg:hidden flex items-center gap-2 mb-8">
            <div className="h-10 w-10 rounded-xl bg-[#3B5B2A] text-white flex items-center justify-center font-bold">V</div>
            <div className="font-bold font-heading">VGRUPS CONNECT</div>
          </div>
          <h1 className="text-2xl font-bold font-heading">Sign in to your account</h1>
          <p className="text-sm text-muted-foreground mt-1">Enterprise access for VGRUPS CONNECT</p>

          <Tabs defaultValue="password" className="mt-8">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="password" data-testid="login-tab-password">Password</TabsTrigger>
              <TabsTrigger value="otp" data-testid="login-tab-otp">OTP</TabsTrigger>
            </TabsList>

            <TabsContent value="password">
              <form onSubmit={submit} className="space-y-4 mt-5">
                <div>
                  <Label htmlFor="email">Email</Label>
                  <Input id="email" data-testid="login-email-input" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required className="mt-1.5" />
                </div>
                <div>
                  <Label htmlFor="password">Password</Label>
                  <Input id="password" data-testid="login-password-input" type="password" value={password} onChange={(e) => setPassword(e.target.value)} required className="mt-1.5" placeholder="••••••••" />
                </div>
                <Button type="submit" data-testid="login-submit-button" disabled={loading} className="w-full bg-[#3B5B2A] hover:bg-[#2D4720]">
                  {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : "Sign In"}
                </Button>
              </form>
            </TabsContent>

            <TabsContent value="otp">
              <div className="space-y-4 mt-5">
                <div>
                  <Label>Email</Label>
                  <Input data-testid="otp-email-input" type="email" value={email} onChange={(e) => setEmail(e.target.value)} className="mt-1.5" />
                </div>
                {!otpSent ? (
                  <Button onClick={sendOtp} disabled={loading} data-testid="otp-send-button" className="w-full bg-[#3B5B2A] hover:bg-[#2D4720]">
                    {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : "Send OTP"}
                  </Button>
                ) : (
                  <div className="space-y-4">
                    {demoCode && (
                      <div className="rounded-lg bg-[#F0F4EE] border border-[#3B5B2A]/20 p-3 text-sm text-[#3B5B2A] flex items-center gap-2">
                        <Activity className="h-4 w-4" /> Demo OTP: <b className="font-mono text-base">{demoCode}</b>
                      </div>
                    )}
                    <div className="flex justify-center">
                      <InputOTP maxLength={6} value={otp} onChange={setOtp} data-testid="otp-input">
                        <InputOTPGroup>
                          {[0, 1, 2, 3, 4, 5].map((i) => <InputOTPSlot key={i} index={i} />)}
                        </InputOTPGroup>
                      </InputOTP>
                    </div>
                    <Button onClick={verifyOtp} disabled={loading || otp.length < 6} data-testid="otp-verify-button" className="w-full bg-[#3B5B2A] hover:bg-[#2D4720]">
                      Verify OTP
                    </Button>
                  </div>
                )}
                <p className="text-xs text-muted-foreground text-center">
                  WhatsApp/Email OTP delivery activates once you connect a provider in Integrations.
                </p>
              </div>
            </TabsContent>
          </Tabs>

          <div className="mt-6 rounded-lg border border-border bg-muted/40 p-3 text-xs text-muted-foreground flex items-start gap-2">
            <ShieldCheck className="h-4 w-4 mt-0.5 text-[#3B5B2A]" />
            <span>Admin demo login — Email: <b>vgdisposables@gmail.com</b> · Password: <b>VgrupsConnect@2026</b></span>
          </div>
        </div>
      </div>
    </div>
  );
}
