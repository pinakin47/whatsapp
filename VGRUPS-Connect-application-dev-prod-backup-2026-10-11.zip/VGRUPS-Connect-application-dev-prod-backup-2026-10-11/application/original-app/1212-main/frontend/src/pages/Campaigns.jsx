import React, { useEffect, useState, useCallback } from "react";
import api, { apiError } from "../lib/api";
import { toast } from "sonner";
import { PageHeader, StatusBadge, DemoBadge } from "../components/common";
import { Card } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { Textarea } from "../components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../components/ui/select";
import { Switch } from "../components/ui/switch";
import { Progress } from "../components/ui/progress";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogTrigger } from "../components/ui/dialog";
import { Megaphone, Send, Eye, Reply, XCircle, Play, Pause, Trash2, Plus, Loader2, Users, Ban, Download } from "lucide-react";

const CONTACT_TYPES = ["lead", "customer", "doctor", "hospital", "pharmacy", "distributor", "cf", "medical_shop", "institution"];
const emptyC = { name: "", message: "", template_name: "", audience: { type: "all", contact_type: "", city: "", tag: "" }, send_now: false, scheduled_at: "" };

function Stat({ icon: Icon, label, value }) {
  return (
    <div className="flex items-center gap-2">
      <Icon className="h-4 w-4 text-muted-foreground" />
      <div><div className="text-sm font-semibold">{Number(value || 0).toLocaleString("en-IN")}</div><div className="text-[10px] text-muted-foreground">{label}</div></div>
    </div>
  );
}

export default function Campaigns() {
  const [items, setItems] = useState([]);
  const [templates, setTemplates] = useState([]);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState(emptyC);
  const [schedule, setSchedule] = useState(false);
  const [saving, setSaving] = useState(false);

  const load = useCallback(() => { api.get("/campaigns").then((r) => setItems(r.data.items)); }, []);
  useEffect(() => {
    load();
    api.get("/whatsapp/templates").then((r) => setTemplates(r.data.items || [])).catch(() => {});
    const t = setInterval(load, 4000);
    return () => clearInterval(t);
  }, [load]);

  const exportCsv = async (c) => {
    try {
      const r = await api.get(`/campaigns/${c.id}/report.csv`, { responseType: "blob" });
      const url = window.URL.createObjectURL(new Blob([r.data]));
      const a = document.createElement("a");
      a.href = url; a.download = `${c.name.replace(/\s/g, "_")}_report.csv`;
      document.body.appendChild(a); a.click(); a.remove();
      window.URL.revokeObjectURL(url);
    } catch (e) { toast.error(apiError(e)); }
  };

  const pickTemplate = (name) => {
    const tpl = templates.find((t) => t.name === name);
    setForm((f) => ({ ...f, template_name: name, message: tpl ? tpl.body : f.message }));
  };

  const create = async () => {
    setSaving(true);
    try {
      const payload = {
        name: form.name, message: form.message, template_name: form.template_name || null, audience: form.audience,
        send_now: !schedule, scheduled_at: schedule && form.scheduled_at ? new Date(form.scheduled_at).toISOString() : null,
      };
      await api.post("/campaigns", payload);
      toast.success(schedule ? "Campaign scheduled" : "Campaign started — sending now");
      setOpen(false); setForm(emptyC); setSchedule(false); load();
    } catch (e) { toast.error(apiError(e)); } finally { setSaving(false); }
  };

  const action = async (id, act) => {
    try { await api.post(`/campaigns/${id}/${act}`); toast.success(act); load(); }
    catch (e) { toast.error(apiError(e)); }
  };
  const remove = async (id) => {
    try { await api.delete(`/campaigns/${id}`); toast.success("Deleted"); load(); }
    catch (e) { toast.error(apiError(e)); }
  };

  return (
    <div className="p-4 md:p-6 animate-fade-up">
      <PageHeader
        title="Campaigns & Broadcast" subtitle={`${items.length} campaigns · sends through your linked WhatsApp number`} testId="campaigns-header"
        actions={
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild><Button data-testid="add-campaign-button" className="bg-[#3B5B2A] hover:bg-[#2D4720]"><Plus className="h-4 w-4 mr-1" /> New Broadcast</Button></DialogTrigger>
            <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>New WhatsApp Broadcast</DialogTitle>
                <DialogDescription>Opted-out contacts are automatically suppressed. Sending respects per-number daily limits.</DialogDescription>
              </DialogHeader>
              <div className="space-y-3">
                <div><Label>Campaign Name *</Label><Input data-testid="campaign-name-input" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
                {templates.length > 0 && (
                  <div>
                    <Label>Use approved template (optional)</Label>
                    <Select value={form.template_name || "none"} onValueChange={(v) => pickTemplate(v === "none" ? "" : v)}>
                      <SelectTrigger data-testid="campaign-template-select"><SelectValue placeholder="None" /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="none">None (custom message)</SelectItem>
                        {templates.map((t) => <SelectItem key={t.id} value={t.name}>{t.name}{t.status === "approved" ? " ✅" : ""}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                )}
                <div><Label>Message *</Label><Textarea rows={4} data-testid="campaign-message-input" value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} placeholder="Hi {name}! New offers on VGRUPS products…" />
                  <p className="text-[11px] text-muted-foreground mt-1">Variables: {"{name}"} {"{company}"} {"{city}"} — auto-filled per contact.</p>
                </div>
                <div>
                  <Label>Audience</Label>
                  <Select value={form.audience.type} onValueChange={(v) => setForm({ ...form, audience: { ...form.audience, type: v } })}>
                    <SelectTrigger data-testid="campaign-audience-type"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All contacts</SelectItem>
                      <SelectItem value="filter">Filtered</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                {form.audience.type === "filter" && (
                  <div className="grid grid-cols-2 gap-2">
                    <div><Label className="text-xs">Contact Type</Label>
                      <Select value={form.audience.contact_type || "any"} onValueChange={(v) => setForm({ ...form, audience: { ...form.audience, contact_type: v === "any" ? "" : v } })}>
                        <SelectTrigger><SelectValue placeholder="Any" /></SelectTrigger>
                        <SelectContent><SelectItem value="any">Any</SelectItem>{CONTACT_TYPES.map((t) => <SelectItem key={t} value={t}>{t.replace(/_/g, " ")}</SelectItem>)}</SelectContent>
                      </Select>
                    </div>
                    <div><Label className="text-xs">City</Label><Input value={form.audience.city} onChange={(e) => setForm({ ...form, audience: { ...form.audience, city: e.target.value } })} /></div>
                    <div className="col-span-2"><Label className="text-xs">Tag</Label><Input value={form.audience.tag} onChange={(e) => setForm({ ...form, audience: { ...form.audience, tag: e.target.value } })} placeholder="e.g. vip" /></div>
                  </div>
                )}
                <div className="flex items-center justify-between rounded-lg border border-border p-3">
                  <div><Label>Schedule for later</Label><p className="text-xs text-muted-foreground">Off = send immediately</p></div>
                  <Switch checked={schedule} onCheckedChange={setSchedule} data-testid="campaign-schedule-toggle" />
                </div>
                {schedule && <Input type="datetime-local" data-testid="campaign-schedule-input" value={form.scheduled_at} onChange={(e) => setForm({ ...form, scheduled_at: e.target.value })} />}
              </div>
              <DialogFooter>
                <Button data-testid="campaign-save-button" disabled={saving || !form.name || !form.message} onClick={create} className="bg-[#3B5B2A] hover:bg-[#2D4720]">
                  {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : schedule ? "Schedule" : "Start Broadcast"}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        }
      />

      <div className="grid md:grid-cols-2 gap-4">
        {items.map((c) => {
          const s = c.stats || {};
          const done = (s.sent || 0) + (s.failed || 0) + (s.skipped || 0);
          const pct = s.total ? Math.round((done / s.total) * 100) : 0;
          return (
            <Card key={c.id} className="p-5" data-testid={`campaign-card-${c.id}`}>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 min-w-0">
                  <div className="h-9 w-9 rounded-lg bg-[#F0F4EE] dark:bg-[#1D2B1E] flex items-center justify-center shrink-0"><Megaphone className="h-4 w-4 text-[#3B5B2A]" /></div>
                  <div className="min-w-0"><div className="font-semibold flex items-center gap-2 truncate">{c.name} {c.is_demo && <DemoBadge />}</div>
                    {c.scheduled_at && <div className="text-[11px] text-muted-foreground">⏰ {new Date(c.scheduled_at).toLocaleString()}</div>}
                  </div>
                </div>
                <StatusBadge status={c.status} />
              </div>
              {!c.is_demo && c.message && <p className="text-xs text-muted-foreground mt-2 line-clamp-2">{c.message}</p>}
              {s.total > 0 && (
                <div className="mt-3">
                  <div className="flex justify-between text-[11px] text-muted-foreground mb-1"><span>{done}/{s.total} processed</span><span>{pct}%</span></div>
                  <Progress value={pct} className="h-2" />
                </div>
              )}
              <div className="grid grid-cols-4 gap-2 mt-4">
                <Stat icon={Send} label="Sent" value={s.sent} />
                <Stat icon={Reply} label="Replies" value={s.replies} />
                <Stat icon={Ban} label="Opt-out" value={s.skipped} />
                <Stat icon={XCircle} label="Failed" value={s.failed} />
              </div>
              {s.total > 0 && (
                <Button size="sm" variant="outline" className="w-full mt-3" data-testid={`campaign-export-${c.id}`} onClick={() => exportCsv(c)}>
                  <Download className="h-3.5 w-3.5 mr-1" /> Export recipient report (CSV)
                </Button>
              )}
              {!c.is_demo && (
                <div className="flex gap-2 mt-4">
                  {["draft"].includes(c.status) && <Button size="sm" variant="outline" className="flex-1" data-testid={`campaign-send-${c.id}`} onClick={() => action(c.id, "send")}><Play className="h-3.5 w-3.5 mr-1" /> Start</Button>}
                  {c.status === "running" && <Button size="sm" variant="outline" className="flex-1" data-testid={`campaign-pause-${c.id}`} onClick={() => action(c.id, "pause")}><Pause className="h-3.5 w-3.5 mr-1" /> Pause</Button>}
                  {["paused", "scheduled"].includes(c.status) && <Button size="sm" variant="outline" className="flex-1" data-testid={`campaign-resume-${c.id}`} onClick={() => action(c.id, "resume")}><Play className="h-3.5 w-3.5 mr-1" /> Resume</Button>}
                  <Button size="sm" variant="ghost" data-testid={`campaign-delete-${c.id}`} onClick={() => remove(c.id)}><Trash2 className="h-4 w-4 text-destructive" /></Button>
                </div>
              )}
            </Card>
          );
        })}
      </div>
    </div>
  );
}
