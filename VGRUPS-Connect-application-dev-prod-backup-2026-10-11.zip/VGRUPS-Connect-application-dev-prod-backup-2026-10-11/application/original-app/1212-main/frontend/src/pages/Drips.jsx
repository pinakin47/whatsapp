import React, { useEffect, useState, useCallback } from "react";
import api, { apiError } from "../lib/api";
import { toast } from "sonner";
import { StatusBadge, DemoBadge } from "../components/common";
import { Card } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { Textarea } from "../components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogTrigger } from "../components/ui/dialog";
import { Plus, Loader2, Play, Pause, Trash2, Clock, CheckCircle2, Reply, ShoppingBag, Ban, GitBranch } from "lucide-react";

const DEFAULT_STEPS = [
  { day: 0, message: "Hi {name}! 👋 Welcome to VGRUPS Healthcare. Thanks for your interest!" },
  { day: 1, message: "Hi {name}, here's our product range and today's best prices. Reply to know more." },
  { day: 3, message: "Just checking in {name} — any questions on our products? We're happy to help." },
  { day: 7, message: "{name}, a quick reminder: special pricing for you this week. Shall we proceed?" },
];
const empty = { name: "", audience: { type: "all", contact_type: "" }, steps: DEFAULT_STEPS };

export default function Drips() {
  const [items, setItems] = useState([]);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState(empty);
  const [saving, setSaving] = useState(false);

  const load = useCallback(() => { api.get("/drips").then((r) => setItems(r.data.items)); }, []);
  useEffect(() => { load(); const t = setInterval(load, 5000); return () => clearInterval(t); }, [load]);

  const setStep = (i, k, v) => setForm((f) => ({ ...f, steps: f.steps.map((s, idx) => idx === i ? { ...s, [k]: v } : s) }));
  const addStep = () => setForm((f) => ({ ...f, steps: [...f.steps, { day: (f.steps.at(-1)?.day || 0) + 7, message: "" }] }));
  const rmStep = (i) => setForm((f) => ({ ...f, steps: f.steps.filter((_, idx) => idx !== i) }));

  const create = async () => {
    setSaving(true);
    try {
      await api.post("/drips", { name: form.name, audience: form.audience, steps: form.steps.map((s) => ({ day: Number(s.day) || 0, message: s.message })) });
      toast.success("Drip sequence created"); setOpen(false); setForm(empty); load();
    } catch (e) { toast.error(apiError(e)); } finally { setSaving(false); }
  };
  const action = async (id, act) => { try { await api.post(`/drips/${id}/${act}`); const r = act === "activate" ? await Promise.resolve() : null; toast.success(act === "activate" ? "Activated & enrolled audience" : act); load(); } catch (e) { toast.error(apiError(e)); } };
  const remove = async (id) => { try { await api.delete(`/drips/${id}`); toast.success("Deleted"); load(); } catch (e) { toast.error(apiError(e)); } };

  return (
    <div data-testid="drips-page">
      <div className="flex justify-end mb-4">
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild><Button data-testid="add-drip-button" className="bg-[#3B5B2A] hover:bg-[#2D4720]"><Plus className="h-4 w-4 mr-1" /> New Drip Sequence</Button></DialogTrigger>
          <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>New Drip Sequence</DialogTitle>
              <DialogDescription>Auto-stops when a contact replies, buys, or opts out. {"{name}"} is filled per contact.</DialogDescription>
            </DialogHeader>
            <div className="space-y-3">
              <div><Label>Name *</Label><Input data-testid="drip-name-input" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
              <div className="space-y-2">
                <Label>Steps</Label>
                {form.steps.map((s, i) => (
                  <div key={i} className="rounded-lg border border-border p-2.5" data-testid={`drip-step-${i}`}>
                    <div className="flex items-center gap-2 mb-1.5">
                      <span className="text-xs font-semibold text-[#3B5B2A]">Day</span>
                      <Input type="number" className="h-7 w-20" value={s.day} onChange={(e) => setStep(i, "day", e.target.value)} />
                      <Button size="icon" variant="ghost" className="ml-auto h-7 w-7" onClick={() => rmStep(i)}><Trash2 className="h-3.5 w-3.5 text-destructive" /></Button>
                    </div>
                    <Textarea rows={2} value={s.message} onChange={(e) => setStep(i, "message", e.target.value)} placeholder="Message…" />
                  </div>
                ))}
                <Button size="sm" variant="outline" onClick={addStep} data-testid="drip-add-step"><Plus className="h-3.5 w-3.5 mr-1" /> Add step</Button>
              </div>
            </div>
            <DialogFooter><Button data-testid="drip-save-button" disabled={saving || !form.name || form.steps.length === 0} onClick={create} className="bg-[#3B5B2A] hover:bg-[#2D4720]">{saving ? <Loader2 className="h-4 w-4 animate-spin" /> : "Create Sequence"}</Button></DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        {items.map((d) => {
          const s = d.stats || {};
          return (
            <Card key={d.id} className="p-5" data-testid={`drip-card-${d.id}`}>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2"><div className="h-9 w-9 rounded-lg bg-[#F0F4EE] dark:bg-[#1D2B1E] flex items-center justify-center"><GitBranch className="h-4 w-4 text-[#3B5B2A]" /></div><div className="font-semibold flex items-center gap-2">{d.name} {d.is_demo && <DemoBadge />}</div></div>
                <StatusBadge status={d.status} />
              </div>
              <div className="text-xs text-muted-foreground mt-2">{(d.steps || []).length} steps · Days {(d.steps || []).map((x) => x.day).join(", ")}</div>
              <div className="grid grid-cols-5 gap-1.5 mt-3 text-center">
                {[["Active", s.active, Clock], ["Sent", s.sent, CheckCircle2], ["Replied", s.replied, Reply], ["Bought", s.purchased, ShoppingBag], ["Opt-out", s.opted_out, Ban]].map(([l, v, Ic]) => (
                  <div key={l}><Ic className="h-3.5 w-3.5 mx-auto text-muted-foreground" /><div className="text-sm font-semibold">{v || 0}</div><div className="text-[9px] text-muted-foreground">{l}</div></div>
                ))}
              </div>
              <div className="flex gap-2 mt-4">
                {d.status === "draft" && <Button size="sm" variant="outline" className="flex-1" data-testid={`drip-activate-${d.id}`} onClick={() => action(d.id, "activate")}><Play className="h-3.5 w-3.5 mr-1" /> Activate</Button>}
                {d.status === "active" && <Button size="sm" variant="outline" className="flex-1" data-testid={`drip-pause-${d.id}`} onClick={() => action(d.id, "pause")}><Pause className="h-3.5 w-3.5 mr-1" /> Pause</Button>}
                {d.status === "paused" && <Button size="sm" variant="outline" className="flex-1" data-testid={`drip-resume-${d.id}`} onClick={() => action(d.id, "resume")}><Play className="h-3.5 w-3.5 mr-1" /> Resume</Button>}
                <Button size="sm" variant="ghost" data-testid={`drip-delete-${d.id}`} onClick={() => remove(d.id)}><Trash2 className="h-4 w-4 text-destructive" /></Button>
              </div>
            </Card>
          );
        })}
        {items.length === 0 && <div className="col-span-full text-center py-10 text-muted-foreground">No drip sequences yet. Create one to start day-based follow-ups.</div>}
      </div>
    </div>
  );
}
