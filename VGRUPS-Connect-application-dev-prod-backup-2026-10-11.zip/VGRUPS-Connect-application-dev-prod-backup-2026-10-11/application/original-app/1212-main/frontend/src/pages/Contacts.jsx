import React, { useEffect, useState, useCallback } from "react";
import api, { apiError } from "../lib/api";
import { toast } from "sonner";
import { PageHeader, StatusBadge, DemoBadge } from "../components/common";
import { Card } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { Textarea } from "../components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../components/ui/select";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger,
} from "../components/ui/dialog";
import {
  Sheet, SheetContent, SheetHeader, SheetTitle,
} from "../components/ui/sheet";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../components/ui/table";
import { Plus, Search, Phone, Mail, MapPin, Building2, Trash2, Loader2 } from "lucide-react";

const TYPES = [
  "all", "lead", "customer", "doctor", "hospital", "pharmacy",
  "distributor", "cf", "medical_shop", "institution",
];
const label = (t) => t.replace(/_/g, " ").replace(/\b\w/g, (c) => c.toUpperCase());

const empty = { name: "", mobile: "", email: "", company: "", contact_type: "lead", city: "", state: "", pincode: "", gst: "", category: "", source: "manual", notes: "" };

export default function Contacts() {
  const [items, setItems] = useState([]);
  const [search, setSearch] = useState("");
  const [type, setType] = useState("all");
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState(empty);
  const [saving, setSaving] = useState(false);
  const [detail, setDetail] = useState(null);

  const load = useCallback(() => {
    api.get(`/contacts?search=${encodeURIComponent(search)}&contact_type=${type}`).then((r) => setItems(r.data.items));
  }, [search, type]);

  useEffect(() => { const t = setTimeout(load, 250); return () => clearTimeout(t); }, [load]);

  const save = async () => {
    setSaving(true);
    try {
      await api.post("/contacts", form);
      toast.success("Contact created");
      setOpen(false); setForm(empty); load();
    } catch (e) { toast.error(apiError(e)); } finally { setSaving(false); }
  };

  const remove = async (id) => {
    try { await api.delete(`/contacts/${id}`); toast.success("Deleted"); load(); }
    catch (e) { toast.error(apiError(e)); }
  };

  const openDetail = async (id) => {
    const { data } = await api.get(`/contacts/${id}`);
    setDetail(data);
  };

  return (
    <div className="p-4 md:p-6 animate-fade-up">
      <PageHeader
        title="CRM / Contacts"
        subtitle={`${items.length} contacts`}
        testId="contacts-header"
        actions={
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button data-testid="add-contact-button" className="bg-[#3B5B2A] hover:bg-[#2D4720]"><Plus className="h-4 w-4 mr-1" /> New Contact</Button>
            </DialogTrigger>
            <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
              <DialogHeader><DialogTitle>New Contact</DialogTitle></DialogHeader>
              <div className="grid grid-cols-2 gap-3">
                <div className="col-span-2"><Label>Name *</Label><Input data-testid="contact-name-input" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
                <div><Label>Mobile *</Label><Input data-testid="contact-mobile-input" value={form.mobile} onChange={(e) => setForm({ ...form, mobile: e.target.value })} placeholder="+9198..." /></div>
                <div><Label>Email</Label><Input value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></div>
                <div><Label>Company</Label><Input value={form.company} onChange={(e) => setForm({ ...form, company: e.target.value })} /></div>
                <div>
                  <Label>Type</Label>
                  <Select value={form.contact_type} onValueChange={(v) => setForm({ ...form, contact_type: v })}>
                    <SelectTrigger data-testid="contact-type-select"><SelectValue /></SelectTrigger>
                    <SelectContent>{TYPES.filter((t) => t !== "all").map((t) => <SelectItem key={t} value={t}>{label(t)}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
                <div><Label>City</Label><Input value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} /></div>
                <div><Label>State</Label><Input value={form.state} onChange={(e) => setForm({ ...form, state: e.target.value })} /></div>
                <div><Label>GST</Label><Input value={form.gst} onChange={(e) => setForm({ ...form, gst: e.target.value })} /></div>
                <div className="col-span-2"><Label>Notes</Label><Textarea value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} /></div>
              </div>
              <DialogFooter>
                <Button data-testid="contact-save-button" disabled={saving || !form.name || !form.mobile} onClick={save} className="bg-[#3B5B2A] hover:bg-[#2D4720]">
                  {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : "Save Contact"}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        }
      />

      <div className="flex flex-col sm:flex-row gap-2 mb-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input data-testid="contacts-search-input" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search name, mobile, company…" className="pl-9" />
        </div>
        <Select value={type} onValueChange={setType}>
          <SelectTrigger className="w-full sm:w-48" data-testid="contacts-type-filter"><SelectValue /></SelectTrigger>
          <SelectContent>{TYPES.map((t) => <SelectItem key={t} value={t}>{t === "all" ? "All Types" : label(t)}</SelectItem>)}</SelectContent>
        </Select>
      </div>

      <Card className="overflow-hidden">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead><TableHead>Type</TableHead><TableHead className="hidden md:table-cell">Company</TableHead>
                <TableHead className="hidden sm:table-cell">Mobile</TableHead><TableHead className="hidden lg:table-cell">City</TableHead><TableHead></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {items.map((c) => (
                <TableRow key={c.id} data-testid={`contact-row-${c.id}`} className="cursor-pointer" onClick={() => openDetail(c.id)}>
                  <TableCell className="font-medium flex items-center gap-2">{c.name} {c.is_demo && <DemoBadge />}</TableCell>
                  <TableCell><span className="text-xs rounded-full bg-muted px-2 py-0.5 capitalize">{label(c.contact_type)}</span></TableCell>
                  <TableCell className="hidden md:table-cell text-muted-foreground">{c.company}</TableCell>
                  <TableCell className="hidden sm:table-cell font-mono text-xs">{c.mobile}</TableCell>
                  <TableCell className="hidden lg:table-cell text-muted-foreground">{c.city}</TableCell>
                  <TableCell onClick={(e) => e.stopPropagation()}>
                    <Button variant="ghost" size="icon" data-testid={`delete-contact-${c.id}`} onClick={() => remove(c.id)}><Trash2 className="h-4 w-4 text-destructive" /></Button>
                  </TableCell>
                </TableRow>
              ))}
              {items.length === 0 && <TableRow><TableCell colSpan={6} className="text-center py-10 text-muted-foreground">No contacts found</TableCell></TableRow>}
            </TableBody>
          </Table>
        </div>
      </Card>

      <Sheet open={!!detail} onOpenChange={(o) => !o && setDetail(null)}>
        <SheetContent className="w-full sm:max-w-md overflow-y-auto">
          {detail && (
            <>
              <SheetHeader><SheetTitle className="flex items-center gap-2">{detail.name} {detail.is_demo && <DemoBadge />}</SheetTitle></SheetHeader>
              <div className="mt-5 space-y-4 text-sm">
                <span className="inline-block text-xs rounded-full bg-[#F0F4EE] text-[#3B5B2A] px-2.5 py-1 capitalize">{label(detail.contact_type)}</span>
                <div className="space-y-2 text-muted-foreground">
                  <div className="flex items-center gap-2"><Phone className="h-4 w-4" /> {detail.mobile}</div>
                  {detail.email && <div className="flex items-center gap-2"><Mail className="h-4 w-4" /> {detail.email}</div>}
                  {detail.company && <div className="flex items-center gap-2"><Building2 className="h-4 w-4" /> {detail.company}</div>}
                  {detail.city && <div className="flex items-center gap-2"><MapPin className="h-4 w-4" /> {detail.city}, {detail.state}</div>}
                </div>
                <div className="rounded-lg border border-border p-3">
                  <div className="text-xs font-semibold mb-2">Orders ({detail.orders?.length || 0})</div>
                  {detail.orders?.length ? detail.orders.map((o) => (
                    <div key={o.id} className="flex justify-between py-1 text-xs"><span>{o.order_no}</span><span>₹{o.total}</span></div>
                  )) : <div className="text-xs text-muted-foreground">No orders</div>}
                </div>
                <div className="rounded-lg border border-border p-3">
                  <div className="text-xs font-semibold mb-2">Related Leads ({detail.leads?.length || 0})</div>
                  {detail.leads?.length ? detail.leads.map((l) => (
                    <div key={l.id} className="flex justify-between py-1 text-xs"><span>{l.title}</span><StatusBadge status={l.status} /></div>
                  )) : <div className="text-xs text-muted-foreground">No leads</div>}
                </div>
              </div>
            </>
          )}
        </SheetContent>
      </Sheet>
    </div>
  );
}
