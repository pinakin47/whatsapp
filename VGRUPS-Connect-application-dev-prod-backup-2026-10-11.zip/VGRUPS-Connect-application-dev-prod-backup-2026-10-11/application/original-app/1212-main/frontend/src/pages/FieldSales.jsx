import React, { useEffect, useState, useCallback } from "react";
import api, { apiError } from "../lib/api";
import { toast } from "sonner";
import { PageHeader } from "../components/common";
import { Card } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { Textarea } from "../components/ui/textarea";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "../components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogTrigger } from "../components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../components/ui/table";
import { Plus, Loader2, Trash2, Stethoscope, CalendarDays, CheckCircle2, IndianRupee, Target, Award } from "lucide-react";

const STATUS_COLOR = { planned: "bg-blue-100 text-blue-700 dark:bg-blue-500/15 dark:text-blue-300", visited: "bg-green-100 text-green-700 dark:bg-green-500/15 dark:text-green-300", skipped: "bg-red-100 text-red-700 dark:bg-red-500/15 dark:text-red-300" };
const empty = { doctor_name: "", clinic_name: "", specialty: "", mobile: "", city: "", address: "", planned_date: "", notes: "" };

export default function FieldSales() {
  const [visits, setVisits] = useState([]);
  const [stats, setStats] = useState({ planned_today: 0, visited_today: 0, total_visits: 0, order_value: 0 });
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState(empty);
  const [saving, setSaving] = useState(false);
  const [checkin, setCheckin] = useState(null);
  const [ci, setCi] = useState({ notes: "", outcome: "", order_value: "" });
  const [targets, setTargets] = useState([]);
  const [tMgr, setTMgr] = useState(false);
  const [mrs, setMrs] = useState([]);
  const [tOpen, setTOpen] = useState(false);
  const [tForm, setTForm] = useState({ mr_id: "", visit_target: 0, order_target: 0, incentive_pct: 0 });

  const today = new Date().toISOString().slice(0, 10);
  const load = useCallback(() => {
    api.get("/field/visits").then((r) => setVisits(r.data.items)).catch((e) => toast.error(apiError(e)));
    api.get("/field/stats").then((r) => setStats(r.data)).catch(() => {});
    api.get("/field/targets").then((r) => { setTargets(r.data.targets); setTMgr(r.data.is_manager); }).catch(() => {});
    api.get("/field/mrs").then((r) => setMrs(r.data.items || [])).catch(() => {});
  }, []);
  useEffect(() => { load(); }, [load]);

  const save = async () => {
    if (!form.doctor_name.trim()) return;
    setSaving(true);
    try { await api.post("/field/visits", { ...form, planned_date: form.planned_date || today }); toast.success("Visit planned"); setOpen(false); setForm(empty); load(); }
    catch (e) { toast.error(apiError(e)); } finally { setSaving(false); }
  };
  const del = async (id) => { try { await api.delete(`/field/visits/${id}`); load(); } catch (e) { toast.error(apiError(e)); } };
  const openCheckin = (v) => { setCheckin(v); setCi({ notes: v.notes || "", outcome: v.outcome || "", order_value: v.order_value || "" }); };
  const doCheckin = async () => {
    try {
      await api.patch(`/field/visits/${checkin.id}`, { status: "visited", notes: ci.notes, outcome: ci.outcome, order_value: Number(ci.order_value) || 0 });
      toast.success("Checked in"); setCheckin(null); load();
    } catch (e) { toast.error(apiError(e)); }
  };
  const skip = async (v) => { try { await api.patch(`/field/visits/${v.id}`, { status: "skipped" }); load(); } catch (e) { toast.error(apiError(e)); } };
  const saveTarget = async () => {
    try {
      await api.post("/field/targets", { mr_id: tForm.mr_id || undefined, visit_target: Number(tForm.visit_target) || 0, order_target: Number(tForm.order_target) || 0, incentive_pct: Number(tForm.incentive_pct) || 0 });
      toast.success("Target saved"); setTOpen(false); load();
    } catch (e) { toast.error(apiError(e)); }
  };

  const beat = visits.filter((v) => v.planned_date === today);

  const Stat = ({ icon: Icon, label, value, testId }) => (
    <Card className="p-4" data-testid={testId}><div className="flex items-center gap-3"><div className="h-10 w-10 rounded-lg bg-[#F0F4EE] dark:bg-[#1D2B1E] flex items-center justify-center"><Icon className="h-5 w-5 text-[#3B5B2A]" /></div><div><div className="text-2xl font-bold">{value}</div><div className="text-xs text-muted-foreground">{label}</div></div></div></Card>
  );
  const Bar = ({ done, target, color }) => { const pct = target > 0 ? Math.min(100, Math.round((done / target) * 100)) : 0; return (<div className="h-2.5 rounded-full bg-muted overflow-hidden"><div className={`h-full ${color || "bg-[#3B5B2A]"}`} style={{ width: pct + "%" }} /></div>); };
  const TargetCard = ({ t }) => (
    <Card className="p-4" data-testid={`target-card-${t.mr_id}`}>
      <div className="flex items-center justify-between">
        <div className="font-medium">{t.mr_name || "You"}</div>
        <div className="text-sm flex items-center gap-1"><Award className="h-4 w-4 text-[#D97706]" /> Incentive: <span className="font-semibold">₹{Number(t.incentive_earned || 0).toLocaleString("en-IN")}</span></div>
      </div>
      <div className="mt-3 space-y-3">
        <div><div className="flex justify-between text-xs mb-1"><span className="text-muted-foreground">Visits</span><span>{t.visits_done}/{t.visit_target || 0}</span></div><Bar done={t.visits_done} target={t.visit_target} /></div>
        <div><div className="flex justify-between text-xs mb-1"><span className="text-muted-foreground">Orders (₹)</span><span>{Number(t.orders_done || 0).toLocaleString("en-IN")}/{Number(t.order_target || 0).toLocaleString("en-IN")}</span></div><Bar done={t.orders_done} target={t.order_target} color="bg-[#D97706]" /></div>
      </div>
    </Card>
  );

  const Row = ({ v }) => (
    <TableRow data-testid={`visit-row-${v.id}`}>
      <TableCell><div className="font-medium">{v.doctor_name}</div><div className="text-xs text-muted-foreground">{v.clinic_name}{v.specialty ? ` · ${v.specialty}` : ""}</div></TableCell>
      <TableCell className="text-muted-foreground text-sm">{v.city || "—"}</TableCell>
      <TableCell className="text-muted-foreground text-sm">{v.planned_date}</TableCell>
      <TableCell><span className={`text-xs px-2 py-0.5 rounded-full font-medium capitalize ${STATUS_COLOR[v.status] || ""}`}>{v.status}</span></TableCell>
      <TableCell className="text-sm">{v.order_value ? `₹${Number(v.order_value).toLocaleString("en-IN")}` : "—"}</TableCell>
      <TableCell className="text-right">
        <div className="flex justify-end gap-1">
          {v.status === "planned" && <Button size="sm" className="bg-[#3B5B2A] hover:bg-[#2D4720]" onClick={() => openCheckin(v)} data-testid={`visit-checkin-${v.id}`}><CheckCircle2 className="h-3.5 w-3.5 mr-1" /> Check in</Button>}
          {v.status === "planned" && <Button size="sm" variant="outline" onClick={() => skip(v)} data-testid={`visit-skip-${v.id}`}>Skip</Button>}
          <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => del(v.id)} data-testid={`visit-delete-${v.id}`}><Trash2 className="h-4 w-4 text-destructive" /></Button>
        </div>
      </TableCell>
    </TableRow>
  );

  const VisitTable = ({ rows }) => (
    <Card className="overflow-hidden"><div className="overflow-x-auto"><Table>
      <TableHeader><TableRow><TableHead>Doctor / Clinic</TableHead><TableHead>City</TableHead><TableHead>Date</TableHead><TableHead>Status</TableHead><TableHead>Order</TableHead><TableHead className="text-right">Actions</TableHead></TableRow></TableHeader>
      <TableBody>{rows.map((v) => <Row key={v.id} v={v} />)}{rows.length === 0 && <TableRow><TableCell colSpan={6} className="text-center py-10 text-muted-foreground">No visits. Plan your first one.</TableCell></TableRow>}</TableBody>
    </Table></div></Card>
  );

  return (
    <div className="p-4 md:p-6 animate-fade-up">
      <PageHeader title="MR / Field Sales" subtitle="Daily beat plan, doctor &amp; clinic visits, targets and incentives" testId="field-sales-header"
        actions={
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild><Button className="bg-[#3B5B2A] hover:bg-[#2D4720]" data-testid="new-visit-button"><Plus className="h-4 w-4 mr-1" /> Plan Visit</Button></DialogTrigger>
            <DialogContent className="max-w-md">
              <DialogHeader><DialogTitle>Plan a visit</DialogTitle><DialogDescription>Add a doctor or clinic to your beat plan.</DialogDescription></DialogHeader>
              <div className="space-y-3">
                <div><Label>Doctor name *</Label><Input value={form.doctor_name} onChange={(e) => setForm({ ...form, doctor_name: e.target.value })} data-testid="visit-doctor-input" /></div>
                <div className="grid grid-cols-2 gap-3"><div><Label>Clinic / Hospital</Label><Input value={form.clinic_name} onChange={(e) => setForm({ ...form, clinic_name: e.target.value })} /></div><div><Label>Specialty</Label><Input value={form.specialty} onChange={(e) => setForm({ ...form, specialty: e.target.value })} /></div></div>
                <div className="grid grid-cols-2 gap-3"><div><Label>Mobile</Label><Input value={form.mobile} onChange={(e) => setForm({ ...form, mobile: e.target.value })} /></div><div><Label>City</Label><Input value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} /></div></div>
                <div><Label>Planned date</Label><Input type="date" value={form.planned_date || today} onChange={(e) => setForm({ ...form, planned_date: e.target.value })} data-testid="visit-date-input" /></div>
                <div><Label>Notes</Label><Textarea rows={2} value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} /></div>
              </div>
              <DialogFooter><Button disabled={saving || !form.doctor_name.trim()} onClick={save} className="bg-[#3B5B2A] hover:bg-[#2D4720]" data-testid="visit-save-button">{saving ? <Loader2 className="h-4 w-4 animate-spin" /> : "Save"}</Button></DialogFooter>
            </DialogContent>
          </Dialog>
        } />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-5">
        <Stat icon={CalendarDays} label="Planned today" value={stats.planned_today} testId="stat-planned" />
        <Stat icon={CheckCircle2} label="Visited today" value={stats.visited_today} testId="stat-visited" />
        <Stat icon={Stethoscope} label="Total visits" value={stats.total_visits} testId="stat-total" />
        <Stat icon={IndianRupee} label="Field orders (₹)" value={Number(stats.order_value || 0).toLocaleString("en-IN")} testId="stat-orders" />
      </div>

      <Tabs defaultValue="beat">
        <TabsList>
          <TabsTrigger value="beat" data-testid="field-tab-beat">Today's Beat Plan ({beat.length})</TabsTrigger>
          <TabsTrigger value="all" data-testid="field-tab-all">All Visits ({visits.length})</TabsTrigger>
          <TabsTrigger value="targets" data-testid="field-tab-targets">Targets &amp; Incentive</TabsTrigger>
        </TabsList>
        <TabsContent value="beat" className="mt-4"><VisitTable rows={beat} /></TabsContent>
        <TabsContent value="all" className="mt-4"><VisitTable rows={visits} /></TabsContent>
        <TabsContent value="targets" className="mt-4">
          {tMgr && (
            <div className="flex justify-end mb-3">
              <Dialog open={tOpen} onOpenChange={setTOpen}>
                <DialogTrigger asChild><Button variant="outline" data-testid="set-target-button"><Target className="h-4 w-4 mr-1.5" /> Set / Update target</Button></DialogTrigger>
                <DialogContent className="max-w-md">
                  <DialogHeader><DialogTitle>Monthly target</DialogTitle><DialogDescription>Set this month's visit &amp; order target and incentive %.</DialogDescription></DialogHeader>
                  <div className="space-y-3">
                    <div><Label>MR</Label>
                      <Select value={tForm.mr_id} onValueChange={(v) => setTForm({ ...tForm, mr_id: v })}>
                        <SelectTrigger data-testid="target-mr-select"><SelectValue placeholder="Select MR" /></SelectTrigger>
                        <SelectContent>{mrs.map((u) => <SelectItem key={u.id} value={u.id}>{u.name}</SelectItem>)}</SelectContent>
                      </Select>
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <div><Label>Visit target</Label><Input type="number" value={tForm.visit_target} onChange={(e) => setTForm({ ...tForm, visit_target: e.target.value })} data-testid="target-visits-input" /></div>
                      <div><Label>Order target (₹)</Label><Input type="number" value={tForm.order_target} onChange={(e) => setTForm({ ...tForm, order_target: e.target.value })} data-testid="target-orders-input" /></div>
                    </div>
                    <div><Label>Incentive %</Label><Input type="number" value={tForm.incentive_pct} onChange={(e) => setTForm({ ...tForm, incentive_pct: e.target.value })} data-testid="target-incentive-input" /></div>
                  </div>
                  <DialogFooter><Button disabled={!tForm.mr_id} onClick={saveTarget} className="bg-[#3B5B2A] hover:bg-[#2D4720]" data-testid="target-save-button">Save target</Button></DialogFooter>
                </DialogContent>
              </Dialog>
            </div>
          )}
          <div className="grid md:grid-cols-2 gap-3">
            {targets.map((t) => <TargetCard key={t.mr_id} t={t} />)}
            {targets.length === 0 && <Card className="p-8 text-center text-muted-foreground md:col-span-2">No targets for this month yet.</Card>}
          </div>
        </TabsContent>
      </Tabs>

      <Dialog open={!!checkin} onOpenChange={(v) => !v && setCheckin(null)}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>Check in — {checkin?.doctor_name}</DialogTitle><DialogDescription>Log the visit outcome and any order.</DialogDescription></DialogHeader>
          <div className="space-y-3">
            <div><Label>Outcome</Label><Input value={ci.outcome} onChange={(e) => setCi({ ...ci, outcome: e.target.value })} placeholder="e.g. Interested, samples given" data-testid="checkin-outcome" /></div>
            <div><Label>Order value (₹)</Label><Input type="number" value={ci.order_value} onChange={(e) => setCi({ ...ci, order_value: e.target.value })} data-testid="checkin-order-value" /></div>
            <div><Label>Notes</Label><Textarea rows={3} value={ci.notes} onChange={(e) => setCi({ ...ci, notes: e.target.value })} data-testid="checkin-notes" /></div>
          </div>
          <DialogFooter><Button onClick={doCheckin} className="bg-[#3B5B2A] hover:bg-[#2D4720]" data-testid="checkin-save">Save check-in</Button></DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
