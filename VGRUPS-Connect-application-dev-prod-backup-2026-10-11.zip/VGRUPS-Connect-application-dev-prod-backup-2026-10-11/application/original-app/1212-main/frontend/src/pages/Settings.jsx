import React, { useEffect, useState } from "react";
import api, { apiError } from "../lib/api";
import { toast } from "sonner";
import { useAuth } from "../context/AuthContext";
import { PageHeader, DemoBadge } from "../components/common";
import { Card } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../components/ui/select";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "../components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger } from "../components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../components/ui/table";
import { Avatar, AvatarFallback } from "../components/ui/avatar";
import { Plus, Loader2, ShieldCheck, Check, X } from "lucide-react";

const emptyUser = { name: "", email: "", password: "Welcome@123", role: "mr", phone: "" };

export default function Settings() {
  const { can } = useAuth();
  const [users, setUsers] = useState([]);
  const [roles, setRoles] = useState([]);
  const [modules, setModules] = useState([]);
  const [logs, setLogs] = useState([]);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState(emptyUser);
  const [saving, setSaving] = useState(false);

  const loadUsers = () => api.get("/users").then((r) => setUsers(r.data.items));
  useEffect(() => {
    loadUsers();
    api.get("/roles").then((r) => { setRoles(r.data.roles); setModules(r.data.modules); });
    if (can("settings", "view")) api.get("/audit-logs").then((r) => setLogs(r.data.items)).catch(() => {});
  }, []);

  const save = async () => {
    setSaving(true);
    try { await api.post("/users", form); toast.success("User created"); setOpen(false); setForm(emptyUser); loadUsers(); }
    catch (e) { toast.error(apiError(e)); } finally { setSaving(false); }
  };

  return (
    <div className="p-4 md:p-6 animate-fade-up">
      <PageHeader title="Settings" subtitle="Team, roles, permissions & audit" testId="settings-header" />
      <Tabs defaultValue="users">
        <TabsList>
          <TabsTrigger value="users" data-testid="settings-tab-users">Team</TabsTrigger>
          <TabsTrigger value="roles" data-testid="settings-tab-roles">Roles & Permissions</TabsTrigger>
          <TabsTrigger value="audit" data-testid="settings-tab-audit">Audit Log</TabsTrigger>
        </TabsList>

        <TabsContent value="users" className="mt-4">
          <div className="flex justify-end mb-3">
            <Dialog open={open} onOpenChange={setOpen}>
              <DialogTrigger asChild><Button data-testid="add-user-button" className="bg-[#3B5B2A] hover:bg-[#2D4720]"><Plus className="h-4 w-4 mr-1" /> New User</Button></DialogTrigger>
              <DialogContent>
                <DialogHeader><DialogTitle>Create User</DialogTitle></DialogHeader>
                <div className="space-y-3">
                  <div><Label>Name</Label><Input data-testid="user-name-input" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
                  <div><Label>Email</Label><Input data-testid="user-email-input" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></div>
                  <div><Label>Password</Label><Input value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} /></div>
                  <div><Label>Role</Label>
                    <Select value={form.role} onValueChange={(v) => setForm({ ...form, role: v })}>
                      <SelectTrigger data-testid="user-role-select"><SelectValue /></SelectTrigger>
                      <SelectContent>{roles.map((r) => <SelectItem key={r.key} value={r.key}>{r.label}</SelectItem>)}</SelectContent>
                    </Select>
                  </div>
                </div>
                <DialogFooter><Button data-testid="user-save-button" disabled={saving || !form.name || !form.email} onClick={save} className="bg-[#3B5B2A] hover:bg-[#2D4720]">{saving ? <Loader2 className="h-4 w-4 animate-spin" /> : "Create"}</Button></DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
          <Card className="overflow-hidden">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader><TableRow><TableHead>User</TableHead><TableHead>Role</TableHead><TableHead className="hidden sm:table-cell">Email</TableHead><TableHead>Status</TableHead></TableRow></TableHeader>
                <TableBody>
                  {users.map((u) => (
                    <TableRow key={u.id} data-testid={`user-row-${u.id}`}>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Avatar className="h-8 w-8"><AvatarFallback className="bg-[#6E8B5B] text-white text-xs">{(u.name || "?").slice(0, 2).toUpperCase()}</AvatarFallback></Avatar>
                          <span className="font-medium flex items-center gap-1">{u.name} {u.is_demo && <DemoBadge />}</span>
                        </div>
                      </TableCell>
                      <TableCell><span className="text-xs rounded-full bg-[#F0F4EE] text-[#3B5B2A] px-2 py-0.5">{u.role_label}</span></TableCell>
                      <TableCell className="hidden sm:table-cell text-muted-foreground text-sm">{u.email}</TableCell>
                      <TableCell>{u.active ? <span className="text-xs text-green-600">Active</span> : <span className="text-xs text-muted-foreground">Disabled</span>}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </Card>
        </TabsContent>

        <TabsContent value="roles" className="mt-4">
          <Card className="overflow-hidden">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader><TableRow><TableHead className="sticky left-0 bg-card">Module</TableHead>{roles.map((r) => <TableHead key={r.key} className="text-center text-xs">{r.label}</TableHead>)}</TableRow></TableHeader>
                <TableBody>
                  {modules.map((m) => (
                    <TableRow key={m}>
                      <TableCell className="font-medium capitalize sticky left-0 bg-card">{m.replace(/_/g, " ")}</TableCell>
                      {roles.map((r) => {
                        const has = (r.permissions[m] || []).length > 0;
                        return <TableCell key={r.key} className="text-center">{has ? <Check className="h-4 w-4 text-green-600 mx-auto" /> : <X className="h-4 w-4 text-muted-foreground/30 mx-auto" />}</TableCell>;
                      })}
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </Card>
        </TabsContent>

        <TabsContent value="audit" className="mt-4">
          <Card className="overflow-hidden">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader><TableRow><TableHead>User</TableHead><TableHead>Action</TableHead><TableHead>Module</TableHead><TableHead>Result</TableHead><TableHead className="hidden md:table-cell">Time</TableHead></TableRow></TableHeader>
                <TableBody>
                  {logs.map((l) => (
                    <TableRow key={l.id} data-testid={`audit-row-${l.id}`}>
                      <TableCell className="text-sm">{l.user_name || l.user_email || "—"}</TableCell>
                      <TableCell><span className="text-xs font-mono rounded bg-muted px-1.5 py-0.5">{l.action}</span></TableCell>
                      <TableCell className="text-sm capitalize">{l.module}</TableCell>
                      <TableCell><span className={`text-xs ${l.result === "success" ? "text-green-600" : "text-red-600"}`}>{l.result}</span></TableCell>
                      <TableCell className="hidden md:table-cell text-xs text-muted-foreground">{l.created_at ? new Date(l.created_at).toLocaleString() : ""}</TableCell>
                    </TableRow>
                  ))}
                  {logs.length === 0 && <TableRow><TableCell colSpan={5} className="text-center py-10 text-muted-foreground"><ShieldCheck className="h-6 w-6 mx-auto mb-2 opacity-40" />No audit records yet</TableCell></TableRow>}
                </TableBody>
              </Table>
            </div>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
