import React, { useEffect, useState, useCallback } from "react";
import api, { apiError } from "../lib/api";
import { toast } from "sonner";
import { PageHeader, DemoBadge } from "../components/common";
import { Card } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger } from "../components/ui/dialog";
import { Plus, Loader2, GripVertical } from "lucide-react";

const COLUMNS = [
  { key: "new", label: "New", color: "#2563EB" },
  { key: "contacted", label: "Contacted", color: "#6366F1" },
  { key: "qualified", label: "Qualified", color: "#0891B2" },
  { key: "interested", label: "Interested", color: "#14B8A6" },
  { key: "quotation", label: "Quotation", color: "#D97706" },
  { key: "negotiation", label: "Negotiation", color: "#EA580C" },
  { key: "won", label: "Won", color: "#16A34A" },
  { key: "lost", label: "Lost", color: "#DC2626" },
  { key: "follow_up", label: "Follow-up", color: "#9333EA" },
];
const SOURCES = ["whatsapp", "website", "google", "meta", "qr", "chrome_extension", "referral", "manual", "campaign", "api"];
const emptyLead = { title: "", contact_name: "", company: "", status: "new", source: "manual", value: 0, specialty: "" };

export default function Leads() {
  const [board, setBoard] = useState({});
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState(emptyLead);
  const [saving, setSaving] = useState(false);
  const [dragId, setDragId] = useState(null);

  const load = useCallback(() => { api.get("/leads").then((r) => setBoard(r.data.board)); }, []);
  useEffect(() => { load(); }, [load]);

  const save = async () => {
    setSaving(true);
    try {
      await api.post("/leads", { ...form, value: Number(form.value) || 0 });
      toast.success("Lead created"); setOpen(false); setForm(emptyLead); load();
    } catch (e) { toast.error(apiError(e)); } finally { setSaving(false); }
  };

  const onDrop = async (status) => {
    if (!dragId) return;
    // optimistic
    let moved = null;
    const next = {};
    for (const col of COLUMNS) {
      next[col.key] = (board[col.key] || []).filter((l) => {
        if (l.id === dragId) { moved = { ...l, status }; return false; }
        return true;
      });
    }
    if (moved) { next[status] = [moved, ...(next[status] || [])]; setBoard(next); }
    setDragId(null);
    try { await api.patch(`/leads/${dragId}/status`, { status }); }
    catch (e) { toast.error(apiError(e)); load(); }
  };

  const total = Object.values(board).reduce((a, c) => a + c.length, 0);

  return (
    <div className="p-4 md:p-6 animate-fade-up h-full flex flex-col">
      <PageHeader
        title="Leads" subtitle={`${total} leads · drag cards between stages`} testId="leads-header"
        actions={
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button data-testid="add-lead-button" className="bg-[#3B5B2A] hover:bg-[#2D4720]"><Plus className="h-4 w-4 mr-1" /> New Lead</Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader><DialogTitle>New Lead</DialogTitle></DialogHeader>
              <div className="grid grid-cols-2 gap-3">
                <div className="col-span-2"><Label>Title *</Label><Input data-testid="lead-title-input" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} /></div>
                <div><Label>Contact Name</Label><Input value={form.contact_name} onChange={(e) => setForm({ ...form, contact_name: e.target.value })} /></div>
                <div><Label>Company</Label><Input value={form.company} onChange={(e) => setForm({ ...form, company: e.target.value })} /></div>
                <div><Label>Value (₹)</Label><Input type="number" value={form.value} onChange={(e) => setForm({ ...form, value: e.target.value })} /></div>
                <div>
                  <Label>Source</Label>
                  <Select value={form.source} onValueChange={(v) => setForm({ ...form, source: v })}>
                    <SelectTrigger data-testid="lead-source-select"><SelectValue /></SelectTrigger>
                    <SelectContent>{SOURCES.map((s) => <SelectItem key={s} value={s}>{s.replace(/_/g, " ")}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
                <div className="col-span-2">
                  <Label>Stage</Label>
                  <Select value={form.status} onValueChange={(v) => setForm({ ...form, status: v })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>{COLUMNS.map((c) => <SelectItem key={c.key} value={c.key}>{c.label}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
              </div>
              <DialogFooter>
                <Button data-testid="lead-save-button" disabled={saving || !form.title} onClick={save} className="bg-[#3B5B2A] hover:bg-[#2D4720]">
                  {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : "Save Lead"}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        }
      />

      <div className="flex-1 overflow-x-auto pb-2">
        <div className="flex gap-3 min-w-max h-full">
          {COLUMNS.map((col) => (
            <div
              key={col.key}
              data-testid={`kanban-column-${col.key}`}
              onDragOver={(e) => e.preventDefault()}
              onDrop={() => onDrop(col.key)}
              className="w-72 shrink-0 flex flex-col rounded-xl bg-muted/40"
            >
              <div className="flex items-center justify-between px-3 py-2.5 border-b border-border">
                <div className="flex items-center gap-2 text-sm font-semibold">
                  <span className="h-2.5 w-2.5 rounded-full" style={{ background: col.color }} />
                  {col.label}
                </div>
                <span className="text-xs text-muted-foreground bg-background rounded-full px-2 py-0.5">{(board[col.key] || []).length}</span>
              </div>
              <div className="flex-1 overflow-y-auto p-2 space-y-2 min-h-24">
                {(board[col.key] || []).map((l) => (
                  <div
                    key={l.id}
                    draggable
                    onDragStart={() => setDragId(l.id)}
                    data-testid={`lead-card-${l.id}`}
                    className="group rounded-lg bg-card border border-border p-3 cursor-grab active:cursor-grabbing hover:shadow-md transition-shadow"
                  >
                    <div className="flex items-start gap-1.5">
                      <GripVertical className="h-4 w-4 text-muted-foreground/40 mt-0.5 shrink-0" />
                      <div className="min-w-0 flex-1">
                        <div className="text-sm font-medium truncate flex items-center gap-1">{l.title} {l.is_demo && <DemoBadge />}</div>
                        {l.company && <div className="text-xs text-muted-foreground truncate">{l.company}</div>}
                        <div className="flex items-center justify-between mt-2">
                          <span className="text-xs font-semibold text-[#3B5B2A] dark:text-[#8BAA78]">₹{Number(l.value).toLocaleString("en-IN")}</span>
                          <span className="text-[10px] rounded bg-muted px-1.5 py-0.5 capitalize">{l.source?.replace(/_/g, " ")}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
