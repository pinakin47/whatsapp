import { useEffect } from "react";
import "@/App.css";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { Toaster } from "sonner";
import { AuthProvider } from "@/context/AuthContext";
import { ThemeProvider } from "@/context/ThemeContext";
import ProtectedRoute from "@/components/ProtectedRoute";
import Layout from "@/components/Layout";
import Login from "@/pages/Login";
import Dashboard from "@/pages/Dashboard";
import Contacts from "@/pages/Contacts";
import Leads from "@/pages/Leads";
import Inbox from "@/pages/Inbox";
import WhatsAppTemplates from "@/pages/WhatsAppTemplates";
import WhatsAppHub from "@/pages/WhatsAppHub";
import Integrations from "@/pages/Integrations";
import Tasks from "@/pages/Tasks";
import Catalog from "@/pages/Catalog";
import Orders from "@/pages/Orders";
import CampaignsHub from "@/pages/CampaignsHub";
import Automations from "@/pages/Automations";
import ChatbotBuilder from "@/pages/ChatbotBuilder";
import Payments from "@/pages/Payments";
import Recruitment from "@/pages/Recruitment";
import IVRSetup from "@/pages/IVRSetup";
import Careers from "@/pages/Careers";
import Ads from "@/pages/Ads";
import ExtensionWidget from "@/pages/ExtensionWidget";
import FieldSales from "@/pages/FieldSales";
import Portal from "@/pages/Portal";
import Settings from "@/pages/Settings";
import ComingSoon from "@/pages/ComingSoon";

const soon = (title, phase, description) => <ComingSoon title={title} phase={phase} description={description} />;

function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <BrowserRouter>
          <Toaster position="top-right" richColors />
          <Routes>
            <Route path="/login" element={<Login />} />
            <Route path="/careers" element={<Careers />} />
            <Route path="/jobs" element={<Navigate to="/careers" replace />} />
            <Route element={<ProtectedRoute><Layout /></ProtectedRoute>}>
              <Route path="/dashboard" element={<Dashboard />} />
              <Route path="/inbox" element={<Inbox />} />
              <Route path="/crm" element={<Contacts />} />
              <Route path="/contacts" element={<Contacts />} />
              <Route path="/leads" element={<Leads />} />
              <Route path="/whatsapp" element={<WhatsAppHub />} />
              <Route path="/campaigns" element={<CampaignsHub />} />
              <Route path="/catalog" element={<Catalog />} />
              <Route path="/orders" element={<Orders />} />
              <Route path="/tasks" element={<Tasks />} />
              <Route path="/integrations" element={<Integrations />} />
              <Route path="/settings" element={<Settings />} />
              <Route path="/sales" element={soon("Sales Pipeline", "Phase 3", "Configurable multi-stage pipelines for Distributor, Medical Shop, Hospital & Doctor segments.")} />
              <Route path="/automation" element={<Automations />} />
              <Route path="/chatbot" element={<ChatbotBuilder />} />
              <Route path="/ivr" element={<IVRSetup />} />
              <Route path="/recruitment" element={<Recruitment />} />
              <Route path="/payments" element={<Payments />} />
              <Route path="/field-sales" element={<FieldSales />} />
              <Route path="/portal" element={<Portal />} />
              <Route path="/extension" element={<ExtensionWidget />} />
              <Route path="/ads" element={<Ads />} />
              <Route path="/reports" element={soon("Reports", "Phase 9", "CRM, WhatsApp, sales and campaign reports with CSV / Excel / PDF export.")} />
            </Route>
            <Route path="*" element={<Navigate to="/dashboard" replace />} />
          </Routes>
        </BrowserRouter>
      </AuthProvider>
    </ThemeProvider>
  );
}

export default App;
