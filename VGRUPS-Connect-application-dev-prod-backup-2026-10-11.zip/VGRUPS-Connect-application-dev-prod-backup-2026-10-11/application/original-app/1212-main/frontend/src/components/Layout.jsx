import React, { useEffect, useState } from "react";
import { NavLink, useNavigate, Outlet, useLocation } from "react-router-dom";
import {
  LayoutDashboard, MessageSquare, Users, Kanban, Contact, TrendingUp, Send,
  Megaphone, Workflow, Bot, Package, ShoppingCart, CreditCard, CheckSquare,
  UserCheck, Globe, Target, Layers, BarChart3, Settings, Menu, Search, Bell,
  Sun, Moon, LogOut, ChevronLeft, Home, Activity, PhoneCall, Briefcase, Store,
} from "lucide-react";
import { useAuth } from "../context/AuthContext";
import { useTheme } from "../context/ThemeContext";
import api from "../lib/api";
import GlobalSearch from "./GlobalSearch";
import { Avatar, AvatarFallback } from "./ui/avatar";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator, DropdownMenuLabel,
} from "./ui/dropdown-menu";

const NAV = [
  { name: "Dashboard", icon: LayoutDashboard, path: "/dashboard" },
  { name: "Inbox", icon: MessageSquare, path: "/inbox" },
  { name: "CRM", icon: Users, path: "/crm" },
  { name: "Leads", icon: Kanban, path: "/leads" },
  { name: "Contacts", icon: Contact, path: "/contacts" },
  { name: "Sales", icon: TrendingUp, path: "/sales" },
  { name: "WhatsApp", icon: Send, path: "/whatsapp" },
  { name: "Campaigns", icon: Megaphone, path: "/campaigns" },
  { name: "Automation", icon: Workflow, path: "/automation" },
  { name: "Chatbot", icon: Bot, path: "/chatbot" },
  { name: "IVR", icon: PhoneCall, path: "/ivr" },
  { name: "Catalog", icon: Package, path: "/catalog" },
  { name: "Orders", icon: ShoppingCart, path: "/orders" },
  { name: "Payments", icon: CreditCard, path: "/payments" },
  { name: "Tasks", icon: CheckSquare, path: "/tasks" },
  { name: "Recruitment", icon: Briefcase, path: "/recruitment" },
  { name: "MR / Field Sales", icon: UserCheck, path: "/field-sales" },
  { name: "Distributor Portal", icon: Store, path: "/portal" },
  { name: "Chrome Extension", icon: Globe, path: "/extension" },
  { name: "Ads", icon: Target, path: "/ads" },
  { name: "Integrations", icon: Layers, path: "/integrations" },
  { name: "Reports", icon: BarChart3, path: "/reports" },
  { name: "Settings", icon: Settings, path: "/settings" },
];

const MOBILE_NAV = [
  { name: "Home", icon: Home, path: "/dashboard" },
  { name: "Inbox", icon: MessageSquare, path: "/inbox" },
  { name: "Leads", icon: Kanban, path: "/leads" },
  { name: "Tasks", icon: CheckSquare, path: "/tasks" },
];

function SidebarContent({ collapsed, onNav }) {
  return (
    <nav className="flex-1 overflow-y-auto py-3 px-2 space-y-0.5">
      {NAV.map((item) => (
        <NavLink
          key={item.path}
          to={item.path}
          onClick={onNav}
          data-testid={`sidebar-nav-item-${item.name.toLowerCase().replace(/[^a-z]/g, "-").replace(/-+/g, "-")}`}
          className={({ isActive }) =>
            `flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm transition-colors ${
              isActive
                ? "bg-[#3B5B2A] text-white font-semibold"
                : "text-[#C3D4B8] hover:bg-white/10 hover:text-white"
            } ${collapsed ? "justify-center" : ""}`
          }
          title={item.name}
        >
          <item.icon className="h-[18px] w-[18px] shrink-0" />
          {!collapsed && <span className="truncate">{item.name}</span>}
        </NavLink>
      ))}
    </nav>
  );
}

export default function Layout() {
  const { user, logout } = useAuth();
  const { theme, toggle } = useTheme();
  const navigate = useNavigate();
  const location = useLocation();
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [waConnected, setWaConnected] = useState(null);

  useEffect(() => {
    let active = true;
    const poll = async () => {
      try {
        const { data } = await api.get("/wa/sessions");
        if (active) setWaConnected(!!data?.connected);
      } catch {
        if (active) setWaConnected(false);
      }
    };
    poll();
    const id = setInterval(poll, 10000);
    return () => { active = false; clearInterval(id); };
  }, []);

  useEffect(() => {
    const handler = (e) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        setSearchOpen(true);
      }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, []);

  useEffect(() => { setMobileOpen(false); }, [location.pathname]);

  const initials = (user?.name || "VG").split(" ").map((w) => w[0]).join("").slice(0, 2).toUpperCase();

  return (
    <div className="flex h-screen overflow-hidden bg-background">
      {/* Desktop sidebar */}
      <aside
        className={`hidden md:flex flex-col bg-[#122013] transition-all duration-300 ${collapsed ? "w-20" : "w-64"}`}
      >
        <div className="flex items-center gap-2.5 h-16 px-4 border-b border-white/10">
          <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-[#3B5B2A] text-white font-bold font-heading">V</div>
          {!collapsed && (
            <div className="min-w-0">
              <div className="text-sm font-bold text-white font-heading leading-tight truncate">VGRUPS HEALTHCARE</div>
              <div className="text-[10px] text-[#8BAA78] tracking-wide truncate">CONNECT Platform</div>
            </div>
          )}
        </div>
        <SidebarContent collapsed={collapsed} />
        <button
          data-testid="sidebar-collapse-btn"
          onClick={() => setCollapsed((c) => !c)}
          className="flex items-center justify-center gap-2 h-11 border-t border-white/10 text-[#8BAA78] hover:text-white text-xs"
        >
          <ChevronLeft className={`h-4 w-4 transition-transform ${collapsed ? "rotate-180" : ""}`} />
          {!collapsed && "Collapse"}
        </button>
      </aside>

      {/* Mobile drawer */}
      {mobileOpen && (
        <div className="fixed inset-0 z-50 md:hidden">
          <div className="absolute inset-0 bg-black/50" onClick={() => setMobileOpen(false)} />
          <aside className="absolute left-0 top-0 h-full w-64 flex flex-col bg-[#122013] animate-fade-up">
            <div className="flex items-center gap-2.5 h-16 px-4 border-b border-white/10">
              <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-[#3B5B2A] text-white font-bold">V</div>
              <div className="text-sm font-bold text-white font-heading">VGRUPS HEALTHCARE</div>
            </div>
            <SidebarContent collapsed={false} onNav={() => setMobileOpen(false)} />
          </aside>
        </div>
      )}

      {/* Main */}
      <div className="flex flex-1 flex-col overflow-hidden">
        <header className="flex items-center justify-between gap-3 h-16 px-4 md:px-6 border-b border-border bg-background/95 backdrop-blur-md sticky top-0 z-40">
          <div className="flex items-center gap-2">
            <button data-testid="mobile-menu-btn" className="md:hidden p-2 -ml-2 rounded-lg hover:bg-muted" onClick={() => setMobileOpen(true)}>
              <Menu className="h-5 w-5" />
            </button>
            <button
              data-testid="global-search-trigger"
              onClick={() => setSearchOpen(true)}
              className="flex items-center gap-2 rounded-lg border border-border bg-muted/50 px-3 py-2 text-sm text-muted-foreground hover:bg-muted transition-colors w-40 sm:w-72"
            >
              <Search className="h-4 w-4" />
              <span className="hidden sm:inline">Search…</span>
              <kbd className="ml-auto hidden sm:inline text-[10px] rounded border border-border bg-background px-1.5 py-0.5">⌘K</kbd>
            </button>
          </div>
          <div className="flex items-center gap-1.5">
            <div
              data-testid="wa-status-pill"
              className={`hidden sm:flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs ${
                waConnected ? "bg-[#3B5B2A]/10 text-[#3B5B2A] dark:text-[#8BAA78]" : "bg-muted text-muted-foreground"
              }`}
            >
              <Activity className={`h-3.5 w-3.5 ${waConnected ? "text-[#3B5B2A] dark:text-[#8BAA78]" : "text-[#D97706]"}`} />
              WhatsApp: {waConnected === null ? "…" : waConnected ? "Connected" : "Not Connected"}
            </div>
            <button data-testid="theme-toggle-button" onClick={toggle} className="p-2 rounded-lg hover:bg-muted">
              {theme === "dark" ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
            </button>
            <button data-testid="notification-bell" className="p-2 rounded-lg hover:bg-muted relative">
              <Bell className="h-5 w-5" />
              <span className="absolute top-1.5 right-1.5 h-2 w-2 rounded-full bg-[#DC2626]" />
            </button>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button data-testid="user-menu-trigger" className="flex items-center gap-2 rounded-lg p-1 hover:bg-muted">
                  <Avatar className="h-8 w-8">
                    <AvatarFallback className="bg-[#3B5B2A] text-white text-xs">{initials}</AvatarFallback>
                  </Avatar>
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <DropdownMenuLabel>
                  <div className="font-medium">{user?.name}</div>
                  <div className="text-xs text-muted-foreground font-normal">{user?.email}</div>
                  <div className="text-[11px] mt-1 inline-block rounded bg-[#F0F4EE] text-[#3B5B2A] px-1.5 py-0.5">{user?.role_label}</div>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => navigate("/settings")} data-testid="menu-settings">Settings</DropdownMenuItem>
                <DropdownMenuItem data-testid="menu-logout" onClick={async () => { await logout(); navigate("/login"); }}>
                  <LogOut className="h-4 w-4 mr-2" /> Log out
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </header>

        <main className="flex-1 overflow-y-auto pb-20 md:pb-0">
          <Outlet />
        </main>

        {/* Mobile bottom nav */}
        <nav className="md:hidden fixed bottom-0 left-0 right-0 z-40 flex items-center justify-around h-16 border-t border-border bg-background/95 backdrop-blur-md">
          {MOBILE_NAV.map((item) => (
            <NavLink
              key={item.path}
              to={item.path}
              data-testid={`mobile-nav-${item.name.toLowerCase()}`}
              className={({ isActive }) => `flex flex-col items-center gap-0.5 text-[11px] ${isActive ? "text-[#3B5B2A] font-semibold" : "text-muted-foreground"}`}
            >
              <item.icon className="h-5 w-5" />
              {item.name}
            </NavLink>
          ))}
          <button onClick={() => setMobileOpen(true)} data-testid="mobile-nav-more" className="flex flex-col items-center gap-0.5 text-[11px] text-muted-foreground">
            <Menu className="h-5 w-5" /> More
          </button>
        </nav>
      </div>

      <GlobalSearch open={searchOpen} setOpen={setSearchOpen} />
    </div>
  );
}
