// Run after a frozen Yarn install so this checks the installed dependency graph,
// not only manifest ranges. Legacy minimatch requires a callable CJS expansion API.
const assert = require("node:assert/strict");
const { createRequire } = require("node:module");

const majors = new Set();
for (const issuer of ["minimatch", "filelist"]) {
  const from = createRequire(require.resolve(`${issuer}/package.json`));
  const minimatch = from("minimatch");
  const minimatchPackage = from("minimatch/package.json");
  const fromMinimatch = createRequire(from.resolve("minimatch/package.json"));
  const expansion = fromMinimatch("brace-expansion");
  assert.equal(typeof expansion, "function",
    `${issuer}'s minimatch ${minimatchPackage.version} requires callable brace-expansion`);
  assert.equal(fromMinimatch("brace-expansion/package.json").version, "2.1.7");
  assert.equal(minimatch("src/a.jsx", "src/*.{js,jsx}"), true);
  assert.equal(minimatch("src/a.css", "src/*.{js,jsx}"), false);
  assert.equal(minimatch("file2.txt", "file{1..3}.txt"), true);
  assert.equal(minimatch("src/b.js", "{src,lib}/{a,b}.{js,ts}"), true);
  assert.deepEqual(new minimatch.Minimatch("src/*.{js,jsx}").braceExpand(),
    ["src/*.js", "src/*.jsx"]);
  majors.add(Number(minimatchPackage.version.split(".")[0]));
  console.log(`${issuer}: minimatch ${minimatchPackage.version}, callable patched expansion OK`);
}
assert.deepEqual([...majors].sort(), [3, 5], "Exercise both legacy minimatch major versions");
const micromatch = require("micromatch");
assert.equal(micromatch.isMatch("src/a.tsx", "src/**/*.{js,jsx,ts,tsx}"), true);
assert.deepEqual(micromatch.braceExpand("src/{a,b}.tsx"), ["src/a.tsx", "src/b.tsx"]);
console.log("micromatch: bounded brace adapter OK");
