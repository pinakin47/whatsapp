"""Small report exports use the same spreadsheet-safe encoding as campaigns."""
from fastapi.responses import Response
from routes_campaign_reports import csv_line


def csv_response(filename, headers, rows):
    return Response(csv_line(headers) + "".join(csv_line(row) for row in rows),
                    media_type="text/csv",
                    headers={"Content-Disposition": f'attachment; filename="{filename}.csv"'})
