"""Receipt aggregation in PostgreSQL; only the selected page leaves the server.

All counts and page rows use a single statement snapshot. CSV uses the same
selection in a transaction-backed cursor, without a history-sized Python list.
"""
import json
from whatsapp_routing import report_sender_phones, report_sender_sql

SUMMARY_KEYS = ("total", "sent", "delivered", "read", "failed", "skipped", "uncertain", "pending")


def receipts_cte(wanted):
    # A gateway echo and an older engine copy may share a provider message ID.
    # Positive provider receipts must not be downgraded by a newer "sent" copy.
    # This reconciles evidence for the SAME part, never across different parts.
    return f"""
    receipts AS MATERIALIZED (
        SELECT DISTINCT ON (m.document->>'wamid')
            m.document->>'wamid' AS wamid, m.document->>'status' AS receipt
        FROM app_documents m
        JOIN ({wanted}) w ON w.wamid = m.document->>'wamid'
        WHERE m.collection_name = 'messages'
            AND m.document->>'is_demo' IS DISTINCT FROM 'true'
        ORDER BY m.document->>'wamid',
            CASE m.document->>'status'
                WHEN 'read' THEN 6 WHEN 'played' THEN 6
                WHEN 'delivered' THEN 5
                WHEN 'failed' THEN 4 WHEN 'error' THEN 4
                WHEN 'sent' THEN 3 ELSE 0 END DESC,
            m.document->>'created_at' DESC NULLS LAST, m.document_id DESC
    ),
    """


def report_query(drip=False):
    collection, field = ("drip_enrollments", "drip_id") if drip else ("campaign_recipients", "campaign_id")
    if drip:
        parts = """
        drip_messages AS MATERIALIZED (
            SELECT m.document_id, m.document,
                NULLIF(m.document->>'contact_id', '') AS contact_id,
                regexp_replace(COALESCE(c.document->>'phone', ''), '\\D', '', 'g') AS phone
            FROM app_documents m
            LEFT JOIN app_documents c ON c.collection_name = 'conversations'
                AND c.document->>'id' = m.document->>'conversation_id'
                AND NULLIF(m.document->>'contact_id', '') IS NULL
            WHERE m.collection_name = 'messages' AND m.document->>'drip_id' = $1
                AND m.document->>'is_demo' IS DISTINCT FROM 'true'
        ),
        linked AS MATERIALIZED (
            SELECT r.document_id AS recipient_id, m.document_id AS part_order,
                m.document->>'wamid' AS wamid,
                CASE WHEN NULLIF(m.document->>'wamid', '') IS NULL THEN 'unknown'
                     ELSE COALESCE(m.document->>'status', 'unknown') END AS receipt
            FROM records r JOIN drip_messages m
                ON NULLIF(r.document->>'contact_id', '') = m.contact_id
            UNION ALL
            SELECT r.document_id, m.document_id, m.document->>'wamid',
                CASE WHEN NULLIF(m.document->>'wamid', '') IS NULL THEN 'unknown'
                     ELSE COALESCE(m.document->>'status', 'unknown') END
            FROM records r JOIN drip_messages m ON m.contact_id IS NULL
                AND m.phone <> '' AND m.phone =
                    regexp_replace(COALESCE(r.document->>'phone', ''), '\\D', '', 'g')
        ),
        """ + receipts_cte("SELECT DISTINCT NULLIF(document->>'wamid', '') AS wamid FROM drip_messages") + """
        parts AS MATERIALIZED (
            SELECT DISTINCT ON (p.recipient_id, COALESCE(NULLIF(p.wamid, ''), p.part_order))
                p.recipient_id, p.part_order, p.wamid, COALESCE(m.receipt, 'unknown') AS receipt
            FROM linked p LEFT JOIN receipts m ON m.wamid = NULLIF(p.wamid, '')
            ORDER BY p.recipient_id, COALESCE(NULLIF(p.wamid, ''), p.part_order), p.part_order
        ),
        """
        state = """CASE
            WHEN r.document->>'send_status' IN ('sending', 'uncertain')
                OR r.document->>'status' IN ('sending', 'uncertain') THEN 'uncertain'
            WHEN COALESCE(s.message_count, 0) > 0 THEN 'sent'
            WHEN r.document->>'status' = 'active' THEN 'pending'
            WHEN r.document->>'status' = 'stopped' THEN 'skipped'
            ELSE COALESCE(r.document->>'status', 'pending') END"""
    else:
        parts = """
        wanted AS MATERIALIZED (
            SELECT r.document_id AS recipient_id, w.wamid, w.ordinality AS part_order
            FROM records r CROSS JOIN LATERAL jsonb_array_elements_text(
                CASE WHEN jsonb_typeof(r.document->'part_wamids') = 'array'
                          AND jsonb_array_length(r.document->'part_wamids') > 0
                     THEN r.document->'part_wamids'
                     WHEN NULLIF(r.document->>'wamid', '') IS NOT NULL
                     THEN jsonb_build_array(r.document->>'wamid')
                     ELSE '[]'::jsonb END
            ) WITH ORDINALITY w(wamid, ordinality)
        ),
        """ + receipts_cte("SELECT DISTINCT wamid FROM wanted") + """
        parts AS MATERIALIZED (
            SELECT w.*, COALESCE(m.receipt, 'unknown') AS receipt
            FROM wanted w LEFT JOIN receipts m USING (wamid)
        ),
        """
        state = "COALESCE(r.document->>'status', 'pending')"
    return f"""
    WITH records AS MATERIALIZED (
        SELECT document_id, document FROM app_documents
        WHERE collection_name = '{collection}' AND document->>'{field}' = $1
    ),
    {parts}
    sender_parts AS (
        SELECT x.recipient_id, x.part_order,
            jsonb_agg(DISTINCT COALESCE(NULLIF(m.document->>'session_id', ''),
                c.document->>'session_id')) AS sessions
        FROM parts x LEFT JOIN app_documents m
            ON m.collection_name = 'messages' AND m.document->>'wamid' = x.wamid
            AND m.document->>'is_demo' IS DISTINCT FROM 'true'
            AND m.document->>'direction' IS DISTINCT FROM 'inbound'
        LEFT JOIN app_documents c ON c.collection_name = 'conversations'
            AND c.document->>'id' = m.document->>'conversation_id'
            AND c.document->>'is_demo' IS DISTINCT FROM 'true'
            AND NULLIF(m.document->>'session_id', '') IS NULL
        GROUP BY x.recipient_id, x.part_order
    ),
    sender_stats AS (
        SELECT recipient_id, jsonb_agg(sessions ORDER BY part_order) AS sender_evidence
        FROM sender_parts GROUP BY recipient_id
    ),
    stats AS (
        SELECT recipient_id, count(*) AS message_count,
            bool_or(receipt IN ('failed', 'error')) AS failed,
            bool_and(receipt IN ('read', 'played')) AS all_read,
            bool_and(receipt IN ('delivered', 'read', 'played')) AS all_delivered
        FROM parts GROUP BY recipient_id
    ),
    outcomes AS (
        SELECT r.*, {state} AS status, COALESCE(s.message_count, 0) AS message_count,
            s.failed, s.all_read, s.all_delivered, a.sender_evidence
        FROM records r LEFT JOIN stats s ON s.recipient_id = r.document_id
        LEFT JOIN sender_stats a ON a.recipient_id = r.document_id
    ),
    rows AS MATERIALIZED (
        SELECT *, CASE WHEN status <> 'sent' THEN status
            WHEN failed THEN 'failed'
            WHEN message_count > 0 AND all_read THEN 'read'
            WHEN message_count > 0 AND all_delivered THEN 'delivered'
            ELSE 'sent' END AS delivery
        FROM outcomes
    ),
    attributed AS MATERIALIZED (
        SELECT p.*, {report_sender_sql()} AS sender_number FROM rows p
    ),
    selected AS MATERIALIZED (
        SELECT * FROM attributed
        WHERE ($2::text = '' OR strpos(lower(
            COALESCE(document->>'name', '') || ' ' ||
            COALESCE(document->>'mobile', document->>'phone', '')
        ), lower($2)) > 0)
        AND ($3::text = '' OR delivery = $3
            OR ($3 = 'uncertain' AND status IN ('sending', 'uncertain')))
        AND ($4::text = '' OR $4 = ANY(string_to_array(sender_number, ', ')))
    )
    """


SUMMARY_SQL = """
SELECT jsonb_build_object(
    'total', count(*),
    'sent', count(*) FILTER (WHERE status = 'sent'),
    'delivered', count(*) FILTER (WHERE delivery IN ('delivered', 'read')),
    'read', count(*) FILTER (WHERE delivery = 'read'),
    'failed', count(*) FILTER (WHERE delivery = 'failed'),
    'skipped', count(*) FILTER (WHERE status = 'skipped'),
    'uncertain', count(*) FILTER (WHERE status IN ('sending', 'uncertain')),
    'pending', count(*) FILTER (WHERE status = 'pending')
) FROM rows
"""


def row_sql(include_parts=True):
    parts = "COALESCE(d.part_deliveries, '[]'::jsonb)" if include_parts else "'[]'::jsonb"
    return f"""jsonb_build_object(
        'id', p.document_id, 'name', document->>'name',
        'mobile', COALESCE(document->>'mobile', document->>'phone'),
        'status', status, 'delivery', delivery,
        'replied', COALESCE(document->'replied', 'false'::jsonb),
        'sent_at', document->>'sent_at',
        'error', COALESCE(NULLIF(document->>'error', ''), document->>'stop_reason'),
        'message_count', message_count, 'part_deliveries', {parts},
        'sender_number', sender_number)"""


async def fetch_report(database, cid, drip, page, page_size, search, delivery, sender=""):
    pool = await database.connect()
    phones = await report_sender_phones(database)
    sql = report_query(drip) + f"""
    , page AS (
        SELECT * FROM selected ORDER BY document_id LIMIT $6 OFFSET $7
    ), page_parts AS (
        SELECT recipient_id, jsonb_agg(jsonb_build_object(
            'wamid', wamid, 'status', receipt) ORDER BY part_order) AS part_deliveries
        FROM parts JOIN page p ON p.document_id = parts.recipient_id
        GROUP BY recipient_id
    )
    SELECT ({SUMMARY_SQL}) AS summary,
        COALESCE((SELECT jsonb_agg(number ORDER BY number) FROM (
            SELECT DISTINCT unnest(string_to_array(sender_number, ', ')) AS number
            FROM attributed
        ) numbers), '[]'::jsonb) AS sender_numbers,
        (SELECT count(*) FROM selected) AS filtered_total,
        COALESCE((SELECT jsonb_agg({row_sql()} ORDER BY p.document_id)
            FROM page p LEFT JOIN page_parts d ON d.recipient_id = p.document_id),
            '[]'::jsonb) AS recipients
    """
    result = await pool.fetchrow(sql, cid, search, delivery, sender, json.dumps(phones),
                                page_size, (page - 1) * page_size)
    return {"summary": json.loads(result["summary"]),
            "sender_numbers": json.loads(result["sender_numbers"]),
            "recipients": json.loads(result["recipients"]),
            "pagination": {"page": page, "page_size": page_size,
                           "total": result["filtered_total"],
                           "pages": (result["filtered_total"] + page_size - 1) // page_size}}


async def export_rows(database, cid, drip, search, delivery, sender=""):
    pool = await database.connect()
    phones = await report_sender_phones(database)
    sql = report_query(drip) + f"SELECT {row_sql(False)} AS row FROM selected p ORDER BY document_id"
    async with pool.acquire() as conn:
        async with conn.transaction(isolation="repeatable_read", readonly=True):
            async for result in conn.cursor(sql, cid, search, delivery, sender, json.dumps(phones), prefetch=500):
                yield json.loads(result["row"])