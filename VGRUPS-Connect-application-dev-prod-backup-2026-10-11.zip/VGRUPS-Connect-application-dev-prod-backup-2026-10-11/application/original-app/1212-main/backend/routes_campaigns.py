import asyncio
import logging
import random
import re
from datetime import datetime, timezone, timedelta
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Response
from pydantic import BaseModel, Field

from db import db, new_id, now_iso, utcnow, log_audit
from auth import get_current_user, require_perm, permissions_for, refresh_role_definitions
from campaign_media import resolve_attachments, signed_url
from campaign_safety import campaign_lock
from routes_campaign_reports import report_csv
import wa_client
import wa_usage
from whatsapp_routing import sender as resolve_sender

logger = logging.getLogger("vgrups.campaigns")
router = APIRouter(prefix="/api", tags=["campaigns"])

BATCH_PER_TICK = 5
TICK_SECONDS = 6


def _norm(s: str) -> str:
    return re.sub(r"\D", "", s or "")


def render_message(text: str, ctx: dict) -> str:
    """Fill {name}/{company}/{city}/{product}/{order_id}/{1}.. per contact."""
    def rep(m):
        key = m.group(1).strip().lower()
        val = ctx.get(key)
        return str(val) if val not in (None, "") else m.group(0)
    return re.sub(r"\{([^}]+)\}", rep, text or "")


class Audience(BaseModel):
    type: str = Field(default="all", pattern=r"^(all|filter|group)$")
    group_id: Optional[str] = None
    contact_type: Optional[str] = None
    city: Optional[str] = None
    state: Optional[str] = None
    tag: Optional[str] = None
    lead_status: Optional[str] = None


class CampaignIn(BaseModel):
    name: str = Field(min_length=1, max_length=200)
    message: str = Field(min_length=1, max_length=10000)
    attachments: list[str] = Field(default_factory=list, max_length=5)
    template_name: Optional[str] = None
    variables: dict = {}
    audience: Audience = Audience()
    scheduled_at: Optional[str] = None  # ISO; if set and future -> scheduled
    send_now: bool = False
    message_gap_seconds: int = Field(default=5, ge=1, le=300)
    sender_session_id: Optional[str] = None


def _empty_stats(total=0):
    return {"total": total, "sent": 0, "delivered": 0, "read": 0,
            "failed": 0, "skipped": 0, "replies": 0, "uncertain": 0}


async def _resolve_contacts(aud: dict) -> list[dict]:
    q: dict = {"deleted": {"$ne": True}, "opted_out": {"$ne": True}, "is_demo": {"$ne": True}}
    if aud.get("type") == "group":
        group = await db.campaign_groups.find_one({"id": aud.get("group_id"), "deleted": {"$ne": True}})
        if not group:
            raise HTTPException(422, "Choose an existing contact group.")
        q["id"] = {"$in": group["contact_ids"]}
    if aud.get("type") == "filter":
        if aud.get("contact_type"):
            q["contact_type"] = aud["contact_type"]
        if aud.get("city"):
            q["city"] = aud["city"]
        if aud.get("state"):
            q["state"] = aud["state"]
        if aud.get("tag"):
            q["tags"] = aud["tag"]
    contacts = await db.contacts.find(q, {"_id": 0, "id": 1, "name": 1, "mobile": 1, "company": 1, "city": 1}).to_list(5000)
    return [c for c in contacts if re.fullmatch(r"\+?[1-9][0-9]{7,14}", re.sub(r"[\s().-]", "", c.get("mobile") or ""))]


async def _materialize(campaign: dict):
    contacts = await _resolve_contacts(campaign.get("audience", {}))
    recips = []
    for c in contacts:
        recips.append({
            "id": new_id(), "campaign_id": campaign["id"], "contact_id": c["id"],
            "name": c.get("name"), "company": c.get("company"), "city": c.get("city"),
            "phone": _norm(c.get("mobile")), "mobile": c.get("mobile"),
            "status": "pending", "wamid": None, "replied": False, "error": None,
            "created_at": now_iso(),
        })
    if recips:
        await db.campaign_recipients.insert_many(recips)
    await db.campaigns.update_one({"id": campaign["id"]},
                                  {"$set": {"stats.total": len(recips), "updated_at": now_iso()}})
    return len(recips)


async def _upsert_conversation(phone: str, name: str, session_id=None):
    conv = await db.conversations.find_one({"phone": phone, "session_id": session_id, "is_demo": {"$ne": True}, "deleted": {"$ne": True}})
    if not conv:
        conv = {"id": new_id(), "phone": phone, "name": name, "contact_id": None,
                "contact_type": "lead", "assigned_to": None, "unread": 0, "starred": False,
                "archived": False, "status": "open", "last_message": "", "last_message_at": now_iso(),
                "is_demo": False, "session_id": session_id, "created_at": now_iso()}
        await db.conversations.insert_one(conv)
    return conv


# ---------------- Engine ----------------
async def _process_campaign(campaign: dict):
    try:
        async with campaign_lock(campaign["id"]):
            current = await db.campaigns.find_one({"id": campaign["id"]})
            if current and current.get("status") == "running":
                await _process_campaign_unlocked(current)
    except HTTPException as exc:
        if exc.status_code != 409:
            raise


async def _process_campaign_unlocked(campaign: dict):
    cid = campaign["id"]
    if campaign.get("is_demo") or campaign.get("deleted"):
        return
    if campaign.get("next_send_at") and campaign["next_send_at"] > now_iso():
        return
    owner = await db.users.find_one({"id": campaign.get("approved_by") or campaign.get("created_by")})
    if not owner or owner.get("deleted") or not owner.get("active", True) or "send" not in permissions_for(owner["role"]).get("campaigns", []):
        await db.campaigns.update_one({"id": cid}, {"$set": {"status": "paused", "last_error": "Campaign sender no longer has permission. An authorized sender must resume."}})
        return
    if not await wa_client.wa_connected():
        return  # stay running; resume when a number connects
    sess = await wa_usage.connected_session(campaign.get("sender_session_id"), database=db)
    if not sess:
        await db.campaigns.update_one({"id": cid}, {"$set": {"last_error": "Assigned WhatsApp sender is offline or unlinked; no fallback number used."}})
        return
    if not campaign.get("sender_session_id"):
        await db.campaigns.update_one({"id": cid}, {"$set": {"sender_session_id": sess["id"]}})
        campaign["sender_session_id"] = sess["id"]
    phone_num = sess.get("phone")
    limit = wa_usage.daily_limit(sess.get("created_at"))

    pending = await db.campaign_recipients.find(
        {"campaign_id": cid, "status": "pending"}, {"_id": 0}).limit(BATCH_PER_TICK).to_list(BATCH_PER_TICK)

    if not pending:
        remaining = await db.campaign_recipients.count_documents({"campaign_id": cid, "status": "pending"})
        if remaining == 0:
            unknown = await db.campaign_recipients.count_documents({"campaign_id": cid, "status": {"$in": ["sending", "uncertain"]}})
            await db.campaigns.update_one({"id": cid}, {"$set": {"status": "attention_required" if unknown else "completed", "updated_at": now_iso()}})
        return

    for r in pending:
        current = await db.campaigns.find_one({"id": cid})
        if not current or current["status"] != "running":
            break
        await refresh_role_definitions()
        sender = await db.users.find_one({"id": campaign.get("approved_by") or campaign.get("created_by")})
        if (not sender or sender.get("deleted") or not sender.get("active", True)
                or "send" not in permissions_for(sender["role"]).get("campaigns", [])):
            await db.campaigns.update_one({"id": cid}, {"$set": {"status": "paused",
                "last_error": "Sender access changed. An authorized sender must resume."}})
            break
        # opt-out guard (re-check live)
        contact = await db.contacts.find_one({"id": r["contact_id"]}, {"_id": 0})
        if not contact or contact.get("opted_out") or contact.get("deleted") or contact.get("is_demo"):
            await db.campaign_recipients.update_one({"id": r["id"]}, {"$set": {"status": "skipped", "error": "opted_out"}})
            await db.campaigns.update_one({"id": cid}, {"$inc": {"stats.skipped": 1}})
            continue
        # daily limit guard (number health)
        used = await wa_usage.usage_today(phone_num)
        if used + max(1, len(campaign.get("attachments", []))) > limit:
            logger.info(f"campaign {cid}: daily limit {limit} reached for {phone_num}; pausing batch")
            break
        claim = await db.campaign_recipients.update_one({"id": r["id"], "status": "pending"}, {"$set": {
            "status": "sending", "sender_session_id": sess.get("id"), "sender_phone": sess.get("phone")}})
        if not claim.matched_count:
            continue
        send_started = False
        try:
            ctx = {"name": r.get("name"), "company": r.get("company"), "city": r.get("city"),
                   **(campaign.get("variables") or {})}
            text = render_message(campaign["message"], ctx)
            files = await resolve_attachments(campaign.get("attachments", []))
            urls = [(f, await signed_url(f["object_path"])) for f in files]
            parts = urls if urls else [(None, None)]
            wamid = None
            for index, (file, url) in enumerate(parts):
                if index:
                    await asyncio.sleep(campaign.get("message_gap_seconds", 5))
                current = await db.campaigns.find_one({"id": cid})
                if not current or current.get("status") != "running":
                    raise RuntimeError("Campaign stopped before the next attachment.")
                send_started = True
                options = {"session_id": sess["id"]} if sess.get("id") else {}
                try:
                    resp = await wa_client.wa_send_media(r["mobile"], url, file["content_type"], file["name"],
                        text if index == 0 else "", **options) if file else await wa_client.wa_send(r["mobile"], text, **options)
                finally:
                    await db.campaigns.update_one({"id": cid}, {"$set": {
                        "next_send_at": (utcnow() + timedelta(seconds=campaign.get("message_gap_seconds", 5))).isoformat()}})
                wamid = resp.get("wamid")
                if not wamid:
                    raise RuntimeError("Provider did not confirm acceptance.")
                await db.campaign_recipients.update_one({"id": r["id"]}, {"$push": {"part_wamids": wamid}})
                await wa_usage.inc_usage(phone_num)
                conv = await _upsert_conversation(r["phone"], r.get("name") or r["phone"], sess.get("id"))
                part_body = text if index == 0 else file["name"]
                await db.messages.update_one({"wamid": wamid}, {"$setOnInsert": {
                    "id": new_id(), "conversation_id": conv["id"], "wamid": wamid, "direction": "outbound",
                    "type": ("document" if file["content_type"] == "application/pdf" else "image") if file else "text",
                    "body": part_body, "status": "sent", "is_demo": False,
                    "sender": "Campaign", "created_at": now_iso()},
                    "$set": {"campaign_id": cid, "session_id": sess.get("id"),
                             "attachments": [file["id"]] if file else []}}, upsert=True)
            await db.conversations.update_one({"id": conv["id"]},
                {"$set": {"last_message": text, "last_message_at": now_iso()}})
            await db.campaign_recipients.update_one({"id": r["id"]},
                {"$set": {"status": "sent", "wamid": wamid, "sent_at": now_iso(), "conversation_id": conv["id"]}})
            await db.campaigns.update_one({"id": cid}, {"$inc": {"stats.sent": 1}})
        except Exception as e:
            await db.campaign_recipients.update_one({"id": r["id"]},
                {"$set": {"status": "uncertain" if send_started else "failed", "error": "Provider acceptance is unresolved; no automatic retry." if send_started else "Attachment preparation failed."}})
            await db.campaigns.update_one({"id": cid}, {"$inc": {"stats.uncertain" if send_started else "stats.failed": 1}})
        await asyncio.sleep(campaign.get("message_gap_seconds", 5))


async def _tick_unlocked():
    await refresh_role_definitions()
    now = utcnow().isoformat()
    # activate due scheduled campaigns
    async for c in db.campaigns.find({"status": "scheduled", "is_demo": {"$ne": True}, "deleted": {"$ne": True}, "scheduled_at": {"$lte": now}}, {"_id": 0}):
        try:
            async with campaign_lock(c["id"]):
                current = await db.campaigns.find_one({"id": c["id"], "status": "scheduled", "scheduled_at": {"$lte": now}})
                if not current:
                    continue
                if await db.campaign_recipients.count_documents({"campaign_id": c["id"]}) == 0:
                    await _materialize(current)
                await db.campaigns.update_one({"id": c["id"], "status": "scheduled"}, {"$set": {"status": "running", "updated_at": now_iso()}})
        except HTTPException as exc:
            if exc.status_code != 409: raise
    # process running campaigns
    async for c in db.campaigns.find({"status": "running", "is_demo": {"$ne": True}, "deleted": {"$ne": True}}, {"_id": 0}):
        try:
            await _process_campaign(c)
        except Exception as e:
            logger.error(f"campaign {c['id']} error: {e}")
    # process drip sequences
    try:
        await _process_drips()
    except Exception as e:
        logger.error(f"drip error: {e}")


async def _tick():
    # Only one scheduler may send across API replicas; recipient claims are
    # an additional durable barrier against retries after crashes/timeouts.
    pool = await db.connect()
    async with pool.acquire() as conn:
        acquired = await conn.fetchval("SELECT pg_try_advisory_lock(hashtext('campaign-scheduler'))")
        if not acquired:
            return
        try:
            await _tick_unlocked()
        finally:
            await conn.execute("SELECT pg_advisory_unlock(hashtext('campaign-scheduler'))")


async def start_campaign_engine():
    logger.info("Campaign engine started")
    while True:
        try:
            await _tick()
        except Exception as e:
            logger.error(f"engine tick error: {e}")
        await asyncio.sleep(TICK_SECONDS)


# ---------------- API ----------------
@router.get("/campaigns")
async def list_campaigns(user: dict = Depends(require_perm("campaigns", "view"))):
    items = await db.campaigns.find({"deleted": {"$ne": True}}, {"_id": 0}).sort("created_at", -1).to_list(100)
    return {"items": items}


@router.post("/campaigns")
async def create_campaign(body: CampaignIn, user: dict = Depends(require_perm("campaigns", "create"))):
    if not body.name.strip() or not body.message.strip():
        raise HTTPException(422, "Campaign name and message cannot be blank.")
    if body.send_now and body.scheduled_at:
        raise HTTPException(422, "Choose either send now or schedule, not both.")
    if (body.send_now or body.scheduled_at) and "send" not in permissions_for(user["role"]).get("campaigns", []):
        raise HTTPException(403, "Campaign send permission is required.")
    if "view" not in permissions_for(user["role"]).get("crm", []):
        raise HTTPException(403, "Contact view permission is required to select campaign recipients.")
    scheduled = False
    if body.scheduled_at:
        try:
            parsed = datetime.fromisoformat(body.scheduled_at.replace("Z", "+00:00"))
            if not parsed.tzinfo or parsed <= utcnow():
                raise ValueError()
            body.scheduled_at = parsed.astimezone(timezone.utc).isoformat()
            scheduled = True
        except ValueError:
            raise HTTPException(422, "Choose a future date and time including timezone.")
    contacts = await _resolve_contacts(body.audience.model_dump())
    if not contacts:
        raise HTTPException(422, "The audience has no eligible real contacts with valid international numbers.")
    attachments = await resolve_attachments(list(dict.fromkeys(body.attachments)), user["id"])
    if body.sender_session_id or body.send_now or scheduled:
        body.sender_session_id = (await resolve_sender(db, body.sender_session_id, require_connected=False))["id"]
    status = "running" if body.send_now else ("scheduled" if scheduled else "draft")
    doc = {"id": new_id(), "name": body.name, "message": body.message,
           "template_name": body.template_name, "variables": body.variables,
           "attachments": [f["id"] for f in attachments],
           "attachment_details": [{k: f[k] for k in ("id", "name", "content_type", "size")} for f in attachments],
           "audience": body.audience.model_dump(), "scheduled_at": body.scheduled_at if scheduled else None,
           "message_gap_seconds": body.message_gap_seconds,
           "sender_session_id": body.sender_session_id,
           "status": "preparing" if body.send_now or scheduled else status, "stats": _empty_stats(), "is_demo": False,
           "created_by": user["id"], "created_at": now_iso(), "updated_at": now_iso()}
    await db.campaigns.insert_one(doc)
    if body.send_now or scheduled:
        await _materialize(doc)
        await db.campaigns.update_one({"id": doc["id"]}, {"$set": {"status": status}})
    await log_audit(user, "create", "campaigns", doc["id"], detail=body.name)
    return await db.campaigns.find_one({"id": doc["id"]}, {"_id": 0})


@router.put("/campaigns/{cid}")
async def edit_campaign(cid: str, body: CampaignIn, user=Depends(require_perm("campaigns", "edit"))):
    async with campaign_lock(cid):
        current = await db.campaigns.find_one({"id": cid, "deleted": {"$ne": True}})
        if not current:
            raise HTTPException(404, "Campaign not found.")
        attempted = await db.campaign_recipients.count_documents({
            "campaign_id": cid, "status": {"$in": ["sending", "sent", "uncertain", "failed"]}})
        if current.get("is_demo") or current.get("status") not in ("draft", "scheduled", "paused") or attempted:
            raise HTTPException(409, "Pause before editing. Campaigns with send attempts cannot be edited or resent.")
        if not body.name.strip() or not body.message.strip():
            raise HTTPException(422, "Campaign name and message cannot be blank.")
        if body.send_now and body.scheduled_at:
            raise HTTPException(422, "Choose send now or schedule, not both.")
        if (body.send_now or body.scheduled_at) and "send" not in permissions_for(user["role"]).get("campaigns", []):
            raise HTTPException(403, "Campaign send permission is required.")
        if "view" not in permissions_for(user["role"]).get("crm", []):
            raise HTTPException(403, "Contact view permission is required.")
        scheduled_at = None
        if body.scheduled_at:
            try:
                parsed = datetime.fromisoformat(body.scheduled_at.replace("Z", "+00:00"))
                if not parsed.tzinfo or parsed <= utcnow(): raise ValueError()
                scheduled_at = parsed.astimezone(timezone.utc).isoformat()
            except ValueError:
                raise HTTPException(422, "Choose a future date and time including timezone.")
        if not await _resolve_contacts(body.audience.model_dump()):
            raise HTTPException(422, "The audience has no eligible real contacts.")
        # Editors can retain existing attachments; new ones must be their own.
        files = []
        for mid in dict.fromkeys(body.attachments):
            files += await resolve_attachments([mid], None if mid in current.get("attachments", []) else user["id"])
        target = "running" if body.send_now else ("scheduled" if scheduled_at else "draft")
        if body.sender_session_id or target != "draft":
            body.sender_session_id = (await resolve_sender(db, body.sender_session_id, require_connected=False))["id"]
        fields = body.model_dump(exclude={"send_now", "scheduled_at"})
        fields.update(name=body.name.strip(), attachments=[f["id"] for f in files],
            attachment_details=[{k: f[k] for k in ("id", "name", "content_type", "size")} for f in files],
            scheduled_at=scheduled_at, status="preparing", approved_by=user["id"],
            stats=_empty_stats(), last_error=None, updated_at=now_iso())
        await db.campaigns.update_one({"id": cid}, {"$set": fields})
        await db.campaign_recipients.delete_many({"campaign_id": cid})
        if target != "draft":
            await _materialize({**current, **fields})
        await db.campaigns.update_one({"id": cid}, {"$set": {"status": target}})
    await log_audit(user, "edit", "campaigns", cid, detail=body.name)
    return await db.campaigns.find_one({"id": cid}, {"_id": 0})


@router.get("/campaigns/{cid}")
async def get_campaign(cid: str, user: dict = Depends(require_perm("campaigns", "view"))):
    c = await db.campaigns.find_one({"id": cid}, {"_id": 0})
    if not c:
        raise HTTPException(status_code=404, detail="Campaign not found")
    recips = await db.campaign_recipients.find({"campaign_id": cid}, {"_id": 0}).limit(500).to_list(500)
    return {"campaign": c, "recipients": recips}


@router.post("/campaigns/{cid}/send")
async def send_campaign(cid: str, user: dict = Depends(require_perm("campaigns", "send"))):
    async with campaign_lock(cid):
        return await _start_campaign(cid, user)


async def _start_campaign(cid, user):
    c = await db.campaigns.find_one({"id": cid}, {"_id": 0})
    if not c:
        raise HTTPException(status_code=404, detail="Campaign not found")
    if c.get("deleted") or c.get("is_demo") or c.get("status") != "draft":
        raise HTTPException(409, "Only a real draft can be started. Uncertain sends cannot be retried.")
    selected = await resolve_sender(db, c.get("sender_session_id"))
    if await db.campaign_recipients.count_documents({"campaign_id": cid}) == 0:
        n = await _materialize(c)
        if n == 0:
            raise HTTPException(status_code=400, detail="No eligible recipients (all opted-out or audience empty).")
    await db.campaigns.update_one({"id": cid}, {"$set": {"status": "running", "approved_by": user["id"], "sender_session_id": selected["id"], "updated_at": now_iso()}})
    await log_audit(user, "send", "campaigns", cid)
    return {"ok": True, "status": "running"}


@router.post("/campaigns/{cid}/pause")
async def pause_campaign(cid: str, user: dict = Depends(require_perm("campaigns", "edit"))):
    await db.campaigns.update_one({"id": cid}, {"$set": {"status": "paused", "updated_at": now_iso()}})
    return {"ok": True}


@router.post("/campaigns/{cid}/resume")
async def resume_campaign(cid: str, user: dict = Depends(require_perm("campaigns", "send"))):
    campaign = await db.campaigns.find_one({"id": cid, "deleted": {"$ne": True}})
    if not campaign:
        raise HTTPException(404, "Campaign not found.")
    if campaign.get("is_demo") or campaign.get("status") not in ("paused", "scheduled"):
        raise HTTPException(409, "Only paused or scheduled real campaigns can be resumed.")
    status = "scheduled" if campaign.get("scheduled_at") and campaign["scheduled_at"] > now_iso() else "running"
    await db.campaigns.update_one({"id": cid}, {"$set": {"status": status, "approved_by": user["id"], "updated_at": now_iso()}})
    return {"ok": True}


@router.delete("/campaigns/{cid}")
async def delete_campaign(cid: str, user: dict = Depends(require_perm("campaigns", "delete"))):
    async with campaign_lock(cid):
        return await _delete_campaign(cid, user)


async def _delete_campaign(cid, user):
    if not await db.campaigns.find_one({"id": cid, "deleted": {"$ne": True}}):
        raise HTTPException(404, "Campaign not found.")
    if await db.campaign_recipients.count_documents({"campaign_id": cid, "status": "sending"}):
        raise HTTPException(409, "A recipient send is in progress. Pause and wait before deleting.")
    await db.campaigns.update_one({"id": cid}, {"$set": {"deleted": True, "status": "cancelled", "updated_at": now_iso()}})
    await log_audit(user, "delete", "campaigns", cid, detail="Cancelled; send evidence retained")
    return {"ok": True}


@router.get("/wa/health")
async def wa_health(user: dict = Depends(require_perm("whatsapp", "view"))):
    return {"numbers": await wa_usage.health_report()}


# ---------------- Campaign report CSV ----------------
@router.get("/campaigns/{cid}/report.csv")
async def campaign_report_csv(cid: str, search: str = "", delivery: str = "",
                              sender: str = "",
                              user: dict = Depends(require_perm("campaigns", "export"))):
    return await report_csv(cid, search=search, delivery=delivery, sender=sender)


# Drip sequences
class DripStep(BaseModel):
    day: int
    message: str


class DripIn(BaseModel):
    name: str
    audience: Audience = Audience()
    steps: list[DripStep] = []
    message_gap_seconds: int = Field(default=5, ge=1, le=300)
    sender_session_id: Optional[str] = None


def _drip_stats():
    return {"active": 0, "sent": 0, "replied": 0, "purchased": 0, "opted_out": 0, "completed": 0, "uncertain": 0}


def _due_for_step(enrolled_at: str, day: int) -> str:
    base = datetime.fromisoformat(enrolled_at)
    from datetime import timedelta
    return (base + timedelta(days=max(0, day))).isoformat()


async def _enroll_drip(d: dict) -> int:
    contacts = await _resolve_contacts(d.get("audience", {}))
    steps = d.get("steps", [])
    step0 = steps[0]["day"] if steps else 0
    count = 0
    for c in contacts:
        if await db.drip_enrollments.find_one({"drip_id": d["id"], "contact_id": c["id"]}):
            continue
        enrolled = now_iso()
        await db.drip_enrollments.insert_one({
            "id": new_id(), "drip_id": d["id"], "contact_id": c["id"], "name": c.get("name"),
            "company": c.get("company"), "city": c.get("city"), "phone": _norm(c.get("mobile")),
            "mobile": c.get("mobile"), "enrolled_at": enrolled, "next_step_index": 0,
            "next_due_at": _due_for_step(enrolled, step0), "status": "active", "stop_reason": None,
            "created_at": enrolled})
        count += 1
    active = await db.drip_enrollments.count_documents({"drip_id": d["id"], "status": "active"})
    await db.drips.update_one({"id": d["id"]}, {"$set": {"stats.active": active, "updated_at": now_iso()}})
    return count


async def _drip_should_stop(enr: dict, session_id=None) -> Optional[str]:
    c = await db.contacts.find_one({"id": enr["contact_id"]}, {"_id": 0})
    if not c or c.get("opted_out") or c.get("deleted") or c.get("is_demo"):
        return "opted_out"
    scope = {"session_id": session_id} if session_id else {}
    conv = await db.conversations.find_one({"phone": enr["phone"], **scope}, {"_id": 0, "id": 1})
    if conv:
        inbound = await db.messages.find_one(
            {"conversation_id": conv["id"], "direction": "inbound", "created_at": {"$gt": enr["enrolled_at"]}})
        if inbound:
            return "replied"
    order = await db.orders.find_one({"contact_id": enr["contact_id"], "created_at": {"$gt": enr["enrolled_at"]}})
    if order:
        return "purchased"
    return None


async def _persist_drip_message(drip_id, enrollment, session, conversation_id, wamid, text):
    """Attach provenance atomically without downgrading a gateway receipt."""
    await db.messages.update_one({"wamid": wamid}, {
        "$setOnInsert": {
            "id": new_id(), "conversation_id": conversation_id, "wamid": wamid,
            "direction": "outbound", "type": "text", "body": text,
            "status": "sent", "is_demo": False, "session_id": session.get("id"),
            "created_at": now_iso(),
        },
        "$set": {"sender": "Drip", "drip_id": drip_id, "contact_id": enrollment["contact_id"]},
    }, upsert=True)


async def _process_drips():
    now = utcnow().isoformat()
    if not await wa_client.wa_connected():
        return
    async for d in db.drips.find({"status": "active", "is_demo": {"$ne": True}, "deleted": {"$ne": True}}, {"_id": 0}):
        sess = await wa_usage.connected_session(d.get("sender_session_id"), database=db)
        if not sess:
            continue
        if not d.get("sender_session_id"):
            await db.drips.update_one({"id": d["id"]}, {"$set": {"sender_session_id": sess["id"]}})
        phone_num = sess.get("phone")
        limit = wa_usage.daily_limit(sess.get("created_at"))
        steps = d.get("steps", [])
        enrs = await db.drip_enrollments.find(
            {"drip_id": d["id"], "status": "active", "next_due_at": {"$lte": now}}, {"_id": 0}
        ).limit(BATCH_PER_TICK).to_list(BATCH_PER_TICK)
        for enr in enrs:
            current = await db.drips.find_one({"id": d["id"], "status": "active", "deleted": {"$ne": True}})
            sender = await db.users.find_one({"id": d.get("approved_by") or d.get("created_by")})
            if not current:
                break
            if not sender or sender.get("deleted") or not sender.get("active", True) or "send" not in permissions_for(sender["role"]).get("campaigns", []):
                await db.drips.update_one({"id": d["id"]}, {"$set": {"status": "paused"}})
                break
            reason = await _drip_should_stop(enr, sess["id"])
            if reason:
                await db.drip_enrollments.update_one({"id": enr["id"]}, {"$set": {"status": "stopped", "stop_reason": reason}})
                await db.drips.update_one({"id": d["id"]}, {"$inc": {f"stats.{reason}": 1, "stats.active": -1}})
                continue
            idx = enr.get("next_step_index", 0)
            if idx >= len(steps):
                await db.drip_enrollments.update_one({"id": enr["id"]}, {"$set": {"status": "completed"}})
                await db.drips.update_one({"id": d["id"]}, {"$inc": {"stats.completed": 1, "stats.active": -1}})
                continue
            if await wa_usage.usage_today(phone_num) >= limit:
                break
            ctx = {"name": enr.get("name"), "company": enr.get("company"), "city": enr.get("city")}
            text = render_message(steps[idx]["message"], ctx)
            claim = await db.drip_enrollments.update_one({
                "id": enr["id"], "status": "active", "sending_step_index": {"$ne": idx}},
                {"$set": {"sending_step_index": idx, "send_status": "sending",
                          "sender_session_id": sess.get("id"), "sender_phone": sess.get("phone")}})
            if not claim.matched_count:
                continue
            try:
                options = {"session_id": sess["id"]} if sess.get("id") else {}
                resp = await wa_client.wa_send(enr["mobile"], text, **options)
                if not resp.get("wamid"):
                    raise RuntimeError("No provider acceptance confirmed.")
                conv = await _upsert_conversation(enr["phone"], enr.get("name") or enr["phone"], sess.get("id"))
                await _persist_drip_message(d["id"], enr, sess, conv["id"], resp["wamid"], text)
                await db.conversations.update_one({"id": conv["id"]},
                    {"$set": {"last_message": text, "last_message_at": now_iso()}})
                await wa_usage.inc_usage(phone_num)
                await db.drips.update_one({"id": d["id"]}, {"$inc": {"stats.sent": 1}})
                await db.drip_enrollments.update_one({"id": enr["id"]}, {"$set": {"send_status": "sent"}})
            except Exception:
                await db.drip_enrollments.update_one({"id": enr["id"]}, {"$set": {
                    "status": "uncertain", "send_status": "uncertain",
                    "error": "Provider acceptance is unresolved; no automatic retry."}})
                await db.drips.update_one({"id": d["id"]}, {"$inc": {"stats.uncertain": 1, "stats.active": -1}})
                await asyncio.sleep(d.get("message_gap_seconds", 5))
                continue
            nxt = idx + 1
            if nxt >= len(steps):
                await db.drip_enrollments.update_one({"id": enr["id"]}, {"$set": {"status": "completed", "next_step_index": nxt}})
                await db.drips.update_one({"id": d["id"]}, {"$inc": {"stats.completed": 1, "stats.active": -1}})
            else:
                await db.drip_enrollments.update_one({"id": enr["id"]},
                    {"$set": {"next_step_index": nxt, "next_due_at": _due_for_step(enr["enrolled_at"], steps[nxt]["day"])}})
            await asyncio.sleep(d.get("message_gap_seconds", 5))


@router.get("/drips")
async def list_drips(user: dict = Depends(require_perm("campaigns", "view"))):
    items = await db.drips.find({"deleted": {"$ne": True}}, {"_id": 0}).sort("created_at", -1).to_list(100)
    return {"items": items}


@router.post("/drips")
async def create_drip(body: DripIn, user: dict = Depends(require_perm("campaigns", "create"))):
    if body.sender_session_id:
        await resolve_sender(db, body.sender_session_id, require_connected=False)
    doc = {"id": new_id(), "name": body.name, "audience": body.audience.model_dump(),
           "steps": [s.model_dump() for s in body.steps], "status": "draft", "stats": _drip_stats(),
           "message_gap_seconds": body.message_gap_seconds,
           "is_demo": False, "created_by": user["id"], "created_at": now_iso(), "updated_at": now_iso()}
    await db.drips.insert_one(doc)
    await log_audit(user, "create", "campaigns", doc["id"], detail=f"drip:{body.name}")
    doc.pop("_id", None)
    return doc


@router.put("/drips/{did}")
async def edit_drip(did: str, body: DripIn, user=Depends(require_perm("campaigns", "edit"))):
    if body.sender_session_id:
        await resolve_sender(db, body.sender_session_id, require_connected=False)
    async with campaign_lock(did):
        current = await db.drips.find_one({"id": did})
        if not current:
            raise HTTPException(404, "Sequence not found.")
        if current.get("is_demo") or current.get("status") != "draft":
            raise HTTPException(409, "Only an unactivated draft sequence can be edited.")
        if not body.name.strip() or any(s.day < 0 or not s.message.strip() for s in body.steps):
            raise HTTPException(422, "Enter a sequence name and valid non-empty steps.")
        if await db.drip_enrollments.count_documents({"drip_id": did}):
            raise HTTPException(409, "Enrolled sequences cannot be edited.")
        await db.drips.update_one({"id": did}, {"$set": {
            **body.model_dump(), "name": body.name.strip(), "updated_at": now_iso()}})
    await log_audit(user, "edit", "campaigns", did, detail="Drip sequence")
    return await db.drips.find_one({"id": did}, {"_id": 0})

@router.post("/drips/{did}/activate")
async def activate_drip(did: str, user: dict = Depends(require_perm("campaigns", "send"))):
    async with campaign_lock(did):
        return await _activate_drip(did, user)


async def _activate_drip(did, user):
    d = await db.drips.find_one({"id": did}, {"_id": 0})
    if not d or d.get("deleted") or d.get("is_demo"):
        raise HTTPException(status_code=404, detail="Drip not found")
    if not d.get("steps"):
        raise HTTPException(status_code=400, detail="Add at least one step before activating")
    selected = await resolve_sender(db, d.get("sender_session_id"), require_connected=False)
    n = await _enroll_drip(d)
    await db.drips.update_one({"id": did}, {"$set": {"status": "active", "approved_by": user["id"], "sender_session_id": selected["id"], "updated_at": now_iso()}})
    return {"ok": True, "enrolled": n}


@router.post("/drips/{did}/pause")
async def pause_drip(did: str, user: dict = Depends(require_perm("campaigns", "edit"))):
    await db.drips.update_one({"id": did}, {"$set": {"status": "paused", "updated_at": now_iso()}})
    return {"ok": True}


@router.post("/drips/{did}/resume")
async def resume_drip(did: str, user: dict = Depends(require_perm("campaigns", "send"))):
    if not await db.drips.find_one({"id": did, "status": "paused", "deleted": {"$ne": True}, "is_demo": {"$ne": True}}):
        raise HTTPException(409, "Only paused real sequences can be resumed.")
    await db.drips.update_one({"id": did}, {"$set": {"status": "active", "approved_by": user["id"], "updated_at": now_iso()}})
    return {"ok": True}


@router.delete("/drips/{did}")
async def delete_drip(did: str, user: dict = Depends(require_perm("campaigns", "delete"))):
    if not await db.drips.find_one({"id": did, "deleted": {"$ne": True}}):
        raise HTTPException(404, "Sequence not found.")
    await db.drips.update_one({"id": did}, {"$set": {"deleted": True, "status": "cancelled", "updated_at": now_iso()}})
    await db.drip_enrollments.update_many({"drip_id": did, "status": "active"}, {"$set": {"status": "stopped", "stop_reason": "cancelled"}})
    await log_audit(user, "delete", "campaigns", did, detail="Drip cancelled; delivery evidence retained")
    return {"ok": True}
