import logging
import time
from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import PlainTextResponse
from pydantic import BaseModel
from typing import Optional

from db import db, new_id, now_iso
from auth import require_perm
from routes_automations import run_automations
import brevo_client

logger = logging.getLogger("vgrups.ads")
router = APIRouter(prefix="/api", tags=["ads"])

AD_SOURCES = ["meta", "facebook", "instagram", "google", "ad_webhook"]
DEFAULT_CFG = {"verify_token": "vgrups_verify", "enabled": True}

_hits: dict[str, list[float]] = {}


def _throttle(ip: str, limit: int = 30, window: int = 60):
    now = time.time()
    h = [t for t in _hits.get(ip, []) if now - t < window]
    if len(h) >= limit:
        raise HTTPException(status_code=429, detail="Rate limit exceeded")
    h.append(now)
    _hits[ip] = h


async def _send_welcome_email(name: str, email: str, contact_id: str | None = None):
    from datetime import datetime, timezone, timedelta
    if contact_id:
        cdoc = await db.contacts.find_one({"id": contact_id}, {"_id": 0, "welcomed_at": 1})
        if cdoc and cdoc.get("welcomed_at"):
            try:
                if datetime.fromisoformat(cdoc["welcomed_at"]) > datetime.now(timezone.utc) - timedelta(days=7):
                    return  # already welcomed recently — avoid duplicate emails on webhook retries
            except Exception:
                pass
    prods = await db.products.find({"image": {"$nin": [None, ""]}}, {"_id": 0}).limit(4).to_list(4)
    cards = "".join(
        f'<td style="padding:8px;text-align:center;font-family:Arial;font-size:13px;color:#333;vertical-align:top;width:130px">'
        f'<img src="{p.get("image")}" alt="" width="120" height="120" style="border-radius:8px;object-fit:cover"/><br/>'
        f'<b>{p.get("name")}</b><br/>₹{p.get("selling_price")}</td>' for p in prods)
    html = f"""<html><body style="margin:0;background:#FAFAF7;padding:0">
      <div style="max-width:600px;margin:0 auto;font-family:Arial">
        <div style="background:#3B5B2A;color:#fff;padding:28px 24px">
          <div style="font-size:13px;opacity:.85">VGRUPS HEALTHCARE</div>
          <h1 style="margin:8px 0 0;font-size:24px">Welcome, {name}! 🎉</h1>
        </div>
        <div style="padding:24px;color:#333;font-size:14px;line-height:1.6">
          <p>Thank you for your interest in VGRUPS Healthcare. We're excited to help you with quality medical & healthcare products at the best prices.</p>
          <p style="margin:18px 0 8px;font-weight:bold">A few of our popular products:</p>
          <table style="border-collapse:collapse;margin:0 auto"><tr>{cards}</tr></table>
          <p style="margin-top:20px">Reply to this email or message us on WhatsApp and our team will share the full catalogue & pricing right away.</p>
          <p style="color:#777;font-size:12px;margin-top:24px">— Team VGRUPS Healthcare</p>
        </div>
      </div></body></html>"""
    status = await send_email_safe(email, name, "Welcome to VGRUPS Healthcare 🎉", html)
    if contact_id and status == "Sent":
        await db.contacts.update_one({"id": contact_id}, {"$set": {"welcomed_at": now_iso()}})
    logger.info(f"welcome email to {email}: {status}")


async def send_email_safe(email, name, subject, html):
    try:
        return await brevo_client.send_email(email, name, subject, html)
    except Exception as e:
        logger.warning(f"welcome email error: {e}")
        return "Failed"


async def _get_cfg() -> dict:
    doc = await db.app_config.find_one({"key": "ad_webhook"}, {"_id": 0})
    return doc["value"] if doc else dict(DEFAULT_CFG)


async def _create_ad_lead(name: str, mobile: Optional[str], email: Optional[str],
                          source: str, campaign: Optional[str], notes: str = "") -> dict:
    source = source if source in AD_SOURCES else "ad_webhook"
    existing = await db.contacts.find_one({"mobile": mobile}) if mobile else None
    contact_id = existing["id"] if existing else new_id()
    if not existing:
        await db.contacts.insert_one({
            "id": contact_id, "name": name, "mobile": mobile, "email": email, "company": None,
            "contact_type": "lead", "address": None, "city": None, "state": None, "pincode": None,
            "gst": None, "category": None, "source": source, "assigned_to": None,
            "tags": ["ad", source], "notes": notes, "opted_out": False, "is_demo": False,
            "deleted": False, "created_at": now_iso(), "updated_at": now_iso()})
    elif email and not existing.get("email"):
        await db.contacts.update_one({"id": contact_id}, {"$set": {"email": email, "updated_at": now_iso()}})
    lead = {"id": new_id(), "title": f"Ad Lead - {name}", "contact_id": contact_id, "contact_name": name,
            "mobile": mobile, "company": None, "status": "new", "source": source, "value": 0,
            "specialty": None, "assigned_to": None, "tags": ["ad", source], "campaign": campaign,
            "notes": notes, "is_demo": False, "deleted": False, "created_at": now_iso(),
            "updated_at": now_iso(), "last_contact": now_iso()}
    await db.leads.insert_one(lead)
    import asyncio
    asyncio.create_task(run_automations("new_lead", {"contact_name": name, "mobile": mobile,
                                                     "contact_id": contact_id, "lead_id": lead["id"]}))
    if email:
        asyncio.create_task(_send_welcome_email(name, email, contact_id))
    lead.pop("_id", None)
    return lead


# ---------------- Config (auth) ----------------
@router.get("/ads/config")
async def get_config(user: dict = Depends(require_perm("ads", "view"))):
    return await _get_cfg()


class CfgIn(BaseModel):
    verify_token: str
    enabled: bool = True


@router.put("/ads/config")
async def set_config(body: CfgIn, user: dict = Depends(require_perm("ads", "edit"))):
    value = body.model_dump()
    await db.app_config.update_one({"key": "ad_webhook"},
        {"$set": {"key": "ad_webhook", "value": value, "updated_at": now_iso()}}, upsert=True)
    return value


@router.get("/ads/leads")
async def ad_leads(user: dict = Depends(require_perm("ads", "view"))):
    items = await db.leads.find({"source": {"$in": AD_SOURCES}}, {"_id": 0}).sort("created_at", -1).to_list(300)
    counts = {s: await db.leads.count_documents({"source": s}) for s in AD_SOURCES}
    counts["total"] = sum(counts.values())
    return {"items": items, "counts": counts}


@router.post("/ads/test-lead")
async def test_lead(user: dict = Depends(require_perm("ads", "create"))):
    import random
    n = random.randint(100, 999)
    lead = await _create_ad_lead(f"Test Lead {n}", f"+9199{random.randint(10000000, 99999999)}",
                                 f"lead{n}@example.com", "meta", "Diwali Campaign", "Simulated ad lead")
    return {"ok": True, "lead": lead}


# ---------------- Public webhooks (no auth) ----------------
@router.get("/webhooks/meta-leads")
async def meta_verify(request: Request):
    cfg = await _get_cfg()
    p = request.query_params
    if p.get("hub.mode") == "subscribe" and p.get("hub.verify_token") == cfg.get("verify_token"):
        return PlainTextResponse(p.get("hub.challenge", ""))
    raise HTTPException(status_code=403, detail="Verification failed")


@router.post("/webhooks/meta-leads")
async def meta_webhook(request: Request):
    _throttle(request.client.host if request.client else "x")
    try:
        payload = await request.json()
    except Exception:
        payload = {}
    await db.ad_webhook_logs.insert_one({"id": new_id(), "provider": "meta", "payload": payload, "created_at": now_iso()})
    created = 0
    for entry in payload.get("entry", []):
        for ch in entry.get("changes", []):
            val = ch.get("value", {})
            fields = {f.get("name"): (f.get("values") or [None])[0] for f in val.get("field_data", [])}
            if fields:
                await _create_ad_lead(fields.get("full_name") or fields.get("name") or "Meta Lead",
                                      fields.get("phone_number") or fields.get("phone"),
                                      fields.get("email"), "meta", val.get("ad_id"), "Meta Lead Ad")
                created += 1
    return {"ok": True, "created": created}


@router.post("/webhooks/lead")
async def generic_lead(request: Request):
    _throttle(request.client.host if request.client else "x")
    try:
        data = await request.json()
    except Exception:
        raise HTTPException(status_code=422, detail="Invalid JSON body")
    name = data.get("name") or data.get("full_name") or "Ad Lead"
    mobile = data.get("mobile") or data.get("phone") or data.get("phone_number")
    source = (data.get("source") or "ad_webhook").lower()
    campaign = data.get("campaign") or data.get("utm_campaign")
    lead = await _create_ad_lead(name, mobile, data.get("email"), source, campaign,
                                 data.get("notes") or "Captured via webhook")
    return {"ok": True, "lead_id": lead["id"]}
