"""Read-only catalogue history. Never calls send/recovery/storage providers."""
from whatsapp_routing import attach_report_senders
from delivery_report_csv import csv_response
from mr_report_receipts import receipt_index, delivery_evidence

FIELDS = ("id", "name", "mr_name", "phone", "contact_ref", "date", "created_at",
          "status", "total_parts", "error", "sender_number")
HEADERS = ["Attempt", "Recipient", "Phone", "Date", "Sender number", "Send status",
           "Parts", "Accepted", "Removed", "Uncertain", "Error", "Receipt status",
           "Required attachments", "Delivered attachments", "Read attachments",
           "Failed attachments", "Delivered at", "Read at"]


def required_attachments(job, saved):
    """Use immutable expected slots, never the observed successful attachment count."""
    required = job.get("total_parts")
    if not isinstance(required, int) or isinstance(required, bool) or required < 1:
        required = None
    snapshot = job.get("parts")
    if snapshot:
        keys = [p.get("key") for p in snapshot]
        if not all(keys) or len(set(keys)) != len(keys) or required not in (None, len(keys)):
            return saved, None
        slots = []
        for key in keys:
            matches = [p for p in saved if p.get("media_key") == key]
            slots.append(matches[0] if len(matches) == 1 else None)
        return slots, len(keys)
    # Legacy snapshots with only a saved count still need distinct attachment slots.
    keys = [p.get("media_key") for p in saved if p.get("media_key")]
    if len(keys) != len(set(keys)):
        required = None
    return saved, required


async def saved_evidence(database, jobs, parts_collection):
    parts = await parts_collection.find({"run_id": {"$in": [j["id"] for j in jobs]}}).to_list(None) if jobs else []
    wamids = list({p["wamid"] for p in parts if p.get("wamid")})
    messages = []
    if wamids:
        messages = await database.messages.find({
            "wamid": {"$in": wamids}, "is_demo": {"$ne": True}}, {"_id": 0}).to_list(None)
        messages += await database.whatsapp_receipts.find({
            "wamid": {"$in": wamids}}, {"_id": 0}).to_list(None)
    receipts = receipt_index(messages)
    by_run = {}
    for part in parts:
        part = dict(part)
        part["delivery"] = delivery_evidence([part], 1, receipts)
        by_run.setdefault(part["run_id"], []).append(part)
    return by_run, receipts


async def summaries(database, jobs, parts_collection, *, evidence=None):
    by_run, receipts = evidence if evidence is not None else await saved_evidence(database, jobs, parts_collection)
    jobs = [dict(j) for j in jobs]
    await attach_report_senders(database, jobs, parts_by_id=by_run)
    return [{**{k: j.get(k) for k in FIELDS},
             "delivery": delivery_evidence(*required_attachments(j, by_run.get(j["id"], [])), receipts),
             "accepted_parts": sum(p.get("status") == "accepted" for p in by_run.get(j["id"], [])),
             "removed_parts": sum(p.get("status") == "removed" for p in by_run.get(j["id"], [])),
             "uncertain_parts": sum(p.get("status") in ("sending", "uncertain") for p in by_run.get(j["id"], []))}
            for j in jobs]


async def page(database, runs, parts, query, offset, limit):
    jobs = await runs.find(query).sort([("created_at", -1), ("id", -1)]).skip(offset).to_list(limit)
    total = await runs.count_documents(query)
    return {"items": await summaries(database, jobs, parts), "offset": offset, "limit": limit,
            "total": total, "has_more": offset + len(jobs) < total}


async def detail(database, job, parts_collection):
    evidence = await saved_evidence(database, [job], parts_collection)
    row = (await summaries(database, [job], parts_collection, evidence=evidence))[0]
    saved = sorted(evidence[0].get(job["id"], []), key=lambda p: p.get("created_at") or "")
    # Snapshot names only; never resolve current catalogue assets or signed URLs.
    assets = {p.get("key"): p for p in job.get("parts", [])}
    row["parts"] = [{**{k: p.get(k) for k in ("id", "status", "wamid", "created_at", "error", "delivery")},
                     "name": assets.get(p.get("media_key"), {}).get("name")}
                    for p in saved]
    return row


def summary_values(row):
    return [row.get("id"), row.get("name") or row.get("mr_name"), row.get("phone"),
            row.get("date") or row.get("created_at"), row.get("sender_number"), row.get("status"),
            row.get("total_parts"), row.get("accepted_parts"), row.get("removed_parts"),
            row.get("uncertain_parts"), row.get("error")] + receipt_values(row)


def receipt_values(row):
    delivery = row.get("delivery") or {}
    return [delivery.get(k) for k in ("status", "required_parts", "delivered_parts",
                                     "read_parts", "failed_parts", "delivered_at", "read_at")]


def history_csv(filename, result, recipient_header="Recipient"):
    headers = [recipient_header if h == "Recipient" else h for h in HEADERS]
    return csv_response(filename, headers, (summary_values(row) for row in result["items"]))


def detail_csv(filename, row, recipient_header="Recipient"):
    headers = [recipient_header if h == "Recipient" else h for h in HEADERS] + [
        "Attachment", "Attachment status", "Provider message ID", "Attachment saved at", "Attachment error",
        "Attachment receipt status", "Attachment delivered at", "Attachment read at"]
    parts = row["parts"]
    return csv_response(filename, headers,
        (summary_values(row) + [p.get("name") or p.get("id"), p.get("status"), p.get("wamid"),
                               p.get("created_at"), p.get("error"),
                               (p.get("delivery") or {}).get("status"),
                               (p.get("delivery") or {}).get("delivered_at"),
                               (p.get("delivery") or {}).get("read_at")] for p in parts or [{}]))
