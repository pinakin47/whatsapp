import logging
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from typing import Optional

from db import db, new_id, now_iso, log_audit
from auth import require_perm
import wa_client

logger = logging.getLogger("vgrups.automations")
router = APIRouter(prefix="/api", tags=["automations"])

TRIGGERS = [
    {"key": "new_lead", "label": "New lead created"},
    {"key": "new_contact", "label": "New contact added"},
    {"key": "new_order", "label": "New order placed"},
    {"key": "payment_received", "label": "Payment received"},
]
ACTION_TYPES = [
    {"key": "send_whatsapp", "label": "Send WhatsApp"},
    {"key": "add_tag", "label": "Add tag"},
    {"key": "create_task", "label": "Create task"},
    {"key": "create_follow_up", "label": "Create follow-up"},
    {"key": "condition", "label": "If / Else branch"},
]
CONDITION_FIELDS = [
    {"key": "contact_type", "label": "Contact type"},
    {"key": "tag", "label": "Tag"},
    {"key": "lead_status", "label": "Lead status"},
    {"key": "source", "label": "Source"},
    {"key": "city", "label": "City"},
]
CONDITION_OPS = [
    {"key": "eq", "label": "is"},
    {"key": "neq", "label": "is not"},
    {"key": "contains", "label": "contains"},
]
TRIGGER_KEYS = [t["key"] for t in TRIGGERS]


ACTION_KEYS = [a["key"] for a in ACTION_TYPES]


class ActionIn(BaseModel):
    type: str
    message: Optional[str] = None
    tag: Optional[str] = None
    title: Optional[str] = None
    field: Optional[str] = None
    op: Optional[str] = None
    value: Optional[str] = None
    then: list["ActionIn"] = []
    otherwise: list["ActionIn"] = []


ActionIn.model_rebuild()


class AutomationIn(BaseModel):
    name: str
    trigger: str
    enabled: bool = True
    actions: list[ActionIn] = []


@router.get("/automations")
async def list_automations(user: dict = Depends(require_perm("automation", "view"))):
    items = await db.automations.find({}, {"_id": 0}).sort("created_at", -1).to_list(100)
    return {"items": items, "triggers": TRIGGERS, "action_types": ACTION_TYPES,
            "condition_fields": CONDITION_FIELDS, "condition_ops": CONDITION_OPS}


def _validate_actions(actions: list[ActionIn]) -> list[str]:
    bad = []
    for a in actions:
        if a.type not in ACTION_KEYS:
            bad.append(a.type)
        if a.type == "condition":
            if not a.field or not a.op:
                raise HTTPException(status_code=422, detail="Condition needs a field and an operator")
            bad += _validate_actions(a.then)
            bad += _validate_actions(a.otherwise)
    return bad


@router.post("/automations")
async def create_automation(body: AutomationIn, user: dict = Depends(require_perm("automation", "create"))):
    if body.trigger not in TRIGGER_KEYS:
        raise HTTPException(status_code=422, detail="Invalid trigger")
    bad = _validate_actions(body.actions)
    if bad:
        raise HTTPException(status_code=422, detail=f"Invalid action type(s): {', '.join(bad)}")
    doc = {"id": new_id(), "name": body.name, "trigger": body.trigger, "enabled": body.enabled,
           "actions": [a.model_dump() for a in body.actions], "runs": 0, "is_demo": False,
           "created_by": user["id"], "created_at": now_iso(), "updated_at": now_iso()}
    await db.automations.insert_one(doc)
    await log_audit(user, "create", "automation", doc["id"], detail=body.name)
    doc.pop("_id", None)
    return doc


@router.put("/automations/{aid}")
async def update_automation(aid: str, body: AutomationIn, user: dict = Depends(require_perm("automation", "edit"))):
    upd = {"name": body.name, "trigger": body.trigger, "enabled": body.enabled,
           "actions": [a.model_dump() for a in body.actions], "updated_at": now_iso()}
    r = await db.automations.update_one({"id": aid}, {"$set": upd})
    if not r.matched_count:
        raise HTTPException(status_code=404, detail="Automation not found")
    return await db.automations.find_one({"id": aid}, {"_id": 0})


@router.post("/automations/{aid}/toggle")
async def toggle_automation(aid: str, user: dict = Depends(require_perm("automation", "edit"))):
    a = await db.automations.find_one({"id": aid}, {"_id": 0})
    if not a:
        raise HTTPException(status_code=404, detail="Automation not found")
    new_state = not a.get("enabled", True)
    await db.automations.update_one({"id": aid}, {"$set": {"enabled": new_state}})
    return {"ok": True, "enabled": new_state}


@router.delete("/automations/{aid}")
async def delete_automation(aid: str, user: dict = Depends(require_perm("automation", "delete"))):
    await db.automations.delete_one({"id": aid})
    return {"ok": True}


@router.post("/automations/{aid}/test")
async def test_automation(aid: str, user: dict = Depends(require_perm("automation", "edit"))):
    a = await db.automations.find_one({"id": aid}, {"_id": 0})
    if not a:
        raise HTTPException(status_code=404, detail="Automation not found")
    ctx = {"contact_name": "Test Lead", "mobile": None, "contact_id": None, "lead_id": None}
    executed = await _execute_actions(a, ctx, test=True)
    return {"ok": True, "executed": executed}


def _match(actual, op: str, value: str) -> bool:
    value = (value or "").strip().lower()
    if isinstance(actual, list):
        vals = [str(x).strip().lower() for x in actual]
        if op == "neq":
            return value not in vals
        return value in vals  # eq / contains
    a = str(actual or "").strip().lower()
    if op == "eq":
        return a == value
    if op == "neq":
        return a != value
    if op == "contains":
        return value in a
    return False


def _eval_condition(act: dict, ctx: dict) -> bool:
    field = act.get("field")
    actual = ctx.get("tags") if field == "tag" else ctx.get(field)
    return _match(actual, act.get("op") or "eq", act.get("value") or "")


async def _execute_actions(automation: dict, ctx: dict, test: bool = False) -> list[str]:
    executed = await _run_list(automation.get("actions", []), ctx, test)
    if not test:
        await db.automations.update_one({"id": automation["id"]}, {"$inc": {"runs": 1}})
    return executed


async def _run_list(actions: list, ctx: dict, test: bool) -> list[str]:
    executed = []
    for act in actions:
        t = act.get("type")
        try:
            if t == "condition":
                passed = _eval_condition(act, ctx)
                branch = act.get("then") if passed else act.get("otherwise")
                executed.append(f"condition {act.get('field')} {act.get('op')} {act.get('value')} → {'THEN' if passed else 'ELSE'}")
                executed += await _run_list(branch or [], ctx, test)
            elif t == "send_whatsapp":
                msg = (act.get("message") or "").replace("{name}", ctx.get("contact_name") or "")
                if ctx.get("mobile") and not test and await wa_client.wa_connected():
                    await wa_client.wa_send(ctx["mobile"], msg)
                    executed.append("send_whatsapp: sent")
                else:
                    executed.append("send_whatsapp: skipped (no connected WhatsApp)")
            elif t == "add_tag":
                tag = act.get("tag")
                if tag and ctx.get("lead_id"):
                    await db.leads.update_one({"id": ctx["lead_id"]}, {"$addToSet": {"tags": tag}})
                if tag and ctx.get("contact_id"):
                    await db.contacts.update_one({"id": ctx["contact_id"]}, {"$addToSet": {"tags": tag}})
                executed.append(f"add_tag: {tag}")
            elif t in ("create_task", "create_follow_up"):
                await db.tasks.insert_one({
                    "id": new_id(), "title": (act.get("title") or "Follow up") + f" - {ctx.get('contact_name', '')}",
                    "task_type": "lead_follow_up" if t == "create_follow_up" else "customer_call",
                    "contact_id": ctx.get("contact_id"), "contact_name": ctx.get("contact_name"),
                    "assigned_to": None, "priority": "medium", "due_date": None, "status": "pending",
                    "notes": "Auto-created by automation", "is_demo": False, "created_by": None,
                    "created_at": now_iso(), "updated_at": now_iso()})
                executed.append(t)
        except Exception as e:
            executed.append(f"{t}: error {e}")
    return executed


async def _enrich_ctx(ctx: dict) -> dict:
    """Add contact_type / tags / city / source / lead_status for condition evaluation."""
    ctx = dict(ctx)
    if ctx.get("contact_id"):
        c = await db.contacts.find_one({"id": ctx["contact_id"]}, {"_id": 0})
        if c:
            ctx.setdefault("contact_type", c.get("contact_type"))
            ctx.setdefault("tags", c.get("tags") or [])
            ctx.setdefault("city", c.get("city"))
            ctx.setdefault("source", c.get("source"))
    if ctx.get("lead_id"):
        ld = await db.leads.find_one({"id": ctx["lead_id"]}, {"_id": 0})
        if ld:
            ctx.setdefault("lead_status", ld.get("status"))
            ctx.setdefault("source", ld.get("source"))
            if not ctx.get("tags"):
                ctx["tags"] = ld.get("tags") or []
    ctx.setdefault("tags", [])
    return ctx


async def run_automations(trigger: str, ctx: dict):
    """Event hook: execute all enabled automations for a trigger. Never raises."""
    try:
        ctx = await _enrich_ctx(ctx)
        async for a in db.automations.find({"trigger": trigger, "enabled": True}, {"_id": 0}):
            await _execute_actions(a, ctx)
    except Exception as e:
        logger.error(f"run_automations {trigger}: {e}")
