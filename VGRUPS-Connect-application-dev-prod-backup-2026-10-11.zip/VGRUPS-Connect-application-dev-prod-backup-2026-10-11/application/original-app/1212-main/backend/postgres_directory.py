"""Set-based directory reads. Only a requested page crosses the database boundary.

Scope is supplied by contact_directory, never guessed here. Source precedence and
document-ID ordering match the document cursor. No cache can stale consent/phones.
"""
import json
from functools import lru_cache
from postgres_query import Query


def normalized_phone(expression):
    return f"ltrim(regexp_replace({expression}, '[\\s().-]', '', 'g'), '+')"


def indexed_phone(fields):
    # Exact parity with the stored generated columns in postgres_schema.sql.
    columns = {
        ("mobile",): "directory_mobile_key",
        ("phone",): "directory_phone_key",
        ("mobile", "phone"): "directory_mobile_first_key",
        ("phone", "mobile"): "directory_phone_first_key",
        ("mobile", "phone", "alternative_phone"): "directory_lead_phone_key",
        ("alternative_phone",): "directory_alternate_phone_key",
    }
    return columns[tuple(fields)]


def first_value(fields):
    return "COALESCE(" + ", ".join(f"NULLIF(document->>'{f}', '')" for f in fields) + ", '')"


@lru_cache(maxsize=8)
def folded(expression):
    # Python's casefold differs from lower for these Unicode characters. Generate
    # the exceptional mappings once, rather than changing search to ASCII-only.
    import sys
    replacements = [(chr(i).lower(), chr(i).casefold()) for i in range(sys.maxunicode + 1)
                    if chr(i).lower() != chr(i).casefold()]
    original = expression
    singles = sorted(set((a, b) for a, b in replacements if len(a) == len(b) == 1))
    expression = f"translate({expression}, '{''.join(a for a, _ in singles)}', '{''.join(b for _, b in singles)}')"
    for source, target in sorted(set((a, b) for a, b in replacements if len(a) != 1 or len(b) != 1)):
        source, target = source.replace("'", "''"), target.replace("'", "''")
        expression = f"replace({expression}, '{source}', '{target}')"
    return f"CASE WHEN {original} ~ '[^ -~]' THEN {expression} ELSE {original} END"


def directory_query(specs, search, contact_type, offset, limit, key=None):
    q = Query("")
    # Query.filter does not use the initial collection parameter. Keep $1 typed.
    branches = []
    for rank, (collection, label, kind, names, phones, selector) in enumerate(specs):
        where = f"collection_name = {q.param(collection)} AND ({q.filter(selector)})"
        account_rank = (f"array_position({q.param(selector['session_id']['$in'], '::text[]')}, document->>'session_id')"
                        if collection == "conversations" else "0")
        name, mobile = first_value(names), first_value(phones)
        normalized = indexed_phone(phones)
        physical = collection == "contacts"
        ref = "document->>'id'" if physical else f"{q.param(collection + ':')} || (document->>'id')"
        # The alternative expansion follows the original record; primary wins.
        for alt in (False, True) if "alternative_phone" in phones else (False,):
            raw = "COALESCE(document->>'alternative_phone', '')" if alt else mobile
            number = indexed_phone(("alternative_phone",)) if alt else normalized
            reference = f"({ref}) || ':alternative_phone'" if alt else ref
            group_key = f"COALESCE(NULLIF({number}, ''), {reference})"
            target_key = q.param(key) if key is not None else None
            narrowed = (f" AND ({number} = {target_key} OR ({number} = '' AND {reference} = {target_key}))"
                        if key is not None else "")
            extra = (f" AND {raw} <> '' AND {number} <> {normalized}" if alt else "")
            display = raw if alt else f"CASE WHEN {number} ~ '^[1-9][0-9]{{7,14}}$' THEN '+' || {number} ELSE {raw} END"
            branches.append(f"""
                SELECT {rank} AS rank, {account_rank} AS account_rank, document_id AS docid, {int(alt)} AS alt,
                    {group_key} AS key,
                    jsonb_build_object(
                        'id', {reference},
                        'contact_id', {'NULL' if alt or not physical else "document->>'id'"},
                        'name', COALESCE(NULLIF({name}, ''), {mobile}),
                        'mobile', {display},
                        'email', document->'email', 'company', document->'company',
                        'city', document->'city', 'state', document->'state',
                        'contact_type', replace(lower(COALESCE(NULLIF(document->>'contact_type', ''), {q.param(kind)})), ' ', '_'),
                        'is_virtual', {'TRUE' if alt or not physical else 'FALSE'},
                        'opted_out', COALESCE(document->'opted_out' NOT IN ('null'::jsonb, 'false'::jsonb, '0'::jsonb, '""'::jsonb), FALSE),
                        'sources', jsonb_build_array({q.param(label + (" (alternate number)" if alt else ""), '::text')}),
                        'aliases', '[]'::jsonb, 'directory_refs', jsonb_build_array({reference})
                    ) AS row
                FROM app_documents WHERE {where} AND ({name} <> '' OR {mobile} <> ''){extra}{narrowed}
            """)
    term = q.param(search.casefold())
    type_param = q.param(contact_type)
    offset_param, limit_param = q.param(offset), q.param(limit)
    search_name = folded("lower(row->>'name')")
    search_text = folded("lower(search_text)")
    order_name = folded("lower(row->>'name')")
    sql = f"""
        WITH entries AS MATERIALIZED ({' UNION ALL '.join(branches)}),
        canonical AS (
            SELECT DISTINCT ON (key) key, row
            FROM entries ORDER BY key, rank, account_rank, docid, alt
        ), metadata AS (
            SELECT key,
                (array_agg(row->>'company' ORDER BY rank, account_rank, docid, alt)
                    FILTER (WHERE COALESCE(row->>'company', '') <> ''))[1] AS company,
                (array_agg(row->>'email' ORDER BY rank, account_rank, docid, alt)
                    FILTER (WHERE COALESCE(row->>'email', '') <> ''))[1] AS email,
                bool_or(strpos({search_name}, {term}) > 0) AS alias_match
            FROM entries GROUP BY key
        ), searchable AS (
            SELECT c.key, c.row, m.alias_match,
                concat_ws(' ', c.row->>'name', c.row->>'mobile', COALESCE(m.company, ''), COALESCE(m.email, '')) AS search_text
            FROM canonical c JOIN metadata m USING (key)
        ), filtered AS MATERIALIZED (
            SELECT key, row FROM searchable
            WHERE ({type_param} = 'all' OR row->>'contact_type' = {type_param})
              AND ({term} = '' OR alias_match OR strpos({search_text}, {term}) > 0)
        ), page AS (
            SELECT key, row_number() OVER (ORDER BY {order_name} COLLATE "C", row->>'id' COLLATE "C") AS position
            FROM filtered ORDER BY {order_name} COLLATE "C", row->>'id' COLLATE "C"
            OFFSET {offset_param} LIMIT {limit_param}
        )
        SELECT (SELECT count(*) FROM filtered) AS total,
            COALESCE(jsonb_agg(e.row ORDER BY p.position, e.rank, e.account_rank, e.docid, e.alt)
                FILTER (WHERE e.key IS NOT NULL), '[]'::jsonb)::text AS rows
        FROM page p JOIN entries e USING (key)
        WHERE $1::text = ''
    """
    return sql, q.params


async def read_page(database, specs, search, contact_type, offset, limit, key=None):
    from contact_directory import merge_rows
    sql, params = directory_query(specs, search, contact_type, offset, limit, key)
    pool = await database.connect()
    result = await pool.fetchrow(sql, *params)
    items = merge_rows(json.loads(result["rows"]))
    return {"items": items, "total": result["total"], "offset": offset, "limit": limit}
