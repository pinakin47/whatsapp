from collections import defaultdict
from datetime import datetime, timezone, timedelta
import re
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from typing import Optional

from db import db, new_id, now_iso, utcnow, log_audit
from auth import get_current_user, require_perm, public_user, ROLES, ROLE_LABELS, MODULES, permissions_for, hash_password
from integrations import integration_status

router = APIRouter(prefix="/api", tags=["platform"])


def _range_days(rng: str) -> int:
    return {"today": 1, "yesterday": 2, "7days": 7, "30days": 30,
            "this_month": 30, "last_month": 60}.get(rng, 30)


@router.get("/dashboard/stats")
async def dashboard_stats(rng: str = "30days", user: dict = Depends(require_perm("dashboard", "view"))):
    since = (utcnow() - timedelta(days=_range_days(rng))).isoformat()
    total_contacts = await db.contacts.count_documents({"deleted": {"$ne": True}})
    new_leads = await db.leads.count_documents({"status": "new", "deleted": {"$ne": True}})
    open_convos = await db.conversations.count_documents({"status": {"$ne": "closed"}, "archived": {"$ne": True}})
    unread = 0
    async for c in db.conversations.find({}, {"unread": 1, "_id": 0}):
        unread += c.get("unread", 0)
    todays_followups = await db.tasks.count_documents({"status": {"$ne": "done"}})
    orders_count = await db.orders.count_documents({})
    revenue = 0.0
    pending_payments = 0.0
    async for o in db.orders.find({}, {"total": 1, "payment_status": 1, "_id": 0}):
        revenue += o.get("total", 0) if o.get("payment_status") == "paid" else 0
        pending_payments += o.get("total", 0) if o.get("payment_status") != "paid" else 0
    campaign_messages = 0
    campaign_replies = 0
    async for c in db.campaigns.find({}, {"stats": 1, "_id": 0}):
        s = c.get("stats", {})
        campaign_messages += s.get("sent", 0)
        campaign_replies += s.get("replies", 0)
    won = await db.leads.count_documents({"status": "won"})
    total_leads = await db.leads.count_documents({"deleted": {"$ne": True}})
    conversion = round((won / total_leads) * 100, 1) if total_leads else 0.0
    return {
        "total_contacts": total_contacts, "new_leads": new_leads, "open_conversations": open_convos,
        "unread_messages": unread, "todays_followups": todays_followups, "orders": orders_count,
        "revenue": round(revenue, 2), "pending_payments": round(pending_payments, 2),
        "campaign_messages": campaign_messages, "campaign_replies": campaign_replies,
        "conversion_rate": conversion,
    }


@router.get("/dashboard/charts")
async def dashboard_charts(rng: str = "30days", user: dict = Depends(require_perm("dashboard", "view"))):
    days = _range_days(rng)
    buckets = [(utcnow() - timedelta(days=i)).strftime("%Y-%m-%d") for i in range(days - 1, -1, -1)]
    lead_by_day = defaultdict(int)
    async for l in db.leads.find({"deleted": {"$ne": True}}, {"created_at": 1, "_id": 0}):
        d = (l.get("created_at") or "")[:10]
        lead_by_day[d] += 1
    sales_by_day = defaultdict(float)
    conv_by_day = defaultdict(int)
    async for o in db.orders.find({}, {"created_at": 1, "total": 1, "_id": 0}):
        sales_by_day[(o.get("created_at") or "")[:10]] += o.get("total", 0)
    async for c in db.conversations.find({}, {"created_at": 1, "_id": 0}):
        conv_by_day[(c.get("created_at") or "")[:10]] += 1

    lead_trend = [{"date": d[5:], "leads": lead_by_day.get(d, 0)} for d in buckets]
    sales_trend = [{"date": d[5:], "value": round(sales_by_day.get(d, 0), 2)} for d in buckets]
    conversation_trend = [{"date": d[5:], "conversations": conv_by_day.get(d, 0)} for d in buckets]

    src = defaultdict(int)
    async for l in db.leads.find({"deleted": {"$ne": True}}, {"source": 1, "_id": 0}):
        src[l.get("source", "manual")] += 1
    lead_source = [{"name": k, "value": v} for k, v in src.items()]

    ctype = defaultdict(int)
    async for c in db.contacts.find({"deleted": {"$ne": True}}, {"contact_type": 1, "_id": 0}):
        ctype[c.get("contact_type", "lead")] += 1
    customer_type = [{"name": k, "value": v} for k, v in ctype.items()]

    camp = []
    async for c in db.campaigns.find({}, {"name": 1, "stats": 1, "_id": 0}):
        s = c.get("stats", {})
        camp.append({"name": c.get("name", "")[:16], "sent": s.get("sent", 0),
                     "delivered": s.get("delivered", 0), "read": s.get("read", 0)})

    mr = defaultdict(lambda: {"leads": 0, "won": 0})
    users = {u["id"]: u["name"] async for u in db.users.find({"role": "mr"}, {"id": 1, "name": 1, "_id": 0})}
    async for l in db.leads.find({"assigned_to": {"$ne": None}}, {"assigned_to": 1, "status": 1, "_id": 0}):
        a = l.get("assigned_to")
        if a in users:
            mr[a]["leads"] += 1
            if l.get("status") == "won":
                mr[a]["won"] += 1
    mr_performance = [{"name": users[a], "leads": v["leads"], "won": v["won"]} for a, v in mr.items()]

    return {
        "lead_trend": lead_trend, "sales_trend": sales_trend,
        "conversation_trend": conversation_trend, "lead_source": lead_source,
        "customer_type": customer_type, "campaign_performance": camp,
        "mr_performance": mr_performance,
    }


# ---------------- Users / Roles ----------------
# ---------------- Integrations ----------------
@router.get("/integrations")
async def get_integrations(user: dict = Depends(require_perm("integrations", "view"))):
    return integration_status()


@router.post("/integrations/{name}/test")
async def test_integration(name: str, user: dict = Depends(require_perm("integrations", "manage"))):
    st = integration_status().get(name)
    if not st:
        raise HTTPException(status_code=404, detail="Unknown integration")
    if not st["configured"]:
        return {"ok": False, "status": "not_configured",
                "message": f"Add these env vars to activate: {', '.join(st['required_env'])}"}
    return {"ok": True, "status": "connected", "message": f"{st['name']} credentials present.",
            "tested_at": now_iso()}


# ---------------- Tasks / Follow-ups ----------------
class TaskIn(BaseModel):
    title: str
    task_type: str = "lead_follow_up"
    contact_id: Optional[str] = None
    contact_name: Optional[str] = None
    assigned_to: Optional[str] = None
    priority: str = "medium"
    due_date: Optional[str] = None
    notes: Optional[str] = None


@router.get("/tasks")
async def list_tasks(user: dict = Depends(require_perm("tasks", "view")), status: Optional[str] = None):
    q: dict = {}
    if status:
        q["status"] = status
    items = await db.tasks.find(q, {"_id": 0}).sort("due_date", 1).to_list(300)
    return {"items": items}


@router.post("/tasks")
async def create_task(body: TaskIn, user: dict = Depends(require_perm("tasks", "create"))):
    doc = body.model_dump()
    doc.update({"id": new_id(), "status": "pending", "is_demo": False,
                "created_by": user["id"], "created_at": now_iso(), "updated_at": now_iso()})
    await db.tasks.insert_one(doc)
    doc.pop("_id", None)
    return doc


@router.patch("/tasks/{tid}")
async def update_task(tid: str, status: str, user: dict = Depends(require_perm("tasks", "edit"))):
    await db.tasks.update_one({"id": tid}, {"$set": {"status": status, "updated_at": now_iso()}})
    return {"ok": True}


# ---------------- Products / Catalog ----------------
@router.get("/products")
async def list_products(user: dict = Depends(require_perm("catalog", "view")), search: Optional[str] = None):
    q: dict = {"deleted": {"$ne": True}}
    if search:
        rx = re.escape(search)
        q["$or"] = [{"name": {"$regex": rx, "$options": "i"}},
                    {"code": {"$regex": rx, "$options": "i"}}]
    items = await db.products.find(q, {"_id": 0}).sort("name", 1).to_list(300)
    return {"items": items}


# ---------------- Orders ----------------
@router.get("/orders")
async def list_orders(user: dict = Depends(require_perm("orders", "view"))):
    items = await db.orders.find({}, {"_id": 0}).sort("created_at", -1).to_list(200)
    return {"items": items}


# ---------------- Campaigns (moved to routes_campaigns.py) ----------------


# ---------------- Audit ----------------
@router.get("/audit-logs")
async def audit_logs(user: dict = Depends(require_perm("settings", "view")), limit: int = 100):
    items = await db.audit_logs.find({}, {"_id": 0}).sort("created_at", -1).to_list(limit)
    return {"items": items}


# ---------------- Global search ----------------
@router.get("/search")
async def global_search(q: str, user: dict = Depends(require_perm("crm", "view"))):
    rx = {"$regex": re.escape(q), "$options": "i"}
    contacts = await db.contacts.find({"$or": [{"name": rx}, {"mobile": rx}, {"company": rx}], "deleted": {"$ne": True}}, {"_id": 0}).to_list(8)
    from lead_access import lead_scope
    leads = await db.leads.find({"$or": [{"title": rx}, {"contact_name": rx}], **lead_scope(user)}, {"_id": 0}).to_list(8)
    products = await db.products.find({"$or": [{"name": rx}, {"code": rx}]}, {"_id": 0}).to_list(8)
    orders = await db.orders.find({"order_no": rx}, {"_id": 0}).to_list(8)
    return {"contacts": contacts, "leads": leads, "products": products, "orders": orders}
