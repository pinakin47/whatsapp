"""Razorpay payment-link helper. Gracefully no-op when keys are absent."""
import os

try:
    import razorpay
except Exception:  # package missing
    razorpay = None


def _env(k: str) -> str:
    return (os.environ.get(k) or "").strip()


def configured() -> bool:
    return bool(razorpay and _env("RAZORPAY_KEY_ID") and _env("RAZORPAY_KEY_SECRET"))


def _client():
    return razorpay.Client(auth=(_env("RAZORPAY_KEY_ID"), _env("RAZORPAY_KEY_SECRET")))


def create_payment_link(amount_rupees: float, description: str, customer: dict,
                        reference_id: str, callback_url: str | None = None) -> dict:
    """Create a hosted Razorpay payment link. Returns {id, short_url}."""
    if not configured():
        raise RuntimeError("Razorpay not configured")
    payload = {
        "amount": int(round(amount_rupees * 100)),  # paise
        "currency": "INR",
        "accept_partial": False,
        "description": description[:255],
        "reference_id": reference_id[:40],
        "customer": {k: v for k, v in customer.items() if v},
        "notify": {"sms": True, "email": bool(customer.get("email"))},
        "reminder_enable": True,
        "notes": {"reference_id": reference_id},
    }
    if callback_url:
        payload["callback_url"] = callback_url
        payload["callback_method"] = "get"
    link = _client().payment_link.create(payload)
    return {"id": link.get("id"), "short_url": link.get("short_url")}


def verify_webhook_signature(body: bytes, signature: str) -> bool:
    secret = _env("RAZORPAY_WEBHOOK_SECRET")
    if not (configured() and secret and signature):
        return False
    try:
        _client().utility.verify_webhook_signature(body.decode(), signature, secret)
        return True
    except Exception:
        return False
