import asyncio
import logging
import time
from contextlib import asynccontextmanager
from datetime import datetime
from fastapi import HTTPException
from db import db, now_iso
from lead_capture_core import settings_for, ingest, notify_admins, REAL, enqueue_message
from lead_capture_delivery import deliver_request
from lead_capture_extract import IST
from auth import refresh_role_definitions, permissions_for


@asynccontextmanager
async def capture_lock(database):
    pool = await database.connect()
    async with pool.acquire() as connection:
        if not await connection.fetchval("SELECT pg_try_advisory_lock(hashtext($1))", "mr:lead-capture"):
            raise HTTPException(409, "Lead capture is being processed. Retry shortly.")
        try:
            yield
        finally:
            await connection.execute("SELECT pg_advisory_unlock(hashtext($1))", "mr:lead-capture")


async def capture_tick(database=db, extractor=None):
    settings = await settings_for(database)
    if not settings["enabled"] or not settings["authorized_messages_confirmed"]:
        return
    await refresh_role_definitions()
    actor = await database.users.find_one({"id": settings.get("approved_by"), "active": {"$ne": False}, **REAL})
    if not actor or actor.get("role") not in ("admin", "super_admin", "sales_manager"):
        return
    perms = permissions_for(actor["role"])
    if "manage" not in perms.get("settings", []) or "create" not in perms.get("leads", []) or "edit" not in perms.get("leads", []):
        return
    kwargs = {"extractor": extractor} if extractor else {}
    async with capture_lock(database):
        # Reconcile a failed queue hook without blocking the original WhatsApp/MR flow.
        for message in await database.messages.find({**REAL, "type": "text",
                "created_at": {"$gte": settings["enabled_since"]},
                "lead_capture_reconciled": {"$ne": True}}).sort("created_at", 1).to_list(100):
            await enqueue_message(database, message)
            await database.messages.update_one({"id": message["id"]}, {"$set": {"lead_capture_reconciled": True}})
        for job in await database.mr_lead_queue.find({"status": {"$in": ["pending", "retry_pending"]}}).sort("created_at", 1).to_list(20):
            if job.get("next_attempt_at", 0) > time.time():
                continue
            result = await ingest(database, job, **kwargs)
            attempts = job.get("attempts", 0) + 1
            await database.mr_lead_queue.update_one({"id": job["id"]}, {"$set": {
                **result, "attempts": attempts, "updated_at": now_iso(),
            }})
        today = datetime.now(IST).date().isoformat()
        for lead in await database.leads.find({**REAL, "source": "WhatsApp – MR",
                                               "next_followup_at": {"$lte": today, "$ne": None},
                                               "status": {"$nin": ["won", "lost"]}}).to_list(500):
            await notify_admins(database, lead, "due:" + today + ":" + lead["id"], "FOLLOW-UP DUE")
    # Do not hold a database lock while waiting for a provider.
    for row in await database.mr_lead_requests.find({"status": {"$in": ["pending", "blocked_not_connected", "blocked_template_required", "disabled"]},
                                                   "resolution": "pending",
                                                   "channel": {"$in": [c for c, flag in (("whatsapp", "ask_missing_phone"), ("voice", "voice_enabled")) if settings[flag]]},
                                                   "$or": [{"next_attempt_at": {"$lte": time.time()}}, {"next_attempt_at": None}]}).sort("created_at", 1).to_list(20):
        if row.get("next_attempt_at", 0) <= time.time():
            await deliver_request(database, row)


async def start_lead_capture():
    while True:
        try:
            await capture_tick()
        except Exception:
            logging.getLogger("vgrups.lead_capture").error("Lead capture cycle failed; original evidence and send reservations retained.")
        await asyncio.sleep(5)
