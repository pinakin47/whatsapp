import os
import secrets
import hashlib
from datetime import datetime, timezone, timedelta

import bcrypt
import jwt
from fastapi import APIRouter, HTTPException, Request, Depends
from pydantic import BaseModel, EmailStr, Field

from db import db, new_id, now_iso, utcnow, log_audit

JWT_ALGORITHM = "HS256"
ACCESS_TTL_MIN = 60 * 24  # 1 day

DEVELOPMENT_ADMIN_EMAIL = "vgdisposables@gmail.com"
DEVELOPMENT_ADMIN_PASSWORD = "VgrupsConnect@2026"
PUBLIC_DEFAULT_ADMIN_CREDENTIALS = {
    ("admin@example.com", "admin123"),
    (DEVELOPMENT_ADMIN_EMAIL, DEVELOPMENT_ADMIN_PASSWORD),
}
PUBLIC_DEFAULT_ADMIN_PASSWORDS = {
    password for _, password in PUBLIC_DEFAULT_ADMIN_CREDENTIALS
}
MIN_PRODUCTION_ADMIN_PASSWORD_LENGTH = 16


def is_production() -> bool:
    return (
        os.environ.get("APP_ENV", "").strip().lower() == "production"
        or os.environ.get("NODE_ENV", "").strip().lower() == "production"
    )


def is_public_default_admin_credentials(email: str, password: str) -> bool:
    return (email.strip().lower(), password) in PUBLIC_DEFAULT_ADMIN_CREDENTIALS


def is_public_default_admin_password(password: str) -> bool:
    return password in PUBLIC_DEFAULT_ADMIN_PASSWORDS


def admin_seed_credentials() -> tuple[str, str, str]:
    admin_name = os.environ.get("ADMIN_NAME", "Admin")
    if not is_production():
        return (
            os.environ.get("ADMIN_EMAIL", DEVELOPMENT_ADMIN_EMAIL).strip().lower(),
            os.environ.get("ADMIN_PASSWORD", DEVELOPMENT_ADMIN_PASSWORD),
            admin_name,
        )

    admin_email = os.environ.get("PRODUCTION_ADMIN_EMAIL", "").strip().lower()
    admin_password = os.environ.get("PRODUCTION_ADMIN_PASSWORD", "")
    if not admin_email or not admin_password:
        raise RuntimeError(
            "Production requires PRODUCTION_ADMIN_EMAIL and PRODUCTION_ADMIN_PASSWORD to be configured as Replit Secrets."
        )
    if (
        len(admin_password) < MIN_PRODUCTION_ADMIN_PASSWORD_LENGTH
        or is_public_default_admin_password(admin_password)
    ):
        raise RuntimeError(
            "Production ADMIN_PASSWORD must be at least 16 characters and cannot use a public demo credential."
        )
    return admin_email, admin_password, admin_name

# ---- Roles & module permissions -------------------------------------------
ROLES = [
    "super_admin", "admin", "sales_manager", "mr", "distributor", "cf",
    "medical_shop", "customer_support", "marketing", "accounts", "view_only",
]

ROLE_LABELS = {
    "super_admin": "Super Admin", "admin": "Admin", "sales_manager": "Sales Manager",
    "mr": "MR / Sales Representative", "distributor": "Distributor", "cf": "C&F",
    "medical_shop": "Medical Shop", "customer_support": "Customer Support",
    "marketing": "Marketing", "accounts": "Accounts", "view_only": "View Only",
}

MODULES = [
    "dashboard", "inbox", "crm", "leads", "contacts", "sales", "whatsapp",
    "campaigns", "automation", "chatbot", "ivr", "catalog", "orders", "payments",
    "tasks", "recruitment", "field_sales", "portal", "extension", "ads", "integrations", "reports", "settings",
]

ALL = ["view", "create", "edit", "delete", "export", "send", "approve", "assign", "manage"]

# Base permission matrix per role. "*" means all modules/actions.
ROLE_PERMISSIONS: dict[str, dict] = {
    "super_admin": {"*": ALL},
    "admin": {"*": ALL},
    "sales_manager": {m: ALL for m in [
        "dashboard", "inbox", "crm", "leads", "contacts", "sales", "whatsapp",
        "campaigns", "catalog", "orders", "payments", "tasks", "recruitment", "field_sales", "reports"]},
    "mr": {m: ["view", "create", "edit", "send", "assign"] for m in [
        "dashboard", "inbox", "crm", "leads", "contacts", "whatsapp", "catalog",
        "orders", "tasks", "field_sales"]},
    "marketing": {m: ALL for m in ["dashboard", "campaigns", "leads", "contacts", "whatsapp", "chatbot", "ivr", "recruitment", "reports"]},
    "customer_support": {m: ["view", "create", "edit", "send", "assign"] for m in [
        "dashboard", "inbox", "crm", "contacts", "whatsapp", "tasks"]},
    "accounts": {m: ["view", "export"] for m in ["dashboard", "orders", "payments", "reports"]},
    "distributor": {m: ["view", "create"] for m in ["dashboard", "catalog", "orders", "payments", "inbox"]},
    "cf": {m: ["view", "edit"] for m in ["dashboard", "orders", "catalog", "reports"]},
    "medical_shop": {m: ["view", "create"] for m in ["dashboard", "catalog", "orders", "inbox"]},
    "view_only": {m: ["view"] for m in MODULES},
}

# Distributor / C&F / Medical Shop see their own orders + ledger via the portal.
ROLE_PERMISSIONS["mr"]["sales"] = ["view", "create"]
for _r in ("distributor", "cf", "medical_shop"):
    ROLE_PERMISSIONS[_r]["portal"] = ["view"]
ROLE_PERMISSIONS["sales_manager"]["portal"] = ALL


ROLE_DEFINITIONS = {}


async def refresh_role_definitions():
    records = await db.roles.find({}, {"_id": 0}).to_list(1000)
    ROLE_DEFINITIONS.clear()
    ROLE_DEFINITIONS.update({r["key"]: r for r in records})


def role_registry():
    result = {r: {"key": r, "label": ROLE_LABELS[r]} for r in ROLES}
    for key, record in ROLE_DEFINITIONS.items():
        if record.get("deleted"):
            result.pop(key, None)
        else:
            result[key] = record
    return result


def permissions_for(role: str) -> dict:
    override = ROLE_DEFINITIONS.get(role)
    perms = ({} if override.get("deleted") else override["permissions"]) if override else ROLE_PERMISSIONS.get(role, {"dashboard": ["view"]})
    if "*" in perms:
        return {m: list(ALL) for m in MODULES}
    resolved = {m: list(perms.get(m, [])) for m in MODULES}
    # 'crm' and 'contacts' are synonyms (the Contacts UI lives under both routes).
    synonyms = [("crm", "contacts")]
    for a, b in synonyms:
        merged = resolved.get(a) or resolved.get(b) or []
        if merged:
            resolved[a] = list(merged)
            resolved[b] = list(merged)
    return resolved


# ---- Password helpers ------------------------------------------------------
def hash_password(password: str) -> str:
    return bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")


def verify_password(plain: str, hashed: str) -> bool:
    try:
        return bcrypt.checkpw(plain.encode("utf-8"), hashed.encode("utf-8"))
    except Exception:
        return False


def _secret() -> str:
    return os.environ["JWT_SECRET"]


def create_access_token(user_id: str, email: str, role: str) -> str:
    payload = {
        "sub": user_id, "email": email, "role": role, "type": "access",
        "exp": utcnow() + timedelta(minutes=ACCESS_TTL_MIN),
    }
    return jwt.encode(payload, _secret(), algorithm=JWT_ALGORITHM)


def public_user(u: dict) -> dict:
    u = dict(u)
    u.pop("_id", None)
    u.pop("password_hash", None)
    u["permissions"] = permissions_for(u.get("role", "view_only"))
    u["role_label"] = role_registry().get(u.get("role"), {}).get("label", u.get("role", ""))
    return u


async def get_current_user(request: Request) -> dict:
    token = None
    auth_header = request.headers.get("Authorization", "")
    if auth_header.startswith("Bearer "):
        token = auth_header[7:]
    if not token:
        token = request.cookies.get("access_token")
    if not token:
        raise HTTPException(status_code=401, detail="Not authenticated")
    try:
        payload = jwt.decode(token, _secret(), algorithms=[JWT_ALGORITHM])
        if payload.get("type") != "access":
            raise HTTPException(status_code=401, detail="Invalid token type")
        user = await db.users.find_one({"id": payload["sub"]}, {"_id": 0})
        if not user or user.get("deleted") or not user.get("active", True):
            raise HTTPException(status_code=401, detail="User not found")
        await refresh_role_definitions()
        return user
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token expired")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Invalid token")


def require_perm(module: str, action: str = "view"):
    async def checker(user: dict = Depends(get_current_user)) -> dict:
        perms = permissions_for(user.get("role", "view_only"))
        if action not in perms.get(module, []):
            raise HTTPException(status_code=403, detail=f"Missing permission: {module}:{action}")
        return user
    return checker


# ---- Schemas ---------------------------------------------------------------
class RegisterIn(BaseModel):
    name: str
    email: EmailStr
    password: str = Field(min_length=6)
    role: str = "mr"


class LoginIn(BaseModel):
    email: EmailStr
    password: str


class ForgotIn(BaseModel):
    email: EmailStr


class ResetIn(BaseModel):
    token: str
    password: str = Field(min_length=6)


class SendOtpIn(BaseModel):
    identifier: str  # phone or email
    channel: str = "whatsapp"  # whatsapp | sms | email
    purpose: str = "login"


class VerifyOtpIn(BaseModel):
    identifier: str
    code: str = Field(pattern=r"^\d{6}$")
    purpose: str = "login"
    channel: str | None = None
    otp_id: str | None = Field(default=None, max_length=64)


router = APIRouter(prefix="/api/auth", tags=["auth"])


def _client_ip(request: Request) -> str:
    return request.headers.get("x-forwarded-for", request.client.host if request.client else "unknown").split(",")[0]


@router.post("/register")
async def register(body: RegisterIn, request: Request):
    email = body.email.lower()
    if await db.users.find_one({"email": email}):
        raise HTTPException(status_code=400, detail="Email already registered")
    role = body.role if body.role in ROLES else "mr"
    # SECURITY: never trust a client-supplied privileged role on public self-registration.
    if role in ("super_admin", "admin"):
        role = "view_only"
    user = {
        "id": new_id(), "name": body.name, "email": email,
        "password_hash": hash_password(body.password), "role": role,
        "active": True, "is_demo": False, "avatar": None, "phone": None,
        "created_at": now_iso(), "updated_at": now_iso(),
    }
    await db.users.insert_one(user)
    await log_audit(user, "register", "settings", user["id"], ip=_client_ip(request))
    token = create_access_token(user["id"], email, role)
    return {"token": token, "user": public_user(user)}


@router.post("/login")
async def login(body: LoginIn, request: Request):
    email = body.email.lower()
    ip = _client_ip(request)
    ident = f"{ip}:{email}"
    attempt = await db.login_attempts.find_one({"identifier": ident})
    if attempt and attempt.get("count", 0) >= 5:
        locked_until = attempt.get("locked_until")
        if locked_until and datetime.fromisoformat(locked_until) > utcnow():
            raise HTTPException(status_code=429, detail="Too many attempts. Try again in a few minutes.")
    public_default_in_production = is_production() and (
        is_public_default_admin_credentials(email, body.password)
        or is_public_default_admin_password(body.password)
    )
    user = None if public_default_in_production else await db.users.find_one({"email": email})
    if not user or not verify_password(body.password, user.get("password_hash", "")):
        count = (attempt.get("count", 0) if attempt else 0) + 1
        await db.login_attempts.update_one(
            {"identifier": ident},
            {"$set": {"identifier": ident, "count": count,
                      "locked_until": (utcnow() + timedelta(minutes=15)).isoformat() if count >= 5 else None}},
            upsert=True,
        )
        await log_audit(user, "login", "settings", result="failed", ip=ip, detail=email)
        raise HTTPException(status_code=401, detail="Invalid email or password")
    await db.login_attempts.delete_one({"identifier": ident})
    if not user.get("active", True):
        raise HTTPException(status_code=403, detail="Account disabled")
    await log_audit(user, "login", "settings", user["id"], ip=ip)
    token = create_access_token(user["id"], email, user["role"])
    return {"token": token, "user": public_user(user)}


@router.get("/me")
async def me(user: dict = Depends(get_current_user)):
    return public_user(user)


@router.post("/logout")
async def logout(user: dict = Depends(get_current_user)):
    await log_audit(user, "logout", "settings", user["id"])
    return {"ok": True}


@router.post("/forgot-password")
async def forgot_password(body: ForgotIn):
    user = await db.users.find_one({"email": body.email.lower()})
    # Always respond ok (no user enumeration)
    if user:
        token = secrets.token_urlsafe(32)
        await db.password_reset_tokens.insert_one({
            "id": new_id(), "token": token, "user_id": user["id"],
            "expires_at": (utcnow() + timedelta(hours=1)).isoformat(),
            "used": False, "created_at": now_iso(),
        })
    return {"ok": True, "message": "If the email exists, a reset link has been generated."}


@router.post("/reset-password")
async def reset_password(body: ResetIn):
    rec = await db.password_reset_tokens.find_one({"token": body.token, "used": False})
    if not rec or datetime.fromisoformat(rec["expires_at"]) < utcnow():
        raise HTTPException(status_code=400, detail="Invalid or expired reset token")
    await db.users.update_one({"id": rec["user_id"]},
                              {"$set": {"password_hash": hash_password(body.password), "updated_at": now_iso()}})
    await db.password_reset_tokens.update_one({"id": rec["id"]}, {"$set": {"used": True}})
    return {"ok": True}


# ---- OTP -------------------------------------------------------------------
def _hash_code(code: str) -> str:
    return hashlib.sha256(code.encode()).hexdigest()


@router.post("/send-otp")
async def send_otp(body: SendOtpIn, request: Request):
    if body.channel == "email" and body.purpose == "login":
        from otp_login import send_login_otp
        return await send_login_otp(body, request)
    if body.channel == "email":
        from otp_login import normalize_email, reserve_send_budget
        body.identifier = normalize_email(body.identifier)
        await reserve_send_budget(body.identifier, request)
    recent = await db.otp_requests.find_one(
        {"identifier": body.identifier, "purpose": body.purpose},
        sort=[("created_at", -1)],
    )
    if recent and recent.get("created_at"):
        delta = (utcnow() - datetime.fromisoformat(recent["created_at"])).total_seconds()
        if delta < 30:
            raise HTTPException(status_code=429, detail=f"Please wait {int(30 - delta)}s before resending")

    from integrations import integration_status, send_whatsapp_otp, send_email_otp
    from wa_client import wa_connected, wa_send
    status = integration_status()
    wa_live = await wa_connected()
    channel_ready = {
        "whatsapp": status["whatsapp"]["configured"] or wa_live,
        "sms": status["sms"]["configured"],
        "email": status["brevo"]["configured"],
    }.get(body.channel, False)

    if not channel_ready and is_production():
        raise HTTPException(
            status_code=503,
            detail=f"{body.channel.title()} OTP delivery is not configured.",
        )

    code = f"{secrets.randbelow(1_000_000):06d}"
    rec = {
        "id": new_id(), "identifier": body.identifier, "channel": body.channel,
        "purpose": body.purpose, "code_hash": _hash_code(code),
        "expires_at": (utcnow() + timedelta(minutes=5)).isoformat(),
        "verified": False, "attempts": 0, "created_at": now_iso(),
    }
    await db.otp_requests.insert_one(rec)
    await log_audit(None, "send_otp", "whatsapp", detail=f"{body.channel}:{body.identifier}", ip=_client_ip(request))

    if channel_ready:
        try:
            if body.channel == "whatsapp":
                if wa_live:
                    await wa_send(body.identifier, f"Your VGRUPS CONNECT verification code is {code}. Valid for 5 minutes.")
                else:
                    await send_whatsapp_otp(body.identifier, code)
            elif body.channel == "email":
                await send_email_otp(body.identifier, code)
            # sms provider abstraction not configured -> handled above
            return {"ok": True, "demo_mode": False, "channel": body.channel,
                    "message": f"OTP sent via {body.channel}"}
        except Exception as e:
            raise HTTPException(status_code=502, detail=f"Failed to send OTP: {e}")

    # Demo mode — provider not configured. Return code so the flow is testable.
    return {"ok": True, "demo_mode": True, "channel": body.channel, "demo_code": code,
            "message": f"{body.channel.title()} provider not configured. Demo OTP shown for testing."}


@router.post("/verify-otp")
async def verify_otp(body: VerifyOtpIn, request: Request = None):
    if body.channel == "email" and body.purpose == "login":
        from otp_login import verify_login_otp
        return await verify_login_otp(body, request)
    rec = await db.otp_requests.find_one(
        {"identifier": body.identifier, "purpose": body.purpose, "verified": False, "login_method": {"$ne": "email_otp"}},
        sort=[("created_at", -1)],
    )
    if not rec:
        raise HTTPException(status_code=400, detail="No OTP request found")
    if datetime.fromisoformat(rec["expires_at"]) < utcnow():
        raise HTTPException(status_code=400, detail="OTP expired")
    if rec.get("attempts", 0) >= 5:
        raise HTTPException(status_code=429, detail="Too many attempts")
    if rec["code_hash"] != _hash_code(body.code):
        await db.otp_requests.update_one({"id": rec["id"]}, {"$inc": {"attempts": 1}})
        raise HTTPException(status_code=400, detail="Invalid OTP")
    await db.otp_requests.update_one({"id": rec["id"]}, {"$set": {"verified": True}})
    return {"ok": True, "verified": True}


async def seed_admin():
    admin_email, admin_password, admin_name = admin_seed_credentials()
    existing = await db.users.find_one({"email": admin_email})
    if existing is None:
        await db.users.insert_one({
            "id": new_id(), "name": admin_name, "email": admin_email,
            "password_hash": hash_password(admin_password), "role": "super_admin",
            "active": True, "is_demo": False, "avatar": None, "phone": None,
            "created_at": now_iso(), "updated_at": now_iso(),
        })
    elif not verify_password(admin_password, existing.get("password_hash", "")):
        await db.users.update_one({"email": admin_email},
                                  {"$set": {"password_hash": hash_password(admin_password),
                                            "role": "super_admin"}})
