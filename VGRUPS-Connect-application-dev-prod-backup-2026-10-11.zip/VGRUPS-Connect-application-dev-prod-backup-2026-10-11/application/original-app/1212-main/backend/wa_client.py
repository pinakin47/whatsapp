import os
import httpx

WA_URL = os.environ.get("WA_SERVICE_URL", "http://127.0.0.1:3001")


async def _client():
    return httpx.AsyncClient(base_url=WA_URL, timeout=20)


async def wa_list_sessions() -> dict:
    try:
        async with httpx.AsyncClient(base_url=WA_URL, timeout=10) as c:
            r = await c.get("/sessions")
            return r.json()
    except Exception:
        return {"sessions": [], "connected": False, "service_down": True}


async def wa_connected() -> bool:
    data = await wa_list_sessions()
    return bool(data.get("connected"))


async def wa_create_session(name: str) -> dict:
    async with httpx.AsyncClient(base_url=WA_URL, timeout=30) as c:
        r = await c.post("/sessions", json={"name": name})
        r.raise_for_status()
        return r.json()


async def wa_get_session(sid: str) -> dict:
    async with httpx.AsyncClient(base_url=WA_URL, timeout=10) as c:
        r = await c.get(f"/sessions/{sid}")
        return r.json()


async def wa_logout(sid: str) -> dict:
    async with httpx.AsyncClient(base_url=WA_URL, timeout=20) as c:
        r = await c.post(f"/sessions/{sid}/logout")
        return r.json()


async def wa_delete(sid: str) -> dict:
    async with httpx.AsyncClient(base_url=WA_URL, timeout=20) as c:
        r = await c.delete(f"/sessions/{sid}")
        return r.json()


async def wa_reconnect(sid: str) -> dict:
    async with httpx.AsyncClient(base_url=WA_URL, timeout=20) as c:
        r = await c.post(f"/sessions/{sid}/reconnect")
        return r.json()


async def wa_send(to: str, text: str, request_id: str | None = None, session_id: str | None = None) -> dict:
    """Send only through an explicitly chosen or configured general QR number."""
    if not session_id:
        from db import db
        from whatsapp_routing import sender
        session_id = (await sender(db))["id"]
    async with httpx.AsyncClient(base_url=WA_URL, timeout=30) as c:
        payload = {"to": to, "text": text}
        if request_id:
            payload["request_id"] = request_id
        if session_id:
            payload["session_id"] = session_id
        r = await c.post("/send", json=payload)
        if r.is_error:
            try:
                detail = r.json().get("error", r.text)
            except Exception:
                detail = r.text
            raise Exception(detail)
        return r.json()


async def wa_send_media(to: str, url: str, content_type: str, filename: str, caption: str, session_id: str | None = None,
                        request_id: str | None = None, media_key: str | None = None) -> dict:
    if not session_id:
        from db import db
        from whatsapp_routing import sender
        session_id = (await sender(db))["id"]
    async with httpx.AsyncClient(base_url=WA_URL, timeout=60) as client:
        response = await client.post("/send-media", json={"to": to, "url": url,
            "content_type": content_type, "filename": filename, "caption": caption, "session_id": session_id,
            "request_id": request_id, "media_key": media_key})
        response.raise_for_status()
        return response.json()
