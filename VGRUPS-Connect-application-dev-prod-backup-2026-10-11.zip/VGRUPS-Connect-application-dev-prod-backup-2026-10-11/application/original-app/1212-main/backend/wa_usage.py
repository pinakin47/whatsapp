"""WhatsApp number-health: warm-up ramp + daily send-limit guard."""
from datetime import datetime
from db import db, utcnow

# Warm-up ramp by number age (days since first linked). Day 5+ => full cap.
WARMUP = {1: 40, 2: 80, 3: 150, 4: 300}
DAILY_CAP = 500


def _today() -> str:
    return utcnow().strftime("%Y-%m-%d")


def warmup_day(created_at: str | None) -> int:
    if not created_at:
        return 99
    try:
        c = datetime.fromisoformat(created_at)
    except Exception:
        return 99
    return max(1, (utcnow() - c).days + 1)


def daily_limit(created_at: str | None) -> int:
    d = warmup_day(created_at)
    return WARMUP.get(d, DAILY_CAP)


async def connected_session(session_id=None, database=None) -> dict | None:
    from whatsapp_routing import sender_or_none
    return await sender_or_none(database if database is not None else db, session_id=session_id)


async def usage_today(phone: str) -> int:
    doc = await db.wa_daily_usage.find_one({"phone": phone, "date": _today()})
    return doc["count"] if doc else 0


async def inc_usage(phone: str, n: int = 1):
    await db.wa_daily_usage.update_one(
        {"phone": phone, "date": _today()},
        {"$inc": {"count": n}, "$setOnInsert": {"phone": phone, "date": _today()}},
        upsert=True,
    )


async def health_report() -> list[dict]:
    out = []
    async for s in db.wa_sessions.find({"status": "connected"}, {"_id": 0}):
        phone = s.get("phone")
        if not phone:
            continue
        used = await usage_today(phone)
        limit = daily_limit(s.get("created_at"))
        out.append({
            "session_id": s["id"], "name": s.get("name"), "phone": phone,
            "warmup_day": warmup_day(s.get("created_at")),
            "daily_limit": limit, "sent_today": used,
            "remaining": max(0, limit - used),
            "healthy": used < limit,
        })
    return out
