from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from db import db, new_id, now_iso, log_audit
from auth import require_perm, permissions_for

router = APIRouter(prefix="/api/campaign-groups", tags=["contact groups"])


class GroupIn(BaseModel):
    name: str = Field(min_length=1, max_length=120)
    contact_ids: list[str] = Field(min_length=1, max_length=5000)


async def validate_group(body, actor):
    if "view" not in permissions_for(actor["role"]).get("crm", []):
        raise HTTPException(403, "Contact view permission is required to manage contact groups.")
    if not body.name.strip():
        raise HTTPException(422, "Group name cannot be blank.")
    ids = list(dict.fromkeys(body.contact_ids))
    contacts = await db.contacts.find({"id": {"$in": ids}, "deleted": {"$ne": True},
                                      "is_demo": {"$ne": True}}, {"id": 1, "_id": 0}).to_list(5000)
    if {c["id"] for c in contacts} != set(ids):
        raise HTTPException(422, "Select existing real contacts only.")
    return ids


@router.get("")
async def groups(actor=Depends(require_perm("campaigns", "view"))):
    if "view" not in permissions_for(actor["role"]).get("crm", []):
        raise HTTPException(403, "Contact view permission is required.")
    return {"items": await db.campaign_groups.find({"deleted": {"$ne": True}}, {"_id": 0}).sort("name", 1).to_list(1000)}


@router.post("")
async def create(body: GroupIn, actor=Depends(require_perm("campaigns", "create"))):
    ids = await validate_group(body, actor)
    doc = {"id": new_id(), "name": body.name.strip(), "contact_ids": ids,
           "created_by": actor["id"], "created_at": now_iso(), "updated_at": now_iso()}
    await db.campaign_groups.insert_one(doc)
    await log_audit(actor, "create", "campaigns", doc["id"], detail="Contact group")
    return doc


@router.put("/{gid}")
async def edit(gid: str, body: GroupIn, actor=Depends(require_perm("campaigns", "edit"))):
    ids = await validate_group(body, actor)
    doc = await db.campaign_groups.find_one({"id": gid, "deleted": {"$ne": True}}, {"_id": 0})
    if not doc:
        raise HTTPException(404, "Group not found.")
    fields = {"name": body.name.strip(), "contact_ids": ids, "updated_at": now_iso()}
    await db.campaign_groups.update_one({"id": gid}, {"$set": fields})
    await log_audit(actor, "edit", "campaigns", gid, detail="Contact group")
    return {**doc, **fields}


@router.delete("/{gid}")
async def remove(gid: str, actor=Depends(require_perm("campaigns", "delete"))):
    if not await db.campaign_groups.find_one({"id": gid, "deleted": {"$ne": True}}):
        raise HTTPException(404, "Group not found.")
    await db.campaign_groups.update_one({"id": gid}, {"$set": {"deleted": True, "updated_at": now_iso()}})
    await log_audit(actor, "delete", "campaigns", gid, detail="Contact group removed; queued recipient snapshots retained")
    return {"ok": True}