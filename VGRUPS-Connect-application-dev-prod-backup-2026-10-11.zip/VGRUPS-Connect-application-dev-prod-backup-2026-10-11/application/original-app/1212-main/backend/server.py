import asyncio
import logging
import os

from fastapi import FastAPI
from starlette.middleware.cors import CORSMiddleware

from db import db
from auth import router as auth_router, seed_admin, refresh_role_definitions
from routes_crm import router as crm_router
from routes_contact_actions import router as contact_actions_router
from contact_catalogue import start_contact_catalogues
from routes_whatsapp import router as whatsapp_router, webhook_router
from routes_platform import router as platform_router
from routes_wa import router as wa_router
from routes_campaigns import router as campaigns_router, start_campaign_engine
from routes_campaign_reports import router as campaign_reports_router
from routes_bot import router as bot_router
from routes_automations import router as automations_router
from routes_orders import router as orders_router
from routes_chatbot import router as chatbot_router
from routes_recruitment import router as recruitment_router
from routes_ivr import router as ivr_router
from routes_mr_settings import router as mr_settings_router, start_mr_reminders
from routes_mr_reporting import router as mr_reporting_router, start_mr_reporting
from routes_mr_workspace import router as mr_workspace_router, start_mr_coaching
from routes_ads import router as ads_router
from routes_ext import router as ext_router
from routes_field import router as field_router
from routes_lead_capture import router as lead_capture_router
from lead_capture_worker import start_lead_capture
from mr_ai_replies import start_mr_ai_replies
from mr_automation_defaults import ensure_automatic_mrs
from routes_catalog_files import router as catalog_files_router
from routes_sales import router as sales_router
from mr_catalog_daily import start_mr_catalog
from demo_cleanup import remove_all_demo_data
import storage

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s")
logger = logging.getLogger("vgrups")


class PrivateQueryFilter(logging.Filter):
    def filter(self, record):
        # Access logs must not expose signed voice callbacks or customer search terms.
        if isinstance(record.args, tuple) and len(record.args) == 5:
            args = list(record.args)
            args[2] = str(args[2]).split("?", 1)[0]
            record.args = tuple(args)
        return True


logging.getLogger("uvicorn.access").addFilter(PrivateQueryFilter())

app = FastAPI(title="VGRUPS CONNECT API")

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=os.environ.get("CORS_ORIGINS", "*").split(","),
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/")
async def health():
    return {"status": "ok"}


@app.get("/api/")
async def root():
    return {"service": "VGRUPS CONNECT", "status": "ok"}


app.include_router(auth_router)
app.include_router(mr_reporting_router)
app.include_router(mr_workspace_router)
app.include_router(contact_actions_router)
app.include_router(crm_router)
app.include_router(whatsapp_router)
app.include_router(webhook_router)
app.include_router(platform_router)
from routes_settings import router as settings_router
app.include_router(settings_router)
from campaign_groups import router as campaign_groups_router
from campaign_media import router as campaign_media_router
app.include_router(campaign_groups_router)
app.include_router(campaign_media_router)
app.include_router(wa_router)
app.include_router(campaigns_router)
app.include_router(campaign_reports_router)
app.include_router(bot_router)
app.include_router(automations_router)
app.include_router(orders_router)
app.include_router(chatbot_router)
app.include_router(recruitment_router)
app.include_router(ivr_router)
app.include_router(mr_settings_router)
app.include_router(ads_router)
app.include_router(ext_router)
app.include_router(field_router)
app.include_router(lead_capture_router)
app.include_router(catalog_files_router)
app.include_router(sales_router)


@app.on_event("startup")
async def startup():
    await db.connect()
    await seed_admin()
    await refresh_role_definitions()
    await ensure_automatic_mrs(db)
    removed = await remove_all_demo_data(db)
    logger.info("Removed explicitly marked demo records by module: %s", removed)
    try:
        await asyncio.to_thread(storage.init_storage)
        logger.info("Object storage initialized")
    except Exception as e:
        logger.warning(f"storage init warn: {e}")
    asyncio.create_task(start_campaign_engine())
    asyncio.create_task(start_mr_reminders())
    asyncio.create_task(start_mr_reporting())
    asyncio.create_task(start_mr_coaching())
    asyncio.create_task(start_lead_capture())
    asyncio.create_task(start_mr_ai_replies())
    asyncio.create_task(start_mr_catalog())
    asyncio.create_task(start_contact_catalogues())
    logger.info("VGRUPS CONNECT startup complete")


@app.on_event("shutdown")
async def shutdown():
    await db.close()
