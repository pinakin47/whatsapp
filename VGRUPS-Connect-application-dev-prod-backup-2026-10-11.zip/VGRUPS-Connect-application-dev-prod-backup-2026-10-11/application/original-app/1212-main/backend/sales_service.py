"""Sales-only storage and bounded, server-side reporting on the existing database."""
import hashlib
import json
import re
from datetime import date, datetime
from decimal import Decimal, ROUND_HALF_UP
from zoneinfo import ZoneInfo

from fastapi import HTTPException
from auth import permissions_for
from db import now_iso
from postgres_query import Query
from postgres_store import ReturnDocument

IST = ZoneInfo("Asia/Kolkata")
REAL = {"deleted": {"$ne": True}, "is_demo": {"$ne": True}}
STATUSES = ("Submitted", "Confirmed", "Processing", "Completed", "Cancelled")


def is_admin(user):
    return user.get("role") in ("admin", "super_admin")


def scope(user, mr_id=None):
    if not is_admin(user) and mr_id and mr_id != user["id"]:
        raise HTTPException(403, "You can view only your own sales.")
    return {**REAL, **({"mr_id": mr_id} if mr_id else
                      ({} if is_admin(user) else {"mr_id": user["id"]}))}


def filters(user, q="", date_from=None, date_to=None, mr_id=None, customer="",
            product_id=None, status=None):
    query = scope(user, mr_id)
    if status:
        if status not in STATUSES:
            raise HTTPException(422, "Invalid sale status.")
        query["status"] = status
    dates = {}
    for key, value in (("$gte", date_from), ("$lte", date_to)):
        if value:
            try:
                if date.fromisoformat(value).isoformat() != value:
                    raise ValueError()
            except ValueError:
                raise HTTPException(422, "Dates must be valid YYYY-MM-DD values.")
            dates[key] = value
    if date_from and date_to and date_from > date_to:
        raise HTTPException(422, "End date must not precede start date.")
    if dates:
        query["sale_date"] = dates
    if q.strip():
        query["search_text"] = {"$regex": re.escape(q.strip()), "$options": "i"}
    if customer.strip():
        query["customer_name"] = {"$regex": re.escape(customer.strip()), "$options": "i"}
    if product_id:
        query["product_ids"] = product_id
    return query


def public(sale):
    return {k: v for k, v in sale.items() if k not in
            ("_id", "request_fingerprint", "request_key", "search_text", "product_ids", "audit")}


def fingerprint(body):
    payload = body.model_dump(mode="json", exclude={"request_key"})
    return hashlib.sha256(json.dumps(payload, sort_keys=True).encode()).hexdigest()


async def owned(database, sale_id, user):
    sale = await database.sales.find_one({"id": sale_id, **scope(user)}, {"_id": 0})
    if not sale:
        raise HTTPException(404, "Sale not found.")
    return sale


async def build_items(database, inputs, previous=None):
    old = {i["product_id"]: i for i in (previous or {}).get("items", [])}
    products = await database.products.find({
        "id": {"$in": list({i.product_id for i in inputs})},
        "active": {"$ne": False}, **REAL}, {"_id": 0}).to_list(100)
    catalog = {p["id"]: p for p in products}
    built = []
    for item in inputs:
        product = catalog.get(item.product_id)
        if not product and item.product_id not in old:
            raise HTTPException(422, "Selected product is no longer available in Catalog.")
        source = product or old[item.product_id]
        price = Decimal(item.unit_price).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
        total = (price * item.quantity).quantize(Decimal("0.01"))
        built.append({"product_id": item.product_id,
                      "product_name": source.get("name") or source.get("product_name") or "Product",
                      "quantity": item.quantity, "unit_price": float(price), "line_total": float(total)})
    total = sum((Decimal(str(i["line_total"])) for i in built), Decimal("0"))
    return {"items": built, "quantity": sum(i["quantity"] for i in built),
            "subtotal": float(total), "grand_total": float(total),
            "product_ids": list(dict.fromkeys(i["product_id"] for i in built))}


def searchable(doc):
    return " ".join(str(doc.get(k) or "") for k in
                    ("sale_id", "customer_name", "phone", "mr_name")) + " " + " ".join(
                        i["product_name"] for i in doc["items"])


def audit(user, action, detail):
    return {"action": action, "user_id": user["id"], "user_name": user.get("name", ""),
            "created_at": now_iso(), "detail": detail}


async def create(database, body, user):
    # Deterministic opaque ID makes retry/upsert atomic without a second collection.
    record_id = hashlib.sha256(f'{user["id"]}:{body.request_key}'.encode()).hexdigest()
    digest = fingerprint(body)
    existing = await database.sales.find_one({"id": record_id}, {"_id": 0})
    if existing:
        if existing.get("request_fingerprint") != digest:
            raise HTTPException(409, "This save key was already used for a different sale.")
        if existing.get("deleted"):
            raise HTTPException(409, "This sale was removed. Refresh before creating a new sale.")
        return public(existing)
    day = datetime.now(IST).date().isoformat()
    doc = {"id": record_id, "sale_id": f"SAL-{day.replace('-', '')}-{record_id[:16].upper()}",
           "mr_id": user["id"], "mr_name": user.get("name", ""),
           "created_by": user["id"], "created_by_name": user.get("name", ""),
           "customer_name": body.customer_name, "phone": body.phone,
           "email": str(body.email) if body.email else None, "address": body.address,
           **await build_items(database, body.items), "status": "Submitted",
           "created_at": now_iso(), "updated_at": now_iso(), "sale_date": day,
           "revision": 1, "request_fingerprint": digest,
           "audit": [audit(user, "created", "Sale submitted.")]}
    doc["search_text"] = searchable(doc)
    saved = await database.sales.find_one_and_update(
        {"id": record_id}, {"$setOnInsert": doc}, upsert=True, return_document=ReturnDocument.AFTER)
    if saved.get("request_fingerprint") != digest:
        raise HTTPException(409, "This save key was already used for a different sale.")
    return public(saved)


async def change(database, sale_id, body, user, remove=False):
    sale = await owned(database, sale_id, user)
    action = "delete" if remove else "edit"
    if action not in permissions_for(user["role"]).get("sales", []):
        raise HTTPException(403, f"Sales {action} permission required.")
    fields = {"updated_at": now_iso()}
    description = "Sale removed; audit and original record retained." if remove else "Sale updated."
    if remove:
        fields["deleted"] = True
    else:
        patch = body.model_dump(exclude_unset=True, exclude={"revision"})
        if "status" in patch:
            fields["status"] = patch["status"]
            description = f'Status: {sale["status"]} → {patch["status"]}.'
        if body.customer_name is not None:
            fields.update(customer_name=body.customer_name, phone=body.phone,
                          email=str(body.email) if body.email else None, address=body.address)
            fields.update(await build_items(database, body.items, sale))
            fields["search_text"] = searchable({**sale, **fields})
            description += " Customer/product values recalculated on server."
    revision = body if remove else body.revision
    event = audit(user, "deleted" if remove else "updated", description)
    event["changes"] = {key: {"before": sale.get(key), "after": value}
                        for key, value in fields.items()
                        if key not in ("updated_at", "search_text", "product_ids") and sale.get(key) != value}
    fields["audit"] = [*sale.get("audit", []), event]
    updated = await database.sales.find_one_and_update(
        {"id": sale_id, "revision": revision, **scope(user)},
        {"$set": fields, "$inc": {"revision": 1}},
        return_document=ReturnDocument.AFTER)
    if not updated:
        raise HTTPException(409, "Sale changed in another session. Refresh before editing.")
    return public(updated)


async def company(database):
    # Never invent company contact information.
    saved = await database.app_config.find_one({"key": "company"}, {"_id": 0})
    value = (saved or {}).get("value") or {}
    if not isinstance(value, dict):
        value = {}
    return {"name": value.get("name") or value.get("company_name") or "VGRUPS HEALTHCARE",
            **{k: value.get(k) or "" for k in ("address", "phone", "email")}}


async def report(database, query, user):
    """Aggregate in PostgreSQL, not the document adapter's in-memory aggregate."""
    sql_query = Query("sales")
    where = sql_query.where(query)
    day = datetime.now(IST).date().isoformat()
    day_param = sql_query.param(day)
    month_param = sql_query.param(day[:7])
    pool = await database.connect()
    row = await pool.fetchrow(
        f"""SELECT count(*) AS count,
        COALESCE(sum((document->>'grand_total')::numeric),0) AS total_value,
        COALESCE(sum((document->>'grand_total')::numeric) FILTER
          (WHERE document->>'sale_date'={day_param}),0) AS today_value,
        COALESCE(sum((document->>'grand_total')::numeric) FILTER
          (WHERE left(document->>'sale_date',7)={month_param}),0) AS month_value
        FROM app_documents WHERE {where}""", *sql_query.params)
    summary = {k: int(row[k]) if k == "count" else float(row[k])
               for k in ("count", "total_value", "today_value", "month_value")}
    summary["active_mrs"] = await database.users.count_documents({
        "role": "mr", "active": {"$ne": False}, **REAL}) if is_admin(user) else None
    aggregate_query = Query("sales")
    aggregate_where = aggregate_query.where(query)
    customers = await pool.fetch(
        f"""SELECT document->>'customer_name' AS name, count(*) AS count,
        sum((document->>'grand_total')::numeric) AS value
        FROM app_documents WHERE {aggregate_where}
        GROUP BY document->>'customer_name' ORDER BY value DESC LIMIT 51""",
        *aggregate_query.params)
    products = await pool.fetch(
        f"""SELECT item->>'product_id' AS id, item->>'product_name' AS name,
        sum((item->>'line_total')::numeric) AS value,
        sum((item->>'quantity')::numeric) AS quantity
        FROM app_documents CROSS JOIN LATERAL jsonb_array_elements(document->'items') item
        WHERE {aggregate_where} GROUP BY item->>'product_id',item->>'product_name'
        ORDER BY value DESC LIMIT 51""", *aggregate_query.params)
    return {"summary": summary, "customer_sales": [
        {"name": r["name"], "count": r["count"], "value": float(r["value"])} for r in customers[:50]],
        "product_sales": [{"id": r["id"], "name": r["name"], "value": float(r["value"]),
                           "quantity": int(r["quantity"])} for r in products[:50]],
        "breakdowns_truncated": len(customers) > 50 or len(products) > 50}
