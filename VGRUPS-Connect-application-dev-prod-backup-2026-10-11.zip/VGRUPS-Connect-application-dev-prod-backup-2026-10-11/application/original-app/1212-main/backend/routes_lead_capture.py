"""MR-owned leads, review queues, independent alerts and immutable WhatsApp evidence."""
import csv
import io
import os
import re
import time
from datetime import datetime, timedelta
from typing import Literal
from fastapi import APIRouter, Depends, HTTPException, Request, Query
from fastapi.responses import Response
from pydantic import BaseModel, Field, field_validator
from auth import require_perm, permissions_for
from db import db, now_iso
from lead_capture_core import (REAL, MANAGERS, DEFAULT_SETTINGS, settings_for, directory_account,
                               event, stable, notify_admins, complete_phone, queue_phone_requests, ingest, match_lead)
from lead_capture_extract import mobile, ai_ready, TYPES, IST, TEXT_FIELDS
from lead_capture_worker import capture_lock
from lead_capture_delivery import voice_ready, valid_voice_token
from routes_crm import LEAD_STATUSES

router = APIRouter(prefix="/api/lead-capture", tags=["MR WhatsApp Lead Capture"])


def allowed(user):
    if user["role"] not in (*MANAGERS, "mr"):
        raise HTTPException(403, "MR or authorized administrator access required")
    return user


def manager(user):
    allowed(user)
    if user["role"] not in MANAGERS:
        raise HTTPException(403, "Administrator access required")


def scope(user):
    allowed(user)
    return {**REAL, **({"assigned_to": user["id"]} if user["role"] == "mr" else {})}


async def lead_for(lid, user):
    row = await db.leads.find_one({"id": lid, **scope(user)}, {"_id": 0})
    if not row:
        raise HTTPException(404, "Lead not found or not accessible")
    return row


async def target_mr(lead):
    account = await db.users.find_one({"id": lead.get("assigned_to"), "active": {"$ne": False}, "role": "mr", **REAL})
    directory = await db.mr_directory.find_one({"email": (account or {}).get("email", ""), "active": True, **REAL})
    if not directory:
        directory = await db.mr_directory.find_one({"id": lead.get("mr_directory_id"), "active": True, **REAL})
    if not directory:
        raise HTTPException(409, "An active MR must be assigned before requesting a phone number")
    result = await directory_account(db, directory)
    if result["mr_id"] != lead.get("assigned_to"):
        raise HTTPException(409, "Assigned MR is unavailable")
    return result


class SettingsIn(BaseModel):
    enabled: bool = False
    authorized_messages_confirmed: bool = False
    ask_missing_phone: bool = False
    voice_enabled: bool = False
    ai_auto_reply: bool = False
    confirm_enable: bool = False


async def settings_response(user=None):
    config = await settings_for(db)
    activity = []
    if user and user["role"] in MANAGERS:
        collection = getattr(db, "mr_ai_replies", None)
        if collection is not None:
            rows = await collection.find({}).sort("created_at", -1).to_list(10)
            activity = [{k: row.get(k) for k in ("id", "mr_name", "status", "reply", "error", "created_at")} for row in rows]
    return {**config, "ai_configured": ai_ready(), "ai_reply_configured": bool(os.environ.get("OPENAI_API_KEY")),
            "ai_reply_activity": activity, "voice_status": "ready" if await voice_ready() else "not_connected"}


@router.get("/settings")
async def get_settings(user=Depends(require_perm("leads", "view"))):
    allowed(user)
    return await settings_response(user)


@router.put("/settings")
async def save_settings(body: SettingsIn, user=Depends(require_perm("settings", "manage"))):
    manager(user)
    old = await settings_for(db)
    activating = body.enabled and (not old["enabled"] or body.ask_missing_phone and not old["ask_missing_phone"] or body.voice_enabled and not old["voice_enabled"] or body.ai_auto_reply and not old["ai_auto_reply"])
    if body.enabled and not body.authorized_messages_confirmed:
        raise HTTPException(422, "Confirm authorized business-message processing first")
    if activating and not body.confirm_enable:
        raise HTTPException(422, "Explicitly confirm activation and automatic MR requests")
    if body.enabled and not all(a in permissions_for(user["role"]).get("leads", []) for a in ("create", "edit")):
        raise HTTPException(403, "Lead create and edit permissions are required for capture")
    if body.enabled and (body.ask_missing_phone or body.voice_enabled or body.ai_auto_reply) and "send" not in permissions_for(user["role"]).get("whatsapp", []):
        raise HTTPException(403, "WhatsApp send permission required for automatic MR requests")
    if body.enabled and body.ai_auto_reply and not os.environ.get("OPENAI_API_KEY"):
        raise HTTPException(422, "Configure your personal OpenAI key before enabling MR automatic replies")
    value = {**body.model_dump(exclude={"confirm_enable"}), "approved_by": user["id"],
             "enabled_since": (old.get("enabled_since") if old["enabled"] else now_iso()) if body.enabled else old.get("enabled_since"),
             "ai_reply_enabled_since": (old.get("ai_reply_enabled_since") if old["enabled"] and old["ai_auto_reply"] else now_iso()) if body.enabled and body.ai_auto_reply else old.get("ai_reply_enabled_since")}
    await db.app_config.update_one({"key": "mr_lead_capture"}, {"$set": {
        "key": "mr_lead_capture", "value": value, "updated_at": now_iso()}}, upsert=True)
    await event(db, "settings", now_iso(), "Capture Settings Updated", "Automatic capture " + ("enabled" if body.enabled else "disabled"), user["id"])
    return await settings_response(user)


@router.get("/options")
async def options(user=Depends(require_perm("leads", "view"))):
    allowed(user)
    rows = await db.mr_directory.find({"active": True, **REAL}, {"_id": 0}).sort("name", 1).to_list(None)
    mrs = []
    for row in rows:
        mr = await directory_account(db, row)
        if user["role"] != "mr" or mr["mr_id"] == user["id"]:
            mrs.append({k: mr[k] for k in ("id", "mr_id", "name", "employee_id")})
    p = permissions_for(user["role"])
    return {"mrs": mrs, "statuses": LEAD_STATUSES, "lead_types": TYPES,
            "priorities": ["normal", "high", "urgent"], "can_manage": user["role"] in MANAGERS,
            "can_export": user["role"] in MANAGERS and "export" in p.get("leads", []),
            "can_configure": user["role"] in MANAGERS and "manage" in p.get("settings", [])}


def filters(user, params):
    query = scope(user)
    view = params.get("view", "all")
    type_views = {"hospital": "Hospital", "doctor": "Doctor", "clinic": "Clinic", "pharmacy": "Pharmacy", "distributor": "Distributor"}
    if view not in ("all", "whatsapp", "new", "missing", "completed", "follow_up", "hot", "converted", "lost", *type_views):
        raise HTTPException(422, "Unknown lead view")
    if view in type_views:
        query["lead_type"] = type_views[view]
    if view != "all":
        query["source"] = "WhatsApp – MR"
    if view in ("new", "converted", "lost", "follow_up"):
        query["status"] = {"new": "new", "converted": "won", "lost": "lost", "follow_up": "follow_up"}[view]
    if view == "hot":
        query["priority"] = {"$in": ["high", "urgent"]}
    phone = params.get("phone")
    if view == "missing" or phone == "missing":
        query["mobile"] = {"$in": [None, ""]}
    elif view == "completed" or phone == "present":
        query["mobile"] = {"$nin": [None, ""]}
    for param, field in (("mr", "mr_directory_id"), ("status", "status"), ("priority", "priority"), ("lead_type", "lead_type")):
        if params.get(param):
            query[field] = str(params[param])[:200]
    for param, field in (("hospital", "company"), ("location", "location"), ("product", "product_interest")):
        if params.get(param):
            query[field] = {"$regex": re.escape(str(params[param])[:200]), "$options": "i"}
    if params.get("date"):
        try:
            start = datetime.strptime(params["date"], "%Y-%m-%d").replace(tzinfo=IST)
            if start.date().isoformat() != params["date"]:
                raise ValueError()
        except ValueError:
            raise HTTPException(422, "Date must be YYYY-MM-DD")
        # Capture timestamps are always UTC, making this an exact indexed range.
        from datetime import timezone
        query["created_at"] = {"$gte": start.astimezone(timezone.utc).isoformat(), "$lt": (start + timedelta(days=1)).astimezone(timezone.utc).isoformat()}
    if params.get("search"):
        rx = {"$regex": re.escape(str(params["search"])[:200]), "$options": "i"}
        query["$or"] = [{k: rx} for k in ("title", "contact_name", "company", "mobile", "display_id")]
    return query


@router.get("/leads")
async def list_leads(request: Request, page: int = 1, limit: int = 25, user=Depends(require_perm("leads", "view"))):
    if page < 1 or not 1 <= limit <= 100:
        raise HTTPException(422, "Invalid pagination")
    query = filters(user, request.query_params)
    return {"items": await db.leads.find(query, {"_id": 0}).sort("created_at", -1).skip((page - 1) * limit).to_list(limit),
            "total": await db.leads.count_documents(query), "page": page, "limit": limit}


@router.get("/export")
async def export(request: Request, user=Depends(require_perm("leads", "export"))):
    manager(user)
    rows = await db.leads.find(filters(user, request.query_params), {"_id": 0}).sort("created_at", -1).to_list(None)
    fields = ["display_id", "created_at", "mr_name", "employee_id", "contact_name", "designation", "company", "doctor_name",
              "mobile", "alternative_phone", "email", "location", "address", "lead_type", "product_interest",
              "requirement", "quantity", "source", "status", "capture_status", "priority", "next_followup_at", "admin_remarks"]
    def safe(value):
        text = str(value or "")
        return "'" + text if text.lstrip().startswith(("=", "+", "-", "@", "\t", "\r")) else text
    output = io.StringIO()
    writer = csv.DictWriter(output, fieldnames=fields)
    writer.writeheader()
    for row in rows:
        writer.writerow({k: safe(row.get(k)) for k in fields})
    await event(db, "export", now_iso(), "Leads Exported", f"{len(rows)} rows", user["id"])
    return Response(output.getvalue(), media_type="text/csv", headers={"Content-Disposition": 'attachment; filename="vgrups-whatsapp-leads.csv"'})


@router.get("/leads/{lid}")
async def detail(lid: str, activity_page: int = Query(1, ge=1, le=1000000),
                 timeline_page: int = Query(1, ge=1, le=1000000), user=Depends(require_perm("leads", "view"))):
    lead = await lead_for(lid, user)
    p = permissions_for(user["role"])
    return {"lead": lead,
            "activities": await db.mr_lead_activities.find({"lead_id": lid}, {"_id": 0}).sort("created_at", -1).skip((activity_page - 1) * 50).to_list(50),
            "timeline": await db.mr_lead_events.find({"lead_id": lid}, {"_id": 0}).sort("created_at", -1).skip((timeline_page - 1) * 50).to_list(50),
            "activity_total": await db.mr_lead_activities.count_documents({"lead_id": lid}),
            "timeline_total": await db.mr_lead_events.count_documents({"lead_id": lid}),
            "requests": await db.mr_lead_requests.find({"lead_id": lid}, {"_id": 0}).sort("created_at", -1).to_list(100),
            "can_edit": "edit" in p.get("leads", []), "can_delete": user["role"] in MANAGERS and "delete" in p.get("leads", [])}


class LeadPatch(BaseModel):
    title: str | None = Field(default=None, max_length=200)
    contact_name: str | None = Field(default=None, max_length=200)
    designation: str | None = Field(default=None, max_length=200)
    company: str | None = Field(default=None, max_length=200)
    hospital_name: str | None = Field(default=None, max_length=200)
    clinic_name: str | None = Field(default=None, max_length=200)
    doctor_name: str | None = Field(default=None, max_length=200)
    pharmacy_name: str | None = Field(default=None, max_length=200)
    distributor_name: str | None = Field(default=None, max_length=200)
    institution_name: str | None = Field(default=None, max_length=200)
    mobile: str | None = None
    alternative_phone: str | None = None
    email: str | None = Field(default=None, max_length=200)
    location: str | None = Field(default=None, max_length=500)
    address: str | None = Field(default=None, max_length=1000)
    lead_type: str | None = None
    product_interest: str | None = Field(default=None, max_length=2000)
    requirement: str | None = Field(default=None, max_length=2000)
    quantity: str | None = Field(default=None, max_length=200)
    notes: str | None = Field(default=None, max_length=4000)
    priority: Literal["normal", "high", "urgent"] | None = None
    next_followup_at: str | None = None
    status: str | None = None
    admin_remarks: str | None = Field(default=None, max_length=4000)
    assigned_to: str | None = None
    verification_status: Literal["Admin verified", "Needs Verification"] | None = None

    @field_validator("mobile", "alternative_phone")
    @classmethod
    def valid_phone(cls, value):
        if value in (None, ""):
            return value
        number = mobile(value)
        if not number:
            raise ValueError("Use a valid ten-digit Indian mobile number")
        return number

    @field_validator("next_followup_at")
    @classmethod
    def valid_date(cls, value):
        if not value:
            return value
        if datetime.strptime(value, "%Y-%m-%d").date().isoformat() != value:
            raise ValueError("Date must be YYYY-MM-DD")
        return value


@router.patch("/leads/{lid}")
async def update_lead(lid: str, body: LeadPatch, user=Depends(require_perm("leads", "edit"))):
    patch = body.model_dump(exclude_unset=True)
    if user["role"] == "mr" and set(patch) & {"assigned_to", "admin_remarks", "verification_status"}:
        raise HTTPException(403, "Only administrators can reassign or verify leads and edit admin remarks")
    if "status" in patch and patch["status"] not in LEAD_STATUSES:
        raise HTTPException(422, "Invalid status")
    if "lead_type" in patch and patch["lead_type"] not in TYPES:
        raise HTTPException(422, "Invalid lead type")
    if "priority" in patch and patch["priority"] is None:
        raise HTTPException(422, "A priority is required")
    async with capture_lock(db):
        lead = await lead_for(lid, user)
        if "assigned_to" in patch:
            if "assign" not in permissions_for(user["role"]).get("leads", []):
                raise HTTPException(403, "Lead assignment permission required")
        if patch.get("assigned_to"):
            account = await db.users.find_one({"id": patch["assigned_to"], "role": "mr", "active": {"$ne": False}, **REAL})
            if not account:
                raise HTTPException(422, "Assign an active MR account")
        if patch.get("mobile"):
            other = await match_lead(db, {"mobile": patch["mobile"]}, {"id": "", "_direct_mr": True}, {})
            if other and other["id"] != lid:
                raise HTTPException(409, "Phone belongs to another lead; resolve the duplicate before updating")
        if "mobile" in patch:
            patch["capture_status"] = "Lead Captured" if patch["mobile"] else "Phone Number Required"
            if not patch["mobile"] and lead.get("mobile"):
                patch["phone_request_version"] = lead.get("phone_request_version", 0) + 1
        patch["updated_at"] = now_iso()
        await db.leads.update_one({"id": lid}, {"$set": patch})
        await event(db, lid, now_iso(), "Lead Reviewed / Updated", "Edited fields: " + ", ".join(body.model_fields_set), user["id"])
        updated = await db.leads.find_one({"id": lid}, {"_id": 0})
        if patch.get("mobile"):
            await db.mr_lead_requests.update_many({"lead_id": lid}, {"$set": {"resolution": "completed"}})
            if patch["mobile"] != lead.get("mobile"):
                await event(db, lid, patch["updated_at"], "Phone Number Received", patch["mobile"], user["id"])
        if patch.get("next_followup_at") and patch["next_followup_at"] != lead.get("next_followup_at"):
            await event(db, lid, patch["updated_at"], "Follow-Up Scheduled", patch["next_followup_at"], user["id"])
        await notify_admins(db, updated, stable(lid, patch["updated_at"]),
                            "PHONE NUMBER RECEIVED" if patch.get("mobile") and not lead.get("mobile") else "LEAD UPDATED")
        return {"lead": updated}


@router.delete("/leads/{lid}")
async def delete_lead(lid: str, user=Depends(require_perm("leads", "delete"))):
    manager(user)
    await lead_for(lid, user)
    await db.leads.update_one({"id": lid}, {"$set": {"deleted": True, "updated_at": now_iso()}})
    await event(db, lid, now_iso(), "Lead Deleted", "Soft-deleted; original evidence retained", user["id"])
    return {"ok": True}


@router.post("/leads/{lid}/request-phone")
async def request_phone(lid: str, user=Depends(require_perm("leads", "edit"))):
    lead = await lead_for(lid, user)
    if lead.get("mobile"):
        raise HTTPException(409, "Lead already has a phone number")
    if "send" not in permissions_for(user["role"]).get("whatsapp", []):
        raise HTTPException(403, "WhatsApp send permission required")
    await queue_phone_requests(db, lead, await target_mr(lead))
    return {"queued": True, "requests": await db.mr_lead_requests.find({"lead_id": lid}, {"_id": 0}).to_list(100)}


@router.post("/leads/{lid}/notifications")
async def repair_notifications(lid: str, user=Depends(require_perm("leads", "edit"))):
    manager(user)
    lead = await lead_for(lid, user)
    await notify_admins(db, lead, stable("manual-alert", lid, lead.get("updated_at")), "LEAD REVIEW ALERT")
    return {"ok": True}


async def visible_ids(user):
    return [row["id"] for row in await db.leads.find(scope(user), {"id": 1}).to_list(None)]


@router.get("/review")
async def review(user=Depends(require_perm("leads", "view"))):
    allowed(user)
    query = {"status": {"$in": ["needs_verification", "ai_extraction_failed", "ownership_conflict"]}}
    if user["role"] == "mr":
        query["mr_id"] = user["id"]
    rows = await db.mr_lead_queue.find(query, {"_id": 0}).sort("created_at", -1).to_list(500)
    if user["role"] == "mr":
        permitted = set(await visible_ids(user))
        for row in rows:
            if row.get("lead_id") not in permitted:
                row.pop("lead_id", None)
    return {"items": rows, "total": await db.mr_lead_queue.count_documents(query)}


@router.post("/review/{rid}/retry")
async def retry_review(rid: str, user=Depends(require_perm("leads", "edit"))):
    allowed(user)
    row = await db.mr_lead_queue.find_one({"id": rid})
    if not row or user["role"] == "mr" and row.get("mr_id") != user["id"]:
        raise HTTPException(404, "Review item not found")
    if not (await settings_for(db))["enabled"]:
        raise HTTPException(409, "Enable authorized lead capture before retrying")
    if row["status"] not in ("needs_verification", "ai_extraction_failed", "ownership_conflict"):
        raise HTTPException(409, "Item is not awaiting review")
    await db.mr_lead_queue.update_one({"id": rid}, {"$set": {"status": "retry_pending", "error": None}})
    await event(db, row.get("lead_id", "review"), rid + now_iso(), "Extraction Retry Requested", "Original message preserved", user["id"])
    return {"ok": True}


class ReviewIn(LeadPatch):
    confirm_verified: bool = False


@router.post("/review/{rid}/approve")
async def approve_review(rid: str, body: ReviewIn, user=Depends(require_perm("leads", "edit"))):
    manager(user)
    if not body.confirm_verified:
        raise HTTPException(422, "Confirm that the corrected information was verified")
    async with capture_lock(db):
        job = await db.mr_lead_queue.find_one({"id": rid})
        if not job:
            raise HTTPException(404, "Review item not found")
        if job.get("status") == "completed":
            return {"ok": True, "lead_id": job.get("lead_id")}
        data = {**(job.get("extracted") or {}), **body.model_dump(exclude_unset=True)}
        data.update(is_business=True, confidence=1)
        if data.get("lead_type") not in TYPES:
            data["lead_type"] = "Other"
        if data.get("priority") not in ("normal", "high", "urgent"):
            data["priority"] = "normal"
        data.setdefault("mobile", None)
        async def reviewed_extract(*_):
            return data
        result = await ingest(db, job, extractor=reviewed_extract, verified_fields=body.model_fields_set - {"confirm_verified"})
        if result["status"] != "completed":
            raise HTTPException(409, result.get("error", "Review cannot be applied"))
        await db.mr_lead_queue.update_one({"id": rid}, {"$set": {**result, "reviewed_by": user["id"], "reviewed_at": now_iso()}})
        await db.leads.update_one({"id": result["lead_id"]}, {"$set": {"verification_status": "Admin verified", "reviewed_by": user["id"]}})
        await event(db, result["lead_id"], rid, "Extraction Manually Verified", "Administrator supplied verified corrections", user["id"])
        return {"ok": True, "lead_id": result["lead_id"]}


@router.get("/activity")
async def activities(user=Depends(require_perm("leads", "view"))):
    query = {"lead_id": {"$in": await visible_ids(user)}}
    return {"items": await db.mr_lead_activities.find(query, {"_id": 0}).sort("created_at", -1).to_list(500),
            "total": await db.mr_lead_activities.count_documents(query)}


@router.get("/requests")
async def requests(user=Depends(require_perm("leads", "view"))):
    query = {"lead_id": {"$in": await visible_ids(user)}}
    return {"items": await db.mr_lead_requests.find(query, {"_id": 0}).sort("created_at", -1).to_list(500),
            "total": await db.mr_lead_requests.count_documents(query)}


@router.get("/analytics")
async def analytics(user=Depends(require_perm("leads", "view"))):
    rows = await db.leads.find({**scope(user), "source": "WhatsApp – MR"}, {"_id": 0}).to_list(None)
    today = datetime.now(IST).date().isoformat()
    result = dict.fromkeys(("total", "missing_phone", "phone_completed", "needs_verification", "hot", "followup_due", "converted", "lost"), 0)
    groups = {}
    for lead in rows:
        result["total"] += 1
        result["missing_phone"] += not bool(lead.get("mobile"))
        result["phone_completed"] += bool(lead.get("mobile"))
        result["needs_verification"] += lead.get("verification_status") == "Needs Verification"
        result["hot"] += lead.get("priority") in ("high", "urgent")
        result["converted"] += lead.get("status") == "won"
        result["lost"] += lead.get("status") == "lost"
        result["followup_due"] += bool(lead.get("next_followup_at") and lead["next_followup_at"] <= today and lead.get("status") not in ("won", "lost"))
        group = groups.setdefault(lead.get("mr_id"), {"mr_id": lead.get("mr_id"), "mr_name": lead.get("mr_name"), "total": 0, "converted": 0, "missing_phone": 0})
        group["total"] += 1
        group["converted"] += lead.get("status") == "won"
        group["missing_phone"] += not bool(lead.get("mobile"))
    return {**result, "by_mr": list(groups.values())}


@router.get("/notifications")
async def notifications(user=Depends(require_perm("leads", "view"))):
    allowed(user)
    query = {"user_id": user["id"]}
    rows = await db.mr_lead_notifications.find(query, {"_id": 0}).sort("created_at", -1).to_list(100)
    permitted = set(await visible_ids(user))
    return {"items": [r for r in rows if r["lead_id"] in permitted],
            "unread": sum(not r.get("read") for r in rows if r["lead_id"] in permitted)}


@router.patch("/notifications/{nid}/read")
async def read_notification(nid: str, user=Depends(require_perm("leads", "view"))):
    allowed(user)
    row = await db.mr_lead_notifications.find_one({"id": nid, "user_id": user["id"]})
    if not row:
        raise HTTPException(404, "Notification not found")
    await lead_for(row["lead_id"], user)
    await db.mr_lead_notifications.update_one({"id": nid}, {"$set": {"read": True}})
    return {"ok": True}


@router.post("/voice/{rid}")
async def voice_callback(rid: str, request: Request, expires: str = "", token: str = ""):
    if not valid_voice_token(rid, expires, token):
        raise HTTPException(403, "Invalid or expired voice callback")
    from urllib.parse import parse_qs
    values = parse_qs((await request.body()).decode())
    call_id = (values.get("CallSid") or [""])[0]
    digits = (values.get("Digits") or [""])[0]
    async with capture_lock(db):
        row = await db.mr_lead_requests.find_one({"id": rid, "channel": "voice", "status": "accepted"})
        if not row or row.get("provider_id") != call_id:
            raise HTTPException(403, "Call does not match the accepted request")
        if row.get("resolution") == "completed":
            return Response("<Response><Say>Phone number already recorded. Thank you.</Say></Response>", media_type="application/xml")
        lead = await db.leads.find_one({"id": row["lead_id"], **REAL})
        if not lead:
            raise HTTPException(404, "Lead not found")
        try:
            await complete_phone(db, lead, digits, await target_mr(lead), key=stable(rid, digits))
            text = "Thank you. The customer phone number has been recorded."
        except ValueError:
            text = "The number could not be applied. Please respond with the lead ID and mobile number on WhatsApp."
        return Response("<Response><Say>" + text + "</Say></Response>", media_type="application/xml")
