import logging
import os
from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel
from typing import Optional
from postgres_store import ReturnDocument

from db import db, new_id, now_iso, log_audit
from auth import require_perm, get_current_user
from routes_automations import run_automations
import wa_client
import razorpay_client

logger = logging.getLogger("vgrups.orders")
router = APIRouter(prefix="/api", tags=["orders"])


async def _fire(trigger: str, ctx: dict):
    import asyncio as _a
    _a.create_task(run_automations(trigger, ctx))


# ---------------- Schemas ----------------
class QuoteItemIn(BaseModel):
    product_id: str
    qty: int = 1


class QuotationIn(BaseModel):
    contact_id: Optional[str] = None
    contact_name: str
    mobile: Optional[str] = None
    items: list[QuoteItemIn] = []
    discount: float = 0
    notes: Optional[str] = None


async def _build_items(items: list[QuoteItemIn]) -> tuple[list[dict], float, float]:
    built, subtotal, gst_amount = [], 0.0, 0.0
    for it in items:
        p = await db.products.find_one({"id": it.product_id}, {"_id": 0})
        if not p:
            continue
        qty = max(1, int(it.qty))
        price = float(p.get("selling_price") or 0)
        amount = price * qty
        gst_pct = float(p.get("gst") or 0)
        subtotal += amount
        gst_amount += amount * gst_pct / 100.0
        built.append({"product_id": p["id"], "code": p.get("code"), "name": p.get("name"),
                      "price": price, "qty": qty, "gst": gst_pct, "amount": round(amount, 2)})
    return built, round(subtotal, 2), round(gst_amount, 2)


async def _next_no(name: str, prefix: str, base: int) -> str:
    doc = await db.counters.find_one_and_update(
        {"_id": name}, {"$inc": {"seq": 1}}, upsert=True, return_document=ReturnDocument.AFTER)
    return f"{prefix}{base + doc['seq']}"


# ---------------- Quotations ----------------
@router.get("/quotations")
async def list_quotations(user: dict = Depends(require_perm("orders", "view"))):
    items = await db.quotations.find({}, {"_id": 0}).sort("created_at", -1).to_list(200)
    return {"items": items}


@router.post("/quotations")
async def create_quotation(body: QuotationIn, user: dict = Depends(require_perm("orders", "create"))):
    if not body.items:
        raise HTTPException(status_code=422, detail="Add at least one product")
    built, subtotal, gst_amount = await _build_items(body.items)
    if not built:
        raise HTTPException(status_code=422, detail="No valid products selected")
    discount = max(0.0, float(body.discount or 0))
    total = round(subtotal + gst_amount - discount, 2)
    doc = {"id": new_id(), "quote_no": await _next_no("quotations", "QT", 1000),
           "contact_id": body.contact_id, "contact_name": body.contact_name, "mobile": body.mobile,
           "items": built, "subtotal": subtotal, "gst_amount": gst_amount, "discount": discount,
           "total": total, "status": "draft", "notes": body.notes, "order_id": None,
           "is_demo": False, "created_by": user["id"], "created_at": now_iso(), "updated_at": now_iso()}
    await db.quotations.insert_one(doc)
    await log_audit(user, "create", "orders", doc["id"], detail=f"quotation:{doc['quote_no']}")
    doc.pop("_id", None)
    return doc


@router.get("/quotations/{qid}")
async def get_quotation(qid: str, user: dict = Depends(require_perm("orders", "view"))):
    q = await db.quotations.find_one({"id": qid}, {"_id": 0})
    if not q:
        raise HTTPException(status_code=404, detail="Quotation not found")
    return q


@router.delete("/quotations/{qid}")
async def delete_quotation(qid: str, user: dict = Depends(require_perm("orders", "delete"))):
    await db.quotations.delete_one({"id": qid})
    return {"ok": True}


def _quote_text(q: dict) -> str:
    lines = [f"*VGRUPS Healthcare — Quotation {q['quote_no']}*", f"For: {q.get('contact_name', '')}", ""]
    for it in q.get("items", []):
        lines.append(f"• {it['name']} ×{it['qty']} — ₹{it['amount']:.0f}")
    lines.append("")
    lines.append(f"Subtotal: ₹{q.get('subtotal', 0):.0f}")
    if q.get("gst_amount"):
        lines.append(f"GST: ₹{q['gst_amount']:.0f}")
    if q.get("discount"):
        lines.append(f"Discount: -₹{q['discount']:.0f}")
    lines.append(f"*Total: ₹{q.get('total', 0):.0f}*")
    if q.get("notes"):
        lines += ["", q["notes"]]
    return "\n".join(lines)


@router.post("/quotations/{qid}/send")
async def send_quotation(qid: str, user: dict = Depends(require_perm("orders", "send")), session_id: Optional[str] = None):
    q = await db.quotations.find_one({"id": qid}, {"_id": 0})
    if not q:
        raise HTTPException(status_code=404, detail="Quotation not found")
    if not q.get("mobile"):
        raise HTTPException(status_code=400, detail="This quotation has no mobile number.")
    from whatsapp_routing import sender
    selected = await sender(db, session_id)
    await wa_client.wa_send(q["mobile"], _quote_text(q), session_id=selected["id"])
    await db.quotations.update_one({"id": qid}, {"$set": {"status": "sent", "updated_at": now_iso()}})
    return {"ok": True, "status": "sent"}


@router.post("/quotations/{qid}/convert")
async def convert_quotation(qid: str, user: dict = Depends(require_perm("orders", "create"))):
    q = await db.quotations.find_one({"id": qid}, {"_id": 0})
    if not q:
        raise HTTPException(status_code=404, detail="Quotation not found")
    if q.get("order_id"):
        raise HTTPException(status_code=400, detail="Quotation already converted to an order")
    order = {"id": new_id(), "order_no": await _next_no("orders", "VG", 20000),
             "contact_id": q.get("contact_id"), "contact_name": q.get("contact_name"), "mobile": q.get("mobile"),
             "items": q.get("items", []), "items_count": len(q.get("items", [])),
             "subtotal": q.get("subtotal", 0), "gst_amount": q.get("gst_amount", 0),
             "discount": q.get("discount", 0), "total": q.get("total", 0),
             "status": "confirmed", "payment_status": "pending", "payment_link": None,
             "payment_link_id": None, "payment_id": None, "quotation_id": qid,
             "is_demo": False, "created_by": user["id"], "created_at": now_iso(), "updated_at": now_iso()}
    await db.orders.insert_one(order)
    await db.quotations.update_one({"id": qid}, {"$set": {"status": "converted", "order_id": order["id"], "updated_at": now_iso()}})
    await log_audit(user, "create", "orders", order["id"], detail=f"order:{order['order_no']}")
    await _fire("new_order", {"contact_name": order["contact_name"], "mobile": order.get("mobile"),
                              "contact_id": order.get("contact_id"), "order_id": order["id"],
                              "order_no": order["order_no"], "order_total": order["total"]})
    order.pop("_id", None)
    return order


# ---------------- Orders / Payments ----------------
@router.get("/orders/{oid}")
async def get_order(oid: str, user: dict = Depends(require_perm("orders", "view"))):
    o = await db.orders.find_one({"id": oid}, {"_id": 0})
    if not o:
        raise HTTPException(status_code=404, detail="Order not found")
    return o


@router.get("/payments/config")
async def payments_config(user: dict = Depends(get_current_user)):
    return {"razorpay_configured": razorpay_client.configured()}


async def _mark_paid(order: dict, payment_id: str | None, source: str):
    await db.orders.update_one({"id": order["id"]},
        {"$set": {"payment_status": "paid", "payment_id": payment_id, "status": "confirmed",
                  "paid_at": now_iso(), "updated_at": now_iso()}})
    await _fire("payment_received", {"contact_name": order.get("contact_name"), "mobile": order.get("mobile"),
                                     "contact_id": order.get("contact_id"), "order_id": order["id"],
                                     "order_no": order.get("order_no"), "order_total": order.get("total")})
    # confirmation message
    if order.get("mobile") and await wa_client.wa_connected():
        try:
            msg = (f"✅ Payment received for order *{order.get('order_no')}*.\n"
                   f"Thank you, {order.get('contact_name')}! Your order is confirmed. — VGRUPS Healthcare")
            await wa_client.wa_send(order["mobile"], msg)
        except Exception as e:
            logger.warning(f"confirmation send failed: {e}")


@router.post("/orders/{oid}/payment-link")
async def create_payment_link(oid: str, request: Request, user: dict = Depends(require_perm("orders", "edit"))):
    o = await db.orders.find_one({"id": oid}, {"_id": 0})
    if not o:
        raise HTTPException(status_code=404, detail="Order not found")
    if not razorpay_client.configured():
        raise HTTPException(status_code=503, detail="Razorpay not configured. Add RAZORPAY_KEY_ID & RAZORPAY_KEY_SECRET in Integrations.")
    try:
        link = razorpay_client.create_payment_link(
            amount_rupees=float(o.get("total") or 0),
            description=f"Order {o.get('order_no')} — VGRUPS Healthcare",
            customer={"name": o.get("contact_name"), "contact": o.get("mobile")},
            reference_id=o.get("order_no") or o["id"],
        )
    except Exception as e:
        raise HTTPException(status_code=502, detail=f"Razorpay error: {e}")
    await db.orders.update_one({"id": oid}, {"$set": {"payment_link": link["short_url"],
                               "payment_link_id": link["id"], "updated_at": now_iso()}})
    # auto-send on WhatsApp if possible
    sent = False
    if o.get("mobile") and await wa_client.wa_connected():
        try:
            await wa_client.wa_send(o["mobile"],
                f"Hi {o.get('contact_name')}, please complete payment ₹{float(o.get('total') or 0):.0f} "
                f"for order {o.get('order_no')} here: {link['short_url']}")
            sent = True
        except Exception as e:
            logger.warning(f"payment link send failed: {e}")
    return {"ok": True, "payment_link": link["short_url"], "whatsapp_sent": sent}


@router.post("/orders/{oid}/mark-paid")
async def mark_paid(oid: str, user: dict = Depends(require_perm("orders", "edit"))):
    o = await db.orders.find_one({"id": oid}, {"_id": 0})
    if not o:
        raise HTTPException(status_code=404, detail="Order not found")
    if o.get("payment_status") == "paid":
        raise HTTPException(status_code=400, detail="Order already paid")
    await _mark_paid(o, payment_id="manual", source="manual")
    await log_audit(user, "mark_paid", "payments", oid, detail=o.get("order_no"))
    return {"ok": True, "payment_status": "paid"}


@router.post("/webhooks/razorpay")
async def razorpay_webhook(request: Request):
    body = await request.body()
    signature = request.headers.get("X-Razorpay-Signature", "")
    if not razorpay_client.verify_webhook_signature(body, signature):
        raise HTTPException(status_code=400, detail="Invalid signature")
    import json
    payload = json.loads(body.decode() or "{}")
    event = payload.get("event", "")
    if event in ("payment_link.paid", "payment.captured"):
        entity = (payload.get("payload", {}).get("payment_link", {}).get("entity")
                  or payload.get("payload", {}).get("payment", {}).get("entity") or {})
        ref = entity.get("reference_id") or (entity.get("notes") or {}).get("reference_id")
        pay_id = entity.get("id")
        if ref:
            o = await db.orders.find_one({"order_no": ref}, {"_id": 0})
            if o and o.get("payment_status") != "paid":
                await _mark_paid(o, payment_id=pay_id, source="razorpay")
    return {"ok": True}
