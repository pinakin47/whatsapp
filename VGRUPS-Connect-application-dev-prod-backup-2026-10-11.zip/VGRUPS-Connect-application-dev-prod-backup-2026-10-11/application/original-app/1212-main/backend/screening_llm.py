"""Single-turn Gemini screening without the vulnerable LiteLLM proxy stack.

Preserves the imported integration's Emergent proxy model, key and X-App-ID
contract, and supports native Gemini keys as the old adapter did.
"""
import os

import httpx


async def screening_completion(api_key: str, model: str, system: str, prompt: str) -> str:
    if not api_key:
        raise RuntimeError("EMERGENT_LLM_KEY is required for AI resume screening")
    async with httpx.AsyncClient(timeout=120) as client:
        if api_key.startswith("sk-emergent-"):
            base = (os.getenv("INTEGRATION_PROXY_URL") or
                    os.getenv("integration_proxy_url") or
                    "https://integrations.emergentagent.com").rstrip("/")
            headers = {"Authorization": f"Bearer {api_key}"}
            app_id = os.getenv("APP_URL") or os.getenv("REACT_APP_BACKEND_URL")
            if app_id:
                headers["X-App-ID"] = app_id
            response = await client.post(
                f"{base}/llm/chat/completions", headers=headers,
                json={"model": f"gemini/{model}", "messages": [
                    {"role": "system", "content": system},
                    {"role": "user", "content": prompt},
                ]},
            )
            response.raise_for_status()
            content = response.json()["choices"][0]["message"]["content"]
        else:
            response = await client.post(
                f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent",
                headers={"x-goog-api-key": api_key},
                json={"systemInstruction": {"parts": [{"text": system}]},
                      "contents": [{"role": "user", "parts": [{"text": prompt}]}]},
            )
            response.raise_for_status()
            content = "".join(part.get("text", "") for part in
                              response.json()["candidates"][0]["content"]["parts"])
        if not isinstance(content, str) or not content.strip():
            raise ValueError("AI screening provider returned no text")
        return content
