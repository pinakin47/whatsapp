"""Parameterized PostgreSQL JSONB queries for the existing document contracts."""
import copy
import json
import re


def get_path(doc, path, default=None):
    value = doc
    for part in path.split("."):
        if not isinstance(value, dict) or part not in value:
            return default
        value = value[part]
    return value


def set_path(doc, path, value):
    parts = path.split(".")
    target = doc
    for part in parts[:-1]:
        if not isinstance(target.get(part), dict):
            target[part] = {}
        target = target[part]
    target[parts[-1]] = copy.deepcopy(value)


def project(doc, projection=None):
    result = copy.deepcopy(doc)
    if not projection:
        return result
    included = [key for key, value in projection.items() if value and key != "_id"]
    if included:
        result = {}
        sentinel = object()
        for key in included:
            value = get_path(doc, key, sentinel)
            if value is not sentinel:
                set_path(result, key, value)
        if projection.get("_id", 1) and "_id" in doc:
            result["_id"] = doc["_id"]
    else:
        for key, value in projection.items():
            if not value:
                parts = key.split(".")
                target = result
                for part in parts[:-1]:
                    target = target.get(part, {}) if isinstance(target, dict) else {}
                if isinstance(target, dict):
                    target.pop(parts[-1], None)
    return result


def apply_update(doc, update, inserting=False):
    result = copy.deepcopy(doc)
    for operator, fields in update.items():
        if operator == "$setOnInsert" and not inserting:
            continue
        if operator in ("$set", "$setOnInsert"):
            for key, value in fields.items():
                set_path(result, key, value)
        elif operator == "$inc":
            for key, value in fields.items():
                current = get_path(result, key, 0)
                if not isinstance(current, (int, float)) or isinstance(current, bool):
                    raise ValueError(f"Cannot increment nonnumeric field {key}")
                set_path(result, key, current + value)
        elif operator == "$addToSet":
            for key, value in fields.items():
                current = get_path(result, key, [])
                if not isinstance(current, list):
                    raise ValueError(f"Cannot add to non-array field {key}")
                current = copy.deepcopy(current)
                additions = value["$each"] if isinstance(value, dict) and "$each" in value else [value]
                for item in additions:
                    if item not in current:
                        current.append(item)
                set_path(result, key, current)
        else:
            raise ValueError(f"Unsupported document update operator: {operator}")
    return result


class Query:
    def __init__(self, collection):
        self.params = [collection]

    def param(self, value, cast=""):
        self.params.append(value)
        return f"${len(self.params)}{cast}"

    def field(self, key, text=False):
        if not isinstance(key, str) or key.startswith("$"):
            raise ValueError("Invalid document field")
        path = self.param(key.split("."), "::text[]")
        return f"(document {'#>>' if text else '#>'} {path})"

    def equal(self, field, value):
        if value is None:
            return f"({field} IS NULL OR {field} = 'null'::jsonb)"
        value_sql = self.param(json.dumps(value), "::jsonb")
        return f"COALESCE(({field} = {value_sql} OR (jsonb_typeof({field}) = 'array' AND {field} @> jsonb_build_array({value_sql}))), FALSE)"

    def condition(self, key, value):
        field = self.field(key)
        if isinstance(value, re.Pattern):
            value = {"$regex": value}
        if not isinstance(value, dict) or not any(k.startswith("$") for k in value):
            return self.equal(field, value)
        conditions = []
        for operator, expected in value.items():
            if operator == "$options":
                continue
            if operator in ("$eq", "$ne"):
                eq = self.equal(field, expected)
                conditions.append(eq if operator == "$eq" else f"NOT ({eq})")
            elif operator in ("$in", "$nin"):
                values = [self.equal(field, item) for item in expected]
                term = "(" + " OR ".join(values) + ")" if values else "FALSE"
                conditions.append(term if operator == "$in" else f"NOT ({term})")
            elif operator in ("$gt", "$gte", "$lt", "$lte"):
                symbol = {"$gt": ">", "$gte": ">=", "$lt": "<", "$lte": "<="}[operator]
                right = self.param(json.dumps(expected), "::jsonb")
                conditions.append(f"(jsonb_typeof({field}) = jsonb_typeof({right}) AND {field} {symbol} {right})")
            elif operator == "$exists":
                conditions.append(f"{field} IS {'NOT ' if expected else ''}NULL")
            elif operator == "$regex":
                flags = expected.flags if isinstance(expected, re.Pattern) else 0
                pattern = expected.pattern if isinstance(expected, re.Pattern) else expected
                insensitive = flags & re.I or "i" in value.get("$options", "")
                # Reuse the path parameter already allocated above. Allocating
                # a second path here leaves a hole in asyncpg's parameter types.
                text_field = f"({field} #>> '{{}}')"
                conditions.append(f"COALESCE((jsonb_typeof({field}) = 'string' AND {text_field} {'~*' if insensitive else '~'} {self.param(pattern)}), FALSE)")
            else:
                raise ValueError(f"Unsupported document query operator: {operator}")
        return "(" + " AND ".join(conditions) + ")"

    def filter(self, selector=None):
        conditions = []
        for key, value in (selector or {}).items():
            if key in ("$or", "$and"):
                join = " OR " if key == "$or" else " AND "
                conditions.append("(" + join.join(self.filter(item) for item in value) + ")" if value else ("FALSE" if key == "$or" else "TRUE"))
            elif key.startswith("$"):
                raise ValueError(f"Unsupported selector: {key}")
            else:
                conditions.append(self.condition(key, value))
        return " AND ".join(conditions) if conditions else "TRUE"

    def where(self, selector=None):
        return "collection_name = $1 AND (" + self.filter(selector) + ")"

    def order(self, sort):
        if not sort:
            return " ORDER BY document_id"
        return " ORDER BY " + ", ".join(
            f"{self.field(key)} {'DESC NULLS LAST' if direction < 0 else 'ASC NULLS FIRST'}"
            for key, direction in sort
        )