"""Real MR directory and opt-in, once-per-day QR WhatsApp reminders."""
import asyncio
import logging
import re
import hashlib
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo
from contextlib import asynccontextmanager
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, EmailStr, Field, field_validator
from auth import require_perm, permissions_for, refresh_role_definitions
from db import db, new_id, now_iso, utcnow, log_audit
import wa_client

router = APIRouter(prefix="/api/settings", tags=["MR settings"])
IST = ZoneInfo("Asia/Kolkata")
DEFAULT_REMINDER = {
    "enabled": False, "time": "09:00", "timezone": "Asia/Kolkata", "message_gap_seconds": 5,
    "message": "Good morning {name} ,kindly send the todays visits schedule up load as pr the following instructions .and evening day end submit todays report .",
}
logger = logging.getLogger("vgrups.mr-reminders")


@asynccontextmanager
async def mr_lock(key):
    pool = await db.connect()
    async with pool.acquire() as conn:
        if not await conn.fetchval("SELECT pg_try_advisory_lock(hashtext($1))", "mr:" + key):
            raise HTTPException(409, "MR settings are being processed. Please retry shortly.")
        try:
            yield
        finally:
            await conn.execute("SELECT pg_advisory_unlock(hashtext($1))", "mr:" + key)


class MRIn(BaseModel):
    name: str = Field(min_length=1, max_length=200)
    phone: str
    email: EmailStr
    employee_id: str = Field(min_length=1, max_length=50)
    active: bool = True

    @field_validator("name", "employee_id")
    @classmethod
    def clean_required(cls, value):
        if not value.strip():
            raise ValueError("This field cannot be blank.")
        return value.strip()

    @field_validator("phone")
    @classmethod
    def clean_phone(cls, value):
        value = re.sub(r"[\s().-]", "", value)
        if not re.fullmatch(r"\+[1-9]\d{7,14}", value):
            raise ValueError("Use an international WhatsApp number with + and country code.")
        return value


class ReminderIn(BaseModel):
    enabled: bool = False
    time: str = Field(default="09:00", pattern=r"^(?:[01]\d|2[0-3]):[0-5]\d$")
    timezone: str = Field(default="Asia/Kolkata", pattern=r"^Asia/Kolkata$")
    message: str = Field(default=DEFAULT_REMINDER["message"], min_length=1, max_length=4000)
    message_gap_seconds: int = Field(default=5, ge=1, le=300)

    @field_validator("message")
    @classmethod
    def validate_message(cls, value):
        if not value.strip():
            raise ValueError("Enter a reminder message.")
        if set(re.findall(r"\{([^}]+)\}", value)) - {"name", "employee_id"}:
            raise ValueError("Only {name} and {employee_id} placeholders are supported.")
        return value


@router.get("/mrs")
async def list_mrs(user=Depends(require_perm("settings", "view"))):
    items = await db.mr_directory.find({"deleted": {"$ne": True}}, {"_id": 0}).sort("name", 1).to_list(2000)
    accounts = await db.users.find({"role": "mr", "deleted": {"$ne": True},
        "is_demo": {"$ne": True}, "active": {"$ne": False}}, {"_id": 0, "id": 1, "email": 1}).to_list(2000)
    linked = {a.get("email", "").lower(): a["id"] for a in accounts}
    return {"items": [{**row, "user_id": linked.get(row["email"].lower())} for row in items]}


async def save_mr(body, user, mid=None):
    async with mr_lock("directory"):
        if mid and not await db.mr_directory.find_one({"id": mid, "deleted": {"$ne": True}}):
            raise HTTPException(404, "MR not found.")
        fields = body.model_dump()
        fields["email"] = str(body.email).lower()
        fields["employee_id"] = body.employee_id.upper()
        for field in ("employee_id", "phone", "email"):
            other = await db.mr_directory.find_one({field: fields[field], "deleted": {"$ne": True}})
            if other and other["id"] != mid:
                raise HTTPException(409, f"An MR with this {field.replace('_', ' ')} already exists.")
        account = await db.users.find_one({"email": fields["email"], "role": "mr",
            "deleted": {"$ne": True}, "is_demo": {"$ne": True}, "active": {"$ne": False}})
        fields.update(user_id=account["id"] if account else None, updated_at=now_iso(), is_demo=False)
        if mid:
            await db.mr_directory.update_one({"id": mid}, {"$set": fields})
        else:
            mid = new_id()
            await db.mr_directory.insert_one({"id": mid, **fields, "created_by": user["id"], "created_at": now_iso()})
        return await db.mr_directory.find_one({"id": mid}, {"_id": 0})


@router.post("/mrs")
async def add_mr(body: MRIn, user=Depends(require_perm("settings", "manage"))):
    row = await save_mr(body, user)
    await log_audit(user, "create", "settings", row["id"], detail="MR directory")
    return row


@router.put("/mrs/{mid}")
async def edit_mr(mid: str, body: MRIn, user=Depends(require_perm("settings", "manage"))):
    row = await save_mr(body, user, mid)
    await log_audit(user, "edit", "settings", mid, detail="MR directory")
    return row


@router.delete("/mrs/{mid}")
async def remove_mr(mid: str, user=Depends(require_perm("settings", "manage"))):
    async with mr_lock("directory"):
        result = await db.mr_directory.update_one({"id": mid, "deleted": {"$ne": True}},
            {"$set": {"deleted": True, "active": False, "updated_at": now_iso()}})
        if not result.matched_count:
            raise HTTPException(404, "MR not found.")
    await log_audit(user, "delete", "settings", mid, detail="MR directory; reminder recipient removed")
    return {"ok": True}


@router.get("/mr-reminders")
async def get_reminder(user=Depends(require_perm("settings", "view"))):
    doc = await db.app_config.find_one({"key": "mr_reminders"})
    return {**DEFAULT_REMINDER, **(doc["value"] if doc else {})}


@router.put("/mr-reminders")
async def set_reminder(body: ReminderIn, user=Depends(require_perm("settings", "manage"))):
    if body.enabled and "send" not in permissions_for(user["role"]).get("whatsapp", []):
        raise HTTPException(403, "WhatsApp send permission is required to enable automatic reminders.")
    async with mr_lock("reminder-settings"):
        await db.app_config.update_one({"key": "mr_reminders"}, {"$set": {
            "key": "mr_reminders", "value": body.model_dump(), "approved_by": user["id"], "updated_at": now_iso()}}, upsert=True)
    await log_audit(user, "edit", "settings", "mr_reminders", detail="Automatic MR reminders enabled" if body.enabled else "Automatic MR reminders disabled")
    return body.model_dump()


@router.get("/mr-reminders/history")
async def reminder_history(user=Depends(require_perm("settings", "view"))):
    return {"items": await db.mr_reminder_runs.find({}, {"_id": 0}).sort("created_at", -1).to_list(500)}


async def reminder_tick(now=None):
    reporting = await db.app_config.find_one({"key": "mr_ivr"})
    if (reporting or {}).get("value", {}).get("enabled"):
        return  # Reporting invitations replace the legacy reminder, never duplicate it.
    now = now or datetime.now(IST)
    now = now.astimezone(IST)
    doc = await db.app_config.find_one({"key": "mr_reminders"})
    config = (doc or {}).get("value", DEFAULT_REMINDER)
    if not config.get("enabled"):
        return
    hour, minute = map(int, config["time"].split(":"))
    scheduled = now.replace(hour=hour, minute=minute, second=0, microsecond=0)
    # Missed reminders must not be sent later in the evening.
    if not scheduled <= now < scheduled + timedelta(hours=3):
        return
    if (doc or {}).get("next_send_at", "") > now.astimezone(ZoneInfo("UTC")).isoformat():
        return
    await refresh_role_definitions()
    approver = await db.users.find_one({"id": doc.get("approved_by")})
    if not approver or approver.get("deleted") or not approver.get("active", True) or \
            "send" not in permissions_for(approver["role"]).get("whatsapp", []) or \
            "manage" not in permissions_for(approver["role"]).get("settings", []):
        return
    from whatsapp_routing import sender_or_none
    session = await sender_or_none(db, purpose="mr")
    if not session:
        return
    mrs = await db.mr_directory.find({"active": True, "deleted": {"$ne": True}, "is_demo": {"$ne": True}}).to_list(2000)
    for mr in mrs:
        # One attempt per MR/date even after crashes, edits, pauses or replicas.
        run_id = f"mr-reminder:{now.date().isoformat()}:{mr['id']}"
        if await db.mr_reminder_runs.find_one({"id": run_id}):
            continue
        live = await db.mr_directory.find_one({"id": mr["id"], "active": True, "deleted": {"$ne": True}})
        latest = await db.app_config.find_one({"key": "mr_reminders"})
        if not live or not latest.get("value", {}).get("enabled"):
            continue
        consent = await db.consent_records.find({"phone": mr["phone"].lstrip("+")}).sort("created_at", -1).to_list(1)
        if consent and consent[0].get("status") == "opted_out":
            continue
        if await db.contacts.find_one({"mobile": {"$in": [live["phone"], live["phone"].lstrip("+")]},
                                      "opted_out": True, "deleted": {"$ne": True}}):
            continue
        message = config["message"].replace("{name}", live["name"]).replace("{employee_id}", live["employee_id"])
        claim = await db.mr_reminder_runs.update_one({"id": run_id}, {"$setOnInsert": {
            "id": run_id, "mr_id": mr["id"], "name": live["name"], "employee_id": live["employee_id"],
            "date": now.date().isoformat(), "status": "sending", "session_id": session["id"], "created_at": now_iso()
        }}, upsert=True)
        if not claim.upserted_id:
            continue
        request_id = hashlib.sha256(run_id.encode()).hexdigest()
        try:
            # The gateway accepts only pre-reserved, correlated 64-hex requests.
            await db.whatsapp_send_requests.update_one({"id": request_id}, {"$setOnInsert": {
                "id": request_id, "state": "sending", "provider": "qr", "recipient_address": live["phone"],
                "message_body": message, "user_id": approver["id"], "source": "mr_reminder", "created_at": now_iso()}}, upsert=True)
            await db.mr_reminder_runs.update_one({"id": run_id}, {"$set": {"gateway_request_id": request_id}})
            response = await wa_client.wa_send(live["phone"], message, request_id=request_id, session_id=session["id"])
            if not response.get("wamid"):
                raise RuntimeError("Provider acceptance unresolved.")
            await db.mr_reminder_runs.update_one({"id": run_id}, {"$set": {"status": "sent", "wamid": response["wamid"]}})
            await db.whatsapp_send_requests.update_one({"id": request_id}, {"$set": {
                "state": "accepted", "accepted_at": now_iso(), "gateway_accepted_wamid": response["wamid"]}})
            from routes_campaigns import _upsert_conversation
            conversation = await _upsert_conversation(live["phone"].lstrip("+"), live["name"], session["id"])
            await db.messages.update_one({"wamid": response["wamid"]}, {"$setOnInsert": {
                "id": new_id(), "conversation_id": conversation["id"], "wamid": response["wamid"],
                "session_id": session["id"], "direction": "outbound", "type": "text", "body": message,
                "sender": "MR reminder", "status": "sent", "is_demo": False, "created_at": now_iso()}}, upsert=True)
            await db.conversations.update_one({"id": conversation["id"]}, {"$set": {
                "last_message": message, "last_message_at": now_iso()}})
        except Exception:
            # Never unlock the daily reservation or change providers after IO.
            await db.mr_reminder_runs.update_one({"id": run_id, "status": "sending"}, {"$set": {
                "status": "uncertain", "error": "Provider acceptance unresolved. No automatic retry."}})
        gap = config.get("message_gap_seconds", 5)
        await db.app_config.update_one({"key": "mr_reminders"}, {"$set": {
            "next_send_at": (utcnow() + timedelta(seconds=gap)).isoformat()}})
        await asyncio.sleep(gap)
        return  # finite work per tick, recheck all guards before the next MR


async def start_mr_reminders():
    while True:
        try:
            async with mr_lock("scheduler"):
                await reminder_tick()
        except HTTPException:
            pass
        except Exception:
            logger.error("MR reminder tick failed; unresolved sends remain reserved.")
        await asyncio.sleep(15)