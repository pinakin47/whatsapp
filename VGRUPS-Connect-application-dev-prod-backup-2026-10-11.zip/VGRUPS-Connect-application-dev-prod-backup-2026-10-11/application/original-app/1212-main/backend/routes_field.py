"""MR field-sales (beat plan + doctor/clinic visits) and distributor/C&F portal."""
import logging
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import Response
from pydantic import BaseModel
from typing import Optional

from db import db, new_id, now_iso
from auth import require_perm

logger = logging.getLogger("vgrups.field")
router = APIRouter(prefix="/api", tags=["field-sales", "portal"])

VISIT_STATUS = ["planned", "visited", "skipped"]


def _today() -> str:
    return datetime.now(timezone.utc).date().isoformat()


def _is_manager(user: dict) -> bool:
    return user.get("role") in ("super_admin", "admin", "sales_manager")


def _month() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m")


class VisitIn(BaseModel):
    doctor_name: str
    clinic_name: Optional[str] = None
    specialty: Optional[str] = None
    mobile: Optional[str] = None
    address: Optional[str] = None
    city: Optional[str] = None
    planned_date: Optional[str] = None
    notes: Optional[str] = None


class VisitUpdate(BaseModel):
    status: Optional[str] = None
    notes: Optional[str] = None
    outcome: Optional[str] = None
    order_value: Optional[float] = None
    doctor_name: Optional[str] = None
    clinic_name: Optional[str] = None
    planned_date: Optional[str] = None


# ---------------- Field visits ----------------
@router.get("/field/visits")
async def list_visits(date: Optional[str] = None, mr_id: Optional[str] = None,
                      user: dict = Depends(require_perm("field_sales", "view"))):
    q: dict = {}
    if not _is_manager(user):
        q["mr_id"] = user["id"]
    elif mr_id:
        q["mr_id"] = mr_id
    if date:
        q["planned_date"] = date
    items = await db.field_visits.find(q, {"_id": 0}).sort("created_at", -1).to_list(500)
    return {"items": items, "statuses": VISIT_STATUS, "is_manager": _is_manager(user)}


@router.post("/field/visits")
async def create_visit(body: VisitIn, user: dict = Depends(require_perm("field_sales", "create"))):
    doc = {"id": new_id(), "mr_id": user["id"], "mr_name": user.get("name"), **body.model_dump(),
           "planned_date": body.planned_date or _today(), "status": "planned",
           "check_in_at": None, "outcome": None, "order_value": 0,
           "created_at": now_iso(), "updated_at": now_iso()}
    await db.field_visits.insert_one(doc)
    doc.pop("_id", None)
    return doc


@router.patch("/field/visits/{vid}")
async def update_visit(vid: str, body: VisitUpdate, user: dict = Depends(require_perm("field_sales", "edit"))):
    v = await db.field_visits.find_one({"id": vid}, {"_id": 0})
    if not v:
        raise HTTPException(status_code=404, detail="Visit not found")
    if not _is_manager(user) and v.get("mr_id") != user["id"]:
        raise HTTPException(status_code=403, detail="Not your visit")
    upd = {k: val for k, val in body.model_dump().items() if val is not None}
    if "status" in upd and upd["status"] not in VISIT_STATUS:
        raise HTTPException(status_code=422, detail="Invalid status")
    if upd.get("status") == "visited" and not v.get("check_in_at"):
        upd["check_in_at"] = now_iso()
    upd["updated_at"] = now_iso()
    await db.field_visits.update_one({"id": vid}, {"$set": upd})
    return {"ok": True, **upd}


@router.delete("/field/visits/{vid}")
async def delete_visit(vid: str, user: dict = Depends(require_perm("field_sales", "delete"))):
    v = await db.field_visits.find_one({"id": vid}, {"_id": 0})
    if v and not _is_manager(user) and v.get("mr_id") != user["id"]:
        raise HTTPException(status_code=403, detail="Not your visit")
    await db.field_visits.delete_one({"id": vid})
    return {"ok": True}


@router.get("/field/stats")
async def field_stats(user: dict = Depends(require_perm("field_sales", "view"))):
    q: dict = {} if _is_manager(user) else {"mr_id": user["id"]}
    today = _today()
    planned_today = await db.field_visits.count_documents({**q, "planned_date": today, "status": "planned"})
    visited_today = await db.field_visits.count_documents({**q, "planned_date": today, "status": "visited"})
    total_visits = await db.field_visits.count_documents(q)
    agg = await db.field_visits.aggregate([{"$match": {**q, "status": "visited"}},
                                           {"$group": {"_id": None, "val": {"$sum": "$order_value"}}}]).to_list(1)
    return {"planned_today": planned_today, "visited_today": visited_today,
            "total_visits": total_visits, "order_value": agg[0]["val"] if agg else 0}


@router.get("/field/mrs")
async def list_mrs(user: dict = Depends(require_perm("field_sales", "view"))):
    if not _is_manager(user):
        return {"items": [{"id": user["id"], "name": user.get("name")}]}
    mrs = await db.users.find({"role": "mr", "deleted": {"$ne": True}, "is_demo": {"$ne": True},
                             "active": {"$ne": False}}, {"_id": 0, "id": 1, "name": 1, "email": 1}).to_list(2000)
    emails = {u.get("email", "").lower() for u in mrs}
    directory = await db.mr_directory.find({"active": True, "deleted": {"$ne": True},
        "is_demo": {"$ne": True}}, {"_id": 0}).to_list(2000)
    mrs += [{"id": f"directory:{m['id']}", "name": m["name"]} for m in directory
            if m.get("email", "").lower() not in emails]
    return {"items": mrs}


# ---------------- Monthly targets + incentive ----------------
class TargetIn(BaseModel):
    mr_id: Optional[str] = None
    month: Optional[str] = None
    visit_target: int = 0
    order_target: float = 0
    incentive_pct: float = 0


async def _achievement(mr_id: str, month: str) -> dict:
    q = {"mr_id": mr_id, "status": "visited", "planned_date": {"$regex": f"^{month}"}}
    visits_done = await db.field_visits.count_documents(q)
    agg = await db.field_visits.aggregate([{"$match": q},
                                           {"$group": {"_id": None, "val": {"$sum": "$order_value"}}}]).to_list(1)
    return {"visits_done": visits_done, "orders_done": round(agg[0]["val"], 2) if agg else 0}


@router.get("/field/targets")
async def list_targets(month: Optional[str] = None, user: dict = Depends(require_perm("field_sales", "view"))):
    m = month or _month()
    if _is_manager(user):
        targets = await db.field_targets.find({"month": m}, {"_id": 0}).to_list(500)
    else:
        targets = await db.field_targets.find({"month": m, "mr_id": user["id"]}, {"_id": 0}).to_list(10)
    out = []
    for t in targets:
        ach = await _achievement(t["mr_id"], m)
        earned = round(ach["orders_done"] * float(t.get("incentive_pct") or 0) / 100.0) \
            if (t.get("order_target") and ach["orders_done"] >= float(t["order_target"])) else 0
        out.append({**t, **ach, "incentive_earned": earned})
    # if an MR has no target set, still return their achievement row
    if not _is_manager(user) and not out:
        ach = await _achievement(user["id"], m)
        out.append({"mr_id": user["id"], "mr_name": user.get("name"), "month": m, "visit_target": 0,
                    "order_target": 0, "incentive_pct": 0, **ach, "incentive_earned": 0})
    return {"month": m, "targets": out, "is_manager": _is_manager(user)}


@router.post("/field/targets")
async def set_target(body: TargetIn, user: dict = Depends(require_perm("field_sales", "edit"))):
    mr_id = body.mr_id or user["id"]
    if mr_id != user["id"] and not _is_manager(user):
        raise HTTPException(status_code=403, detail="Only managers can set targets for others")
    m = body.month or _month()
    mr = await db.users.find_one({"id": mr_id}, {"_id": 0, "name": 1})
    doc = {"mr_id": mr_id, "mr_name": (mr or {}).get("name"), "month": m,
           "visit_target": int(body.visit_target), "order_target": float(body.order_target),
           "incentive_pct": float(body.incentive_pct), "updated_at": now_iso()}
    await db.field_targets.update_one({"mr_id": mr_id, "month": m},
                                      {"$set": doc, "$setOnInsert": {"id": new_id(), "created_at": now_iso()}},
                                      upsert=True)
    return {"ok": True, **doc}


# ---------------- Distributor / C&F portal ----------------
@router.get("/portal/summary")
async def portal_summary(user: dict = Depends(require_perm("portal", "view"))):
    is_admin = user.get("role") in ("super_admin", "admin")
    q: dict = {} if is_admin else {"created_by": user["id"]}
    orders = await db.orders.find(q, {"_id": 0}).sort("created_at", -1).to_list(200)
    billed = sum(float(o.get("total") or 0) for o in orders)
    paid = sum(float(o.get("total") or 0) for o in orders if o.get("payment_status") == "paid")
    return {
        "orders": [{"order_no": o.get("order_no"), "contact_name": o.get("contact_name"),
                    "total": o.get("total"), "status": o.get("status"),
                    "payment_status": o.get("payment_status"), "items_count": o.get("items_count"),
                    "created_at": o.get("created_at")} for o in orders],
        "ledger": {"billed": round(billed, 2), "paid": round(paid, 2),
                   "outstanding": round(billed - paid, 2), "order_count": len(orders)},
        "preview_all": is_admin,
    }


def _invoice_pdf(order: dict) -> bytes:
    import io
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.units import mm
    from reportlab.pdfgen import canvas

    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=A4)
    w, h = A4
    y = h - 25 * mm
    c.setFillColorRGB(0.23, 0.36, 0.16)
    c.rect(0, h - 18 * mm, w, 18 * mm, fill=1, stroke=0)
    c.setFillColorRGB(1, 1, 1)
    c.setFont("Helvetica-Bold", 16)
    c.drawString(20 * mm, h - 12 * mm, "VGRUPS HEALTHCARE")
    c.setFont("Helvetica", 9)
    c.drawRightString(w - 20 * mm, h - 12 * mm, "TAX INVOICE")

    c.setFillColorRGB(0, 0, 0)
    c.setFont("Helvetica-Bold", 12)
    c.drawString(20 * mm, y, f"Invoice: {order.get('order_no', '')}")
    c.setFont("Helvetica", 9)
    c.drawString(20 * mm, y - 6 * mm, f"Date: {(order.get('created_at') or '')[:10]}")
    c.drawString(20 * mm, y - 11 * mm, f"Bill to: {order.get('contact_name', '')}")
    if order.get("mobile"):
        c.drawString(20 * mm, y - 16 * mm, f"Mobile: {order.get('mobile')}")
    c.drawRightString(w - 20 * mm, y - 6 * mm, f"Payment: {order.get('payment_status', 'pending').upper()}")

    ty = y - 28 * mm
    c.setFont("Helvetica-Bold", 9)
    c.drawString(20 * mm, ty, "Item")
    c.drawString(110 * mm, ty, "Qty")
    c.drawString(130 * mm, ty, "Rate")
    c.drawRightString(w - 20 * mm, ty, "Amount")
    c.line(20 * mm, ty - 2 * mm, w - 20 * mm, ty - 2 * mm)
    ty -= 8 * mm
    c.setFont("Helvetica", 9)
    for it in order.get("items", []):
        c.drawString(20 * mm, ty, str(it.get("name", ""))[:55])
        c.drawString(110 * mm, ty, str(it.get("qty", "")))
        c.drawString(130 * mm, ty, f"{float(it.get('price', 0)):.0f}")
        c.drawRightString(w - 20 * mm, ty, f"{float(it.get('amount', 0)):.0f}")
        ty -= 6 * mm
        if ty < 40 * mm:
            c.showPage()
            ty = h - 30 * mm

    c.line(110 * mm, ty, w - 20 * mm, ty)
    ty -= 7 * mm
    for label, val in [("Subtotal", order.get("subtotal", 0)), ("GST", order.get("gst_amount", 0)),
                       ("Discount", -float(order.get("discount", 0) or 0))]:
        c.drawString(130 * mm, ty, label)
        c.drawRightString(w - 20 * mm, ty, f"{float(val or 0):.0f}")
        ty -= 6 * mm
    c.setFont("Helvetica-Bold", 11)
    c.drawString(130 * mm, ty, "Total")
    c.drawRightString(w - 20 * mm, ty, f"Rs. {float(order.get('total', 0)):.0f}")
    c.setFont("Helvetica-Oblique", 8)
    c.drawString(20 * mm, 18 * mm, "This is a computer-generated invoice from VGRUPS CONNECT.")
    c.showPage()
    c.save()
    return buf.getvalue()


@router.get("/portal/orders/{order_no}/invoice.pdf")
async def portal_invoice(order_no: str, user: dict = Depends(require_perm("portal", "view"))):
    is_admin = user.get("role") in ("super_admin", "admin")
    q = {"order_no": order_no} if is_admin else {"order_no": order_no, "created_by": user["id"]}
    order = await db.orders.find_one(q, {"_id": 0})
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")
    pdf = _invoice_pdf(order)
    return Response(content=pdf, media_type="application/pdf",
                    headers={"Content-Disposition": f'inline; filename="invoice-{order_no}.pdf"'})


class StockItemIn(BaseModel):
    name: str
    qty: int = 1


class StockRequestIn(BaseModel):
    items: list[StockItemIn] = []
    notes: Optional[str] = None


@router.get("/portal/stock-requests")
async def list_stock_requests(user: dict = Depends(require_perm("portal", "view"))):
    is_admin = user.get("role") in ("super_admin", "admin")
    q = {} if is_admin else {"requested_by": user["id"]}
    items = await db.stock_requests.find(q, {"_id": 0}).sort("created_at", -1).to_list(100)
    return {"items": items}


@router.post("/portal/stock-requests")
async def create_stock_request(body: StockRequestIn, user: dict = Depends(require_perm("portal", "view"))):
    if not body.items:
        raise HTTPException(status_code=422, detail="Add at least one item")
    doc = {"id": new_id(), "number": f"SR-{int(datetime.now(timezone.utc).timestamp())}",
           "requested_by": user["id"], "requested_by_name": user.get("name"),
           "items": [i.model_dump() for i in body.items], "notes": body.notes,
           "status": "pending", "created_at": now_iso(), "updated_at": now_iso()}
    await db.stock_requests.insert_one(doc)
    doc.pop("_id", None)
    return doc
