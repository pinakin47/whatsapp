"""Directory browsing and explicit single-recipient WhatsApp actions."""
from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field, field_validator
from auth import require_perm
from db import db
from contact_directory import directory_page, recipient, check_consent, international_phone
import contact_catalogue as catalogue
import catalogue_reports as reports
from mr_catalog_daily import catalogue_snapshot
from routes_whatsapp import RecipientMessageIn, send_to_recipient

router = APIRouter(prefix="/api/contacts", tags=["Individual contact WhatsApp"])
KEY_PATTERN = r"^[A-Za-z0-9_-]+$"


class AttemptIn(BaseModel):
    request_key: str = Field(min_length=16, max_length=128, pattern=KEY_PATTERN)
    expected_phone: str
    session_id: str | None = None


class MessageIn(AttemptIn):
    body: str = Field(min_length=1, max_length=10000)

    @field_validator("body")
    @classmethod
    def clean_body(cls, value):
        if not value.strip():
            raise ValueError("Message cannot be blank.")
        return value.strip()


@router.get("/directory")
async def all_contacts(search: str = "", contact_type: str = "all", offset: int = Query(0, ge=0),
                       limit: int = Query(100, ge=1, le=500), user=Depends(require_perm("crm", "view"))):
    return await directory_page(db, user, search, contact_type, offset, limit)


@router.get("/catalogue-assets")
async def catalogue_assets(user=Depends(require_perm("catalog", "view"))):
    parts = await catalogue_snapshot(db)
    return {"items": [{k: p[k] for k in ("name", "content_type")} for p in parts], "total": len(parts),
            "image_count": sum(p["content_type"] == "image/jpeg" for p in parts),
            "pdf_count": sum(p["content_type"] == "application/pdf" for p in parts)}


@router.get("/catalogue-attempts/{key}")
async def catalogue_attempt(key: str, user=Depends(require_perm("crm", "view")),
                            viewer=Depends(require_perm("catalog", "view"))):
    job = await db.contact_catalogue_runs.find_one({"id": catalogue.attempt_id(user["id"], key), "user_id": user["id"]})
    if not job:
        raise HTTPException(404, "No saved catalogue attempt.")
    return await catalogue.status(db, job)


@router.get("/catalogue-attempts/{key}/report.csv")
async def catalogue_attempt_csv(key: str, user=Depends(require_perm("crm", "view")),
                                exporter=Depends(require_perm("crm", "export")),
                                viewer=Depends(require_perm("catalog", "view")),
                                catalog_exporter=Depends(require_perm("catalog", "export"))):
    from delivery_report_csv import csv_response
    row = await catalogue_attempt(key, user)
    return csv_response("individual_catalogue_delivery",
        ["Recipient", "Sender number", "Send status", "Parts", "Accepted", "Removed", "Uncertain", "Error"],
        [[row["phone"], row["sender_number"], row["status"], row["total_parts"],
          row["accepted_parts"], row["removed_parts"], row["uncertain_parts"], row["error"]]])


@router.get("/catalogue-history")
async def catalogue_history(contact_ref: str | None = None, offset: int = Query(0, ge=0),
                            limit: int = Query(20, ge=1, le=100),
                            user=Depends(require_perm("crm", "view")),
                            viewer=Depends(require_perm("catalog", "view"))):
    query = {"user_id": user["id"]}
    if contact_ref is not None:
        query["contact_ref"] = contact_ref
    return await reports.page(db, db.contact_catalogue_runs, db.contact_catalogue_parts, query, offset, limit)


@router.get("/catalogue-history.csv")
async def catalogue_history_csv(contact_ref: str | None = None, offset: int = Query(0, ge=0),
                                limit: int = Query(20, ge=1, le=100),
                                user=Depends(require_perm("crm", "view")),
                                viewer=Depends(require_perm("catalog", "view")),
                                exporter=Depends(require_perm("crm", "export")),
                                catalog_exporter=Depends(require_perm("catalog", "export"))):
    result = await catalogue_history(contact_ref, offset, limit, user, viewer)
    return reports.history_csv("individual_catalogue_history", result)


@router.get("/catalogue-history/{run_id}")
async def catalogue_history_detail(run_id: str, user=Depends(require_perm("crm", "view")),
                                   viewer=Depends(require_perm("catalog", "view"))):
    job = await db.contact_catalogue_runs.find_one({"id": run_id, "user_id": user["id"]})
    if not job:
        raise HTTPException(404, "No saved catalogue attempt.")
    return await reports.detail(db, job, db.contact_catalogue_parts)


@router.get("/catalogue-history/{run_id}/report.csv")
async def catalogue_history_detail_csv(run_id: str, user=Depends(require_perm("crm", "view")),
                                       viewer=Depends(require_perm("catalog", "view")),
                                       exporter=Depends(require_perm("crm", "export")),
                                       catalog_exporter=Depends(require_perm("catalog", "export"))):
    row = await catalogue_history_detail(run_id, user, viewer)
    return reports.detail_csv("individual_catalogue_attempt", row)


@router.post("/{cid}/message")
async def send_message(cid: str, body: MessageIn, user=Depends(require_perm("inbox", "send"))):
    row = await recipient(db, cid, user)
    phone = await check_consent(db, row)
    if phone != international_phone(body.expected_phone):
        raise HTTPException(409, "Contact number changed. Reload Contacts before sending.")
    # Use the same durable request identity as recovery's phone payload.
    response = await send_to_recipient(RecipientMessageIn(body=body.body, phone=phone,
                                                        request_key=body.request_key, session_id=body.session_id), user)
    if response.get("conversation_id"):
        await db.conversations.update_one({"id": response["conversation_id"],
            "name": {"$in": [phone, phone.lstrip("+")]}},
            {"$set": {"name": row["name"], "contact_id": row["contact_id"], "contact_type": row["contact_type"]}})
    return response


@router.post("/{cid}/catalogue", status_code=202)
async def send_catalogue(cid: str, body: AttemptIn, user=Depends(require_perm("inbox", "send"))):
    return await catalogue.enqueue(db, user, cid, body.request_key, body.expected_phone, body.session_id)
