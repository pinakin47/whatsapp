"""Permission-filtered contact directory, without copying or changing source records."""
import re
from fastapi import HTTPException
from auth import permissions_for
from lead_access import lead_scope
from whatsapp_routing import accounts

REAL = {"deleted": {"$ne": True}, "is_demo": {"$ne": True}}


def phone_key(value):
    return re.sub(r"[\s().-]", "", str(value or "")).lstrip("+")


def international_phone(value):
    number = phone_key(value)
    if not re.fullmatch(r"[1-9]\d{7,14}", number):
        raise HTTPException(422, "Add a valid international number with country code in the original record.")
    return "+" + number


async def directory_sources(database, user):
    """Ordered source precedence is shared by paging and fresh recipient checks."""
    permissions = permissions_for(user["role"])
    if "view" not in permissions.get("crm", []):
        raise HTTPException(403, "Contact view permission is required.")
    sources = []

    def add(collection, label, kind, name_fields, phone_fields, selector):
        sources.append((collection, label, kind, name_fields, phone_fields, selector))

    add("contacts", "Contacts", "customer", ("name",), ("mobile", "phone"), REAL)
    if "view" in permissions.get("settings", []):
        add("mr_directory", "MR Directory", "mr", ("name",), ("phone", "mobile"), REAL)
        add("users", "Team Users", "team", ("name",), ("phone", "mobile"), REAL)
    if "view" in permissions.get("leads", []):
        add("leads", "Leads", "lead", ("contact_name", "name", "title"),
            ("mobile", "phone", "alternative_phone"), lead_scope(user))
    if "view" in permissions.get("orders", []):
        add("orders", "Orders", "customer", ("contact_name", "customer_name", "name"),
            ("mobile", "phone"), REAL)
        add("quotations", "Quotations", "customer", ("contact_name", "customer_name", "name"),
            ("mobile", "phone"), REAL)
    if "view" in permissions.get("recruitment", []):
        add("candidates", "Recruitment", "candidate", ("name",), ("phone", "mobile"), REAL)
    if "view" in permissions.get("inbox", []):
        sessions = [session["id"] for session in await accounts(database, include_archived=True)]
        # One query for all known live and archived accounts, never one account only.
        add("conversations", "WhatsApp Inbox", "customer", ("name",), ("phone",),
            {**REAL, "session_id": {"$in": sessions}})
    return sources


def source_rows(source, spec):
    collection, label, kind, name_fields, phone_fields, _ = spec
    name = next((source.get(k) for k in name_fields if source.get(k)), "")
    mobile = next((source.get(k) for k in phone_fields if source.get(k)), "")
    if not name and not mobile:
        return []
    physical = collection == "contacts"
    ref = source["id"] if physical else f"{collection}:{source['id']}"
    row = {"id": ref, "contact_id": source["id"] if physical else None,
        "name": name or str(mobile), "mobile": str(mobile or ""),
        "email": source.get("email"), "company": source.get("company"),
        "city": source.get("city"), "state": source.get("state"),
        "contact_type": (source.get("contact_type") or kind).lower().replace(" ", "_"),
        "is_virtual": not physical, "opted_out": bool(source.get("opted_out")),
        "sources": [label], "aliases": [], "directory_refs": [ref]}
    if re.fullmatch(r"[1-9]\d{7,14}", phone_key(mobile)):
        row["mobile"] = "+" + phone_key(mobile)
    rows = [row]
    alternate = source.get("alternative_phone")
    if alternate and phone_key(alternate) != phone_key(mobile):
        alternate_ref = f"{collection}:{source['id']}:alternative_phone"
        rows.append({**row, "id": alternate_ref, "contact_id": None,
            "mobile": str(alternate), "is_virtual": True,
            "directory_refs": [alternate_ref], "sources": [label + " (alternate number)"]})
    return rows


async def directory_page(database, user, search="", contact_type="all", offset=0, limit=100):
    return await database.contact_directory_page(
        await directory_sources(database, user), search.strip(), contact_type, offset, limit)


async def directory(database, user):
    """Reference implementation for document-API fixtures, not the browsing path."""
    rows = []
    for spec in await directory_sources(database, user):
        collection, _, _, name_fields, phone_fields, selector = spec
        # Only contact fields leave the source collection; never return credentials,
        # candidate resumes or private lead/report payloads.
        projection = {k: 1 for k in ("id", "email", "company", "city", "state", "contact_type",
            "opted_out", *name_fields, *phone_fields)}
        projection["_id"] = 0
        if collection == "conversations":
            projection["session_id"] = 1
        records = await getattr(database, collection).find(selector, projection).to_list(None)
        if collection == "conversations":
            session_order = {sid: i for i, sid in enumerate(selector["session_id"]["$in"])}
            # Session is needed solely for source precedence, never in output.
            records.sort(key=lambda source: session_order[source["session_id"]])
        for source in records:
            rows.extend(source_rows(source, spec))
    return merge_rows(rows)


def merge_rows(rows):
    merged = {}
    for row in rows:
        key = phone_key(row["mobile"]) or row["id"]
        if key not in merged:
            merged[key] = row
            continue
        current = merged[key]
        if row["name"] != current["name"] and row["name"] not in current["aliases"]:
            current["aliases"].append(row["name"])
        current["sources"] = list(dict.fromkeys([*current["sources"], *row["sources"]]))
        current["directory_refs"].extend(row["directory_refs"])
        current["opted_out"] |= row["opted_out"]
        for field in ("email", "company", "city", "state"):
            current[field] = current.get(field) or row.get(field)
    return sorted(merged.values(), key=lambda r: (r["name"].casefold(), r["id"]))


async def recipient(database, cid, user):
    specs = await directory_sources(database, user)
    # Resolve the exact reference under current permissions first. Do not resolve
    # a stale ID via a cached phone or silently substitute a different record.
    target = None
    for spec in specs:
        collection = spec[0]
        prefix = "" if collection == "contacts" else collection + ":"
        if prefix and not cid.startswith(prefix):
            continue
        source_id = cid[len(prefix):]
        alternate = source_id.endswith(":alternative_phone")
        if alternate:
            source_id = source_id[:-len(":alternative_phone")]
        projection = {k: 1 for k in ("id", "contact_type", "opted_out", *spec[3], *spec[4])}
        source = await database.contact_directory_source(collection, source_id, spec[5], projection)
        if source:
            target = next((r for r in source_rows(source, spec) if r["id"] == cid), None)
        if target:
            break
    row = None
    if target:
        result = await database.contact_directory_page(
            specs, "", "all", 0, 1, key=phone_key(target["mobile"]) or target["id"])
        row = next((r for r in result["items"] if cid in r["directory_refs"]), None)
    if not row:
        raise HTTPException(404, "Contact not found or no longer accessible.")
    return row


async def check_consent(database, row):
    phone = international_phone(row["mobile"])
    if row["opted_out"] or await database.contact_phone_opted_out(phone_key(phone)):
        raise HTTPException(409, "This recipient opted out of WhatsApp messages.")
    consents = await database.consent_records.find({"phone": phone.lstrip("+")}).sort("created_at", -1).to_list(1)
    if consents and consents[0].get("status") == "opted_out":
        raise HTTPException(409, "This recipient opted out of WhatsApp messages.")
    return phone
