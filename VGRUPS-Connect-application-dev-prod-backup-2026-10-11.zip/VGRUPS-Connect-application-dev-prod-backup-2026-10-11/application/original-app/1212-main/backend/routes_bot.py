from fastapi import APIRouter, Depends
from pydantic import BaseModel
from typing import Optional

from db import db, new_id, now_iso
from auth import require_perm

router = APIRouter(prefix="/api", tags=["bot"])

DEFAULT_BOT = {
    "enabled": False,
    "welcome": "👋 Welcome to VGRUPS Healthcare! We're glad you reached out.",
    "askName": "To help you better, may I know your name?",
    "askProduct": "Which product are you interested in? (e.g. VD3K2, Nitrile Gloves, N95 Masks)",
    "askQuantity": "Great! How many units do you need?",
    "handoff": "Thank you! 🙏 Our sales team will contact you shortly with pricing and availability.",
}


class BotConfig(BaseModel):
    enabled: bool = False
    welcome: str = DEFAULT_BOT["welcome"]
    askName: str = DEFAULT_BOT["askName"]
    askProduct: str = DEFAULT_BOT["askProduct"]
    askQuantity: str = DEFAULT_BOT["askQuantity"]
    handoff: str = DEFAULT_BOT["handoff"]


@router.get("/bot/config")
async def get_bot_config(user: dict = Depends(require_perm("chatbot", "view"))):
    doc = await db.app_config.find_one({"key": "bot"}, {"_id": 0})
    return doc["value"] if doc else DEFAULT_BOT


@router.put("/bot/config")
async def set_bot_config(body: BotConfig, user: dict = Depends(require_perm("chatbot", "manage"))):
    await db.app_config.update_one({"key": "bot"},
                                   {"$set": {"key": "bot", "value": body.model_dump(), "updated_at": now_iso()}},
                                   upsert=True)
    return body.model_dump()


@router.get("/consent")
async def list_consent(user: dict = Depends(require_perm("contacts", "view")), limit: int = 200):
    items = await db.consent_records.find({}, {"_id": 0}).sort("created_at", -1).to_list(limit)
    opted_out = await db.contacts.count_documents({"opted_out": True, "deleted": {"$ne": True}})
    return {"items": items, "opted_out_total": opted_out}
