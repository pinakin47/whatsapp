"""Serialize edits/start/cancel with sending without blocking unrelated campaigns."""
from contextlib import asynccontextmanager
from fastapi import HTTPException
from db import db


@asynccontextmanager
async def campaign_lock(cid):
    pool = await db.connect()
    async with pool.acquire() as conn:
        key = "campaign-management:" + cid
        acquired = await conn.fetchval("SELECT pg_try_advisory_lock(hashtext($1))", key)
        if not acquired:
            raise HTTPException(409, "This campaign is processing. Pause it and wait for the current send to finish before editing.")
        try:
            yield
        finally:
            await conn.execute("SELECT pg_advisory_unlock(hashtext($1))", key)