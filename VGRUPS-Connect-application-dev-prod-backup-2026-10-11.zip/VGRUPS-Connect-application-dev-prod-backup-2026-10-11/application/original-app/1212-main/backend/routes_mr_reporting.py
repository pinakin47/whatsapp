"""Opt-in MR reporting invitations and independently claimed admin notifications."""
import asyncio
import hashlib
import html
import logging
import re
from datetime import datetime, timedelta, timezone
from pydantic import BaseModel, Field, EmailStr, TypeAdapter
from fastapi import APIRouter, Depends, HTTPException
from auth import require_perm, permissions_for, refresh_role_definitions
from db import db, now_iso, new_id, log_audit
from routes_mr_settings import IST, mr_lock
import wa_client
import brevo_client
from mr_report_receipts import receipt_index, delivery_evidence
from whatsapp_routing import attach_report_senders, report_sender_context

router = APIRouter(prefix="/api", tags=["MR reporting"])
logger = logging.getLogger("vgrups.mr-reporting")
DEFAULT_CONFIG = {
    "enabled": False, "morning_time": "08:00", "closing_time": "20:00",
    "timezone": "Asia/Kolkata", "message_gap_seconds": 5,
    "email_reports": True, "whatsapp_reports": True,
}
REAL = {"active": {"$ne": False}, "deleted": {"$ne": True}, "is_demo": {"$ne": True}}
UNAVAILABLE_ERROR = "Missing contact, channel configuration or consent."


def valid_report_email(value):
    """Normalize valid addresses; historical/imported invalid contacts are no-IO."""
    try:
        return str(TypeAdapter(EmailStr).validate_python(value))
    except ValueError:
        return None


def can_send_report(user, channel):
    perms = permissions_for(user.get("role", ""))
    return (user.get("role") in ("admin", "super_admin") and
            user.get("active") is not False and not user.get("deleted") and not user.get("is_demo") and
            "view" in perms.get("field_sales", []) and
            "manage" in perms.get("settings", []) and "manage" in perms.get("reports", []) and
            "send" in perms.get("reports", []) and
            (channel == "email" or "send" in perms.get("whatsapp", [])))


def recoverable(claim, history):
    # Legacy unavailable claims were written only by the scheduler's no-IO branch.
    no_io = claim.get("provider_io") is False or (
        "provider_io" not in claim and claim.get("error") == UNAVAILABLE_ERROR)
    return (claim.get("status") == "unavailable" and no_io and
            all(claim.get(k) for k in ("id", "report_id", "submission_id", "user_id")) and
            claim.get("channel") in ("email", "whatsapp") and
            not any(claim.get(k) for k in ("part", "original_notification_id",
                                          "wamid", "gateway_request_id")) and
            not any(x["id"] != claim["id"] and
                    x.get("submission_id") == claim.get("submission_id") and
                    x.get("user_id") == claim.get("user_id") and
                    x.get("channel") == claim.get("channel") for x in history))


class SendReportIn(BaseModel):
    confirm: bool = False


@router.post("/field/report-notifications/{notification_id}/send-now")
async def send_report_now(notification_id: str, body: SendReportIn,
                          user=Depends(require_perm("field_sales", "view"))):
    await refresh_role_definitions()
    actor = await db.users.find_one({"id": user["id"], **REAL})
    original = await db.mr_report_notifications.find_one({"id": notification_id})
    if not actor or not can_send_report(actor, (original or {}).get("channel")):
        raise HTTPException(403, "Administrator, reporting management and send permissions are required.")
    if not body.confirm:
        raise HTTPException(422, "Explicit confirmation is required to send this saved report.")
    if not original:
        raise HTTPException(404, "Notification not found.")
    history = await db.mr_report_notifications.find({
        "submission_id": original.get("submission_id"), "user_id": original.get("user_id"),
        "channel": original.get("channel")}).to_list(None)
    if not recoverable(original, history):
        raise HTTPException(409, "This notification cannot be retried. Existing attempts remain reserved.")
    # Check exact gateway evidence as well, including legacy rows.
    request_id = hashlib.sha256(original["id"].encode()).hexdigest()
    if await db.whatsapp_send_requests.find_one({"id": request_id}):
        raise HTTPException(409, "Provider evidence exists. Sending again is blocked.")
    doc = await db.app_config.find_one({"key": "mr_ivr"})
    config = {**DEFAULT_CONFIG, **(doc or {}).get("value", {})}
    channel = original["channel"]
    if not config["enabled"] or not config[f"{channel}_reports"]:
        raise HTTPException(409, "Reporting or this channel is disabled.")
    recipient = await db.users.find_one({"id": original["user_id"], **REAL,
                                        "role": {"$in": ["admin", "super_admin"]}})
    if not recipient:
        raise HTTPException(409, "The recipient must be an active, non-demo administrator.")
    session = None
    if channel == "email":
        address = valid_report_email(recipient.get("email"))
        if address is None:
            raise HTTPException(409, "The administrator needs a valid email address.")
        if not brevo_client.configured():
            raise HTTPException(409, "Email delivery is unavailable.")
    else:
        address = re.sub(r"[\s().-]", "", recipient.get("phone") or recipient.get("mobile") or "")
        if not re.fullmatch(r"\+[1-9]\d{7,14}", address):
            raise HTTPException(409, "The administrator needs a valid international phone number.")
        if await opted_out(address):
            raise HTTPException(409, "WhatsApp consent does not allow sending.")
        from whatsapp_routing import sender_or_none
        session = await sender_or_none(db, purpose="mr")
        if not session:
            raise HTTPException(409, "The QR WhatsApp channel is unavailable.")
    submission = await db.mr_report_submissions.find_one({"id": original["submission_id"]})
    if not submission or submission["report"]["id"] != original["report_id"]:
        raise HTTPException(409, "The saved closing snapshot is unavailable.")
    # Stable ID makes simultaneous clicks and subsequent requests idempotent across workers.
    claim = {k: original[k] for k in ("report_id", "submission_id", "user_id", "channel")}
    claim.update(id=f"{original['id']}:manual", original_notification_id=original["id"],
                 name=recipient.get("name", ""), recipient_address=address,
                 requested_by=actor["id"], confirmed_at=now_iso(), created_at=now_iso(),
                 status="sending", provider="qr" if channel == "whatsapp" else "brevo",
                 provider_io=True)
    reserved = await db.mr_report_notifications.update_one({"id": claim["id"]},
        {"$setOnInsert": claim}, upsert=True)
    if not reserved.upserted_id:
        raise HTTPException(409, "A manual attempt is already reserved. No message was resent.")
    # Audit must succeed before delivery. A failure leaves the reservation blocked, not retryable.
    await log_audit(actor, "send", "reports", claim["id"],
                    detail=f"Confirmed saved MR report delivery; original={original['id']}; channel={channel}")
    await deliver_report(claim, submission["report"], address, session, actor, config)
    attempt = await db.mr_report_notifications.find_one({"id": claim["id"]}, {"_id": 0})
    if attempt and attempt.get("channel") == "whatsapp":
        await attach_report_senders(db, [attempt])
    return {"attempt": attempt}


class ReportingIn(BaseModel):
    confirm_enable: bool = False
    enabled: bool = False
    morning_time: str = Field(default="08:00", pattern=r"^(?:[01]\d|2[0-3]):[0-5]\d$")
    closing_time: str = Field(default="20:00", pattern=r"^(?:[01]\d|2[0-3]):[0-5]\d$")
    timezone: str = Field(default="Asia/Kolkata", pattern=r"^Asia/Kolkata$")
    message_gap_seconds: int = Field(default=5, ge=1, le=300)
    email_reports: bool = True
    whatsapp_reports: bool = True


@router.get("/settings/mr-ivr")
async def get_config(user=Depends(require_perm("settings", "view"))):
    doc = await db.app_config.find_one({"key": "mr_ivr"})
    return {**DEFAULT_CONFIG, **(doc or {}).get("value", {})}


@router.put("/settings/mr-ivr")
async def set_config(body: ReportingIn, user=Depends(require_perm("settings", "manage"))):
    if body.morning_time == body.closing_time:
        raise HTTPException(422, "Morning and closing times must be different.")
    if body.enabled and "send" not in permissions_for(user["role"]).get("whatsapp", []):
        raise HTTPException(403, "WhatsApp send permission is required.")
    if body.enabled and not body.confirm_enable:
        raise HTTPException(422, "Explicit confirmation is required to enable real sends.")
    value = body.model_dump(exclude={"confirm_enable"})
    async with mr_lock("reporting-settings"):
        await db.app_config.update_one({"key": "mr_ivr"}, {"$set": {
            "key": "mr_ivr", "value": value, "approved_by": user["id"],
            "updated_at": now_iso()}}, upsert=True)
    await log_audit(user, "edit", "settings", "mr_ivr",
                    detail="MR reporting IVR enabled" if body.enabled else "MR reporting IVR disabled")
    return value


@router.get("/field/daily-reports")
async def daily_reports(date: str | None = None, mr_id: str | None = None,
                        user=Depends(require_perm("field_sales", "view"))):
    from routes_field import _is_manager
    manager = _is_manager(user)
    day = date or datetime.now(IST).date().isoformat()
    try:
        if datetime.strptime(day, "%Y-%m-%d").date().isoformat() != day:
            raise ValueError()
    except ValueError:
        raise HTTPException(422, "Date must be YYYY-MM-DD.")
    query = {"date": day}
    if not manager:
        query["mr_id"] = user["id"]
    elif mr_id:
        query["mr_id"] = mr_id
    items = await db.mr_daily_reports.find(query, {"_id": 0}).sort("mr_name", 1).to_list(2000)
    # Scope all history/evidence reads to the reports selected above, including
    # the MR-only permission filter and the report limit.
    notifications = await db.mr_report_notifications.find({
        "report_id": {"$in": [row["id"] for row in items]}},
        {"_id": 0}).sort("created_at", -1).to_list(None) if items else []
    by_report = {}
    for claim in notifications:
        by_report.setdefault(claim["report_id"], []).append(claim)
    evidence = await load_report_receipts(notifications, include_senders=True)
    for row in items:
        # Derive from current answers, never a stale cross-conversation cached total.
        plan, closing = row.get("plan", {}), row.get("closing", {})
        goal = plan.get("expected_sales")
        row["summary"] = {
            "planned_visits": plan.get("planned_visits", 0),
            "completed_visits": closing.get("completed_visits", 0),
            "pending_visits": max(0, plan.get("planned_visits", 0) - closing.get("completed_visits", 0)),
            **{key: closing.get(key, 0) for key in ("doctor_visits", "customer_visits", "calls",
                "orders", "sales", "quotations", "tomorrow_visits")},
            "daily_goal": goal,
            "achievement_pct": round(closing.get("sales", 0) / goal * 100, 2) if goal and goal > 0 else None,
        }
        row["notifications"] = by_report.get(row["id"], [])
        for claim in row["notifications"]:
            claim["can_send_now"] = can_send_report(user, claim.get("channel")) and recoverable(
                claim, row["notifications"])
        await attach_report_receipts(row["notifications"], evidence=evidence)
    return {"items": items, "is_manager": manager}


@router.get("/field/daily-reports.csv")
async def daily_reports_csv(date: str | None = None, mr_id: str | None = None,
                            user=Depends(require_perm("field_sales", "view")),
                            exporter=Depends(require_perm("field_sales", "export"))):
    from delivery_report_csv import csv_response
    result = await daily_reports(date, mr_id, user)
    return csv_response("mr_delivery_report",
        ["Date", "MR", "Attempt", "Channel", "Recipient", "Sender number", "Send status",
         "Receipt", "Delivered at", "Read at", "Part", "Error"],
        ([r["date"], r["mr_name"], n["id"], n.get("channel"), n.get("recipient_address"),
          n.get("sender_number", "Unknown") if n.get("channel") == "whatsapp" else "",
          n.get("status"), n.get("delivery", {}).get("status"),
          n.get("delivery", {}).get("delivered_at"), n.get("delivery", {}).get("read_at"),
          n.get("part"), n.get("error")]
         for r in result["items"] for n in r["notifications"]))


def valid_required_parts(required):
    return isinstance(required, int) and not isinstance(required, bool) and required >= 1


async def load_report_receipts(claims, *, include_senders=False):
    """Read exact receipt IDs and immutable legacy counts once per selection."""
    whatsapp = [c for c in claims if c.get("channel") == "whatsapp"]
    wamids = list({c["wamid"] for c in whatsapp if c.get("wamid")})
    messages = await db.messages.find({
        "wamid": {"$in": wamids}, "is_demo": {"$ne": True}}, {"_id": 0}).to_list(None) if wamids else []
    sender_context = await report_sender_context(db, messages) if include_senders and whatsapp else None
    if wamids:
        messages += await db.whatsapp_receipts.find({
            "wamid": {"$in": wamids}}, {"_id": 0}).to_list(None)
    legacy_reports = {}
    for claim in whatsapp:
        if (not claim.get("part") and not valid_required_parts(claim.get("required_parts"))
                and claim.get("submission_id")):
            legacy_reports.setdefault(claim["submission_id"], set()).add(claim.get("report_id"))
    legacy_ids = list(legacy_reports)
    submissions = await db.mr_report_submissions.find({
        "id": {"$in": legacy_ids}}, {"_id": 0}).to_list(None) if legacy_ids else []
    snapshots = {}
    for submission in submissions:
        saved = submission.get("report")
        if saved and saved.get("id") in legacy_reports[submission["id"]]:
            snapshots[submission["id"]] = (
                saved.get("id"), (len(report_text(saved)) + 2999) // 3000)
    result = (receipt_index(messages), snapshots)
    return (*result, sender_context) if include_senders else result


async def attach_report_receipts(claims, *, evidence=None):
    """Exact saved wamids only. Expose explicit per-stage provider times on each part
    and the last part's time on complete attempts; never use creation/status_at,
    infer delivery time from read time, or change send/retry eligibility.
    Matching remains report-local even when evidence reads are shared.
    """
    receipts, snapshots, sender_context = evidence if evidence is not None else await load_report_receipts(
        claims, include_senders=True)
    whatsapp = [c for c in claims if c.get("channel") == "whatsapp"]
    by_id = {c["id"]: c for c in whatsapp}
    parts_by_id = {}
    for claim in whatsapp:
        if claim.get("part"):
            claim["delivery"] = delivery_evidence([claim], 1, receipts)
            continue
        required = claim.get("required_parts")
        if not valid_required_parts(required):
            # Old attempts predate required_parts. Derive only from their immutable
            # closing snapshot, never the edited daily report or observed part count.
            saved = snapshots.get(claim.get("submission_id"))
            required = saved[1] if saved and saved[0] == claim.get("report_id") else None
        if required:
            parts = []
            for i in range(required):
                part = by_id.get(f"{claim['id']}:part:{i}")
                if part and (part.get("attempt_id") not in (None, claim["id"]) or
                             part.get("submission_id") != claim.get("submission_id") or
                             part.get("user_id") != claim.get("user_id") or
                             part.get("part") != i + 1):
                    part = None
                parts.append(part)
        else:
            # Preserve partial evidence when the historical expected count is unknown.
            parts = [p for p in whatsapp if p.get("part") and
                     p.get("attempt_id") == claim["id"]]
        claim["delivery"] = delivery_evidence(parts, required, receipts)
        parts_by_id[claim["id"]] = parts
    await attach_report_senders(db, whatsapp, parts_by_id=parts_by_id, context=sender_context)


async def opted_out(phone):
    digits = phone.lstrip("+")
    consent = await db.consent_records.find({"phone": digits}).sort("created_at", -1).to_list(1)
    return bool((consent and consent[0].get("status") == "opted_out") or
                await db.contacts.find_one({"mobile": {"$in": [phone, digits]},
                    "opted_out": True, "deleted": {"$ne": True}}))


async def manual_still_allowed(claim, address):
    """Recheck after reservation/audit and between multipart provider calls."""
    await refresh_role_definitions()
    doc = await db.app_config.find_one({"key": "mr_ivr"})
    config = {**DEFAULT_CONFIG, **(doc or {}).get("value", {})}
    actor = await db.users.find_one({"id": claim["requested_by"], **REAL})
    recipient = await db.users.find_one({"id": claim["user_id"], **REAL,
                                        "role": {"$in": ["admin", "super_admin"]}})
    channel = claim["channel"]
    if not actor or not can_send_report(actor, channel) or not recipient or \
            not config["enabled"] or not config[f"{channel}_reports"]:
        return False
    if channel == "email":
        current = valid_report_email(recipient.get("email"))
        return current is not None and current == address and brevo_client.configured()
    current = re.sub(r"[\s().-]", "", recipient.get("phone") or recipient.get("mobile") or "")
    return current == address and not await opted_out(address)


async def scheduled_email_still_allowed(claim, address, approver):
    """Revalidate the scheduler's approval and recipient after acquiring its claim."""
    await refresh_role_definitions()
    recipient = await db.users.find_one({"id": claim["user_id"], **REAL,
                                        "role": {"$in": ["admin", "super_admin"]}})
    actor = await db.users.find_one({"id": approver["id"], **REAL})
    latest = await db.app_config.find_one({"key": "mr_ivr"})
    config = {**DEFAULT_CONFIG, **(latest or {}).get("value", {})}
    return bool(recipient and actor and config["enabled"] and config["email_reports"] and
                latest.get("approved_by") == actor["id"] and
                "manage" in permissions_for(actor["role"]).get("settings", []) and
                "send" in permissions_for(actor["role"]).get("whatsapp", []) and
                valid_report_email(recipient.get("email")) == address and brevo_client.configured())


async def qr_still_allowed(claim, phone, approver):
    """Refresh authorization and the exact recipient for every QR provider call."""
    if claim.get("original_notification_id"):
        return await manual_still_allowed(claim, phone)
    await refresh_role_definitions()
    latest = await db.app_config.find_one({"key": "mr_ivr"})
    config = {**DEFAULT_CONFIG, **(latest or {}).get("value", {})}
    actor = await db.users.find_one({"id": approver["id"], **REAL})
    if not config["enabled"] or not config["whatsapp_reports"] or not actor or \
            latest.get("approved_by") != actor["id"] or \
            "manage" not in permissions_for(actor["role"]).get("settings", []) or \
            "send" not in permissions_for(actor["role"]).get("whatsapp", []):
        return False
    if claim.get("phase"):
        recipient = await db.mr_directory.find_one({"id": claim["mr_id"], **REAL, "active": True})
        individual = await db.mr_ivr_profiles.find_one({"id": claim["mr_id"]})
        saved = await db.mr_daily_reports.find_one({"id": f"{claim['date']}:{claim['mr_id']}"})
        if (individual or {}).get("value", {}).get("ivr_enabled") is False or \
                ((saved or {}).get(f"{claim['phase']}_submitted_at") and
                 claim.get("message_kind") != "submitted_confirmation"):
            return False
    else:
        recipient = await db.users.find_one({"id": claim["user_id"], **REAL,
                                            "role": {"$in": ["admin", "super_admin"]}})
    current = re.sub(r"[\s().-]", "", (recipient or {}).get("phone") or
                     (recipient or {}).get("mobile") or "")
    return bool(recipient and current == phone and re.fullmatch(r"\+[1-9]\d{7,14}", phone)
                and not await opted_out(phone))


async def send_qr(collection, claim, phone, text, session, approver):
    """Reserve before IO; a crash/timeout can never release or resend this claim."""
    if not await qr_still_allowed(claim, phone, approver):
        return
    claim = {**claim, "created_at": now_iso(), "status": "sending",
             "session_id": session["id"], "sender_phone": session.get("phone")}
    request_id = hashlib.sha256(claim["id"].encode()).hexdigest()
    acquired = await collection.update_one({"id": claim["id"]},
        {"$setOnInsert": {**claim, "gateway_request_id": request_id}}, upsert=True)
    if not acquired.upserted_id:
        return
    try:
        await db.whatsapp_send_requests.update_one({"id": request_id}, {"$setOnInsert": {
            "id": request_id, "state": "sending", "provider": "qr", "recipient_address": phone,
            "message_body": text, "user_id": approver["id"], "source": "mr_reporting",
            "created_at": now_iso()}}, upsert=True)
        # Both reservation writes await database IO. Approval/consent can change
        # during either write; never use the pre-reservation result for delivery.
        if not await qr_still_allowed(claim, phone, approver):
            raise RuntimeError("Delivery authorization changed after reservation")
        response = await wa_client.wa_send(phone, text, request_id=request_id, session_id=session["id"])
        if not response.get("wamid"):
            raise RuntimeError("Acceptance unresolved")
        await db.whatsapp_send_requests.update_one({"id": request_id}, {"$set": {
            "state": "accepted", "accepted_at": now_iso(), "gateway_accepted_wamid": response["wamid"]}})
        await collection.update_one({"id": claim["id"]}, {"$set": {
            "status": "sent", "wamid": response["wamid"], "session_id": session["id"]}})
        from routes_campaigns import _upsert_conversation
        conversation = await _upsert_conversation(phone.lstrip("+"), claim.get("name", ""), session["id"])
        await db.messages.update_one({"wamid": response["wamid"]}, {"$setOnInsert": {
            "id": new_id(), "conversation_id": conversation["id"], "wamid": response["wamid"],
            "session_id": session["id"], "direction": "outbound", "type": "text", "body": text,
            "sender": "MR reporting", "status": "sent", "is_demo": False, "created_at": now_iso()}}, upsert=True)
        await db.conversations.update_one({"id": conversation["id"]}, {"$set": {
            "last_message": text, "last_message_at": now_iso()}})
        if claim.get("phase") and claim.get("message_kind") != "submitted_confirmation":
            await db.conversations.update_one({"id": conversation["id"]}, {"$set": {
                "mr_invitation": {"id": claim["id"], "date": claim["date"], "phase": claim["phase"]}}})
    except Exception:
        await collection.update_one({"id": claim["id"], "status": "sending"}, {"$set": {
            "status": "uncertain", "error": "Acceptance unresolved. No automatic retry."}})


def report_text(report):
    summary = report.get("summary", {})
    labels = {
        "planned_visits": "Planned visits", "completed_visits": "Completed visits",
        "pending_visits": "Pending visits", "doctor_visits": "Doctors",
        "customer_visits": "Hospitals/clinics/customers", "calls": "Calls",
        "quotations": "Quotations", "orders": "Orders", "sales": "Sales (INR)",
        "daily_goal": "Morning expected sales (INR)", "achievement_pct": "Achievement vs morning plan (%)",
        "tomorrow_visits": "Tomorrow visits",
    }
    lines = ["VGRUPS HEALTHCARE — DAILY MR REPORT", f"Date: {report['date']}",
             f"MR: {report['mr_name']} ({report.get('employee_id', '')})"]
    lines += [f"{label}: {summary.get(key) if summary.get(key) is not None else 'Not set'}"
              for key, label in labels.items()]
    # Include all submitted details, not just totals. Email carries the same report.
    import json
    for section in ("plan", "closing"):
        lines += [f"\n{section.title()} details:", json.dumps(report.get(section, {}),
                    ensure_ascii=False, indent=2)]
    return "\n".join(lines)


async def deliver_report(claim, report, address, session, approver, config):
    """Use one reserved parent and independent, permanently reserved QR part claims."""
    text = report_text(report)
    key = claim["id"]
    if claim["channel"] == "whatsapp":
        chunks = [text[i:i + 3000] for i in range(0, len(text), 3000)]
        # Save the full requirement before any IO, including parts not reached after a timeout.
        await db.mr_report_notifications.update_one({"id": key}, {"$set": {
            "required_parts": len(chunks), "session_id": session["id"],
            "sender_phone": session.get("phone")}})
        for i, chunk in enumerate(chunks):
            part_id = f"{key}:part:{i}"
            await send_qr(db.mr_report_notifications, {
                **claim, "id": part_id, "attempt_id": key, "part": i + 1},
                address, f"Report part {i + 1}/{len(chunks)}\n{chunk}", session, approver)
            part = await db.mr_report_notifications.find_one({"id": part_id})
            if not part or part.get("status") != "sent":
                break  # Never continue after unresolved acceptance.
            await asyncio.sleep(config["message_gap_seconds"])
        parts = [await db.mr_report_notifications.find_one({"id": f"{key}:part:{i}"})
                 for i in range(len(chunks))]
        status = "sent" if all(p and p["status"] == "sent" for p in parts) else "uncertain"
    else:
        try:
            if claim.get("original_notification_id") and not await manual_still_allowed(claim, address):
                raise RuntimeError("Delivery authorization changed after reservation")
            if not claim.get("original_notification_id") and not await scheduled_email_still_allowed(claim, address, approver):
                raise RuntimeError("Scheduled email authorization changed after reservation")
            result = await brevo_client.send_email(address, claim.get("name", ""),
                f"Daily MR Report — {report['mr_name']} — {report['date']}",
                "<pre style=\"white-space:pre-wrap\">" + html.escape(text) + "</pre>")
            status = "sent" if result == "Sent" else "uncertain"
        except Exception:
            status = "uncertain"
    await db.mr_report_notifications.update_one({"id": key}, {"$set": {
        "status": status, "completed_at": now_iso(),
        "error": "" if status == "sent" else "Acceptance unresolved. No automatic retry."}})


async def reporting_tick(now=None):
    now = (now or datetime.now(IST)).astimezone(IST)
    doc = await db.app_config.find_one({"key": "mr_ivr"})
    config = {**DEFAULT_CONFIG, **(doc or {}).get("value", {})}
    if not config["enabled"]:
        return
    await refresh_role_definitions()
    approver = await db.users.find_one({"id": doc.get("approved_by"), **REAL})
    if not approver or "manage" not in permissions_for(approver["role"]).get("settings", []) or \
            "send" not in permissions_for(approver["role"]).get("whatsapp", []):
        return
    from whatsapp_routing import sender_or_none
    session = await sender_or_none(db, purpose="mr")
    date = now.date().isoformat()
    # Label interrupted reservations honestly, without releasing or retrying them.
    cutoff = (now - timedelta(minutes=10)).astimezone(timezone.utc).isoformat()
    await db.mr_report_notifications.update_many({"status": "sending", "created_at": {"$lt": cutoff}},
        {"$set": {"status": "uncertain", "error": "Interrupted reservation. No automatic retry."}})
    pending = await db.mr_report_submissions.find_one({"notified_complete": {"$ne": True}})
    if session and (doc.get("next_kind") != "notifications" or not pending):
        for phase, time_key in (("plan", "morning_time"), ("closing", "closing_time")):
            hour, minute = map(int, config[time_key].split(":"))
            scheduled = now.replace(hour=hour, minute=minute, second=0, microsecond=0)
            if not scheduled <= now < scheduled + timedelta(hours=3):
                continue
            mrs = await db.mr_directory.find({**REAL, "active": True}).to_list(None)
            for mr in mrs:
                individual = await db.mr_ivr_profiles.find_one({"id": mr["id"]})
                if (individual or {}).get("value", {}).get("ivr_enabled") is False:
                    continue
                key = f"mr-ivr:{date}:{phase}:{mr['id']}"
                if await db.mr_ivr_invites.find_one({"id": key}) or await opted_out(mr["phone"]):
                    continue
                saved = await db.mr_daily_reports.find_one({"id": f"{date}:{mr['id']}"})
                completed = bool((saved or {}).get(f"{phase}_submitted_at"))
                message_kind = "submitted_confirmation" if completed else "prompt"
                if completed and phase == "plan":
                    text = (f"Good morning {mr['name']}\nYour plan for today has already been submitted. "
                            "Thank you.")
                elif completed:
                    text = (f"{mr['name']}, your day-end report has already been submitted. Thank you.")
                elif phase == "plan":
                    text = (f"Good morning {mr['name']}\nVGRUPS Healthcare Daily Field Report\n"
                            "1. Start today's plan\n2. Yesterday's pending follow-ups\n"
                            "3. View my target\n4. Talk to manager\nReply PLAN to return to this menu.")
                else:
                    text = (f"VGRUPS HEALTHCARE — DAY CLOSING\n{mr['name']}, please complete today's field report.\n"
                            "1. Start day closing\n2. Complete later\n3. Talk to manager\n"
                            "If a morning draft is in progress, reply CLOSING first.")
                if (individual or {}).get("value", {}).get("field_flow_enabled"):
                    text += "\n7 — Full field activity flow (FIELD). If a draft is open, type FIELD."
                await send_qr(db.mr_ivr_invites, {"id": key, "mr_id": mr["id"], "name": mr["name"],
                    "date": date, "phase": phase, "message_kind": message_kind},
                    mr["phone"], text, session, approver)
                await asyncio.sleep(config["message_gap_seconds"])
                await db.app_config.update_one({"key": "mr_ivr"}, {"$set": {"next_kind": "notifications"}})
                return True
    # Submissions are immutable snapshots. Each admin/channel has its own durable claim.
    query = {"notified_complete": {"$ne": True}}
    if not session:
        query["email_complete"] = {"$ne": True}
    submissions = await db.mr_report_submissions.find(query).sort(
        "submitted_at", 1).to_list(50)
    admins = await db.users.find({**REAL, "role": {"$in": ["admin", "super_admin"]}}).to_list(2000)
    for submission in submissions:
        report = submission["report"]
        for admin in admins:
            for channel in ("email", "whatsapp"):
                if not config[f"{channel}_reports"]:
                    continue
                key = f"mr-report:{submission['id']}:{admin['id']}:{channel}"
                if await db.mr_report_notifications.find_one({"id": key}):
                    continue
                claim = {"id": key, "report_id": report["id"], "submission_id": submission["id"],
                         "user_id": admin["id"], "channel": channel, "name": admin.get("name", ""),
                         "created_at": now_iso()}
                phone = admin.get("phone") or admin.get("mobile") or ""
                import re
                phone = re.sub(r"[\s().-]", "", phone)
                email = valid_report_email(admin.get("email")) if channel == "email" else None
                unavailable = (channel == "email" and (email is None or not brevo_client.configured())) or \
                    (channel == "whatsapp" and not re.fullmatch(r"\+[1-9]\d{7,14}", phone))
                if channel == "whatsapp" and not unavailable and await opted_out(phone):
                    unavailable = True
                if unavailable:
                    await db.mr_report_notifications.update_one({"id": key}, {"$setOnInsert": {
                        **claim, "status": "unavailable", "provider_io": False,
                        "error": UNAVAILABLE_ERROR}}, upsert=True)
                    continue
                if channel == "whatsapp":
                    if not session:
                        continue  # no provider IO or claim yet; wait for QR reconnection
                    claimed = await db.mr_report_notifications.update_one({"id": key},
                        {"$setOnInsert": {**claim, "status": "sending"}}, upsert=True)
                    if not claimed.upserted_id:
                        continue
                    await deliver_report(claim, report, phone, session, approver, config)
                else:
                    claimed = await db.mr_report_notifications.update_one({"id": key}, {"$setOnInsert": {
                        **claim, "status": "sending"}}, upsert=True)
                    if not claimed.upserted_id:
                        continue
                    await deliver_report(claim, report, email, None, approver, config)
                await asyncio.sleep(config["message_gap_seconds"])
                await db.app_config.update_one({"key": "mr_ivr"}, {"$set": {"next_kind": "invites"}})
                return True
        # Don't finish the submission while WhatsApp awaits a connected session.
        waiting = False
        if config["whatsapp_reports"] and not session:
            for admin in admins:
                key = f"mr-report:{submission['id']}:{admin['id']}:whatsapp"
                if not await db.mr_report_notifications.find_one({"id": key}):
                    waiting = True
        if waiting:
            await db.mr_report_submissions.update_one({"id": submission["id"]},
                {"$set": {"email_complete": True}})
            continue
        await db.mr_report_submissions.update_one({"id": submission["id"]}, {"$set": {"notified_complete": True}})


async def start_mr_reporting():
    while True:
        worked = False
        try:
            async with mr_lock("reporting-scheduler"):
                worked = await reporting_tick()
        except HTTPException:
            pass
        except Exception:
            logger.error("MR reporting tick failed; uncertain sends remain reserved.")
        await asyncio.sleep(0 if worked else 15)