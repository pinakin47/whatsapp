"""The primary linked QR account owns history, including while temporarily offline."""
from fastapi import HTTPException
import wa_client
from db import db


async def linked_session(database=None, session_id=None):
    database = database if database is not None else db
    if session_id:
        from whatsapp_routing import accounts
        return next((s for s in await accounts(database, include_archived=True) if s["id"] == session_id), None)
    data = await wa_client.wa_list_sessions()
    live = data.get("sessions", [])
    connected = next((s for s in live if s.get("status") == "connected"), None)
    if connected:
        saved = await database.app_config.find_one({"key": "inbox_linked_account"})
        value = {k: connected.get(k) for k in ("id", "phone", "name")}
        if (saved or {}).get("value") != value:
            await database.app_config.update_one({"key": "inbox_linked_account"},
                {"$set": {"key": "inbox_linked_account", "value": value}}, upsert=True)
        return connected
    pin = (await database.app_config.find_one({"key": "inbox_linked_account"}) or {}).get("value")
    stored = await database.wa_sessions.find({"deleted": {"$ne": True}, "is_demo": {"$ne": True}}).sort("updated_at", -1).to_list(100)
    if pin:
        candidates = [pin]
    else:
        known = [s for s in stored if s.get("phone") and s.get("status") not in ("logged_out", "deleted")]
        formerly_connected = [s for s in known if s.get("status") == "connected"]
        # Bootstrap older installations only when the previous linked account is unambiguous.
        candidates = formerly_connected[:1] if len(formerly_connected) == 1 else known if len(known) == 1 else []
    for session in candidates:
        if not session or not session.get("phone"):
            continue
        current = next((s for s in live if s.get("id") == session["id"]), None)
        record = next((s for s in stored if s.get("id") == session["id"]), None)
        if not record:
            continue
        if pin and record.get("phone") and record["phone"] != pin.get("phone"):
            continue
        # Explicit logout/replacement is not a temporary disconnection.
        if any(s and s.get("status") in ("logged_out", "deleted") for s in (current, record)):
            continue
        return {**session, "status": (current or {}).get("status", "disconnected")}
    return None


async def scoped_conversation(cid, database=None, session_id=None):
    database = database if database is not None else db
    session = await linked_session(database, session_id=session_id)
    if not session:
        raise HTTPException(404, "No QR-linked WhatsApp number. Scan a number in WhatsApp Connections.")
    conversation = await database.conversations.find_one({
        "id": cid, "session_id": session["id"],
        "is_demo": {"$ne": True}, "deleted": {"$ne": True}}, {"_id": 0})
    if not conversation:
        raise HTTPException(404, "Chat does not belong to the currently linked number.")
    return conversation, session