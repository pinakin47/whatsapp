import os
import asyncio
import json
from pathlib import Path
import httpx

API_VERSION = os.environ.get("META_API_VERSION", "v23.0")


def _env(k: str) -> str:
    return (os.environ.get(k) or "").strip()


def integration_status() -> dict:
    whatsapp_ok = all(_env(k) for k in ["META_ACCESS_TOKEN", "META_PHONE_NUMBER_ID", "META_WABA_ID"])
    return {
        "whatsapp": {
            "name": "WhatsApp Cloud API", "configured": whatsapp_ok,
            "required_env": ["META_ACCESS_TOKEN", "META_PHONE_NUMBER_ID", "META_WABA_ID", "META_WEBHOOK_VERIFY_TOKEN", "META_APP_SECRET"],
            "docs": "Meta for Developers → WhatsApp → API Setup",
        },
        "brevo": {
            "name": "Brevo (Email)", "configured": bool(
                _env("BREVO_SENDER_EMAIL") and (
                    _env("BREVO_API_KEY") or _env("BREVO_USE_CONNECTOR").lower() == "true"
                )
            ),
            "required_env": ["BREVO_SENDER_EMAIL"] if _env("BREVO_USE_CONNECTOR").lower() == "true" else ["BREVO_API_KEY", "BREVO_SENDER_EMAIL"],
            "docs": "Connected Brevo account → Verified senders",
        },
        "razorpay": {
            "name": "Razorpay (Payments)", "configured": bool(_env("RAZORPAY_KEY_ID") and _env("RAZORPAY_KEY_SECRET")),
            "required_env": ["RAZORPAY_KEY_ID", "RAZORPAY_KEY_SECRET"],
            "docs": "Razorpay Dashboard → Settings → API Keys",
        },
        "ai": {
            "name": "AI Assistant", "configured": bool(_env("AI_API_KEY")),
            "required_env": ["AI_API_KEY"], "docs": "Provider API key",
        },
        "sms": {
            "name": "SMS Provider", "configured": bool(_env("SMS_API_KEY")),
            "required_env": ["SMS_API_KEY"], "docs": "SMS provider API key",
        },
        "google": {
            "name": "Google (Sheets / Ads / Leads)", "configured": bool(_env("GOOGLE_API_KEY")),
            "required_env": ["GOOGLE_API_KEY"], "docs": "Google Cloud Console",
        },
        "meta_ads": {
            "name": "Meta Ads / Lead Ads", "configured": bool(_env("META_ACCESS_TOKEN")),
            "required_env": ["META_ACCESS_TOKEN"], "docs": "Meta Business Suite",
        },
    }


def whatsapp_configured() -> bool:
    return integration_status()["whatsapp"]["configured"]


def _graph_url(path: str) -> str:
    return f"https://graph.facebook.com/{API_VERSION}/{path.lstrip('/')}"


async def graph_post(path: str, payload: dict) -> dict:
    token = _env("META_ACCESS_TOKEN")
    async with httpx.AsyncClient(timeout=20) as c:
        r = await c.post(_graph_url(path), headers={"Authorization": f"Bearer {token}"}, json=payload)
    if r.is_error:
        raise Exception(r.text[:500])
    return r.json()


async def send_whatsapp_text(to: str, body: str) -> dict:
    pnid = _env("META_PHONE_NUMBER_ID")
    return await graph_post(f"{pnid}/messages", {
        "messaging_product": "whatsapp", "recipient_type": "individual",
        "to": to, "type": "text", "text": {"preview_url": False, "body": body},
    })


async def send_whatsapp_template(to: str, name: str, language: str = "en_US", body_params: list[str] | None = None) -> dict:
    pnid = _env("META_PHONE_NUMBER_ID")
    components = []
    if body_params:
        components = [{"type": "body", "parameters": [{"type": "text", "text": v} for v in body_params]}]
    return await graph_post(f"{pnid}/messages", {
        "messaging_product": "whatsapp", "to": to, "type": "template",
        "template": {"name": name, "language": {"code": language}, "components": components},
    })


async def send_whatsapp_otp(to: str, code: str) -> dict:
    # Uses an approved authentication template in production.
    return await send_whatsapp_template(to, "otp_authentication", "en_US", [code])


async def brevo_connector_request(action: str, payload: dict | None = None) -> dict:
    helper = Path(__file__).resolve().parents[3] / "artifacts/api-server/brevo-proxy.mjs"
    process = await asyncio.create_subprocess_exec(
        "node", str(helper), stdin=asyncio.subprocess.PIPE,
        stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.DEVNULL,
    )
    try:
        output, _ = await asyncio.wait_for(
            process.communicate(json.dumps({"action": action, "payload": payload}).encode()),
            timeout=30,
        )
    except BaseException:
        process.kill()
        await process.wait()
        raise
    result = json.loads(output)
    if process.returncode or result.get("error"):
        raise RuntimeError(result.get("error", "Brevo connector request failed."))
    return result


async def send_email_otp(to: str, code: str) -> dict:
    payload = {
        "sender": {"email": _env("BREVO_SENDER_EMAIL"), "name": _env("BREVO_SENDER_NAME") or "VGRUPS CONNECT"},
        "to": [{"email": to}],
        "subject": "Your VGRUPS CONNECT sign-in code",
        "htmlContent": f"<p>Your sign-in code is <b>{code}</b>.</p><p>It expires in 5 minutes. Do not share it with anyone.</p><p>If you did not request this code, ignore this email.</p>",
        "textContent": f"Your VGRUPS CONNECT sign-in code is {code}. It expires in 5 minutes. Do not share it. If you did not request it, ignore this email.",
    }
    return await send_brevo_email(payload)


async def send_brevo_email(payload: dict) -> dict:
    """Use the same connected account for all transactional mail."""
    if _env("BREVO_USE_CONNECTOR").lower() == "true":
        return await brevo_connector_request("send-email", payload)
    async with httpx.AsyncClient(timeout=20) as c:
        r = await c.post("https://api.brevo.com/v3/smtp/email",
                         headers={"api-key": _env("BREVO_API_KEY"), "Content-Type": "application/json"},
                         json=payload)
    if r.is_error:
        raise RuntimeError(f"Brevo email delivery failed (HTTP {r.status_code}).")
    return r.json()
