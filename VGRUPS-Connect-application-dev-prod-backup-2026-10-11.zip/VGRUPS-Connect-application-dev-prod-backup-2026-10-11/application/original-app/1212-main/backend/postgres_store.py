"""PostgreSQL persistence with the app's existing async document API.

JSONB preserves the supplied document shapes; filtering executes in PostgreSQL.
All writes use collection-scoped transaction locks shared with the WA service,
so upserts and counter increments remain atomic across both runtimes.
Schema/index DDL lives in postgres_schema.sql, never in application startup.
"""
import asyncio
import copy
import json
import os
import uuid
from types import SimpleNamespace

import asyncpg

from postgres_query import Query, apply_update, get_path, project


class ReturnDocument:
    BEFORE = False
    AFTER = True


class Cursor:
    def __init__(self, collection, selector=None, projection=None, pipeline=None):
        self.collection = collection
        self.selector = selector or {}
        self.projection = projection
        self.pipeline = pipeline
        self.sort_fields = []
        self.maximum = None
        self.offset = 0

    def sort(self, key, direction=None):
        self.sort_fields = list(key.items()) if isinstance(key, dict) else (key if isinstance(key, list) else [(key, direction)])
        return self

    def limit(self, maximum):
        self.maximum = int(maximum)
        return self

    def skip(self, offset):
        self.offset = max(0, int(offset))
        return self

    async def to_list(self, length=None):
        maximum = self.maximum
        if length is not None:
            maximum = min(maximum, length) if maximum is not None else length
        if self.pipeline is not None:
            items = await self._aggregate()
            items = items[self.offset:]
            return items if maximum is None else items[:maximum]
        query = Query(self.collection.name)
        sql = "SELECT document FROM app_documents WHERE " + query.where(self.selector)
        sql += query.order(self.sort_fields)
        if maximum is not None:
            sql += " LIMIT " + query.param(max(0, int(maximum)))
        if self.offset:
            sql += " OFFSET " + query.param(self.offset)
        pool = await self.collection.database.connect()
        rows = await pool.fetch(sql, *query.params)
        return [project(json.loads(row["document"]), self.projection) for row in rows]

    async def _aggregate(self):
        stages = list(self.pipeline)
        selector = stages.pop(0)["$match"] if stages and "$match" in stages[0] else {}
        items = await self.collection.find(selector).to_list(None)
        for stage in stages:
            if "$group" in stage:
                spec = stage["$group"]
                groups = {}
                for item in items:
                    key = get_path(item, spec["_id"][1:]) if isinstance(spec["_id"], str) and spec["_id"].startswith("$") else spec["_id"]
                    encoded = json.dumps(key, sort_keys=True)
                    group = groups.setdefault(encoded, {"_id": key})
                    for field, expression in spec.items():
                        if field == "_id":
                            continue
                        if set(expression) != {"$sum"}:
                            raise ValueError("Unsupported aggregation accumulator")
                        value = expression["$sum"]
                        value = get_path(item, value[1:], 0) if isinstance(value, str) and value.startswith("$") else value
                        group[field] = group.get(field, 0) + (value if isinstance(value, (int, float)) and not isinstance(value, bool) else 0)
                items = list(groups.values())
            elif "$sort" in stage:
                for field, direction in reversed(list(stage["$sort"].items())):
                    items.sort(key=lambda item: (get_path(item, field) is not None, get_path(item, field)), reverse=direction < 0)
            elif "$limit" in stage:
                items = items[:stage["$limit"]]
            else:
                raise ValueError(f"Unsupported aggregation stage: {list(stage)}")
        return items

    def __aiter__(self):
        async def iterate():
            for item in await self.to_list(None):
                yield item
        return iterate()


class Collection:
    def __init__(self, database, name):
        self.database = database
        self.name = name

    def find(self, selector=None, projection=None):
        return Cursor(self, selector, projection)

    def aggregate(self, pipeline):
        return Cursor(self, pipeline=pipeline)

    async def find_one(self, selector=None, projection=None, sort=None):
        cursor = self.find(selector, projection)
        if sort:
            cursor.sort(sort)
        items = await cursor.to_list(1)
        return items[0] if items else None

    async def count_documents(self, selector=None):
        query = Query(self.name)
        sql = "SELECT count(*) FROM app_documents WHERE " + query.where(selector)
        pool = await self.database.connect()
        return await pool.fetchval(sql, *query.params)

    async def _lock(self, conn):
        await conn.execute("SELECT pg_advisory_xact_lock(hashtextextended($1, 0))", self.name)

    async def insert_one(self, document):
        pool = await self.database.connect()
        async with pool.acquire() as conn:
            async with conn.transaction():
                await self._lock(conn)
                result = await self._insert(conn, document)
        await self._reconcile_message(document)
        return result

    async def _reconcile_message(self, document):
        if self.name == "messages" and document and document.get("wamid"):
            from whatsapp_receipts import reconcile_receipts
            await reconcile_receipts(self, document["wamid"])

    async def _insert(self, conn, document):
        doc = copy.deepcopy(document)
        key = str(doc.get("_id") or doc.get("id") or uuid.uuid4().hex)
        doc["_id"] = key
        await conn.execute(
            "INSERT INTO app_documents(collection_name, document_id, document) VALUES($1, $2, $3::jsonb)",
            self.name, key, json.dumps(doc),
        )
        return SimpleNamespace(inserted_id=key)

    async def insert_many(self, documents):
        pool = await self.database.connect()
        async with pool.acquire() as conn:
            async with conn.transaction():
                await self._lock(conn)
                ids = [(await self._insert(conn, document)).inserted_id for document in documents]
        for document in documents:
            await self._reconcile_message(document)
        return SimpleNamespace(inserted_ids=ids)

    async def _update(self, selector, update, upsert=False, many=False):
        pool = await self.database.connect()
        async with pool.acquire() as conn:
            async with conn.transaction():
                await self._lock(conn)
                query = Query(self.name)
                sql = "SELECT document_id, document FROM app_documents WHERE " + query.where(selector)
                if not many:
                    sql += " LIMIT 1"
                sql += " FOR UPDATE"
                rows = await conn.fetch(sql, *query.params)
                before, after, upserted, modified = None, None, None, 0
                if not rows and upsert:
                    base = {key: value for key, value in selector.items() if not key.startswith("$") and not isinstance(value, dict)}
                    after = apply_update(base, update, inserting=True)
                    inserted = await self._insert(conn, after)
                    after["_id"] = inserted.inserted_id
                    upserted = inserted.inserted_id
                for row in rows:
                    before = json.loads(row["document"])
                    after = apply_update(before, update)
                    if after != before:
                        modified += 1
                        await conn.execute(
                            "UPDATE app_documents SET document=$3::jsonb WHERE collection_name=$1 AND document_id=$2",
                            self.name, row["document_id"], json.dumps(after),
                        )
                return SimpleNamespace(matched_count=len(rows), modified_count=modified, upserted_id=upserted), before, after

    async def update_one(self, selector, update, upsert=False):
        result, _, after = await self._update(selector, update, upsert)
        if upsert:
            await self._reconcile_message(after)
        return result

    async def update_many(self, selector, update, upsert=False):
        result, _, after = await self._update(selector, update, upsert, many=True)
        if result.upserted_id:
            await self._reconcile_message(after)
        return result

    async def find_one_and_update(self, selector, update, upsert=False, return_document=ReturnDocument.BEFORE, projection=None):
        _, before, after = await self._update(selector, update, upsert)
        if upsert:
            await self._reconcile_message(after)
            if after and self.name == "messages":
                after = await self.find_one({"_id": after["_id"]})
        doc = after if return_document == ReturnDocument.AFTER else before
        return project(doc, projection) if doc is not None else None

    async def _delete(self, selector, many=False):
        pool = await self.database.connect()
        async with pool.acquire() as conn:
            async with conn.transaction():
                await self._lock(conn)
                query = Query(self.name)
                where = query.where(selector)
                sql = f"DELETE FROM app_documents WHERE collection_name=$1 AND document_id IN (SELECT document_id FROM app_documents WHERE {where}"
                if not many:
                    sql += " LIMIT 1"
                sql += ")"
                status = await conn.execute(sql, *query.params)
        return SimpleNamespace(deleted_count=int(status.split()[-1]))

    async def delete_one(self, selector):
        return await self._delete(selector)

    async def delete_many(self, selector):
        return await self._delete(selector, many=True)


class PostgresDatabase:
    def __init__(self):
        self.pool = None
        self._connect_lock = asyncio.Lock()
        self.collections = {}

    def __getattr__(self, name):
        if name.startswith("_"):
            raise AttributeError(name)
        return self[name]

    def __getitem__(self, name):
        if name not in self.collections:
            self.collections[name] = Collection(self, name)
        return self.collections[name]

    async def contact_directory_page(self, specs, search, contact_type, offset, limit, key=None):
        from postgres_directory import read_page
        return await read_page(self, specs, search, contact_type, offset, limit, key)

    async def contact_directory_source(self, collection, source_id, selector, projection):
        query = Query(collection)
        where = query.where(selector)
        source_param = query.param(source_id)
        fields = [query.param(field) for field, include in projection.items() if include and field != "_id"]
        selected = "jsonb_build_object(" + ", ".join(f"{field}::text, document->{field}::text" for field in fields) + ")"
        pool = await self.connect()
        document = await pool.fetchval(
            f"SELECT {selected} FROM app_documents WHERE {where} "
            f"AND document->>'id' = {source_param} ORDER BY document_id LIMIT 1", *query.params)
        return json.loads(document) if document else None

    async def contact_phone_opted_out(self, phone):
        from postgres_directory import indexed_phone
        query = Query("contacts")
        where = query.where({"deleted": {"$ne": True}, "is_demo": {"$ne": True}})
        number = query.param(phone)
        fields = [indexed_phone((field,)) for field in ("mobile", "phone")]
        pool = await self.connect()
        return await pool.fetchval(
            f"SELECT EXISTS(SELECT 1 FROM app_documents WHERE {where} AND document->'opted_out' = 'true'::jsonb AND "
            f"({' OR '.join(f'{field} = {number}' for field in fields)}))", *query.params)

    async def connect(self):
        async with self._connect_lock:
            if self.pool is None:
                self.pool = await asyncpg.create_pool(os.environ["DATABASE_URL"], min_size=1, max_size=10)
                # Fail clearly if the development schema has not been applied.
                await self.pool.fetchval("SELECT count(*) FROM app_documents WHERE FALSE")
        return self.pool

    async def close(self):
        if self.pool is not None:
            await self.pool.close()
            self.pool = None