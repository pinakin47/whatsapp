"""One daily catalogue batch per active MR; every image/file is a separately reserved part."""
import asyncio
import logging
from datetime import datetime
from urllib.parse import urlparse
from auth import permissions_for, refresh_role_definitions
from db import db, now_iso, new_id
from lead_capture_core import stable
from routes_mr_settings import IST
from campaign_media import signed_url
import wa_client

REAL = {"deleted": {"$ne": True}, "is_demo": {"$ne": True}}
IMAGE_HOSTS = {"images.unsplash.com", "storage.googleapis.com"}


async def catalogue_snapshot(database):
    parts = []
    urls = set()
    for product in await database.products.find(REAL).sort("name", 1).to_list(None):
        for url in [product.get("image"), *(product.get("images") or [])]:
            if not isinstance(url, str) or not url or url in urls:
                continue
            target = urlparse(url)
            if target.scheme != "https" or target.hostname not in IMAGE_HOSTS:
                continue
            urls.add(url)
            parts.append({"key": stable("product-image", url), "url": url, "content_type": "image/jpeg",
                "name": product.get("name") or "Product", "filename": "product.jpg"})
    for file in await database.campaign_media.find({"purpose": "catalog", "state": "ready",
            **REAL}).sort("created_at", 1).to_list(None):
        parts.append({"key": stable("catalog-file", file["id"]), "media_id": file["id"],
            "object_path": file["object_path"], "name": file["name"], "filename": file["name"],
            "content_type": file["content_type"]})
    return parts


async def allowed(database, job):
    cfg = await database.app_config.find_one({"key": "mr_catalog_daily"}) or {}
    if not cfg.get("value", {}).get("enabled", False):
        return None
    actor = await database.users.find_one({"id": cfg.get("approved_by"), "active": {"$ne": False}, **REAL})
    if not actor:
        return None
    perms = permissions_for(actor["role"])
    if ("manage" not in perms.get("settings", []) or "send" not in perms.get("whatsapp", []) or
            "view" not in perms.get("catalog", []) or "send" not in perms.get("catalog", [])):
        return None
    mr = await database.mr_directory.find_one({"id": job["mr_id"], "active": True, **REAL})
    if not mr or mr["phone"] != job["phone"]:
        return None
    profile = await database.mr_ivr_profiles.find_one({"id": mr["id"]}) or {}
    if profile.get("value", {}).get("ivr_enabled") is False:
        return None
    if await database.contacts.find_one({"mobile": {"$in": [mr["phone"], mr["phone"].lstrip("+")]},
            "opted_out": True, "deleted": {"$ne": True}}):
        return None
    consent = await database.consent_records.find({"phone": mr["phone"].lstrip("+")}).sort("created_at", -1).to_list(1)
    if consent and consent[0].get("status") == "opted_out":
        return None
    return mr


async def deliver_part(database, job, part, session):
    identity = stable("mr-daily-catalogue", job["id"], part["key"])
    if await database.mr_catalog_parts.find_one({"id": identity}):
        return
    mr = await allowed(database, job)
    if not mr:
        await database.mr_catalog_runs.update_one({"id": job["id"]}, {"$set": {"status": "cancelled", "error": "MR inactive, paused, opted out or no longer authorized"}})
        return
    try:
        url = part.get("url")
        if part.get("media_id"):
            file = await database.campaign_media.find_one({"id": part["media_id"], "state": "ready", "deleted": {"$ne": True}})
            if not file:
                await database.mr_catalog_parts.update_one({"id": identity}, {"$setOnInsert": {
                    "id": identity, "run_id": job["id"], "media_key": part["key"], "status": "removed", "created_at": now_iso()}}, upsert=True)
                return
            url = await signed_url(part["object_path"])
    except Exception:
        await database.mr_catalog_runs.update_one({"id": job["id"]}, {"$set": {"status": "blocked_storage", "error": "File storage unavailable; no provider send attempted"}})
        return
    claim = await database.mr_catalog_parts.update_one({"id": identity}, {"$setOnInsert": {
        "id": identity, "run_id": job["id"], "status": "sending", "session_id": session["id"],
        "media_key": part["key"], "created_at": now_iso()}}, upsert=True)
    if not claim.upserted_id:
        return
    caption = f"VGRUPS Healthcare — daily catalogue {job['date']}\n{part['name']}"
    try:
        if not await allowed(database, job):
            await database.mr_catalog_parts.update_one({"id": identity}, {"$set": {"status": "cancelled"}})
            return
        conv = await database.conversations.find_one({"phone": {"$in": [mr["phone"], mr["phone"].lstrip("+")]},
            "session_id": session["id"], **REAL})
        if not conv:
            conv = {"id": new_id(), "name": mr["name"], "phone": mr["phone"].lstrip("+"),
                "session_id": session["id"], "is_demo": False, "created_at": now_iso(), "unread": 0}
            await database.conversations.insert_one(conv)
        await database.whatsapp_send_requests.update_one({"id": identity}, {"$setOnInsert": {
            "id": identity, "state": "sending", "provider": "qr", "recipient_address": mr["phone"],
            "message_body": caption, "media_key": part["key"], "gateway_message_id": None,
            "source": "mr_catalog", "conversation_id": conv["id"], "created_at": now_iso(),
        }}, upsert=True)
        response = await wa_client.wa_send_media(mr["phone"], url, part["content_type"], part["filename"], caption,
            session_id=session["id"], request_id=identity, media_key=part["key"])
        if not response.get("wamid"):
            raise RuntimeError("Provider acceptance unresolved")
        wamid = response["wamid"]
        await database.messages.update_one({"wamid": wamid}, {"$setOnInsert": {
            "id": identity, "wamid": wamid, "conversation_id": conv["id"], "session_id": session["id"],
            "direction": "outbound", "type": "document" if part["content_type"] == "application/pdf" else "image",
            "body": caption, "status": "sent", "created_at": now_iso(), "is_demo": False,
        }, "$set": {"sender": "MR daily catalogue", "capture_skip": True, "media_id": part.get("media_id"),
            "media_url": part.get("url"), "filename": part["filename"], "content_type": part["content_type"]}}, upsert=True)
        await database.messages.update_one({"wamid": wamid, "status": "sending"}, {"$set": {"status": "sent"}})
        await database.conversations.update_one({"id": conv["id"]}, {"$set": {"last_message": caption, "last_message_at": now_iso()}})
        await database.mr_catalog_parts.update_one({"id": identity}, {"$set": {"status": "accepted", "wamid": wamid}})
        await database.whatsapp_send_requests.update_one({"id": identity}, {"$set": {"state": "accepted", "provider_id": wamid}})
    except Exception:
        await database.mr_catalog_parts.update_one({"id": identity}, {"$set": {
            "status": "uncertain", "error": "Provider acceptance unresolved; no automatic resend."}})
        await database.whatsapp_send_requests.update_one({"id": identity}, {"$set": {"state": "uncertain"}})


async def catalog_tick(database=db, now=None):
    now = (now or datetime.now(IST)).astimezone(IST)
    doc = await database.app_config.find_one({"key": "mr_catalog_daily"}) or {}
    cfg = doc.get("value", {})
    if not cfg.get("enabled"):
        return
    await refresh_role_definitions()
    from whatsapp_routing import sender_or_none
    session = await sender_or_none(database, purpose="mr")
    if not session:
        return
    hour, minute = map(int, cfg.get("time", "09:00").split(":"))
    if now < now.replace(hour=hour, minute=minute, second=0, microsecond=0):
        return
    date = now.date().isoformat()
    snapshot = None
    for mr in await database.mr_directory.find({"active": True, **REAL}).sort("name", 1).to_list(None):
        key = stable("mr-catalog-day", date, mr["id"])
        old = await database.mr_catalog_runs.find_one({"id": key})
        if old and old.get("status") != "no_assets":
            continue
        candidate = {"id": key, "mr_id": mr["id"], "phone": mr["phone"], "mr_name": mr["name"], "date": date}
        if not await allowed(database, candidate):
            continue
        if snapshot is None:
            snapshot = await catalogue_snapshot(database)
        value = {**candidate, "parts": snapshot, "total_parts": len(snapshot),
            "session_id": session["id"], "sender_phone": session.get("phone"),
            "status": "pending" if snapshot else "no_assets", "created_at": now_iso()}
        if old:  # Safe only because no assets/parts ever existed or contacted a provider.
            await database.mr_catalog_runs.update_one({"id": key, "status": "no_assets"}, {"$set": value})
        else:
            await database.mr_catalog_runs.update_one({"id": key}, {"$setOnInsert": value}, upsert=True)
    for job in await database.mr_catalog_runs.find({"date": date,
            "status": {"$in": ["pending", "blocked_storage"]}}).sort("last_attempt_at", 1).to_list(None):
        if session["id"] != job["session_id"]:
            continue  # A different number never takes over an existing batch.
        records = await database.mr_catalog_parts.find({"run_id": job["id"]}).to_list(None)
        done = {r["media_key"] for r in records if r.get("media_key")}
        part = next((p for p in job["parts"] if p["key"] not in done), None)
        if part:
            await deliver_part(database, job, part, session)
            await database.mr_catalog_runs.update_one({"id": job["id"]}, {"$set": {"last_attempt_at": now_iso()}})
            return  # Fair, bounded work; next tick advances the next MR.
        status = "accepted" if all(r["status"] in ("accepted", "removed") for r in records) else "needs_review"
        await database.mr_catalog_runs.update_one({"id": job["id"]}, {"$set": {
            "status": status, "error": None if status == "accepted" else "Some parts have unresolved outcomes. No automatic resend."}})


async def start_mr_catalog():
    while True:
        try:
            await catalog_tick()
        except Exception:
            logging.getLogger("vgrups.mr-catalog").error("Daily catalogue cycle failed; reservations retained.")
        await asyncio.sleep(5)
