import asyncio
import logging
import os
import re
import time
from fastapi import APIRouter, Depends, HTTPException, Request, UploadFile, File, Form, Header
from fastapi.responses import Response
from pydantic import BaseModel, field_validator
from typing import Optional
from postgres_store import ReturnDocument

from db import db, new_id, now_iso
from auth import require_perm
import storage
import ai_screening

WA_INTERNAL_SECRET = os.environ.get("WA_INTERNAL_SECRET", "")
ALLOWED_RESUME_TYPES = {
    "application/pdf", "application/msword",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    "application/octet-stream",
}

logger = logging.getLogger("vgrups.recruitment")
router = APIRouter(prefix="/api", tags=["recruitment"])

STAGES = ["applied", "screening", "shortlisted", "interview", "selected", "offer", "joined", "rejected"]

_apply_hits: dict[str, list[float]] = {}


def _throttle(ip: str, limit: int = 10, window: int = 60):
    now = time.time()
    hits = [t for t in _apply_hits.get(ip, []) if now - t < window]
    if len(hits) >= limit:
        raise HTTPException(status_code=429, detail="Too many applications. Please try again shortly.")
    hits.append(now)
    _apply_hits[ip] = hits


async def _app_id() -> str:
    doc = await db.counters.find_one_and_update({"_id": "applications"}, {"$inc": {"seq": 1}},
                                                upsert=True, return_document=ReturnDocument.AFTER)
    return f"VGRUPS-{1000 + doc['seq']}"


# Common questions asked to every candidate (channel-agnostic spec for the WhatsApp/web flow)
COMMON_QUESTIONS = [
    {"q": "Full name (as per documents)", "type": "text"},
    {"q": "WhatsApp / mobile number", "type": "text"},
    {"q": "Email address", "type": "text"},
    {"q": "Current city & area", "type": "text"},
    {"q": "Highest qualification", "type": "choice", "options": ["10th", "12th", "Diploma", "Graduate", "Post Graduate", "Professional", "Other"]},
    {"q": "Total experience", "type": "choice", "options": ["Fresher", "<1 year", "1-2 years", "3-5 years", "5-10 years", "10+ years"]},
    {"q": "Current / previous company", "type": "text"},
    {"q": "Current monthly salary", "type": "text"},
    {"q": "Expected monthly salary", "type": "text"},
    {"q": "Joining availability", "type": "choice", "options": ["Immediately", "Within 7 days", "Within 15 days", "Within 30 days", "More than 30 days"]},
]

POSITION_QUESTIONS = {
    "ACC": [{"q": "Have you independently handled GST work?", "type": "choice", "options": ["Yes - independently", "Yes - with supervision", "Basic knowledge", "No experience"]},
            {"q": "Rate your MS Excel skills", "type": "choice", "options": ["Basic", "Intermediate", "Advanced"]},
            {"q": "Handled bank/customer/supplier reconciliation?", "type": "choice", "options": ["Yes", "No", "Basic experience"]}],
    "MR": [{"q": "Comfortable travelling within your territory?", "type": "choice", "options": ["Yes", "No"]},
           {"q": "Valid driving licence?", "type": "choice", "options": ["Yes", "No"]},
           {"q": "Access to a two-wheeler for field work?", "type": "choice", "options": ["Yes", "No"]},
           {"q": "Which product categories have you promoted?", "type": "text"}],
    "DOC": [{"q": "Medical registration authority & number", "type": "text"},
            {"q": "Briefly describe your clinical experience", "type": "text"},
            {"q": "Preferred working schedule", "type": "choice", "options": ["Full day", "Morning", "Evening", "Rotational"]}],
    "NUR-M": [{"q": "Valid nursing registration?", "type": "choice", "options": ["Yes", "No", "In process"]},
              {"q": "Areas worked in", "type": "choice", "options": ["OPD", "Ward", "Emergency", "ICU", "Dressing", "Injection/Medication", "Other"]},
              {"q": "Comfortable with rotational duties?", "type": "choice", "options": ["Yes", "No"]}],
    "NUR-F": [{"q": "Valid nursing registration?", "type": "choice", "options": ["Yes", "No", "In process"]},
              {"q": "Areas worked in", "type": "choice", "options": ["OPD", "Ward", "Emergency", "ICU", "Dressing", "Injection/Medication", "Other"]},
              {"q": "Comfortable with rotational duties?", "type": "choice", "options": ["Yes", "No"]}],
    "SMM": [{"q": "Platforms you've managed", "type": "text"},
            {"q": "Content you can create (posts/reels/videos...)", "type": "text"},
            {"q": "Portfolio / Instagram / work link", "type": "text"}],
    "RCP": [{"q": "Languages you can communicate in", "type": "text"},
            {"q": "Comfortable with computers, email, Word/Excel?", "type": "choice", "options": ["Yes", "Basic", "No"]},
            {"q": "Experience handling visitors/calls/enquiries?", "type": "choice", "options": ["Yes", "No"]}],
    "HR": [{"q": "Recruitment activities handled", "type": "text"},
           {"q": "Which HRMS/HR software have you used?", "type": "text"},
           {"q": "Attendance & payroll coordination experience?", "type": "choice", "options": ["Yes", "No", "Basic"]}],
    "PUR": [{"q": "Handled supplier/vendor communication?", "type": "choice", "options": ["Yes", "No"]},
            {"q": "Compared quotations & negotiated prices?", "type": "choice", "options": ["Yes", "No"]},
            {"q": "Prepared & followed up Purchase Orders?", "type": "choice", "options": ["Yes", "No"]}],
    "STORE": [{"q": "Inventory activities handled", "type": "text"},
              {"q": "Which inventory/ERP software used?", "type": "text"},
              {"q": "Comfortable in a warehouse/store environment?", "type": "choice", "options": ["Yes", "No"]}],
    "CSE": [{"q": "Communication channels handled", "type": "text"},
            {"q": "Experience handling complaints & service requests?", "type": "choice", "options": ["Yes", "No"]},
            {"q": "Professional communication languages", "type": "text"}],
    "GFX": [{"q": "Design software you're comfortable with", "type": "text"},
            {"q": "Designed medical/pharma/healthcare creatives?", "type": "choice", "options": ["Yes", "No"]},
            {"q": "Portfolio link", "type": "text"}],
    "DME": [{"q": "Advertising platforms managed", "type": "text"},
            {"q": "Practical SEO experience?", "type": "choice", "options": ["Yes", "Basic", "No"]},
            {"q": "Analytics tools used", "type": "text"}],
    "SALES": [{"q": "Customer types handled", "type": "text"},
              {"q": "Comfortable with daily field visits?", "type": "choice", "options": ["Yes", "No"]},
              {"q": "Previous monthly sales target", "type": "text"},
              {"q": "Typical % of target achieved", "type": "text"}],
    "DSM": [{"q": "How many sales reps have you managed?", "type": "text"},
            {"q": "Territories (states/districts) managed", "type": "text"},
            {"q": "Approx active distributors/dealers handled", "type": "text"},
            {"q": "Approx monthly sales responsibility", "type": "text"},
            {"q": "Comfortable with inter-city/state travel?", "type": "choice", "options": ["Yes", "No"]}],
}

POSITIONS = [
    {"code": "ACC", "title": "Accounts Executive", "department": "Accounts", "type": "Full-time", "location": "Head Office", "salary_min": 18000, "salary_max": 32000,
     "summary": "Handle accounting, GST filing, invoicing and ledger reconciliation.", "requirements": ["B.Com / M.Com", "Tally & Excel", "GST & TDS knowledge"],
     "qa": [{"q": "What is the salary range?", "a": "₹18,000 – ₹32,000 per month based on experience."}]},
    {"code": "MR", "title": "Medical Representative", "department": "Sales", "type": "Full-time", "location": "Field / Territory", "salary_min": 20000, "salary_max": 40000,
     "summary": "Promote VGRUPS products to doctors, clinics and pharmacies; hit monthly targets.", "requirements": ["Any graduate", "Two-wheeler + licence", "Good communication"],
     "qa": [{"q": "Is there travel allowance?", "a": "Yes, daily travel and mobile allowance over and above salary."}]},
    {"code": "DOC", "title": "Doctor / Medical Officer", "department": "Clinical", "type": "Full-time", "location": "Clinic", "salary_min": 60000, "salary_max": 120000,
     "summary": "Consultations, clinical protocols and product advisory.", "requirements": ["MBBS / BAMS / BHMS", "Valid registration"],
     "qa": [{"q": "Are part-time slots available?", "a": "Yes, full-time and visiting consultant roles are available."}]},
    {"code": "NUR-M", "title": "Male Nurse", "department": "Nursing", "type": "Full-time", "location": "Clinic", "salary_min": 15000, "salary_max": 28000,
     "summary": "Patient care, injections, dressing and ward duties.", "requirements": ["GNM / B.Sc Nursing", "Nursing registration"],
     "qa": [{"q": "Are night shifts involved?", "a": "Rotational day/night shifts with shift allowance."}]},
    {"code": "NUR-F", "title": "Female Nurse", "department": "Nursing", "type": "Full-time", "location": "Clinic", "salary_min": 15000, "salary_max": 28000,
     "summary": "Patient care, procedures, records and OPD/ward support.", "requirements": ["GNM / B.Sc Nursing", "Nursing registration"],
     "qa": [{"q": "Is accommodation provided?", "a": "Hostel accommodation can be arranged for outstation candidates."}]},
    {"code": "SMM", "title": "Social Media Executive", "department": "Marketing", "type": "Full-time", "location": "Head Office / Hybrid", "salary_min": 16000, "salary_max": 35000,
     "summary": "Manage social pages, create content, run campaigns.", "requirements": ["Graduate", "Canva/Photoshop", "IG/FB/YouTube"],
     "qa": [{"q": "Is it work-from-home?", "a": "Hybrid — a mix of office and remote."}]},
    {"code": "RCP", "title": "Receptionist", "department": "Front Office", "type": "Full-time", "location": "Clinic / Head Office", "salary_min": 12000, "salary_max": 22000,
     "summary": "Greet visitors, manage appointments, calls and front-desk.", "requirements": ["12th / Graduate", "Good communication", "Basic computer"],
     "qa": [{"q": "What are the timings?", "a": "Mon–Sat, 9:30 AM to 6:30 PM."}]},
    {"code": "HR", "title": "HR Executive", "department": "Human Resources", "type": "Full-time", "location": "Head Office", "salary_min": 18000, "salary_max": 35000,
     "summary": "Recruitment, onboarding, attendance & payroll coordination.", "requirements": ["Graduate/MBA-HR", "HRMS knowledge", "Good communication"],
     "qa": [{"q": "What is the salary?", "a": "₹18,000 – ₹35,000 per month based on experience."}]},
    {"code": "PUR", "title": "Purchase Executive", "department": "Purchase", "type": "Full-time", "location": "Head Office", "salary_min": 18000, "salary_max": 32000,
     "summary": "Vendor management, quotations, negotiation and purchase orders.", "requirements": ["Graduate", "Negotiation skills", "Excel"],
     "qa": [{"q": "What is the salary?", "a": "₹18,000 – ₹32,000 per month based on experience."}]},
    {"code": "STORE", "title": "Store / Warehouse Executive", "department": "Warehouse", "type": "Full-time", "location": "Warehouse", "salary_min": 14000, "salary_max": 26000,
     "summary": "Inward/outward, stock verification, batch & expiry tracking, dispatch.", "requirements": ["12th / Graduate", "Inventory/ERP basics"],
     "qa": [{"q": "What is the salary?", "a": "₹14,000 – ₹26,000 per month based on experience."}]},
    {"code": "CSE", "title": "Customer Support Executive", "department": "Support", "type": "Full-time", "location": "Head Office", "salary_min": 14000, "salary_max": 28000,
     "summary": "Handle calls, WhatsApp, email & CRM; resolve customer queries.", "requirements": ["Graduate", "Good communication", "Multi-lingual preferred"],
     "qa": [{"q": "What is the salary?", "a": "₹14,000 – ₹28,000 per month based on experience."}]},
    {"code": "GFX", "title": "Graphic Designer", "department": "Marketing", "type": "Full-time", "location": "Head Office / Hybrid", "salary_min": 16000, "salary_max": 35000,
     "summary": "Design creatives for medical/pharma products & campaigns.", "requirements": ["Photoshop/Illustrator/Canva", "Portfolio"],
     "qa": [{"q": "What is the salary?", "a": "₹16,000 – ₹35,000 per month based on your portfolio."}]},
    {"code": "DME", "title": "Digital Marketing Executive", "department": "Marketing", "type": "Full-time", "location": "Head Office / Hybrid", "salary_min": 18000, "salary_max": 40000,
     "summary": "Run Google/Meta ads, SEO and analytics for VGRUPS.", "requirements": ["Google/Meta Ads", "SEO basics", "Analytics"],
     "qa": [{"q": "What is the salary?", "a": "₹18,000 – ₹40,000 per month based on experience."}]},
    {"code": "SALES", "title": "Sales Executive", "department": "Sales", "type": "Full-time", "location": "Field / Territory", "salary_min": 16000, "salary_max": 35000,
     "summary": "Sell to hospitals, clinics, pharmacies & distributors; hit targets.", "requirements": ["Any graduate", "Field sales", "Two-wheeler preferred"],
     "qa": [{"q": "Is there incentive?", "a": "Yes, attractive incentives on achieving targets."}]},
    {"code": "DSM", "title": "Distributor Sales Manager", "department": "Sales", "type": "Full-time", "location": "Regional", "salary_min": 35000, "salary_max": 80000,
     "summary": "Manage distributor network, sales team and regional targets.", "requirements": ["Graduate", "Team management", "Distributor handling"],
     "qa": [{"q": "What is the salary?", "a": "₹35,000 – ₹80,000 per month based on experience."}]},
]


async def seed_recruitment():
    for p in POSITIONS:
        q = COMMON_QUESTIONS + POSITION_QUESTIONS.get(p["code"], [])
        existing = await db.positions.find_one({"code": p["code"]})
        if existing:
            if not existing.get("questions"):
                await db.positions.update_one({"code": p["code"]}, {"$set": {"questions": q}})
            continue
        await db.positions.insert_one({"id": new_id(), **p, "questions": q, "status": "open",
                                       "is_demo": True, "created_at": now_iso(), "updated_at": now_iso()})


class QA(BaseModel):
    q: str
    a: Optional[str] = ""


class QItem(BaseModel):
    q: str
    type: str = "text"
    options: list[str] = []


class PositionIn(BaseModel):
    title: str
    department: str = "General"
    type: str = "Full-time"
    location: str = ""
    salary_min: int = 0
    salary_max: int = 0
    summary: str = ""
    requirements: list[str] = []
    qa: list[QA] = []
    questions: list[QItem] = []
    status: str = "open"


class ApplyIn(BaseModel):
    name: str
    mobile: str
    email: Optional[str] = None
    position_id: str
    location: Optional[str] = None
    qualification: Optional[str] = None
    experience: Optional[str] = None
    current_company: Optional[str] = None
    current_salary: Optional[str] = None
    expected_salary: Optional[str] = None
    joining: Optional[str] = None
    resume_url: Optional[str] = None
    notes: Optional[str] = None
    consent: bool = False

    @field_validator("mobile")
    @classmethod
    def _valid_mobile(cls, v):
        if len(re.sub(r"[^0-9]", "", v or "")) < 10:
            raise ValueError("Enter a valid mobile number")
        return v.strip()


# ---------------- Public (no auth) — Careers ----------------
@router.get("/careers/positions")
async def public_positions():
    items = await db.positions.find({"status": "open"}, {"_id": 0}).sort("created_at", 1).to_list(100)
    return {"items": items}


@router.post("/careers/apply")
async def public_apply(body: ApplyIn, request: Request):
    _throttle(request.client.host if request.client else "unknown")
    if not body.consent:
        raise HTTPException(status_code=400, detail="Please accept the declaration to submit your application")
    pos = await db.positions.find_one({"id": body.position_id}, {"_id": 0})
    if not pos:
        raise HTTPException(status_code=404, detail="Position not found")
    application_id = await _app_id()
    cand = {"id": new_id(), "application_id": application_id, "name": body.name, "mobile": body.mobile,
            "email": body.email, "position_id": pos["id"], "position_title": pos["title"],
            "department": pos.get("department"), "stage": "applied", "location": body.location,
            "qualification": body.qualification, "experience": body.experience,
            "current_company": body.current_company, "current_salary": body.current_salary,
            "expected_salary": body.expected_salary, "joining": body.joining, "resume_url": body.resume_url,
            "notes": body.notes, "source": "careers_page", "interview_date": None, "interview_time": None,
            "interview_mode": None, "is_demo": False, "created_at": now_iso(), "updated_at": now_iso()}
    await db.candidates.insert_one(cand)
    existing = await db.contacts.find_one({"mobile": body.mobile})
    if not existing:
        await db.contacts.insert_one({
            "id": new_id(), "name": body.name, "mobile": body.mobile, "email": body.email, "company": None,
            "contact_type": "candidate", "address": None, "city": body.location, "state": None, "pincode": None,
            "gst": None, "category": pos["title"], "source": "careers", "assigned_to": None,
            "tags": ["candidate", pos["department"]], "notes": f"Applied for {pos['title']} ({application_id})",
            "opted_out": False, "is_demo": False, "deleted": False, "created_at": now_iso(), "updated_at": now_iso()})
    else:
        await db.contacts.update_one({"id": existing["id"]}, {
            "$addToSet": {"tags": {"$each": ["candidate", pos["department"]]}},
            "$set": {"category": pos["title"], "updated_at": now_iso()}})
    return {"ok": True, "application_id": application_id,
            "message": f"Application submitted! Your Application ID is {application_id}."}


# ---------------- Management (auth) ----------------
@router.get("/recruitment/positions")
async def list_positions(user: dict = Depends(require_perm("recruitment", "view"))):
    items = await db.positions.find({}, {"_id": 0}).sort("created_at", 1).to_list(100)
    return {"items": items, "stages": STAGES}


@router.post("/recruitment/positions")
async def create_position(body: PositionIn, user: dict = Depends(require_perm("recruitment", "create"))):
    doc = {"id": new_id(), "code": None, **body.model_dump(), "is_demo": False,
           "created_at": now_iso(), "updated_at": now_iso()}
    await db.positions.insert_one(doc)
    doc.pop("_id", None)
    return doc


@router.put("/recruitment/positions/{pid}")
async def update_position(pid: str, body: PositionIn, user: dict = Depends(require_perm("recruitment", "edit"))):
    r = await db.positions.update_one({"id": pid}, {"$set": {**body.model_dump(), "updated_at": now_iso()}})
    if not r.matched_count:
        raise HTTPException(status_code=404, detail="Position not found")
    return await db.positions.find_one({"id": pid}, {"_id": 0})


@router.delete("/recruitment/positions/{pid}")
async def delete_position(pid: str, user: dict = Depends(require_perm("recruitment", "delete"))):
    await db.positions.delete_one({"id": pid})
    return {"ok": True}


@router.get("/recruitment/candidates")
async def list_candidates(position_id: Optional[str] = None, user: dict = Depends(require_perm("recruitment", "view"))):
    q = {"position_id": position_id} if position_id else {}
    items = await db.candidates.find(q, {"_id": 0}).sort("created_at", -1).to_list(500)
    return {"items": items}


class StageIn(BaseModel):
    stage: str


@router.patch("/recruitment/candidates/{cid}")
async def set_stage(cid: str, body: StageIn, user: dict = Depends(require_perm("recruitment", "edit"))):
    if body.stage not in STAGES:
        raise HTTPException(status_code=422, detail="Invalid stage")
    r = await db.candidates.update_one({"id": cid}, {"$set": {"stage": body.stage, "updated_at": now_iso()}})
    if not r.matched_count:
        raise HTTPException(status_code=404, detail="Candidate not found")
    return {"ok": True, "stage": body.stage}


@router.delete("/recruitment/candidates/{cid}")
async def delete_candidate(cid: str, user: dict = Depends(require_perm("recruitment", "delete"))):
    await db.candidates.delete_one({"id": cid})
    return {"ok": True}


class CandMsgIn(BaseModel):
    message: str
    stage: Optional[str] = None
    interview_date: Optional[str] = None
    interview_time: Optional[str] = None
    interview_mode: Optional[str] = None
    session_id: Optional[str] = None


@router.post("/recruitment/candidates/{cid}/whatsapp")
async def candidate_whatsapp(cid: str, body: CandMsgIn, user: dict = Depends(require_perm("recruitment", "edit"))):
    import wa_client
    from urllib.parse import quote
    from whatsapp_routing import sender
    selected = await sender(db, body.session_id)
    c = await db.candidates.find_one({"id": cid}, {"_id": 0})
    if not c:
        raise HTTPException(status_code=404, detail="Candidate not found")
    if not c.get("mobile"):
        raise HTTPException(status_code=400, detail="Candidate has no mobile number")
    if not body.message.strip():
        raise HTTPException(status_code=422, detail="Message is empty")
    upd = {"updated_at": now_iso()}
    if body.stage and body.stage in STAGES:
        upd["stage"] = body.stage
    for f in ("interview_date", "interview_time", "interview_mode"):
        if getattr(body, f):
            upd[f] = getattr(body, f)
    if len(upd) > 1:
        await db.candidates.update_one({"id": cid}, {"$set": upd})
    if selected:
        await wa_client.wa_send(c["mobile"], body.message, session_id=selected["id"])
        return {"ok": True, "sent": True, "stage": upd.get("stage")}
    digits = re.sub(r"\D", "", c["mobile"])
    return {"ok": True, "sent": False, "wa_link": f"https://wa.me/{digits}?text={quote(body.message)}", "stage": upd.get("stage")}


# ---------------- Resume document (object storage) ----------------
@router.post("/recruitment/resume-upload")
async def resume_upload(
    file: UploadFile = File(...),
    candidate_id: str = Form(...),
    mobile: Optional[str] = Form(None),
    x_wa_secret: Optional[str] = Header(None),
):
    """Internal endpoint — called by the WhatsApp (Baileys) service to persist a candidate's resume."""
    if not WA_INTERNAL_SECRET or x_wa_secret != WA_INTERNAL_SECRET:
        raise HTTPException(status_code=401, detail="unauthorized")
    cand = await db.candidates.find_one({"id": candidate_id}, {"_id": 0})
    if not cand:
        raise HTTPException(status_code=404, detail="Candidate not found")
    data = await file.read()
    if len(data) > 15 * 1024 * 1024:
        raise HTTPException(status_code=413, detail="File too large (max 15MB)")
    ct = file.content_type or "application/octet-stream"
    ext = (file.filename.rsplit(".", 1)[-1] if file.filename and "." in file.filename else "bin").lower()
    path = f"{storage.APP_NAME}/resumes/{candidate_id}/{new_id()}.{ext}"
    try:
        result = await asyncio.to_thread(storage.put_object, path, data, ct)
    except Exception as e:
        logger.error(f"resume upload failed for {candidate_id}: {e}")
        raise HTTPException(status_code=502, detail="Storage upload failed")
    await db.candidates.update_one({"id": candidate_id}, {"$set": {
        "resume_path": result["path"], "resume_filename": file.filename,
        "resume_content_type": ct, "resume_size": result.get("size") or len(data),
        "resume_url": f"/api/recruitment/candidates/{candidate_id}/resume",
        "updated_at": now_iso()}})
    logger.info(f"resume stored for candidate {candidate_id}: {result['path']}")
    return {"ok": True, "path": result["path"]}


@router.get("/recruitment/candidates/{cid}/resume")
async def download_resume(cid: str, user: dict = Depends(require_perm("recruitment", "view"))):
    cand = await db.candidates.find_one({"id": cid}, {"_id": 0})
    if not cand or not cand.get("resume_path"):
        raise HTTPException(status_code=404, detail="No resume on file")
    try:
        data, ct = await asyncio.to_thread(storage.get_object, cand["resume_path"])
    except Exception as e:
        logger.error(f"resume fetch failed for {cid}: {e}")
        raise HTTPException(status_code=502, detail="Could not retrieve resume")
    fn = cand.get("resume_filename") or "resume"
    return Response(content=data, media_type=cand.get("resume_content_type") or ct,
                    headers={"Content-Disposition": f'inline; filename="{fn}"'})


# ---------------- AI resume screening ----------------
async def _run_screening(cid: str) -> dict:
    cand = await db.candidates.find_one({"id": cid}, {"_id": 0})
    if not cand:
        raise HTTPException(status_code=404, detail="Candidate not found")
    pos = await db.positions.find_one({"id": cand.get("position_id")}, {"_id": 0}) or {}
    resume_text = ""
    if cand.get("resume_path"):
        try:
            raw, ct = await asyncio.to_thread(storage.get_object, cand["resume_path"])
            resume_text = await asyncio.to_thread(
                ai_screening.extract_resume_text, raw, ct, cand.get("resume_filename", ""))
        except Exception as e:
            logger.warning(f"screening: resume fetch/extract failed for {cid}: {e}")
    result = await ai_screening.score_candidate(pos, cand, resume_text)
    await db.candidates.update_one({"id": cid}, {"$set": {
        "ai_score": result["score"], "ai_recommendation": result["recommendation"],
        "ai_summary": result["summary"], "ai_strengths": result["strengths"],
        "ai_concerns": result["concerns"], "ai_scored_at": now_iso(), "updated_at": now_iso()}})
    return result


@router.post("/recruitment/candidates/{cid}/score")
async def score_candidate_endpoint(cid: str, user: dict = Depends(require_perm("recruitment", "edit"))):
    try:
        return {"ok": True, **await _run_screening(cid)}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"AI screening failed for {cid}: {e}")
        raise HTTPException(status_code=502, detail="AI screening failed")


@router.post("/recruitment/candidates/{cid}/auto-score")
async def auto_score_internal(cid: str, x_wa_secret: Optional[str] = Header(None)):
    """Internal — called by the WhatsApp service when an application completes."""
    if not WA_INTERNAL_SECRET or x_wa_secret != WA_INTERNAL_SECRET:
        raise HTTPException(status_code=401, detail="unauthorized")
    try:
        return {"ok": True, **await _run_screening(cid)}
    except Exception as e:
        logger.error(f"auto-score failed for {cid}: {e}")
        return {"ok": False, "error": "screening failed"}
