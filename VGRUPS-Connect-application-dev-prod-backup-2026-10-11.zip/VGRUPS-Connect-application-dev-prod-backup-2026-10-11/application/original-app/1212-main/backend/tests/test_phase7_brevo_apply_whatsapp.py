"""Phase 7 — 15 positions, richer apply (consent + fields + App ID),
candidate WhatsApp with interview fields, Brevo welcome email on ad lead w/ email."""
import os
import time
import pytest
import requests

BASE_URL = os.environ.get("REACT_APP_BACKEND_URL").rstrip("/")
ADMIN = {"email": "vgdisposables@gmail.com", "password": "VgrupsConnect@2026"}

EXPECTED_15_TITLES = {
    "Accounts Executive", "Medical Representative", "Doctor / Medical Officer",
    "Male Nurse", "Female Nurse", "Social Media Executive", "Receptionist",
    "HR Executive", "Purchase Executive", "Store / Warehouse Executive",
    "Customer Support Executive", "Graphic Designer", "Digital Marketing Executive",
    "Sales Executive", "Distributor Sales Manager",
}


@pytest.fixture(scope="module")
def token():
    r = requests.post(f"{BASE_URL}/api/auth/login", json=ADMIN, timeout=15)
    assert r.status_code == 200, r.text
    return r.json()["token"]


@pytest.fixture(scope="module")
def auth(token):
    return {"Authorization": f"Bearer {token}"}


# ------- Positions (public + admin) -------
def test_public_careers_has_15_positions_all_expected():
    r = requests.get(f"{BASE_URL}/api/careers/positions", timeout=15)
    assert r.status_code == 200
    items = r.json()["items"]
    titles = {p["title"] for p in items}
    missing = EXPECTED_15_TITLES - titles
    assert not missing, f"Missing positions: {missing}"
    assert len(items) >= 15


def test_each_position_has_common_plus_specific_questions(auth):
    r = requests.get(f"{BASE_URL}/api/recruitment/positions", headers=auth, timeout=15)
    assert r.status_code == 200
    for p in r.json()["items"]:
        if p["title"] in EXPECTED_15_TITLES:
            qs = p.get("questions") or []
            assert len(qs) >= 11, f"{p['title']} questions={len(qs)}"


# ------- Apply flow — consent + App ID -------
def _first_pos():
    r = requests.get(f"{BASE_URL}/api/careers/positions", timeout=15)
    return r.json()["items"][0]


def test_apply_without_consent_rejected():
    pos = _first_pos()
    body = {"name": "TEST_NC Candidate", "mobile": "+919000222111",
            "position_id": pos["id"], "consent": False}
    r = requests.post(f"{BASE_URL}/api/careers/apply", json=body, timeout=15)
    assert r.status_code == 400
    assert "declaration" in r.text.lower() or "consent" in r.text.lower()


def test_apply_with_consent_returns_vgrups_application_id():
    pos = _first_pos()
    body = {"name": "TEST_P7 Candidate", "mobile": "+919000222333",
            "email": "testp7@example.com", "position_id": pos["id"],
            "location": "Hyderabad", "qualification": "Graduate", "experience": "1-2 years",
            "current_salary": "20000", "expected_salary": "30000",
            "joining": "Within 15 days", "resume_url": "https://drive.google.com/x",
            "consent": True}
    r = requests.post(f"{BASE_URL}/api/careers/apply", json=body, timeout=15)
    assert r.status_code == 200, r.text
    d = r.json()
    assert d["ok"] is True
    aid = d["application_id"]
    assert aid.startswith("VGRUPS-")
    num = int(aid.split("-")[1])
    assert num >= 1001


def test_apply_short_mobile_rejected():
    pos = _first_pos()
    r = requests.post(f"{BASE_URL}/api/careers/apply",
                      json={"name": "x", "mobile": "123", "position_id": pos["id"], "consent": True},
                      timeout=15)
    assert r.status_code in (400, 422)


# ------- Candidate WhatsApp with interview fields -------
def test_candidate_whatsapp_saves_interview_fields_and_sends(auth):
    pos = _first_pos()
    body = {"name": "TEST_P7 WAcand", "mobile": "+919000222444",
            "position_id": pos["id"], "consent": True}
    r = requests.post(f"{BASE_URL}/api/careers/apply", json=body, timeout=15)
    assert r.status_code == 200
    time.sleep(0.5)
    r2 = requests.get(f"{BASE_URL}/api/recruitment/candidates", headers=auth, timeout=15)
    cand = next(c for c in r2.json()["items"] if c["mobile"] == "+919000222444")
    cid = cand["id"]

    msg = {"message": "TEST_P7 interview confirmed", "stage": "interview",
           "interview_date": "2026-02-10", "interview_time": "11:00 AM",
           "interview_mode": "Office"}
    r3 = requests.post(f"{BASE_URL}/api/recruitment/candidates/{cid}/whatsapp",
                       json=msg, headers=auth, timeout=20)
    assert r3.status_code == 200, r3.text
    d = r3.json()
    assert d["ok"] is True
    # sent may be True or False depending on WA session state
    assert "sent" in d
    assert d.get("stage") == "interview"

    # Verify interview fields persisted
    r4 = requests.get(f"{BASE_URL}/api/recruitment/candidates", headers=auth, timeout=15)
    saved = next(c for c in r4.json()["items"] if c["id"] == cid)
    assert saved["interview_date"] == "2026-02-10"
    assert saved["interview_time"] == "11:00 AM"
    assert saved["interview_mode"] == "Office"
    assert saved["stage"] == "interview"


# ------- Brevo welcome email path via /api/ads/test-lead -------
def test_ads_test_lead_fires_welcome_email_in_background(auth):
    r = requests.post(f"{BASE_URL}/api/ads/test-lead", headers=auth, timeout=15)
    assert r.status_code == 200, r.text
    lead = r.json()["lead"]
    assert lead["source"] == "meta"
    assert lead["title"].startswith("Ad Lead - Test Lead")


# ------- Cleanup -------
def test_cleanup_test_candidates(auth):
    r = requests.get(f"{BASE_URL}/api/recruitment/candidates", headers=auth, timeout=15)
    for c in r.json()["items"]:
        if (c.get("name") or "").startswith("TEST_P7") or (c.get("name") or "").startswith("TEST_NC"):
            requests.delete(f"{BASE_URL}/api/recruitment/candidates/{c['id']}",
                            headers=auth, timeout=15)
    # Also cleanup leads from test-lead
    # (left as-is — only remove by name prefix TEST_P7 if any)
