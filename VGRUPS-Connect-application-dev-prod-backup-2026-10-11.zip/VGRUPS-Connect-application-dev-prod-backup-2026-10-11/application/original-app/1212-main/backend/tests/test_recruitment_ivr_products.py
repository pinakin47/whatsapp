"""Tests for iteration 7: distinct product images, Recruitment ATS, public Careers, IVR config."""
import os
import pytest
import requests

def _read_frontend_env_url():
    try:
        with open("/app/frontend/.env") as f:
            for line in f:
                if line.strip().startswith("REACT_APP_BACKEND_URL="):
                    return line.strip().split("=", 1)[1]
    except Exception:
        pass
    return None


BASE_URL = (os.environ.get("REACT_APP_BACKEND_URL") or _read_frontend_env_url() or "").rstrip("/")
assert BASE_URL, "REACT_APP_BACKEND_URL not set"
ADMIN_EMAIL = "vgdisposables@gmail.com"
ADMIN_PASS = "VgrupsConnect@2026"


@pytest.fixture(scope="module")
def token():
    r = requests.post(f"{BASE_URL}/api/auth/login", json={"email": ADMIN_EMAIL, "password": ADMIN_PASS}, timeout=15)
    assert r.status_code == 200, r.text
    return r.json()["token"]


@pytest.fixture(scope="module")
def auth(token):
    return {"Authorization": f"Bearer {token}"}


# ---------------- Products: 15 distinct images ----------------
def test_products_15_distinct_images(auth):
    r = requests.get(f"{BASE_URL}/api/products", headers=auth, timeout=15)
    assert r.status_code == 200
    data = r.json()
    products = data.get("items", data) if isinstance(data, dict) else data
    assert len(products) == 15, f"expected 15 products, got {len(products)}"
    images = [p.get("image", "") for p in products]
    assert all(img.startswith("http") for img in images), f"non-http images: {[i for i in images if not i.startswith('http')]}"
    assert len(set(images)) == 15, f"images not distinct: {len(set(images))} unique out of 15"


# ---------------- Recruitment positions seeded ----------------
EXPECTED_ROLES = {
    "Accounts Executive", "Medical Representative", "Doctor/Medical Officer",
    "Male Nurse", "Female Nurse", "Social Media Executive", "Receptionist"
}


def test_recruitment_positions_seeded(auth):
    r = requests.get(f"{BASE_URL}/api/recruitment/positions", headers=auth, timeout=15)
    assert r.status_code == 200, r.text
    positions = r.json().get("items", [])
    titles = {p["title"].replace(" / ", "/") for p in positions}
    # Normalize expected (Doctor / Medical Officer vs Doctor/Medical Officer)
    expected = {t.replace(" / ", "/") for t in EXPECTED_ROLES}
    assert expected.issubset(titles), f"missing roles: {expected - titles}"
    for p in positions:
        assert isinstance(p.get("requirements", []), list)
        assert isinstance(p.get("qa", []), list)


def test_position_crud(auth):
    payload = {
        "title": "TEST_QA_Engineer",
        "department": "QA",
        "salary_min": 30000, "salary_max": 50000,
        "summary": "Test role",
        "requirements": ["Python", "Playwright"],
        "qa": [{"q": "Years of exp?", "a": "", "required": True}],
    }
    cr = requests.post(f"{BASE_URL}/api/recruitment/positions", json=payload, headers=auth, timeout=15)
    assert cr.status_code in (200, 201), cr.text
    pos = cr.json()
    pid = pos.get("id")
    assert pid

    up = requests.put(f"{BASE_URL}/api/recruitment/positions/{pid}", json={**payload, "summary": "Updated"}, headers=auth, timeout=15)
    assert up.status_code in (200, 204), up.text

    dl = requests.delete(f"{BASE_URL}/api/recruitment/positions/{pid}", headers=auth, timeout=15)
    assert dl.status_code in (200, 204), dl.text


# ---------------- Public Careers (no auth) ----------------
def test_careers_public_positions_no_auth():
    r = requests.get(f"{BASE_URL}/api/careers/positions", timeout=15)
    assert r.status_code == 200
    data = r.json().get("items", [])
    assert len(data) >= 7
    titles = {p["title"].replace(" / ", "/") for p in data}
    expected = {t.replace(" / ", "/") for t in EXPECTED_ROLES}
    assert expected.issubset(titles)


def test_careers_apply_creates_candidate_and_contact(auth):
    import time
    uniq = f"+9199000{int(time.time()) % 100000:05d}"
    pos = requests.get(f"{BASE_URL}/api/careers/positions", timeout=15).json().get("items", [])
    pid = pos[0]["id"]

    payload = {
        "position_id": pid,
        "name": "TEST_Applicant_X",
        "mobile": uniq,
        "email": f"test_{int(time.time())}@example.com",
        "experience": "3 years",
    }
    r = requests.post(f"{BASE_URL}/api/careers/apply", json=payload, timeout=15)
    assert r.status_code in (200, 201), r.text

    cands = requests.get(f"{BASE_URL}/api/recruitment/candidates", headers=auth, timeout=15).json().get("items", [])
    match = [c for c in cands if c.get("name") == "TEST_Applicant_X"]
    assert match, "candidate not found after apply"
    candidate = match[0]
    assert candidate.get("stage") == "applied"
    cid = candidate["id"]

    contacts_resp = requests.get(f"{BASE_URL}/api/contacts", headers=auth, timeout=15).json()
    contacts = contacts_resp.get("items", contacts_resp) if isinstance(contacts_resp, dict) else contacts_resp
    cand_contact = [c for c in contacts if c.get("mobile") == uniq]
    assert cand_contact, "CRM contact not created"
    assert cand_contact[0].get("contact_type") == "candidate" or "candidate" in (cand_contact[0].get("tags") or [])

    for stage in ["screening", "interview", "hired"]:
        pr = requests.patch(f"{BASE_URL}/api/recruitment/candidates/{cid}", json={"stage": stage}, headers=auth, timeout=15)
        assert pr.status_code in (200, 204), f"{stage}: {pr.text}"

    # cleanup
    requests.delete(f"{BASE_URL}/api/recruitment/candidates/{cid}", headers=auth, timeout=15)
    for c in cand_contact:
        ccid = c.get("id")
        if ccid:
            requests.delete(f"{BASE_URL}/api/contacts/{ccid}", headers=auth, timeout=15)


# ---------------- IVR ----------------
@pytest.fixture(scope="module")
def reset_ivr():
    """Reset the PostgreSQL IVR config so GET returns the default."""
    import asyncio
    from postgres_store import PostgresDatabase

    async def clear():
        store = PostgresDatabase()
        try:
            await store.app_config.delete_one({"key": "ivr"})
        finally:
            await store.close()

    asyncio.run(clear())
    yield
    asyncio.run(clear())


def test_ivr_get_default(auth, reset_ivr):
    r = requests.get(f"{BASE_URL}/api/ivr", headers=auth, timeout=15)
    assert r.status_code == 200, r.text
    data = r.json()
    assert "options" in data
    assert len(data["options"]) == 5
    assert data["enabled"] is True


def test_ivr_put_empty_options_422(auth):
    r = requests.put(f"{BASE_URL}/api/ivr", json={"greeting": "hi", "options": [], "enabled": False}, headers=auth, timeout=15)
    assert r.status_code == 422, f"expected 422 for empty options, got {r.status_code}: {r.text}"


def test_ivr_put_valid_200_and_reset(auth):
    payload = {
        "greeting": "Welcome TEST",
        "footer": "Reply with number",
        "enabled": False,
        "options": [
            {"label": "Sales", "response": "Our sales team will reach out.", "handoff": True},
            {"label": "Catalogue", "response": "See catalog link.", "handoff": False},
        ],
    }
    r = requests.put(f"{BASE_URL}/api/ivr", json=payload, headers=auth, timeout=15)
    assert r.status_code == 200, r.text
    # verify saved
    g = requests.get(f"{BASE_URL}/api/ivr", headers=auth, timeout=15).json()
    assert g["greeting"] == "Welcome TEST"
    assert len(g["options"]) == 2
