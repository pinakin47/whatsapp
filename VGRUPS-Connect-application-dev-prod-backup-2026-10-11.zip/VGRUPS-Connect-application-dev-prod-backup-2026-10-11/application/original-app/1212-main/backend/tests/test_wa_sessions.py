"""Backend tests for WhatsApp QR session feature (/api/wa/*)."""
import os
import time
import pytest
import requests

BASE_URL = os.environ.get("REACT_APP_BACKEND_URL", "https://vgrups-connect.preview.emergentagent.com").rstrip("/")
ADMIN_EMAIL = "vgdisposables@gmail.com"
ADMIN_PASSWORD = "VgrupsConnect@2026"


@pytest.fixture(scope="module")
def admin_token():
    r = requests.post(f"{BASE_URL}/api/auth/login", json={"email": ADMIN_EMAIL, "password": ADMIN_PASSWORD}, timeout=15)
    assert r.status_code == 200, r.text
    return r.json()["token"]


@pytest.fixture(scope="module")
def admin_headers(admin_token):
    return {"Authorization": f"Bearer {admin_token}", "Content-Type": "application/json"}


@pytest.fixture(scope="module")
def viewer_token():
    """Create a view_only user, return its token. Skip if cannot create."""
    r = requests.post(f"{BASE_URL}/api/auth/login", json={"email": ADMIN_EMAIL, "password": ADMIN_PASSWORD}, timeout=15)
    admin_tok = r.json()["token"]
    email = f"TEST_waviewer_{int(time.time())}@example.com"
    cr = requests.post(
        f"{BASE_URL}/api/users",
        headers={"Authorization": f"Bearer {admin_tok}"},
        json={"name": "WA Viewer", "email": email, "password": "Test@12345", "role": "view_only"},
        timeout=15,
    )
    if cr.status_code not in (200, 201):
        pytest.skip(f"Could not create view_only user: {cr.status_code} {cr.text}")
    lr = requests.post(f"{BASE_URL}/api/auth/login", json={"email": email, "password": "Test@12345"}, timeout=15)
    assert lr.status_code == 200, lr.text
    return lr.json()["token"]


# ---------- List sessions ----------

def test_list_sessions_shape(admin_headers):
    r = requests.get(f"{BASE_URL}/api/wa/sessions", headers=admin_headers, timeout=15)
    assert r.status_code == 200, r.text
    data = r.json()
    assert "sessions" in data and isinstance(data["sessions"], list)
    assert "connected" in data


def test_list_sessions_unauth():
    r = requests.get(f"{BASE_URL}/api/wa/sessions", timeout=10)
    assert r.status_code in (401, 403)


# ---------- WhatsApp /status ----------

def test_whatsapp_status(admin_headers):
    r = requests.get(f"{BASE_URL}/api/whatsapp/status", headers=admin_headers, timeout=15)
    assert r.status_code == 200, r.text
    data = r.json()
    # Must include qr-related fields per spec
    for k in ("qr_connected", "qr_sessions", "active"):
        assert k in data, f"missing {k} in /status response: {data}"
    assert isinstance(data["qr_sessions"], list)


# ---------- Create / poll QR / delete ----------

def test_create_poll_qr_and_delete(admin_headers):
    # Create
    cr = requests.post(
        f"{BASE_URL}/api/wa/sessions",
        headers=admin_headers,
        json={"name": "TEST_pytest_session"},
        timeout=20,
    )
    assert cr.status_code == 200, cr.text
    created = cr.json()
    assert "id" in created
    sid = created["id"]
    assert created.get("status") in ("connecting", "qr", "connected")

    try:
        # Poll for QR
        qr_found = False
        qr_len = 0
        deadline = time.time() + 10
        while time.time() < deadline:
            lr = requests.get(f"{BASE_URL}/api/wa/sessions", headers=admin_headers, timeout=10)
            assert lr.status_code == 200
            sess = next((s for s in lr.json().get("sessions", []) if s.get("id") == sid), None)
            if sess and sess.get("qr") and sess["qr"].startswith("data:image"):
                qr_found = True
                qr_len = len(sess["qr"])
                assert sess.get("status") == "qr"
                break
            time.sleep(1)
        assert qr_found, "QR data URL did not appear within 10s"
        assert qr_len > 500, f"QR too short: {qr_len}"
    finally:
        # Delete
        dr = requests.delete(f"{BASE_URL}/api/wa/sessions/{sid}", headers=admin_headers, timeout=15)
        assert dr.status_code == 200, dr.text

        # Verify removed
        lr2 = requests.get(f"{BASE_URL}/api/wa/sessions", headers=admin_headers, timeout=10)
        ids = [s.get("id") for s in lr2.json().get("sessions", [])]
        assert sid not in ids


def test_logout_session_endpoint(admin_headers):
    cr = requests.post(
        f"{BASE_URL}/api/wa/sessions",
        headers=admin_headers,
        json={"name": "TEST_logout_session"},
        timeout=20,
    )
    assert cr.status_code == 200, cr.text
    sid = cr.json()["id"]
    try:
        time.sleep(2)
        lo = requests.post(f"{BASE_URL}/api/wa/sessions/{sid}/logout", headers=admin_headers, timeout=20)
        assert lo.status_code == 200, lo.text
    finally:
        requests.delete(f"{BASE_URL}/api/wa/sessions/{sid}", headers=admin_headers, timeout=15)


# ---------- RBAC ----------

def test_viewer_can_list(viewer_token):
    r = requests.get(
        f"{BASE_URL}/api/wa/sessions",
        headers={"Authorization": f"Bearer {viewer_token}"},
        timeout=10,
    )
    assert r.status_code == 200, r.text


def test_viewer_cannot_create(viewer_token):
    r = requests.post(
        f"{BASE_URL}/api/wa/sessions",
        headers={"Authorization": f"Bearer {viewer_token}", "Content-Type": "application/json"},
        json={"name": "TEST_viewer_create"},
        timeout=15,
    )
    assert r.status_code == 403, f"expected 403 for view_only, got {r.status_code}: {r.text}"


def test_viewer_cannot_delete(viewer_token, admin_headers):
    cr = requests.post(f"{BASE_URL}/api/wa/sessions", headers=admin_headers, json={"name": "TEST_rbac_del"}, timeout=20)
    assert cr.status_code == 200
    sid = cr.json()["id"]
    try:
        r = requests.delete(
            f"{BASE_URL}/api/wa/sessions/{sid}",
            headers={"Authorization": f"Bearer {viewer_token}"},
            timeout=15,
        )
        assert r.status_code == 403
    finally:
        requests.delete(f"{BASE_URL}/api/wa/sessions/{sid}", headers=admin_headers, timeout=15)


# ---------- Inbox send 503 when no QR connected ----------

def test_inbox_send_when_disconnected_returns_503(admin_headers):
    # This 503 behaviour only applies when NO Baileys QR session is connected
    # AND Cloud API is unconfigured. If a QR session is connected, the send path
    # correctly delegates to Baileys and returns 200 — so gate the assertion.
    sess = requests.get(f"{BASE_URL}/api/wa/sessions", headers=admin_headers, timeout=10).json()
    if sess.get("connected"):
        pytest.skip("Baileys QR session connected — inbox send delegates to Baileys (200), 503 not expected")

    convs = requests.get(f"{BASE_URL}/api/whatsapp/conversations", headers=admin_headers, timeout=15)
    assert convs.status_code == 200
    items = convs.json() if isinstance(convs.json(), list) else convs.json().get("items", [])
    if not items:
        pytest.skip("No conversations seeded")
    cid = items[0].get("id") or items[0].get("_id")
    r = requests.post(
        f"{BASE_URL}/api/whatsapp/conversations/{cid}/send",
        headers=admin_headers,
        json={"body": "TEST_pytest_message"},
        timeout=15,
    )
    assert r.status_code == 503, f"expected 503 (no QR + no Cloud API), got {r.status_code}: {r.text}"
    body = r.text.lower()
    assert "qr" in body or "whatsapp" in body
