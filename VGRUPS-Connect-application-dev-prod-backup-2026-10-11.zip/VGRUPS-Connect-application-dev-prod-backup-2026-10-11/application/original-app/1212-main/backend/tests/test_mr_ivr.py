"""No live sends or customer writes: MR settings, daily claims and IVR contracts."""
import unittest
from contextlib import ExitStack
from types import SimpleNamespace
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo
from unittest.mock import patch, AsyncMock
import httpx
from fastapi import FastAPI
import auth
import routes_mr_settings as mr
import routes_ivr as ivr
import routes_campaigns as campaigns
from test_settings_campaigns import Collection, fake_lock


class MRIVRTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.actor = {"id": "owner", "name": "Synthetic administrator", "role": "super_admin", "active": True}
        self.db = SimpleNamespace(**{name: Collection() for name in [
            "users", "roles", "mr_directory", "app_config", "mr_reminder_runs",
            "consent_records", "contacts", "messages", "conversations", "whatsapp_send_requests", "ivr_events"]})
        self.db.users.records.append(self.actor.copy())
        self.stack = ExitStack()
        for module in (auth, mr, ivr, campaigns):
            self.stack.enter_context(patch.object(module, "db", self.db))
        self.stack.enter_context(patch.object(mr, "mr_lock", fake_lock))
        self.stack.enter_context(patch.object(mr, "log_audit", AsyncMock()))
        self.stack.enter_context(patch.object(mr.asyncio, "sleep", AsyncMock()))
        self.stack.enter_context(patch.object(mr.wa_client, "wa_list_sessions", AsyncMock(return_value={
            "sessions": [{"id": "qr-mock", "status": "connected", "phone": "synthetic"}]})))
        self.send = self.stack.enter_context(patch.object(mr.wa_client, "wa_send", AsyncMock(side_effect=[
            {"wamid": "mock-day-one"}, {"wamid": "mock-day-two"}])))
        app = FastAPI()
        app.include_router(mr.router)
        app.include_router(ivr.router)
        app.dependency_overrides[auth.get_current_user] = lambda: self.actor
        self.client = httpx.AsyncClient(transport=httpx.ASGITransport(app), base_url="http://mock")
        self.body = {"name": "Synthetic MR", "phone": "+15550001111", "email": "mr@example.com", "employee_id": "MR-001", "active": True}

    async def asyncTearDown(self):
        await self.client.aclose()
        self.stack.close()

    async def add_mr(self):
        response = await self.client.post("/api/settings/mrs", json=self.body)
        self.assertEqual(response.status_code, 200, response.text)
        return response.json()

    async def enable(self):
        response = await self.client.put("/api/settings/mr-reminders", json={
            **mr.DEFAULT_REMINDER, "enabled": True})
        self.assertEqual(response.status_code, 200, response.text)

    async def test_directory_crud_unique_and_not_a_login(self):
        row = await self.add_mr()
        self.assertIsNone(row["user_id"])
        self.assertEqual(len(self.db.users.records), 1)
        self.assertEqual((await self.client.post("/api/settings/mrs", json=self.body)).status_code, 409)
        bad = await self.client.post("/api/settings/mrs", json={**self.body, "phone": "9876543210"})
        self.assertEqual(bad.status_code, 422)
        edited = await self.client.put(f"/api/settings/mrs/{row['id']}", json={**self.body, "name": "Changed MR", "active": False})
        self.assertEqual(edited.json()["name"], "Changed MR")
        await self.client.delete(f"/api/settings/mrs/{row['id']}")
        self.assertEqual((await self.client.get("/api/settings/mrs")).json()["items"], [])

    async def test_default_off_no_sends_and_time_validation(self):
        await self.add_mr()
        self.assertFalse((await self.client.get("/api/settings/mr-reminders")).json()["enabled"])
        await mr.reminder_tick()
        self.send.assert_not_awaited()
        for fields in ({"time": "25:00"}, {"message_gap_seconds": 0}, {"message": "Hi {unknown}"}):
            response = await self.client.put("/api/settings/mr-reminders", json={**mr.DEFAULT_REMINDER, **fields})
            self.assertEqual(response.status_code, 422)

    async def test_morning_once_daily_scoped_and_reserved(self):
        row = await self.add_mr()
        await self.enable()
        day = datetime.now(mr.IST).replace(hour=9, minute=0, second=0, microsecond=0)
        await mr.reminder_tick(day - timedelta(minutes=1))
        self.send.assert_not_awaited()
        await mr.reminder_tick(day)
        self.assertEqual(self.send.await_count, 1)
        args = self.send.await_args
        self.assertEqual(args.kwargs["session_id"], "qr-mock")
        self.assertRegex(args.kwargs["request_id"], r"^[a-f0-9]{64}$")
        self.assertIn(row["name"], args.args[1])
        self.assertNotIn("{name}", args.args[1])
        self.assertEqual(self.db.whatsapp_send_requests.records[0]["provider"], "qr")
        self.db.app_config.records[0].pop("next_send_at", None)
        await mr.reminder_tick(day + timedelta(minutes=1))
        self.assertEqual(self.send.await_count, 1)
        await mr.reminder_tick(day + timedelta(days=1))
        self.assertEqual(self.send.await_count, 2)
        self.assertEqual(len(self.db.mr_reminder_runs.records), 2)
        self.assertEqual(len(self.db.messages.records), 2)

    async def test_timeout_never_retries_no_evening_catchup(self):
        await self.add_mr()
        await self.enable()
        self.send.side_effect = TimeoutError("synthetic")
        day = datetime.now(mr.IST).replace(hour=9, minute=0, second=0, microsecond=0)
        await mr.reminder_tick(day)
        self.assertEqual(self.db.mr_reminder_runs.records[0]["status"], "uncertain")
        self.db.app_config.records[0].pop("next_send_at", None)
        await mr.reminder_tick(day + timedelta(minutes=1))
        await mr.reminder_tick(day + timedelta(hours=9))
        self.send.assert_awaited_once()

    async def test_optout_inactive_and_revoked_sender(self):
        await self.add_mr()
        await self.enable()
        day = datetime.now(mr.IST).replace(hour=9, minute=0, second=0, microsecond=0)
        self.db.mr_directory.records[0]["active"] = False
        await mr.reminder_tick(day)
        self.db.mr_directory.records[0]["active"] = True
        self.db.consent_records.records.append({"phone": "15550001111", "status": "opted_out", "created_at": "2026-01-01"})
        await mr.reminder_tick(day)
        self.db.consent_records.records.clear()
        self.db.users.records[0]["active"] = False
        await mr.reminder_tick(day)
        self.send.assert_not_awaited()

    async def test_directory_and_ivr_role_gates(self):
        self.actor["role"] = "view_only"
        self.assertEqual((await self.client.post("/api/settings/mrs", json=self.body)).status_code, 403)
        self.assertEqual((await self.client.put("/api/ivr", json=ivr.DEFAULT_IVR)).status_code, 403)
        self.actor["role"] = "super_admin"
        with patch.object(mr, "permissions_for", return_value={"settings": ["manage"]}):
            self.assertEqual((await self.client.put("/api/settings/mr-reminders", json={**mr.DEFAULT_REMINDER, "enabled": True})).status_code, 403)

    async def test_ivr_nested_config_and_real_analytics(self):
        config = (await self.client.get("/api/ivr")).json()
        self.assertEqual(len(config["options"]), 7)
        self.assertEqual(config["options"][0]["options"][0]["action"], "catalogue")
        config["sales_contact"] = "+15550002222"
        response = await self.client.put("/api/ivr", json=config)
        self.assertEqual(response.status_code, 200, response.text)
        self.assertEqual((await self.client.get("/api/ivr")).json()["sales_contact"], "+15550002222")
        self.db.ivr_events.records.append({"id": "event", "conversation_id": "c", "created_at": datetime.now(ZoneInfo("UTC")).isoformat(),
            "metric": "pricing_enquiries", "new_conversation": True, "handoff": True})
        self.db.conversations.records.append({"id": "c", "created_at": datetime.now(ZoneInfo("UTC")).isoformat()})
        report = (await self.client.get("/api/ivr/analytics?period=today")).json()
        self.assertEqual(report["summary"]["pricing_enquiries"], 1)
        self.assertEqual(report["summary"]["human_handoffs"], 1)
        self.assertEqual(report["summary"]["new_conversations"], 1)
        config["catalogue_url"] = "javascript:alert(1)"
        self.assertEqual((await self.client.put("/api/ivr", json=config)).status_code, 422)