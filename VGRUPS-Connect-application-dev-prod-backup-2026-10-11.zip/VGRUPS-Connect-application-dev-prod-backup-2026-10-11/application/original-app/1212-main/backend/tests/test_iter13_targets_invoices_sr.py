"""Iteration 13 - Field Targets, Distributor Invoices, Stock Requests + health route."""
import os
import pytest
import requests

def _load_env():
    try:
        for ln in open("/app/frontend/.env"):
            if ln.startswith("REACT_APP_BACKEND_URL="):
                return ln.split("=", 1)[1].strip()
    except Exception:
        pass
    return os.environ.get("REACT_APP_BACKEND_URL", "")

BASE_URL = (os.environ.get("REACT_APP_BACKEND_URL") or _load_env()).rstrip("/")
assert BASE_URL, "REACT_APP_BACKEND_URL not configured"
ADMIN_EMAIL = "vgdisposables@gmail.com"
ADMIN_PASS = "VgrupsConnect@2026"


@pytest.fixture(scope="module")
def admin_token():
    r = requests.post(f"{BASE_URL}/api/auth/login",
                      json={"email": ADMIN_EMAIL, "password": ADMIN_PASS}, timeout=20)
    assert r.status_code == 200, r.text
    return r.json()["token"]


@pytest.fixture(scope="module")
def admin_headers(admin_token):
    return {"Authorization": f"Bearer {admin_token}"}


@pytest.fixture(scope="module")
def admin_me(admin_headers):
    r = requests.get(f"{BASE_URL}/api/auth/me", headers=admin_headers, timeout=10)
    assert r.status_code == 200
    return r.json()


# ---------------- Health ----------------
class TestHealth:
    def test_root_health(self):
        # External ingress routes "/" to frontend; verify backend internal health route.
        r = requests.get("http://localhost:8001/", timeout=10)
        assert r.status_code == 200
        assert r.json().get("status") == "ok"

    def test_api_root(self):
        r = requests.get(f"{BASE_URL}/api/", timeout=10)
        assert r.status_code == 200
        d = r.json()
        assert d.get("service") == "VGRUPS CONNECT"


# ---------------- Field Targets ----------------
class TestFieldTargets:
    def test_requires_auth(self):
        r = requests.get(f"{BASE_URL}/api/field/targets", timeout=10)
        assert r.status_code in (401, 403)

    def test_set_and_list_target(self, admin_headers, admin_me):
        mr_id = admin_me["id"]
        payload = {"mr_id": mr_id, "visit_target": 20, "order_target": 1000,
                   "incentive_pct": 10}
        r = requests.post(f"{BASE_URL}/api/field/targets", json=payload,
                          headers=admin_headers, timeout=15)
        assert r.status_code == 200, r.text
        d = r.json()
        assert d["ok"] is True
        assert d["mr_id"] == mr_id
        assert d["visit_target"] == 20
        assert d["order_target"] == 1000
        assert d["incentive_pct"] == 10

        # list
        r = requests.get(f"{BASE_URL}/api/field/targets", headers=admin_headers, timeout=10)
        assert r.status_code == 200
        body = r.json()
        assert body["is_manager"] is True
        assert "month" in body
        found = [t for t in body["targets"] if t["mr_id"] == mr_id]
        assert found, f"target not found in list: {body}"
        t = found[0]
        for k in ("visit_target", "order_target", "incentive_pct",
                  "visits_done", "orders_done", "incentive_earned"):
            assert k in t, f"missing {k}"
        assert t["visit_target"] == 20
        # incentive_earned should be 0 unless orders_done >= order_target
        if t["orders_done"] < t["order_target"]:
            assert t["incentive_earned"] == 0

    def test_upsert_updates(self, admin_headers, admin_me):
        mr_id = admin_me["id"]
        r = requests.post(f"{BASE_URL}/api/field/targets",
                          json={"mr_id": mr_id, "visit_target": 25,
                                "order_target": 1500, "incentive_pct": 12},
                          headers=admin_headers, timeout=15)
        assert r.status_code == 200
        r = requests.get(f"{BASE_URL}/api/field/targets", headers=admin_headers, timeout=10)
        found = [t for t in r.json()["targets"] if t["mr_id"] == mr_id][0]
        assert found["visit_target"] == 25
        assert found["order_target"] == 1500
        assert found["incentive_pct"] == 12


# ---------------- Portal Invoices ----------------
class TestPortalInvoice:
    def test_invoice_pdf_or_404(self, admin_headers):
        # Get an order from portal summary
        r = requests.get(f"{BASE_URL}/api/portal/summary", headers=admin_headers, timeout=15)
        assert r.status_code == 200
        orders = r.json().get("orders", [])
        if not orders:
            pytest.skip("No orders available")
        order_no = orders[0]["order_no"]
        r = requests.get(f"{BASE_URL}/api/portal/orders/{order_no}/invoice.pdf",
                         headers=admin_headers, timeout=20)
        assert r.status_code == 200, r.text
        assert r.headers.get("content-type", "").startswith("application/pdf")
        assert r.content[:4] == b"%PDF", "not a valid PDF"
        assert len(r.content) > 500

    def test_invoice_not_found(self, admin_headers):
        r = requests.get(f"{BASE_URL}/api/portal/orders/DOES-NOT-EXIST-XYZ/invoice.pdf",
                         headers=admin_headers, timeout=15)
        assert r.status_code == 404

    def test_invoice_requires_auth(self):
        r = requests.get(f"{BASE_URL}/api/portal/orders/XYZ/invoice.pdf", timeout=10)
        assert r.status_code in (401, 403)


# ---------------- Stock Requests ----------------
class TestStockRequests:
    created_id = None

    def test_create_empty_422(self, admin_headers):
        r = requests.post(f"{BASE_URL}/api/portal/stock-requests",
                          json={"items": [], "notes": "x"},
                          headers=admin_headers, timeout=10)
        assert r.status_code == 422

    def test_create_and_list(self, admin_headers):
        payload = {"items": [{"name": "TEST_SR_Gauze", "qty": 5},
                             {"name": "TEST_SR_Gloves", "qty": 2}],
                   "notes": "TEST iter13"}
        r = requests.post(f"{BASE_URL}/api/portal/stock-requests", json=payload,
                          headers=admin_headers, timeout=15)
        assert r.status_code == 200, r.text
        d = r.json()
        assert d.get("number", "").startswith("SR-")
        assert d["status"] == "pending"
        assert len(d["items"]) == 2
        TestStockRequests.created_id = d["id"]

        r = requests.get(f"{BASE_URL}/api/portal/stock-requests",
                         headers=admin_headers, timeout=10)
        assert r.status_code == 200
        items = r.json().get("items", [])
        found = [x for x in items if x.get("id") == TestStockRequests.created_id]
        assert found, "created SR not in list"
        assert found[0]["items"][0]["name"] == "TEST_SR_Gauze"

    def test_requires_auth(self):
        r = requests.get(f"{BASE_URL}/api/portal/stock-requests", timeout=10)
        assert r.status_code in (401, 403)


def teardown_module(module):
    """Best-effort cleanup for created stock requests via direct DB."""
    try:
        import asyncio, sys
        sys.path.insert(0, "/app/backend")
        from db import db  # noqa
        async def _cleanup():
            await db.stock_requests.delete_many({"notes": "TEST iter13"})
        asyncio.get_event_loop().run_until_complete(_cleanup())
    except Exception as e:
        print(f"cleanup skipped: {e}")
