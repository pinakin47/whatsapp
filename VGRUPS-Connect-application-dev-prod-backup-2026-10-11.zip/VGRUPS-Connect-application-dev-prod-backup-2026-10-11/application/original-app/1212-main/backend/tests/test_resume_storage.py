"""Tests for Resume-over-WhatsApp object-storage endpoints (iteration 11)."""
import io
import os
import pytest
import requests

BASE_URL = (os.environ.get("REACT_APP_BACKEND_URL") or "").rstrip("/")
WA_SECRET = "vg_wa_internal_7a3f9b2c8e1d4f6b"
ADMIN_EMAIL = "vgdisposables@gmail.com"
ADMIN_PASSWORD = "VgrupsConnect@2026"


@pytest.fixture(scope="module")
def api():
    if not BASE_URL:
        pytest.skip("REACT_APP_BACKEND_URL not set")
    s = requests.Session()
    s.headers.update({"Content-Type": "application/json"})
    return s


@pytest.fixture(scope="module")
def admin_token(api):
    r = api.post(f"{BASE_URL}/api/auth/login",
                 json={"email": ADMIN_EMAIL, "password": ADMIN_PASSWORD}, timeout=30)
    assert r.status_code == 200, r.text
    return r.json()["token"]


@pytest.fixture(scope="module")
def auth_headers(admin_token):
    return {"Authorization": f"Bearer {admin_token}"}


@pytest.fixture(scope="module")
def position_id(api):
    r = api.get(f"{BASE_URL}/api/careers/positions", timeout=30)
    assert r.status_code == 200
    items = r.json()["items"]
    assert len(items) >= 1
    return items[0]["id"]


@pytest.fixture
def test_candidate(api, auth_headers, position_id):
    """Create a TEST_ candidate via public /careers/apply, yield id, delete after."""
    import time
    mobile = f"+91900{int(time.time() * 1000) % 10000000:07d}"
    r = api.post(f"{BASE_URL}/api/careers/apply", json={
        "name": "TEST_ResumeStorage", "mobile": mobile,
        "position_id": position_id, "consent": True,
    }, timeout=30)
    assert r.status_code == 200, r.text
    app_id = r.json()["application_id"]
    # Lookup internal id
    lst = api.get(f"{BASE_URL}/api/recruitment/candidates", headers=auth_headers, timeout=30)
    assert lst.status_code == 200
    cand = next((c for c in lst.json()["items"] if c.get("application_id") == app_id), None)
    assert cand, f"Candidate with app_id {app_id} not found"
    cid = cand["id"]
    yield cid, mobile
    # cleanup
    api.delete(f"{BASE_URL}/api/recruitment/candidates/{cid}", headers=auth_headers, timeout=30)


# ---- Resume upload auth guards ----
def test_resume_upload_no_secret_returns_401(api, test_candidate):
    cid, mobile = test_candidate
    files = {"file": ("r.pdf", b"%PDF-1.4 TEST", "application/pdf")}
    data = {"candidate_id": cid, "mobile": mobile}
    r = requests.post(f"{BASE_URL}/api/recruitment/resume-upload", files=files, data=data, timeout=30)
    assert r.status_code == 401, r.text


def test_resume_upload_wrong_secret_returns_401(api, test_candidate):
    cid, mobile = test_candidate
    files = {"file": ("r.pdf", b"%PDF-1.4 TEST", "application/pdf")}
    data = {"candidate_id": cid, "mobile": mobile}
    r = requests.post(f"{BASE_URL}/api/recruitment/resume-upload",
                      files=files, data=data,
                      headers={"X-WA-Secret": "wrong-secret"}, timeout=30)
    assert r.status_code == 401


# ---- Resume upload happy path + round-trip ----
def test_resume_upload_and_download_roundtrip(api, auth_headers, test_candidate):
    cid, mobile = test_candidate
    sample_bytes = b"%PDF-1.4\n%VGRUPS-RESUME-TEST-" + os.urandom(64) + b"\n%%EOF"
    files = {"file": ("TEST_resume.pdf", sample_bytes, "application/pdf")}
    data = {"candidate_id": cid, "mobile": mobile}
    r = requests.post(f"{BASE_URL}/api/recruitment/resume-upload",
                      files=files, data=data,
                      headers={"X-WA-Secret": WA_SECRET}, timeout=60)
    assert r.status_code == 200, r.text
    body = r.json()
    assert body["ok"] is True
    assert body["path"].startswith("vgrups-connect/resumes/")

    # Candidate record should now have resume_* fields
    lst = api.get(f"{BASE_URL}/api/recruitment/candidates", headers=auth_headers, timeout=30)
    cand = next(c for c in lst.json()["items"] if c["id"] == cid)
    assert cand.get("resume_filename") == "TEST_resume.pdf"
    assert cand.get("resume_content_type") == "application/pdf"
    assert cand.get("resume_size") == len(sample_bytes) or cand.get("resume_size")  # size may be stored
    assert cand.get("resume_url") == f"/api/recruitment/candidates/{cid}/resume"

    # Download — unauth
    r_unauth = requests.get(f"{BASE_URL}/api/recruitment/candidates/{cid}/resume", timeout=30)
    assert r_unauth.status_code in (401, 403)

    # Download — authed, must return exact bytes
    r_dl = requests.get(f"{BASE_URL}/api/recruitment/candidates/{cid}/resume",
                        headers=auth_headers, timeout=60)
    assert r_dl.status_code == 200
    assert r_dl.content == sample_bytes
    assert "application/pdf" in r_dl.headers.get("Content-Type", "")


def test_download_resume_404_when_no_resume(api, auth_headers, test_candidate):
    cid, _mobile = test_candidate
    r = requests.get(f"{BASE_URL}/api/recruitment/candidates/{cid}/resume",
                     headers=auth_headers, timeout=30)
    assert r.status_code == 404


# ---- Regression: WA sessions + careers ----
def test_wa_sessions_connected(api, auth_headers):
    r = api.get(f"{BASE_URL}/api/wa/sessions", headers=auth_headers, timeout=30)
    assert r.status_code == 200
    body = r.json()
    assert body.get("connected") is True
    assert any(s.get("status") == "connected" for s in body.get("sessions", []))


def test_careers_lists_15_positions(api):
    r = api.get(f"{BASE_URL}/api/careers/positions", timeout=30)
    assert r.status_code == 200
    assert len(r.json()["items"]) == 15
