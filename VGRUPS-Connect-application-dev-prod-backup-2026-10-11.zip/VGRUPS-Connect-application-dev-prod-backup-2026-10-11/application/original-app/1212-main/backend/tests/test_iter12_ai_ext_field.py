"""Iteration 12: AI resume screening + Chrome Extension/Widget + Field sales + Portal."""
import os
import io
import time
import pytest
import requests

BASE = os.environ.get("REACT_APP_BACKEND_URL", "https://vgrups-connect.preview.emergentagent.com").rstrip("/")
API = BASE + "/api"
ADMIN_EMAIL = "vgdisposables@gmail.com"
ADMIN_PASS = "VgrupsConnect@2026"
WA_SECRET = "vg_wa_internal_7a3f9b2c8e1d4f6b"


@pytest.fixture(scope="module")
def admin_token():
    r = requests.post(f"{API}/auth/login", json={"email": ADMIN_EMAIL, "password": ADMIN_PASS}, timeout=20)
    assert r.status_code == 200, r.text
    return r.json()["token"]


@pytest.fixture(scope="module")
def ah(admin_token):
    return {"Authorization": f"Bearer {admin_token}"}


# ---------- Minimal real PDF with extractable text ----------
def _real_pdf_bytes() -> bytes:
    # Pre-built minimal PDF with text "John Doe Accounts GST Tally 5 yrs"
    txt = "John Doe B.Com Accounts Receivable Payable GST Tally ERP Bank Reconciliation 5 years experience Hyderabad"
    body = f"BT /F1 12 Tf 50 750 Td ({txt}) Tj ET"
    objs = []
    objs.append(b"1 0 obj<</Type/Catalog/Pages 2 0 R>>endobj")
    objs.append(b"2 0 obj<</Type/Pages/Kids[3 0 R]/Count 1>>endobj")
    objs.append(b"3 0 obj<</Type/Page/Parent 2 0 R/MediaBox[0 0 612 792]/Contents 4 0 R/Resources<</Font<</F1 5 0 R>>>>>>endobj")
    stream = body.encode()
    objs.append(b"4 0 obj<</Length " + str(len(stream)).encode() + b">>stream\n" + stream + b"\nendstream endobj")
    objs.append(b"5 0 obj<</Type/Font/Subtype/Type1/BaseFont/Helvetica>>endobj")
    out = b"%PDF-1.4\n"
    offsets = []
    for o in objs:
        offsets.append(len(out))
        out += o + b"\n"
    xref = len(out)
    out += b"xref\n0 6\n0000000000 65535 f \n"
    for off in offsets:
        out += f"{off:010d} 00000 n \n".encode()
    out += b"trailer<</Size 6/Root 1 0 R>>\nstartxref\n" + str(xref).encode() + b"\n%%EOF"
    return out


# =============== AI Resume Screening ===============
class TestAIScreening:
    cand_id = None

    def test_create_candidate_via_careers(self, ah):
        pos = requests.get(f"{API}/careers/positions", timeout=20).json()
        pid = pos["items"][0]["id"] if "items" in pos else pos[0]["id"]
        payload = {
            "position_id": pid,
            "name": "TEST_AIScore Candidate",
            "mobile": f"+91900{int(time.time()) % 10000000:07d}",
            "email": "test_aiscore@example.com",
            "experience": "5 years",
            "location": "Hyderabad",
            "consent": True,
        }
        r = requests.post(f"{API}/careers/apply", json=payload, timeout=20)
        assert r.status_code == 200, r.text
        app_id = r.json().get("application_id") or r.json().get("id")
        # find candidate
        lst = requests.get(f"{API}/recruitment/candidates", headers=ah, timeout=20).json()
        items = lst.get("items", lst)
        match = [c for c in items if c.get("name", "").startswith("TEST_AIScore")]
        assert match, "candidate not found after apply"
        TestAIScreening.cand_id = match[0]["id"]

    def test_upload_resume_requires_secret(self, ah):
        files = {"file": ("r.pdf", _real_pdf_bytes(), "application/pdf")}
        data = {"candidate_id": TestAIScreening.cand_id}
        # no secret
        r = requests.post(f"{API}/recruitment/resume-upload", files=files, data=data, timeout=30)
        assert r.status_code == 401
        # correct secret
        r = requests.post(f"{API}/recruitment/resume-upload",
                          files={"file": ("r.pdf", _real_pdf_bytes(), "application/pdf")},
                          data=data, headers={"X-WA-Secret": WA_SECRET}, timeout=30)
        assert r.status_code == 200, r.text
        assert r.json().get("ok") is True

    def test_manual_score_endpoint(self, ah):
        r = requests.post(f"{API}/recruitment/candidates/{TestAIScreening.cand_id}/score",
                          headers=ah, timeout=90)
        assert r.status_code == 200, r.text
        d = r.json()
        assert isinstance(d.get("score"), (int, float))
        assert 0 <= d["score"] <= 100
        assert d["recommendation"] in ("strong_fit", "possible_fit", "weak_fit")
        assert "summary" in d and isinstance(d.get("strengths"), list) and isinstance(d.get("concerns"), list)
        # persistence
        lst = requests.get(f"{API}/recruitment/candidates", headers=ah, timeout=20).json()
        items = lst.get("items", lst)
        cand = next(c for c in items if c["id"] == TestAIScreening.cand_id)
        assert cand.get("ai_score") == d["score"]
        assert cand.get("ai_recommendation") == d["recommendation"]
        assert cand.get("ai_scored_at")

    def test_auto_score_auth(self, ah):
        # missing secret
        r = requests.post(f"{API}/recruitment/candidates/{TestAIScreening.cand_id}/auto-score", timeout=30)
        assert r.status_code == 401
        # wrong secret
        r = requests.post(f"{API}/recruitment/candidates/{TestAIScreening.cand_id}/auto-score",
                          headers={"X-WA-Secret": "bad"}, timeout=30)
        assert r.status_code == 401

    def test_cleanup(self, ah):
        if TestAIScreening.cand_id:
            r = requests.delete(f"{API}/recruitment/candidates/{TestAIScreening.cand_id}", headers=ah, timeout=20)
            assert r.status_code in (200, 204, 404)


# =============== Chrome Extension / Widget ===============
class TestExtWidget:
    def test_ext_lookup_requires_auth(self):
        r = requests.get(f"{API}/ext/lookup/9177999986", timeout=20)
        assert r.status_code == 401

    def test_ext_lookup_authed(self, ah):
        r = requests.get(f"{API}/ext/lookup/9876543210", headers=ah, timeout=20)
        assert r.status_code == 200
        d = r.json()
        assert "found" in d and "wa_link" in d
        assert d["wa_link"] and "wa.me" in d["wa_link"]

    def test_ext_capture_requires_auth(self):
        r = requests.post(f"{API}/ext/capture", json={"phone": "+919000000011"}, timeout=20)
        assert r.status_code == 401

    created_cid = None
    def test_ext_capture_authed(self, ah):
        phone = f"+91900{int(time.time()) % 10000000:07d}"
        r = requests.post(f"{API}/ext/capture", headers=ah,
                          json={"phone": phone, "name": "TEST_ExtLead", "note": "from test", "page": "https://x.com"},
                          timeout=20)
        assert r.status_code == 200, r.text
        d = r.json()
        assert d.get("ok") is True and d.get("contact_id")
        TestExtWidget.created_cid = d["contact_id"]

    def test_ext_download_requires_auth(self):
        r = requests.get(f"{API}/ext/download", timeout=20, allow_redirects=False)
        assert r.status_code == 401

    def test_ext_download_authed(self, ah):
        r = requests.get(f"{API}/ext/download", headers=ah, timeout=30)
        # 200 if extension dir exists, else 404 (acceptable but prefer 200)
        assert r.status_code in (200, 404)
        if r.status_code == 200:
            assert r.headers.get("content-type", "").startswith("application/zip")
            assert len(r.content) > 100

    def test_widget_js_public(self):
        r = requests.get(f"{API}/widget.js", timeout=20)
        assert r.status_code == 200
        assert "javascript" in r.headers.get("content-type", "")
        assert "wa.me" in r.text

    def test_widget_click_public(self):
        r = requests.post(f"{API}/widget/click", json={"source": "test", "utm": "pytest"}, timeout=20)
        assert r.status_code == 200
        assert r.json().get("ok") is True

    def test_widget_stats_auth(self, ah):
        r = requests.get(f"{API}/widget/stats", timeout=20)
        assert r.status_code == 401
        r = requests.get(f"{API}/widget/stats", headers=ah, timeout=20)
        assert r.status_code == 200
        d = r.json()
        assert isinstance(d.get("total_clicks"), int)
        assert isinstance(d.get("by_source"), list)
        assert "number" in d


# =============== Field Sales ===============
class TestFieldSales:
    vid = None
    def test_create_visit(self, ah):
        r = requests.post(f"{API}/field/visits", headers=ah,
                          json={"doctor_name": "TEST_Dr Rao", "clinic_name": "TEST Clinic", "city": "Hyd"},
                          timeout=20)
        assert r.status_code == 200, r.text
        d = r.json()
        assert d["id"] and d["status"] == "planned"
        TestFieldSales.vid = d["id"]

    def test_list_visits_admin_is_manager(self, ah):
        r = requests.get(f"{API}/field/visits", headers=ah, timeout=20)
        assert r.status_code == 200
        d = r.json()
        assert d.get("is_manager") is True
        assert any(v["id"] == TestFieldSales.vid for v in d["items"])

    def test_checkin_visit(self, ah):
        r = requests.patch(f"{API}/field/visits/{TestFieldSales.vid}", headers=ah,
                           json={"status": "visited", "outcome": "interested",
                                 "order_value": 1500, "notes": "ok"}, timeout=20)
        assert r.status_code == 200
        # verify persistence
        lst = requests.get(f"{API}/field/visits", headers=ah, timeout=20).json()
        v = next(x for x in lst["items"] if x["id"] == TestFieldSales.vid)
        assert v["status"] == "visited" and v["order_value"] == 1500 and v["check_in_at"]

    def test_stats(self, ah):
        r = requests.get(f"{API}/field/stats", headers=ah, timeout=20)
        assert r.status_code == 200
        d = r.json()
        for k in ("planned_today", "visited_today", "total_visits", "order_value"):
            assert k in d

    def test_delete_visit(self, ah):
        r = requests.delete(f"{API}/field/visits/{TestFieldSales.vid}", headers=ah, timeout=20)
        assert r.status_code == 200


# =============== Portal ===============
class TestPortal:
    def test_portal_summary_admin(self, ah):
        r = requests.get(f"{API}/portal/summary", headers=ah, timeout=20)
        assert r.status_code == 200, r.text
        d = r.json()
        assert "ledger" in d and "orders" in d
        for k in ("billed", "paid", "outstanding", "order_count"):
            assert k in d["ledger"]
        assert d.get("preview_all") is True

    def test_portal_summary_requires_auth(self):
        r = requests.get(f"{API}/portal/summary", timeout=20)
        assert r.status_code == 401


# =============== Regression ===============
class TestRegression:
    def test_wa_sessions_connected(self, ah):
        r = requests.get(f"{API}/wa/sessions", headers=ah, timeout=20)
        assert r.status_code == 200
        assert r.json().get("connected") in (True, False)  # just reachable

    def test_careers_positions(self):
        r = requests.get(f"{API}/careers/positions", timeout=20)
        assert r.status_code == 200
        items = r.json().get("items", r.json())
        assert len(items) >= 15
