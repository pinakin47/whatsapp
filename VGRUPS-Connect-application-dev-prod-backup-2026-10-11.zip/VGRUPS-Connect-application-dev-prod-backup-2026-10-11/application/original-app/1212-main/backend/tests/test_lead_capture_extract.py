"""Provider routing tests; all credentials and HTTP responses are synthetic."""
import json
import os
import unittest
from unittest.mock import patch

import httpx
import lead_capture_extract as extraction


class ProviderTests(unittest.IsolatedAsyncioTestCase):
    text = "Sample Clinic requires gloves. Customer phone 9000000100."
    managed = {
        "AI_INTEGRATIONS_OPENAI_BASE_URL": "https://managed.example.test/v1",
        "AI_INTEGRATIONS_OPENAI_API_KEY": "synthetic-managed",
    }

    async def run_extraction(self, environment, status=200):
        self.requests = []

        def handle(request):
            self.requests.append(request)
            if status != 200:
                return httpx.Response(status, json={"error": {"message": "Synthetic failure"}})
            return httpx.Response(200, json={"choices": [{"message": {"content": json.dumps({
                "is_business": True, "confidence": .95, "lead_type": "Clinic",
                "clinic_name": "Sample Clinic", "requirement": "gloves",
            })}}]})

        client = httpx.AsyncClient(transport=httpx.MockTransport(handle))
        with patch.dict(os.environ, environment, clear=True), patch.object(extraction.httpx, "AsyncClient", return_value=client):
            return await extraction.extract_information(self.text)

    def test_ready_when_personal_key_is_configured(self):
        with patch.dict(os.environ, {"OPENAI_API_KEY": "synthetic-personal"}, clear=True):
            self.assertTrue(extraction.ai_ready())

    def test_not_ready_without_complete_credentials(self):
        for environment in ({}, {"AI_INTEGRATIONS_OPENAI_BASE_URL": "https://managed.example.test/v1"}):
            with patch.dict(os.environ, environment, clear=True):
                self.assertFalse(extraction.ai_ready())

    async def test_personal_key_takes_precedence_over_managed_provider(self):
        result = await self.run_extraction({**self.managed, "OPENAI_API_KEY": "synthetic-personal"})
        request = self.requests[0]
        self.assertEqual(str(request.url), "https://api.openai.com/v1/chat/completions")
        self.assertEqual(request.headers["Authorization"], "Bearer synthetic-personal")
        self.assertEqual(json.loads(request.content)["model"], "gpt-5-mini")
        self.assertEqual(result["mobile"], "+919000000100")
        self.assertEqual(result["clinic_name"], "Sample Clinic")

    async def test_existing_managed_provider_remains_available_without_personal_key(self):
        await self.run_extraction(self.managed)
        request = self.requests[0]
        self.assertEqual(str(request.url), "https://managed.example.test/v1/chat/completions")
        self.assertEqual(request.headers["Authorization"], "Bearer synthetic-managed")
        self.assertEqual(json.loads(request.content)["model"], "gpt-5.6-luna")

    async def test_personal_key_failure_does_not_fall_back_to_managed_billing(self):
        with self.assertRaises(httpx.HTTPStatusError):
            await self.run_extraction({**self.managed, "OPENAI_API_KEY": "synthetic-personal"}, status=401)
        self.assertEqual(len(self.requests), 1)
        self.assertEqual(self.requests[0].url.host, "api.openai.com")
