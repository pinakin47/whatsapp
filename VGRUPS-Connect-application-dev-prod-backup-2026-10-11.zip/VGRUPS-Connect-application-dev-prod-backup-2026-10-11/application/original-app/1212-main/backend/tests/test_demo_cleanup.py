import unittest
from types import SimpleNamespace
from unittest.mock import AsyncMock

from demo_cleanup import remove_demo_contacts, remove_demo_users


class CleanupTests(unittest.IsolatedAsyncioTestCase):
    async def test_only_explicit_demo_contacts_are_deleted(self):
        contacts = SimpleNamespace(update_many=AsyncMock(return_value=SimpleNamespace(modified_count=50)))
        self.assertEqual(await remove_demo_contacts(SimpleNamespace(contacts=contacts)), 50)
        selector, update = contacts.update_many.call_args.args
        self.assertEqual(selector, {"is_demo": True, "deleted": {"$ne": True}})
        self.assertIs(update["$set"]["deleted"], True)
        self.assertIn("updated_at", update["$set"])

    async def test_repeat_cleanup_is_safe(self):
        contacts = SimpleNamespace(update_many=AsyncMock(return_value=SimpleNamespace(modified_count=0)))
        self.assertEqual(await remove_demo_contacts(SimpleNamespace(contacts=contacts)), 0)

    async def test_only_demo_users_are_removed_and_disabled(self):
        users = SimpleNamespace(
            count_documents=AsyncMock(return_value=1),
            update_many=AsyncMock(return_value=SimpleNamespace(modified_count=10)))
        self.assertEqual(await remove_demo_users(SimpleNamespace(users=users)), 10)
        selector, update = users.update_many.call_args.args
        self.assertIs(selector["is_demo"], True)
        self.assertIs(update["$set"]["deleted"], True)
        self.assertIs(update["$set"]["active"], False)

    async def test_users_repeat_cleanup_is_safe(self):
        users = SimpleNamespace(count_documents=AsyncMock(return_value=1),
            update_many=AsyncMock(return_value=SimpleNamespace(modified_count=0)))
        self.assertEqual(await remove_demo_users(SimpleNamespace(users=users)), 0)

    async def test_cleanup_preserves_last_administrator(self):
        users = SimpleNamespace(count_documents=AsyncMock(return_value=0), update_many=AsyncMock())
        with self.assertRaises(RuntimeError):
            await remove_demo_users(SimpleNamespace(users=users))
        users.update_many.assert_not_awaited()