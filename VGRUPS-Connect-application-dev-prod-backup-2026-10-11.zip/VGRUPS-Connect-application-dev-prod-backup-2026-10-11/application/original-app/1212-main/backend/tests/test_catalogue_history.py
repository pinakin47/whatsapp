"""Synthetic read-only history and export checks; providers/database fail closed."""
import csv
import io
import unittest
from unittest.mock import AsyncMock, patch

import auth
import contact_catalogue
import httpx
import test_report_sender_numbers as sender_tests


class CatalogueHistoryTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        await sender_tests.SenderReports.asyncSetUp(self)
        self.guards = [self.no_database, self.no_gateway]
        self.guards.append(self.stack.enter_context(patch.object(httpx.AsyncHTTPTransport,
            "handle_async_request", AsyncMock(side_effect=AssertionError("Live HTTP forbidden")))))
        self.addCleanup(lambda: [guard.assert_not_called() for guard in self.guards])
        for method in ("enqueue", "catalogue_tick"):
            self.guards.append(self.stack.enter_context(patch.object(contact_catalogue, method,
                AsyncMock(side_effect=AssertionError("Reports must never send or retry")))))
        self.guards.append(self.stack.enter_context(patch.object(contact_catalogue, "signed_url",
            AsyncMock(side_effect=AssertionError("Reports must not resolve live assets")))))
        for collection in vars(self.db).values():
            for operation in ("insert_one", "update_one", "update_many"):
                self.guards.append(self.stack.enter_context(patch.object(collection, operation,
                    AsyncMock(side_effect=AssertionError("History must never write")))))
        for n in range(45):
            job = {"id": f"saved-{n:02}", "user_id": "admin", "contact_ref": "deleted-contact",
                   "name": "Saved contact", "mr_name": "Saved MR", "phone": "+15559999999",
                   "created_at": "2026-10-07T09:00:00Z", "date": "2026-10-07",
                   "session_id": "gone", "sender_phone": "+15550000006",
                   "status": "needs_review", "total_parts": 2,
                   "parts": [{"key": "a", "name": "Archived file.pdf"},
                             {"key": "b", "name": "Old image.jpg"}]}
            self.db.contact_catalogue_runs.records.append(job)
            self.db.mr_catalog_runs.records.append(dict(job))
            for collection in (self.db.contact_catalogue_parts, self.db.mr_catalog_parts):
                collection.records += [
                    {"id": f"{job['id']}-a", "run_id": job["id"], "media_key": "a",
                     "status": "accepted", "wamid": f"provider-{n}"},
                    {"id": f"{job['id']}-b", "run_id": job["id"], "media_key": "b",
                     "status": "uncertain", "error": "Acceptance unresolved"}]
        self.db.contact_catalogue_runs.records.append({"id": "private", "user_id": "other",
                                                      "created_at": "2099-01-01"})

    def attachment(self, key):
        return next(p for p in self.db.contact_catalogue_parts.records
                    if p["id"] == f"saved-00-{key}")

    async def test_receipts_match_exact_ids_merge_monotonically_and_export(self):
        # Evidence in either persisted source, even after Inbox reconciliation.
        self.attachment("b")["wamid"] = "exact-b"
        self.db.messages.records = [
            {"wamid": "provider-0", "status": "read", "delivered_at": "2026-10-07T10:00:01Z",
             "read_at": "2026-10-07T10:01:01Z"},
            {"wamid": "exact-b", "status": "sent", "created_at": "2026-10-07T10:00:00Z"}]
        self.db.whatsapp_receipts.records = [
            {"wamid": "provider-0", "status": "sent"},
            {"wamid": "exact-b", "status": "played", "delivered_at": "2026-10-07T10:00:02Z",
             "read_at": "2026-10-07T10:01:02Z"},
            {"wamid": "unrelated", "status": "read"}]
        # Give both history families the same immutable IDs.
        next(p for p in self.db.mr_catalog_parts.records if p["id"] == "saved-00-b")["wamid"] = "exact-b"
        for base in ("/api/contacts/catalogue-history", "/api/catalog/daily-mr"):
            row = (await self.client.get(base + "/saved-00")).json()
            self.assertEqual(row["status"], "needs_review")
            self.assertEqual(row["uncertain_parts"], 1)
            self.assertEqual(row["parts"][1]["status"], "uncertain")
            self.assertEqual(row["delivery"], {
                "status": "read", "required_parts": 2, "delivered_parts": 2, "read_parts": 2,
                "failed_parts": 0, "delivered_at": "2026-10-07T10:00:02.000Z",
                "read_at": "2026-10-07T10:01:02.000Z"})
            listed = (await self.client.get(base + "?offset=40")).json()["items"]
            self.assertEqual(next(r for r in listed if r["id"] == "saved-00")["delivery"], row["delivery"])
            page_csv = list(csv.DictReader(io.StringIO(
                (await self.client.get(base + ".csv?offset=40")).text)))
            exported = next(r for r in page_csv if r["Attempt"] == "saved-00")
            self.assertEqual(exported["Receipt status"], "read")
            self.assertEqual(exported["Delivered attachments"], "2")
            self.assertEqual(exported["Read attachments"], "2")
            self.assertEqual(exported["Send status"], "needs_review")
            detail_csv = list(csv.DictReader(io.StringIO(
                (await self.client.get(base + "/saved-00/report.csv")).text)))
            self.assertEqual(detail_csv[1]["Attachment receipt status"], "read")
            self.assertEqual(detail_csv[1]["Attachment read at"], "2026-10-07T10:01:02.000Z")
            self.assertEqual(detail_csv[0]["Attachment delivered at"], "2026-10-07T10:00:01.000Z")

    async def test_missing_times_remain_unknown_even_with_full_read_confirmation(self):
        self.attachment("b")["wamid"] = "exact-b"
        self.db.messages.records = [
            {"wamid": "provider-0", "status": "read", "status_at": "2026-10-07T12:00:00Z",
             "created_at": "2026-10-07T11:00:00Z", "read_at": "2026-10-07T12:00:00Z"},
            {"wamid": "exact-b", "status": "read", "delivered_at": "not-a-time",
             "read_at": "2026-10-07T12:00:01"}]  # no timezone, not provider evidence
        base = "/api/contacts/catalogue-history/saved-00"
        row = (await self.client.get(base)).json()
        self.assertEqual(row["delivery"]["status"], "read")
        self.assertIsNone(row["delivery"]["delivered_at"])
        self.assertIsNone(row["delivery"]["read_at"])
        self.assertIsNone(row["parts"][0]["delivery"]["delivered_at"])
        self.assertEqual(row["parts"][0]["delivery"]["read_at"], "2026-10-07T12:00:00.000Z")
        rows = list(csv.DictReader(io.StringIO((await self.client.get(base + "/report.csv")).text)))
        self.assertTrue(all(r["Delivered at"] == r["Read at"] == "" for r in rows))
        self.assertEqual(rows[1]["Attachment read at"], "")

    async def test_partial_missing_removed_duplicate_and_failed_attachments(self):
        self.db.whatsapp_receipts.records = [{"wamid": "provider-0", "status": "read"}]
        base = "/api/contacts/catalogue-history/saved-00"
        for second_status in ("uncertain", "removed", "accepted"):
            self.attachment("b")["status"] = second_status
            row = (await self.client.get(base)).json()
            self.assertEqual(row["delivery"]["status"], "partial")
            self.assertEqual(row["delivery"]["required_parts"], 2)
            self.assertEqual(row["parts"][1]["delivery"]["status"], "unknown")
        self.attachment("b")["wamid"] = "provider-0"
        row = (await self.client.get(base)).json()
        self.assertEqual(row["delivery"]["status"], "partial")
        self.assertEqual(row["delivery"]["read_parts"], 1)
        self.attachment("b")["wamid"] = "failed-b"
        self.db.whatsapp_receipts.records.append({"wamid": "failed-b", "status": "failed"})
        row = (await self.client.get(base)).json()
        self.assertEqual(row["delivery"]["status"], "failed")
        self.assertEqual(row["delivery"]["failed_parts"], 1)
        self.assertEqual(row["status"], "needs_review")
        self.db.contact_catalogue_parts.records.remove(self.attachment("b"))
        self.assertEqual((await self.client.get(base)).json()["delivery"]["status"], "partial")
        # A duplicate saved row for one snapshot slot cannot replace the missing slot.
        self.db.contact_catalogue_parts.records.append({**self.attachment("a"), "id": "duplicate-a"})
        row = (await self.client.get(base)).json()
        self.assertEqual(row["delivery"]["status"], "unknown")
        self.assertEqual(row["delivery"]["required_parts"], 2)

    async def test_acceptance_demo_and_nearby_message_ids_prove_nothing(self):
        self.db.messages.records = [
            {"wamid": "provider-0", "status": "read", "is_demo": True},
            {"wamid": "provider-0-other", "status": "read", "phone": "+15559999999"}]
        self.db.whatsapp_receipts.records = [{"wamid": "provider-0", "status": "read", "is_demo": True}]
        row = (await self.client.get("/api/contacts/catalogue-history/saved-00")).json()
        self.assertEqual(row["accepted_parts"], 1)
        self.assertEqual(row["delivery"]["status"], "unknown")
        self.assertEqual(row["parts"][0]["delivery"]["status"], "unknown")

    async def test_legacy_counts_use_only_saved_expectations(self):
        job = self.db.contact_catalogue_runs.records[0]
        self.db.whatsapp_receipts.records = [{"wamid": "provider-0", "status": "delivered"}]
        base = "/api/contacts/catalogue-history/saved-00"
        job.pop("parts")
        job["total_parts"] = 3
        row = (await self.client.get(base)).json()
        self.assertEqual(row["delivery"]["status"], "partial")
        self.assertEqual(row["delivery"]["required_parts"], 3)
        for count in (None, True, 0, "1"):
            job["total_parts"] = count
            row = (await self.client.get(base)).json()
            self.assertIsNone(row["delivery"]["required_parts"])
            self.assertEqual(row["delivery"]["status"], "partial")
        job["total_parts"] = 1
        self.db.contact_catalogue_parts.records.remove(self.attachment("b"))
        self.assertEqual((await self.client.get(base)).json()["delivery"]["status"], "delivered")

    async def test_complete_pagination_and_matching_page_exports(self):
        for base in ("/api/contacts/catalogue-history", "/api/catalog/daily-mr"):
            seen = []
            for offset, count in ((0, 20), (20, 20), (40, 5)):
                query = f"?offset={offset}&limit=20"
                response = await self.client.get(base + query)
                self.assertEqual(response.status_code, 200, response.text)
                data = response.json()
                self.assertEqual(data["total"], 45)
                self.assertEqual(len(data["items"]), count)
                self.assertEqual(data["has_more"], offset < 40)
                ids = [row["id"] for row in data["items"]]
                seen += ids
                exported = await self.client.get(base + ".csv" + query)
                self.assertEqual(exported.status_code, 200, exported.text)
                rows = list(csv.DictReader(io.StringIO(exported.text)))
                self.assertEqual([r["Attempt"] for r in rows], ids)
                self.assertTrue(all(r["Sender number"] == "'+15550000006" for r in rows))
                self.assertTrue(all(r["Uncertain"] == "1" for r in rows))
            self.assertEqual(len(set(seen)), 45)
            self.assertEqual(seen[0], "saved-44")  # deterministic timestamp tie
            empty = (await self.client.get(base + "?offset=60")).json()
            self.assertEqual(empty["items"], [])
            self.assertFalse(empty["has_more"])

    async def test_saved_details_survive_missing_contact_sender_and_asset(self):
        for base in ("/api/contacts/catalogue-history", "/api/catalog/daily-mr"):
            path = base + "/saved-00"
            response = await self.client.get(path)
            self.assertEqual(response.status_code, 200, response.text)
            data = response.json()
            self.assertEqual(data["sender_number"], "+15550000006")
            self.assertEqual(data["status"], "needs_review")
            self.assertEqual(data["uncertain_parts"], 1)
            self.assertEqual([p["name"] for p in data["parts"]], ["Archived file.pdf", "Old image.jpg"])
            self.assertEqual(data["parts"][0]["wamid"], "provider-0")
            self.assertIsNone(data["parts"][1]["wamid"])
            rows = list(csv.DictReader(io.StringIO((await self.client.get(path + "/report.csv")).text)))
            self.assertEqual(len(rows), 2)
            self.assertEqual(rows[0]["Provider message ID"], "provider-0")
            self.assertEqual(rows[1]["Attachment status"], "uncertain")
            self.assertEqual(rows[1]["Provider message ID"], "")
            self.assertTrue(all(row["Send status"] == "needs_review" for row in rows))
            self.assertNotIn("object_path", response.text)
        self.no_gateway.assert_not_called()
        self.no_database.assert_not_called()

    async def test_individual_owner_scope_and_contact_filter(self):
        path = "/api/contacts/catalogue-history"
        for suffix in ("/private", "/private/report.csv"):
            self.assertEqual((await self.client.get(path + suffix)).status_code, 404)
        result = (await self.client.get(path + "?contact_ref=deleted-contact")).json()
        self.assertEqual(result["total"], 45)
        self.assertEqual((await self.client.get(path + "?contact_ref=someone-else")).json()["total"], 0)
        self.actor = {"id": "other", "role": "super_admin", "active": True}
        self.assertEqual((await self.client.get(path)).json()["total"], 1)
        for suffix in ("/saved-00", "/saved-00/report.csv"):
            self.assertEqual((await self.client.get(path + suffix)).status_code, 404)

    async def test_view_export_permissions_and_bounded_inputs(self):
        self.actor = {"id": "admin", "role": "history_reader", "active": True}
        perms = {"crm": ["view"], "catalog": ["view"]}
        with patch.dict(auth.ROLE_DEFINITIONS, {"history_reader": {"permissions": perms}}):
            for base in ("/api/contacts/catalogue-history", "/api/catalog/daily-mr"):
                self.assertEqual((await self.client.get(base)).status_code, 200)
                self.assertEqual((await self.client.get(base + "/saved-00")).status_code, 200)
                for suffix in (".csv", "/saved-00/report.csv"):
                    self.assertEqual((await self.client.get(base + suffix)).status_code, 403)
                for query in ("?offset=-1", "?limit=0", "?limit=101", "?offset=x"):
                    self.assertEqual((await self.client.get(base + query)).status_code, 422)
            perms["crm"] += ["export"]
            self.assertEqual((await self.client.get("/api/contacts/catalogue-history.csv")).status_code, 403)
            perms["catalog"] += ["export"]
            self.assertEqual((await self.client.get("/api/contacts/catalogue-history.csv")).status_code, 200)
            perms["catalog"].remove("view")
            for path in ("/api/contacts/catalogue-history", "/api/contacts/catalogue-history/saved-00",
                         "/api/contacts/catalogue-history.csv", "/api/catalog/daily-mr/saved-00/report.csv"):
                self.assertEqual((await self.client.get(path)).status_code, 403)
