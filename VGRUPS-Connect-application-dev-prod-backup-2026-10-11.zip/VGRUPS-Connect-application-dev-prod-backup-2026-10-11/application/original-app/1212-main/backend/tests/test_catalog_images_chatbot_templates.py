"""Backend tests for iteration 6: Catalog Images + Chatbot Templates."""
import os
import pytest
import requests

BASE_URL = os.environ.get("REACT_APP_BACKEND_URL", "https://vgrups-connect.preview.emergentagent.com").rstrip("/")
ADMIN_EMAIL = "vgdisposables@gmail.com"
ADMIN_PASSWORD = "VgrupsConnect@2026"


@pytest.fixture(scope="module")
def token():
    r = requests.post(f"{BASE_URL}/api/auth/login", json={"email": ADMIN_EMAIL, "password": ADMIN_PASSWORD}, timeout=20)
    assert r.status_code == 200, f"login failed: {r.status_code} {r.text}"
    return r.json()["token"]


@pytest.fixture(scope="module")
def client(token):
    s = requests.Session()
    s.headers.update({"Authorization": f"Bearer {token}", "Content-Type": "application/json"})
    return s


# --- Catalog Images ---

def test_products_all_have_image(client):
    r = client.get(f"{BASE_URL}/api/products", timeout=20)
    assert r.status_code == 200
    data = r.json()
    items = data.get("items") if isinstance(data, dict) else data
    assert isinstance(items, list) and len(items) >= 15, f"got {len(items) if items else 0} products"
    missing = [p.get("code") for p in items if not p.get("image")]
    assert not missing, f"products without image: {missing}"
    # all image URLs should be http(s)
    for p in items:
        assert str(p["image"]).startswith("http"), f"bad image url for {p.get('code')}: {p.get('image')}"


def test_unsplash_images_reachable(client):
    """Spot-check a few product image URLs resolve (not a 404)."""
    r = client.get(f"{BASE_URL}/api/products", timeout=20)
    items = r.json().get("items") if isinstance(r.json(), dict) else r.json()
    by_code = {p["code"]: p["image"] for p in items}
    failures = []
    for code in ["VD3K2", "NG-100", "BP-01", "SM-50", "ECG-250"]:
        url = by_code.get(code)
        try:
            resp = requests.get(url, timeout=15, stream=True, allow_redirects=True)
            if resp.status_code >= 400:
                failures.append(f"{code} -> {url} => {resp.status_code}")
            resp.close()
        except Exception as e:
            failures.append(f"{code} -> {url} => {e}")
    assert not failures, "Unreachable images: " + "; ".join(failures)


# --- Chatbot Templates ---

def test_templates_list(client):
    r = client.get(f"{BASE_URL}/api/chatbot/templates", timeout=15)
    assert r.status_code == 200
    body = r.json()
    items = body.get("items") if isinstance(body, dict) else body
    assert isinstance(items, list) and len(items) == 3
    keys = {t["key"] for t in items}
    assert keys == {"lead_capture", "pricing_bot", "order_status"}
    for t in items:
        for f in ("key", "name", "description", "start", "nodes"):
            assert f in t, f"missing {f} in {t.get('key')}"
        assert isinstance(t["nodes"], list) and len(t["nodes"]) >= 2
        ids = {n["id"] for n in t["nodes"]}
        assert t["start"] in ids, f"start {t['start']} not in nodes for {t['key']}"
        # every next-link must resolve
        valid = ids | {None}
        for n in t["nodes"]:
            assert n.get("next") in valid, f"{t['key']} node {n['id']} next invalid"
            for o in n.get("options", []):
                assert o.get("next") in valid, f"{t['key']} option {o.get('label')} invalid"


def test_pricing_bot_shape(client):
    r = client.get(f"{BASE_URL}/api/chatbot/templates", timeout=15)
    items = r.json()["items"]
    pb = next(t for t in items if t["key"] == "pricing_bot")
    assert pb["start"] == "pw"
    assert len(pb["nodes"]) == 6


# --- Enable + reset flow ---

def test_enable_pricing_bot_then_reset(client):
    # fetch original flow (may be default or saved)
    orig = client.get(f"{BASE_URL}/api/chatbot/flow", timeout=15).json()

    # get pricing template
    items = client.get(f"{BASE_URL}/api/chatbot/templates", timeout=15).json()["items"]
    pb = next(t for t in items if t["key"] == "pricing_bot")

    payload = {"enabled": True, "start": pb["start"], "nodes": pb["nodes"]}
    r = client.put(f"{BASE_URL}/api/chatbot/flow", json=payload, timeout=15)
    assert r.status_code == 200, r.text

    cur = client.get(f"{BASE_URL}/api/chatbot/flow", timeout=15).json()
    assert cur["enabled"] is True
    assert cur["start"] == "pw"
    assert len(cur["nodes"]) == 6

    # Restore original (if orig had enabled key assume it is prior saved shape)
    restore = {"enabled": bool(orig.get("enabled", False)),
               "start": orig["start"], "nodes": orig["nodes"]}
    rr = client.put(f"{BASE_URL}/api/chatbot/flow", json=restore, timeout=15)
    assert rr.status_code == 200, rr.text
