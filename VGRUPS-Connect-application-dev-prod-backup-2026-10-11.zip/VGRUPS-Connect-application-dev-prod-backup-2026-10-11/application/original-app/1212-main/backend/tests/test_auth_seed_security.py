import asyncio
import sys
from types import ModuleType

import pytest
from fastapi import HTTPException
from starlette.requests import Request

import auth


@pytest.fixture
def clear_admin_environment(monkeypatch):
    for key in (
        "APP_ENV",
        "NODE_ENV",
        "ADMIN_EMAIL",
        "ADMIN_PASSWORD",
        "ADMIN_NAME",
        "PRODUCTION_ADMIN_EMAIL",
        "PRODUCTION_ADMIN_PASSWORD",
    ):
        monkeypatch.delenv(key, raising=False)


def test_development_seed_keeps_demo_admin_login(clear_admin_environment):
    assert auth.admin_seed_credentials() == (
        auth.DEVELOPMENT_ADMIN_EMAIL,
        auth.DEVELOPMENT_ADMIN_PASSWORD,
        "Admin",
    )


def test_development_seeded_admin_can_log_in(clear_admin_environment, monkeypatch):
    fake_db = type(
        "FakeDatabase",
        (),
        {
            "users": FakeCollection(),
            "login_attempts": FakeCollection(),
        },
    )()
    monkeypatch.setattr(auth, "db", fake_db)

    async def ignore_audit(*_args, **_kwargs):
        return None

    monkeypatch.setattr(auth, "log_audit", ignore_audit)
    monkeypatch.setenv("JWT_SECRET", "test-only-signing-secret")
    asyncio.run(auth.seed_admin())

    result = asyncio.run(
        auth.login(
            auth.LoginIn(
                email=auth.DEVELOPMENT_ADMIN_EMAIL,
                password=auth.DEVELOPMENT_ADMIN_PASSWORD,
            ),
            make_request(),
        )
    )
    assert result["user"]["email"] == auth.DEVELOPMENT_ADMIN_EMAIL
    assert result["user"]["role"] == "super_admin"


def test_production_seed_requires_configured_credentials(
    clear_admin_environment, monkeypatch
):
    monkeypatch.setenv("APP_ENV", "production")

    with pytest.raises(
        RuntimeError,
        match="PRODUCTION_ADMIN_EMAIL and PRODUCTION_ADMIN_PASSWORD",
    ):
        auth.admin_seed_credentials()


@pytest.mark.parametrize(
    "password",
    [
        "admin123",
        auth.DEVELOPMENT_ADMIN_PASSWORD,
        "short",
    ],
)
def test_production_seed_rejects_public_or_short_passwords(
    clear_admin_environment, monkeypatch, password
):
    monkeypatch.setenv("APP_ENV", "production")
    monkeypatch.setenv("PRODUCTION_ADMIN_EMAIL", "owner@example.com")
    monkeypatch.setenv("PRODUCTION_ADMIN_PASSWORD", password)

    with pytest.raises(RuntimeError, match="at least 16 characters"):
        auth.admin_seed_credentials()


class FakeCollection:
    def __init__(self, record=None):
        self.records = [record] if record else []

    async def find_one(self, query=None, *_args, **_kwargs):
        query = query or {}
        return next(
            (
                record
                for record in self.records
                if all(record.get(key) == value for key, value in query.items())
            ),
            None,
        )

    async def insert_one(self, record):
        self.records.append(record)
        return None

    async def update_one(self, *_args, **_kwargs):
        return None

    async def delete_one(self, *_args, **_kwargs):
        return None


@pytest.mark.parametrize("production", [False, True])
def test_unconfigured_otp_is_demo_only_in_development(
    clear_admin_environment, monkeypatch, production
):
    if production:
        monkeypatch.setenv("APP_ENV", "production")

    integrations = ModuleType("integrations")
    integrations.integration_status = lambda: {
        "whatsapp": {"configured": False},
        "sms": {"configured": False},
        "brevo": {"configured": False},
    }
    async def unused_send(*_args, **_kwargs):
        raise AssertionError("No provider should be used")

    integrations.send_whatsapp_otp = unused_send
    integrations.send_email_otp = unused_send
    wa_client = ModuleType("wa_client")

    async def not_connected():
        return False

    wa_client.wa_connected = not_connected
    wa_client.wa_send = unused_send
    monkeypatch.setitem(sys.modules, "integrations", integrations)
    monkeypatch.setitem(sys.modules, "wa_client", wa_client)

    fake_db = type(
        "FakeDatabase",
        (),
        {"otp_requests": FakeCollection()},
    )()
    monkeypatch.setattr(auth, "db", fake_db)

    async def ignore_audit(*_args, **_kwargs):
        return None

    monkeypatch.setattr(auth, "log_audit", ignore_audit)
    request_data = auth.SendOtpIn(
        identifier="owner@example.com",
        channel="email",
        purpose="login",
    )

    if production:
        with pytest.raises(HTTPException) as exc:
            asyncio.run(auth.send_otp(request_data, make_request()))
        assert exc.value.status_code == 503
        assert fake_db.otp_requests.records == []
    else:
        result = asyncio.run(auth.send_otp(request_data, make_request()))
        assert result["demo_mode"] is True
        assert len(result["demo_code"]) == 6


def make_request():
    return Request(
        {
            "type": "http",
            "asgi": {"version": "3.0"},
            "http_version": "1.1",
            "method": "POST",
            "scheme": "http",
            "path": "/api/auth/login",
            "raw_path": b"/api/auth/login",
            "query_string": b"",
            "headers": [(b"x-forwarded-for", b"127.0.0.1")],
            "client": ("127.0.0.1", 1234),
            "server": ("test", 80),
        }
    )


@pytest.mark.parametrize(
    ("email", "password"),
    [
        ("admin@example.com", "admin123"),
        (auth.DEVELOPMENT_ADMIN_EMAIL, auth.DEVELOPMENT_ADMIN_PASSWORD),
    ],
)
def test_production_login_rejects_public_defaults_even_if_account_exists(
    clear_admin_environment, monkeypatch, email, password
):
    monkeypatch.setenv("APP_ENV", "production")
    stored_user = {
        "id": "existing-demo-admin",
        "email": email,
        "password_hash": auth.hash_password(password),
        "role": "super_admin",
        "active": True,
    }
    fake_db = type(
        "FakeDatabase",
        (),
        {
            "users": FakeCollection(stored_user),
            "login_attempts": FakeCollection(),
        },
    )()
    monkeypatch.setattr(auth, "db", fake_db)

    async def ignore_audit(*_args, **_kwargs):
        return None

    monkeypatch.setattr(auth, "log_audit", ignore_audit)

    with pytest.raises(HTTPException) as exc:
        asyncio.run(
            auth.login(
                auth.LoginIn(email=email, password=password),
                make_request(),
            )
        )
    assert exc.value.status_code == 401