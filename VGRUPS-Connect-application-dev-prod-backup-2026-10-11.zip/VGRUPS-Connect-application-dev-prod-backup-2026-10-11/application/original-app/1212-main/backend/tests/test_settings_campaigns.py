"""Isolated management/scheduler tests: no live customers, files or database."""
import copy
import unittest
from contextlib import asynccontextmanager
from datetime import timedelta
from types import SimpleNamespace
from unittest.mock import AsyncMock, Mock, patch
import httpx
from fastapi import FastAPI
import auth
import routes_settings as settings
import routes_campaigns as campaigns
import campaign_groups as groups
import campaign_media as media
import routes_campaign_reports as reports
import routes_whatsapp as inbox
import inbox_scope
import whatsapp_routing as routing
from postgres_store import PostgresDatabase
original_process_drips = campaigns._process_drips
from db import utcnow


def matches(doc, query):
    for key, expected in query.items():
        value = doc.get(key)
        if isinstance(expected, dict):
            for op, operand in expected.items():
                if op == "$ne" and value == operand: return False
                if op == "$in" and value not in operand: return False
                if op == "$lte" and (value is None or value > operand): return False
        elif value != expected: return False
    return True


class Cursor:
    def __init__(self, values): self.values = copy.deepcopy(values)
    def sort(self, *_): return self
    def limit(self, n): self.values = self.values[:n]; return self
    async def to_list(self, n): return self.values[:n]
    def __aiter__(self):
        async def iterate():
            for value in self.values: yield value
        return iterate()


class Collection:
    def __init__(self, records=()): self.records = copy.deepcopy(list(records))
    def find(self, query=None, *_): return Cursor([d for d in self.records if matches(d, query or {})])
    async def find_one(self, query, *_): return next((copy.deepcopy(d) for d in self.records if matches(d, query)), None)
    async def count_documents(self, query): return sum(matches(d, query) for d in self.records)
    async def insert_one(self, record): self.records.append(copy.deepcopy(record))
    async def insert_many(self, records): self.records.extend(copy.deepcopy(records))
    async def delete_many(self, query):
        self.records[:] = [d for d in self.records if not matches(d, query)]

    async def update_one(self, query, update, upsert=False):
        record = next((d for d in self.records if matches(d, query)), None)
        inserted = record is None and upsert
        if inserted:
            record = {**query, **copy.deepcopy(update.get("$setOnInsert", {}))}
            self.records.append(record)
        if record is not None:
            for key, value in update.get("$set", {}).items():
                path = key.split(".")
                target = record
                for part in path[:-1]: target = target.setdefault(part, {})
                target[path[-1]] = copy.deepcopy(value)
            for key, value in update.get("$inc", {}).items():
                parent, _, leaf = key.partition(".")
                target = record.setdefault(parent, {}) if leaf else record
                target[leaf or key] = target.get(leaf or key, 0) + value
            for key, value in update.get("$push", {}).items(): record.setdefault(key, []).append(value)
        return SimpleNamespace(matched_count=int(record is not None and not inserted), upserted_id="new" if inserted else None)


@asynccontextmanager
async def fake_lock(*args): yield

async def fixture_report(database, cid, drip, page, page_size, search, delivery, sender=""):
    """HTTP/scheduler fixtures only; real SQL is tested in test_campaign_report_history."""
    records = (database.drip_enrollments if drip else database.campaign_recipients).records
    rows = []
    summary = dict.fromkeys(("total", "sent", "delivered", "read", "failed", "skipped", "uncertain", "pending"), 0)
    by_id = {m.get("wamid"): m for m in database.messages.records}
    for record in records:
        if record.get("drip_id" if drip else "campaign_id") != cid:
            continue
        ids = record.get("part_wamids") or ([record["wamid"]] if record.get("wamid") else [])
        state = record.get("status", "pending")
        if drip:
            ids = [m["wamid"] for m in database.messages.records
                   if m.get("drip_id") == cid and m.get("contact_id") == record.get("contact_id") and m.get("wamid")]
            state = "sent" if ids else {"active": "pending", "stopped": "skipped"}.get(state, state)
            if record.get("send_status") in ("sending", "uncertain"):
                state = "uncertain"
        parts = [{"wamid": wid, "status": by_id.get(wid, {}).get("status", "unknown")} for wid in ids]
        outcome = reports.delivery_for(parts, state)
        summary["total"] += 1
        summary["sent"] += state == "sent"
        summary["delivered"] += outcome in ("delivered", "read")
        summary["read"] += outcome == "read"
        summary["failed"] += outcome == "failed"
        summary["skipped"] += state == "skipped"
        summary["uncertain"] += state in ("sending", "uncertain")
        summary["pending"] += state == "pending"
        rows.append({"id": record["id"], "name": record.get("name"), "mobile": record.get("mobile"),
                     "status": state, "delivery": outcome, "replied": record.get("replied", False),
                     "sent_at": record.get("sent_at"), "error": record.get("error"),
                     "message_count": len(parts), "part_deliveries": parts, "sender_number": "Unknown"})
    selected = [r for r in rows if (not delivery or r["delivery"] == delivery)
                and (not sender or r["sender_number"] == sender)
                and (not search or search.lower() in f'{r["name"]} {r["mobile"]}'.lower())]
    return {"summary": summary, "sender_numbers": ["Unknown"] if rows else [],
            "recipients": selected[(page - 1) * page_size:page * page_size],
            "pagination": {"page": page, "page_size": page_size, "total": len(selected),
                           "pages": (len(selected) + page_size - 1) // page_size}}
class ManagementTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.actor = {"id": "owner", "name": "Mock administrator", "role": "super_admin", "active": True}
        self.db = SimpleNamespace(**{name: Collection() for name in (
            "users", "roles", "contacts", "campaign_groups", "campaign_media", "campaigns",
            "campaign_recipients", "messages", "conversations", "drips", "drip_enrollments",
            "wa_sessions", "app_config", "orders")})
        self.session = {"id": "linked", "name": "Mock", "phone": "15550002222",
                        "status": "connected", "created_at": None}
        self.live_sessions = {"connected": True, "sessions": [copy.deepcopy(self.session)]}
        self.db.wa_sessions.records.append(copy.deepcopy(self.session))
        self.db.app_config.records.append({"key": routing.CONFIG_KEY, "value": {
            "general_session_id": self.session["id"], "mr_session_id": self.session["id"]}})
        self.db.users.records.append(copy.deepcopy(self.actor))
        self.db.contacts.records.append({"id": "contact", "name": "Synthetic recipient",
            "mobile": "+15550001111", "is_demo": False, "deleted": False})
        # Block independently imported database bindings and real HTTP transports.
        # MockTransport (storage) and ASGITransport (the app) remain usable.
        self.no_database = AsyncMock(side_effect=AssertionError("Live database forbidden"))
        self.no_http = AsyncMock(side_effect=AssertionError("Live HTTP forbidden"))
        self.no_sync_http = Mock(side_effect=AssertionError("Live HTTP forbidden"))
        self.no_cloud_send = AsyncMock(side_effect=AssertionError("Cloud fallback forbidden"))
        self.patches = [
            patch.object(PostgresDatabase, "connect", self.no_database),
            patch.object(httpx.AsyncHTTPTransport, "handle_async_request", self.no_http),
            patch.object(httpx.HTTPTransport, "handle_request", self.no_sync_http),
            patch.object(inbox, "send_whatsapp_text", self.no_cloud_send)]
        self.patches += [patch.object(module, "db", self.db) for module in (
            auth, settings, campaigns, groups, media, reports, inbox, inbox_scope, campaigns.wa_usage)]
        self.patches += [patch.object(module, "log_audit", AsyncMock()) for module in (settings, campaigns, groups, inbox)]
        self.patches += [patch.object(reports, "fetch_report", fixture_report),
                         patch.object(reports, "export_rows", fixture_export)]
        self.patches += [patch.object(settings, "settings_lock", fake_lock),
            patch.object(campaigns, "campaign_lock", fake_lock),
            patch.object(campaigns.wa_client, "wa_list_sessions", AsyncMock(
                side_effect=lambda: copy.deepcopy(self.live_sessions))),
            patch.object(campaigns.wa_client, "wa_connected", AsyncMock(
                side_effect=lambda: self.live_sessions["connected"])),
            patch.object(campaigns.wa_client, "wa_send", AsyncMock(return_value={"wamid": "mock-text"})),
            patch.object(campaigns.wa_client, "wa_send_media", AsyncMock(return_value={"wamid": "mock-file"})),
            patch.object(campaigns.wa_usage, "daily_limit", return_value=100),
            patch.object(campaigns.wa_usage, "usage_today", AsyncMock(return_value=0)),
            patch.object(campaigns.wa_usage, "inc_usage", AsyncMock()),
            patch.object(campaigns, "_process_drips", AsyncMock()),
            patch.object(campaigns, "signed_url", AsyncMock(return_value="https://storage.googleapis.com/mock")),
            patch.object(campaigns.asyncio, "sleep", AsyncMock())]
        for p in self.patches:
            p.start()
            self.addCleanup(p.stop)
        auth.ROLE_DEFINITIONS.clear()
        app = FastAPI()
        for module in (settings, groups, media, campaigns, reports, inbox): app.include_router(module.router)
        app.dependency_overrides[auth.get_current_user] = lambda: self.actor
        self.client = httpx.AsyncClient(transport=httpx.ASGITransport(app), base_url="http://test")
        self.addAsyncCleanup(self.client.aclose)

    async def asyncTearDown(self):
        # Catch attempted side effects even if application code swallowed the error.
        self.no_database.assert_not_called()
        self.no_http.assert_not_called()
        self.no_sync_http.assert_not_called()
        self.no_cloud_send.assert_not_called()
        auth.ROLE_DEFINITIONS.clear()

    async def create_group(self):
        response = await self.client.post("/api/campaign-groups", json={"name": "Test group", "contact_ids": ["contact", "contact"]})
        self.assertEqual(response.status_code, 200, response.text)
        self.assertEqual(response.json()["contact_ids"], ["contact"])
        return response.json()["id"]

    async def test_users_roles_persist_and_protect_admins(self):
        role = {"key": "test_role", "label": "Test role", "permissions": {"dashboard": ["view"]}}
        self.assertEqual((await self.client.post("/api/roles", json=role)).status_code, 200)
        user = {"name": "Synthetic user", "email": "fixture@example.com", "password": "Test-only-pass-123", "role": "test_role", "active": True}
        response = await self.client.post("/api/users", json=user)
        self.assertEqual(response.status_code, 200, response.text)
        uid = response.json()["id"]
        self.assertNotIn("password_hash", response.json())
        original_hash = self.db.users.records[-1]["password_hash"]
        body = {k: v for k, v in user.items() if k != "password"}
        body["name"] = "Renamed fixture"
        self.assertEqual((await self.client.put(f"/api/users/{uid}", json=body)).status_code, 200)
        self.assertEqual(self.db.users.records[-1]["password_hash"], original_hash)
        self.assertEqual((await self.client.delete("/api/roles/test_role")).status_code, 409)
        self.assertEqual((await self.client.put("/api/roles/test_role", json={**role, "label": "Renamed role"})).status_code, 200)
        self.assertEqual((await self.client.delete(f"/api/users/{uid}")).status_code, 200)
        self.assertFalse(self.db.users.records[-1]["active"])
        self.assertEqual((await self.client.delete("/api/roles/test_role")).status_code, 200)
        self.assertEqual((await self.client.delete("/api/roles/admin")).status_code, 409)
        self.assertEqual((await self.client.delete("/api/users/owner")).status_code, 409)
        self.db.users.records.append({"id": "manager", "role": "test_manager", "active": True})
        self.actor["id"] = "manager"
        self.assertEqual((await self.client.delete("/api/users/owner")).status_code, 409)

    async def test_permissions_and_bad_role_grants(self):
        self.actor["role"] = "view_only"
        self.assertEqual((await self.client.post("/api/roles", json={
            "key": "test_role", "label": "Test", "permissions": {}})).status_code, 403)
        self.actor["role"] = "limited"
        auth.ROLE_DEFINITIONS["limited"] = {"permissions": {"settings": ["create"]}}
        self.assertEqual((await self.client.post("/api/roles", json={
            "key": "test_role", "label": "Test", "permissions": {"inbox": ["send"]}})).status_code, 403)

    async def test_disabled_users_cannot_continue_existing_sessions(self):
        from starlette.requests import Request
        from fastapi import HTTPException
        self.db.users.records[0]["active"] = False
        with patch.object(auth, "_secret", return_value="unit-test-placeholder"), patch.object(
                auth.jwt, "decode", return_value={"sub": "owner", "type": "access"}):
            with self.assertRaises(HTTPException) as failure:
                await auth.get_current_user(Request({"type": "http", "headers": [(b"authorization", b"Bearer mock")]}))
        self.assertEqual(failure.exception.status_code, 401)

    async def test_file_finalization_checks_owner_and_stored_file(self):
        self.db.campaign_media.records.append({"id": "upload", "owner_id": "owner", "state": "pending",
            "name": "test.pdf", "content_type": "application/pdf", "size": 5, "object_path": "/mock/object"})
        client_class = httpx.AsyncClient
        def storage_response(request):
            if request.method == "HEAD":
                return httpx.Response(200, headers={"content-type": "application/pdf", "content-length": "5"})
            self.assertEqual(request.headers.get("range"), "bytes=0-15")
            return httpx.Response(206, content=b"%PDF-")
        def storage_client(**kwargs):
            return client_class(transport=httpx.MockTransport(storage_response), **kwargs)
        with patch.object(media, "signed_url", AsyncMock(return_value="https://storage.googleapis.com/mock")), patch.object(
                media.httpx, "AsyncClient", storage_client):
            response = await self.client.post("/api/campaigns/media/upload/complete")
        self.assertEqual(response.status_code, 200, response.text)
        self.assertEqual(response.json()["state"], "ready")
        self.assertEqual(self.db.campaign_media.records[0]["state"], "ready")
        self.actor["id"] = "unrelated"
        self.assertEqual((await self.client.post("/api/campaigns/media/upload/complete")).status_code, 404)

    async def test_groups_schedule_and_automatic_send(self):
        gid = await self.create_group()
        future = (utcnow() + timedelta(days=1)).isoformat()
        payload = {"name": "Synthetic campaign", "message": "Hello {name}", "audience": {"type": "group", "group_id": gid}, "scheduled_at": future}
        response = await self.client.post("/api/campaigns", json=payload)
        self.assertEqual(response.status_code, 200, response.text)
        self.assertEqual(response.json()["status"], "scheduled")
        await campaigns._tick_unlocked()
        campaigns.wa_client.wa_send.assert_not_awaited()
        self.db.campaigns.records[0]["scheduled_at"] = (utcnow() - timedelta(minutes=1)).isoformat()
        await campaigns._tick_unlocked()
        campaigns.wa_client.wa_send.assert_awaited_once()
        self.assertEqual(campaigns.wa_client.wa_send.call_args.kwargs["session_id"], "linked")
        self.assertEqual(self.db.campaigns.records[0]["sender_session_id"], "linked")
        self.assertEqual(self.db.campaign_recipients.records[0]["status"], "sent")
        self.db.campaigns.records[0]["next_send_at"] = (utcnow() - timedelta(seconds=1)).isoformat()
        await campaigns._tick_unlocked()
        campaigns.wa_client.wa_send.assert_awaited_once()
        for date in ("bad", (utcnow() - timedelta(days=1)).isoformat(), "2030-01-01T10:00:00"):
            self.assertEqual((await self.client.post("/api/campaigns", json={**payload, "scheduled_at": date})).status_code, 422)
        self.assertEqual((await self.client.put(f"/api/campaign-groups/{gid}", json={"name": "Edited", "contact_ids": ["contact"]})).status_code, 200)
        self.assertEqual((await self.client.delete(f"/api/campaign-groups/{gid}")).status_code, 200)

    async def test_optout_and_uncertain_media_never_retry(self):
        gid = await self.create_group()
        for mid, mime in (("image", "image/png"), ("pdf", "application/pdf")):
            self.db.campaign_media.records.append({"id": mid, "state": "ready", "owner_id": "owner", "object_path": "/mock/file",
                "content_type": mime, "name": mid, "size": 20})
        response = await self.client.post("/api/campaigns", json={"name": "Files", "message": "Synthetic",
            "audience": {"type": "group", "group_id": gid}, "attachments": ["image", "pdf"], "send_now": True})
        self.assertEqual(response.status_code, 200, response.text)
        campaigns.wa_client.wa_send_media.side_effect = [{"wamid": "mock-image"}, TimeoutError("mock uncertain")]
        await campaigns._tick_unlocked()
        self.assertEqual(campaigns.wa_client.wa_send_media.await_count, 2)
        for call in campaigns.wa_client.wa_send_media.call_args_list:
            self.assertEqual(call.kwargs["session_id"], "linked")
        self.assertEqual(self.db.campaign_recipients.records[0]["status"], "uncertain")
        self.assertEqual(self.db.campaign_recipients.records[0]["part_wamids"], ["mock-image"])
        self.db.campaigns.records[0]["next_send_at"] = (utcnow() - timedelta(seconds=1)).isoformat()
        await campaigns._tick_unlocked()
        self.assertEqual(campaigns.wa_client.wa_send_media.await_count, 2)
        self.assertEqual(self.db.campaigns.records[0]["status"], "attention_required")
        campaigns.wa_client.wa_send.assert_not_awaited()
        self.db.contacts.records[0]["opted_out"] = True
        self.assertEqual((await self.client.post("/api/campaigns", json={
            "name": "Suppressed", "message": "test", "audience": {"type": "group", "group_id": gid}})).status_code, 422)
        self.assertEqual((await self.client.post("/api/campaigns/media/request-upload", json={
            "name": "bad.exe", "content_type": "application/octet-stream", "size": 10})).status_code, 422)

    async def test_campaign_edit_reschedule_gap_and_no_resend(self):
        gid = await self.create_group()
        body = {"name": "Editable", "message": "First", "audience": {"type": "group", "group_id": gid}}
        response = await self.client.post("/api/campaigns", json=body)
        self.assertEqual(response.status_code, 200, response.text)
        created = response.json()
        cid = created["id"]
        scheduled = {**body, "name": "Rescheduled", "message": "Preview body",
            "message_gap_seconds": 10, "scheduled_at": (utcnow() + timedelta(days=1)).isoformat()}
        edited = await self.client.put(f"/api/campaigns/{cid}", json=scheduled)
        self.assertEqual(edited.status_code, 200, edited.text)
        self.assertEqual(edited.json()["status"], "scheduled")
        self.assertEqual(edited.json()["message_gap_seconds"], 10)
        self.assertEqual(len(self.db.campaign_recipients.records), 1)
        await campaigns._tick_unlocked()
        campaigns.wa_client.wa_send.assert_not_awaited()
        self.assertEqual((await self.client.post(f"/api/campaigns/{cid}/resume")).status_code, 200)
        self.assertEqual(self.db.campaigns.records[0]["status"], "scheduled")
        self.db.campaigns.records[0]["scheduled_at"] = (utcnow() - timedelta(seconds=1)).isoformat()
        await campaigns._tick_unlocked()
        campaigns.asyncio.sleep.assert_awaited_with(10)
        self.assertEqual((await self.client.put(f"/api/campaigns/{cid}", json=body)).status_code, 409)
        for gap in (0, 301, -1):
            self.assertEqual((await self.client.post("/api/campaigns", json={**body, "message_gap_seconds": gap})).status_code, 422)
        self.assertEqual((await self.client.delete(f"/api/campaigns/{cid}")).status_code, 200)
        self.assertEqual(len(self.db.campaign_recipients.records), 1)
        self.assertEqual((await self.client.get("/api/campaigns")).json()["items"], [])

    async def test_delivery_reports_require_every_attachment_receipt(self):
        self.db.campaigns.records.append({"id": "report", "name": "Report", "status": "completed"})
        self.db.campaign_recipients.records.append({"id": "r", "campaign_id": "report", "name": "=formula",
            "mobile": "+15550001111", "status": "sent", "part_wamids": ["a", "b"]})
        self.db.messages.records.extend([{"wamid": "a", "status": "read"}, {"wamid": "b", "status": "sent"}])
        first = (await self.client.get("/api/campaigns/report/report")).json()
        self.assertEqual(first["summary"]["delivered"], 0)
        self.assertEqual(first["recipients"][0]["delivery"], "sent")
        self.db.messages.records[1]["status"] = "delivered"
        second = (await self.client.get("/api/campaigns/report/report")).json()
        self.assertEqual(second["summary"]["delivered"], 1)
        self.assertEqual(second["summary"]["read"], 0)
        self.db.campaign_recipients.records[0]["status"] = "uncertain"
        third = (await self.client.get("/api/campaigns/report/report")).json()
        self.assertEqual(third["summary"]["delivered"], 0)
        self.assertEqual(third["summary"]["uncertain"], 1)
        csv_response = await self.client.get("/api/campaigns/report/report.csv")
        self.assertEqual(csv_response.status_code, 200)
        self.assertIn("'=formula", csv_response.text)

    async def test_inbox_only_live_linked_number_and_no_dummy_messages(self):
        for cid, sid, demo in (("visible", "linked", False), ("foreign", "other", False),
                                ("demo", "linked", True), ("unscanned", None, False)):
            self.db.conversations.records.append({"id": cid, "session_id": sid, "is_demo": demo})
            self.db.messages.records.append({"id": cid, "conversation_id": cid, "session_id": sid, "is_demo": demo})
        self.db.messages.records.append({"id": "dummy-message", "conversation_id": "visible", "session_id": "linked", "is_demo": True})
        response = await self.client.get("/api/whatsapp/conversations")
        self.assertEqual(response.status_code, 200, response.text)
        self.assertEqual([c["id"] for c in response.json()["items"]], ["visible"])
        thread = await self.client.get("/api/whatsapp/conversations/visible/messages")
        self.assertEqual([m["id"] for m in thread.json()["messages"]], ["visible"])
        for cid in ("foreign", "demo", "unscanned"):
            self.assertEqual((await self.client.get(f"/api/whatsapp/conversations/{cid}/messages")).status_code, 404)
            self.assertEqual((await self.client.post(f"/api/whatsapp/conversations/{cid}/send", json={"body": "Must not send"})).status_code, 404)
            self.assertEqual((await self.client.post(f"/api/whatsapp/conversations/{cid}/flag?action=star")).status_code, 404)
        campaigns.wa_client.wa_send.assert_not_awaited()
        other = {**self.session, "id": "other", "phone": "15550003333"}
        self.db.wa_sessions.records.append(copy.deepcopy(other))
        self.live_sessions["sessions"].append(copy.deepcopy(other))
        selected = await self.client.get("/api/whatsapp/conversations", params={"session_id": "other"})
        self.assertEqual(selected.status_code, 200, selected.text)
        self.assertEqual([c["id"] for c in selected.json()["items"]], ["foreign"])
        selected_thread = await self.client.get("/api/whatsapp/conversations/foreign/messages",
                                                params={"session_id": "other"})
        self.assertEqual(selected_thread.status_code, 200, selected_thread.text)
        self.assertEqual([m["id"] for m in selected_thread.json()["messages"]], ["foreign"])
        for cid, selected_id in (("visible", "other"), ("foreign", "linked")):
            denied = await self.client.get(f"/api/whatsapp/conversations/{cid}/messages",
                                           params={"session_id": selected_id})
            self.assertEqual(denied.status_code, 404, denied.text)
        campaigns.wa_client.wa_send.assert_not_awaited()
        # A temporary outage preserves saved account history. Explicit logout
        # removes the implicit linked account; these are different states.
        self.live_sessions.update(sessions=[], connected=False)
        offline = (await self.client.get("/api/whatsapp/conversations")).json()
        self.assertEqual([c["id"] for c in offline["items"]], ["visible"])
        self.assertFalse(offline["connected"])
        offline_thread = await self.client.get("/api/whatsapp/conversations/visible/messages")
        self.assertEqual(offline_thread.status_code, 200, offline_thread.text)
        self.assertEqual([m["id"] for m in offline_thread.json()["messages"]], ["visible"])
        self.db.wa_sessions.records[0]["status"] = "logged_out"
        unlinked = (await self.client.get("/api/whatsapp/conversations")).json()
        self.assertEqual(unlinked["items"], [])
        self.assertEqual(unlinked["empty_reason"], "no_linked_number")

    async def test_drip_draft_edit_and_gap_report(self):
        body = {"name": "Sequence", "steps": [{"day": 0, "message": "First preview"}], "message_gap_seconds": 10}
        created = await self.client.post("/api/drips", json=body)
        self.assertEqual(created.status_code, 200, created.text)
        did = created.json()["id"]
        edited = await self.client.put(f"/api/drips/{did}", json={**body, "name": "Edited sequence"})
        self.assertEqual(edited.status_code, 200)
        self.assertEqual(edited.json()["message_gap_seconds"], 10)
        self.assertEqual((await self.client.get(f"/api/drips/{did}/report")).status_code, 200)
        self.db.drips.records[0]["status"] = "active"
        self.assertEqual((await self.client.put(f"/api/drips/{did}", json=body)).status_code, 409)

    async def test_drip_unknown_acceptance_never_resends(self):
        drip = {"id": "uncertain-drip", "name": "Synthetic", "status": "active", "created_by": "owner",
                "steps": [{"day": 0, "message": "Test"}], "message_gap_seconds": 10, "stats": {"active": 1}}
        self.db.drips.records.append(drip)
        self.db.drip_enrollments.records.append({"id": "enrollment", "drip_id": drip["id"], "contact_id": "contact",
            "name": "Fixture", "phone": "15550001111", "mobile": "+15550001111", "status": "active",
            "enrolled_at": (utcnow() - timedelta(days=1)).isoformat(),
            "next_due_at": (utcnow() - timedelta(days=1)).isoformat(), "next_step_index": 0})
        campaigns.wa_client.wa_send.side_effect = TimeoutError("mock only")
        await original_process_drips()
        self.assertEqual(self.db.drip_enrollments.records[0]["status"], "uncertain")
        await original_process_drips()
        campaigns.wa_client.wa_send.assert_awaited_once()
        self.assertEqual(campaigns.wa_client.wa_send.call_args.kwargs["session_id"], "linked")
        self.assertEqual(self.db.drips.records[0]["sender_session_id"], "linked")
        report = (await self.client.get(f"/api/drips/{drip['id']}/report")).json()
        self.assertEqual(report["summary"]["uncertain"], 1)


async def fixture_export(database, cid, drip, search, delivery, sender=""):
    report = await fixture_report(database, cid, drip, 1, 1000000, search, delivery, sender)
    for row in report["recipients"]:
        yield row


if __name__ == "__main__": unittest.main()
