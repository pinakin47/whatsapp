"""Isolated MR auto-replies: no real database, OpenAI, WhatsApp or telephone calls."""
import asyncio
import copy
import json
import os
import unittest
from datetime import datetime, timedelta, timezone
from unittest.mock import AsyncMock, patch

import httpx
import auth
import mr_ai_context
import mr_ai_replies as replies
from db import now_iso
from lead_capture_core import stable
from test_lead_capture import Collection, fake_database
import test_lead_capture as capture_fixture


class ReplyTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.db = fake_database()
        for name in ("mr_ai_replies", "mr_ivr_profiles", "contacts", "mr_daily_reports", "field_visits", "field_targets", "whatsapp_send_requests"):
            setattr(self.db, name, Collection())
        auth.ROLE_DEFINITIONS.clear()
        self.now = now_iso()
        self.mr = {"id": "dir", "email": "mr@example.test", "phone": "+919000000001", "name": "Fixture MR", "employee_id": "TEST", "active": True}
        self.db.mr_directory.records.append(self.mr)
        self.db.users.records += [{"id": "mr", "email": self.mr["email"], "role": "mr", "active": True},
                                  {"id": "admin", "role": "admin", "active": True}]
        self.db.app_config.records.append({"key": "mr_lead_capture", "value": {
            "enabled": True, "authorized_messages_confirmed": True, "ai_auto_reply": True,
            "ai_reply_enabled_since": "2020-01-01T00:00:00+00:00", "approved_by": "admin"}})
        self.conv = {"id": "conv", "phone": "919000000001", "session_id": "qr"}
        self.db.wa_sessions.records = [{"id": "qr", "phone": "15550000000", "status": "connected"}]
        self.msg = {"id": "source", "wamid": "source-provider", "conversation_id": "conv", "session_id": "qr",
                    "direction": "inbound", "type": "text", "body": "How do I complete my report?", "created_at": self.now}
        self.row = {"id": stable("mr-ai", "source-provider"), "message_id": "source", "conversation_id": "conv",
                    "session_id": "qr", "mr_id": "mr", "mr_directory_id": "dir", "mr_name": "Fixture MR",
                    "status": "pending", "created_at": self.now}
        self.db.conversations.records.append(self.conv)
        self.db.messages.records.append(self.msg)
        self.db.mr_ai_replies.records.append(copy.deepcopy(self.row))
        self.generator = AsyncMock(return_value="Reply CLOSING, then use the menu to enter and confirm your results.")
        self.sessions = patch.object(replies.wa_client, "wa_list_sessions", AsyncMock(return_value={
            "sessions": [{"id": "qr", "status": "connected"}]}))
        self.sessions.start()
        self.sender = patch.object(replies.wa_client, "wa_send", AsyncMock(return_value={"wamid": "accepted-provider"}))
        self.send = self.sender.start()

    async def asyncTearDown(self):
        self.sessions.stop()
        self.sender.stop()
        auth.ROLE_DEFINITIONS.clear()

    async def run_reply(self):
        await replies.process_reply(self.db, self.row, self.generator)
        return self.db.mr_ai_replies.records[0]

    async def test_reply_persists_in_inbox_and_does_not_mutate_reports(self):
        self.conv["mr_ivr"] = {"field": "completed_visits", "phase": "closing", "data": {"sales": 1500}}
        before = copy.deepcopy(self.conv["mr_ivr"])
        result = await self.run_reply()
        self.assertEqual(result["status"], "accepted")
        self.assertEqual(self.db.mr_daily_reports.records, [])
        self.assertEqual(self.conv["mr_ivr"], before)
        outbound = self.db.messages.records[1]
        self.assertEqual(outbound["sender"], "MR AI assistant")
        self.assertTrue(outbound["capture_skip"])
        self.assertEqual(outbound["status"], "sent")
        self.assertEqual(self.send.call_args.kwargs["session_id"], "qr")
        self.assertEqual(self.db.whatsapp_send_requests.records[0]["provider"], "qr")

    async def test_only_the_mrs_own_context_is_supplied(self):
        self.db.mr_daily_reports.records += [
            {"id": datetime.now(mr_ai_context.IST).date().isoformat() + ":dir", "summary": {"sales": 500}},
            {"id": datetime.now(mr_ai_context.IST).date().isoformat() + ":other", "summary": {"sales": 999999}}]
        self.db.field_visits.records += [
            {"mr_id": "mr", "planned_date": datetime.now(mr_ai_context.IST).date().isoformat(), "clinic_name": "Own Clinic"},
            {"mr_id": "other", "planned_date": datetime.now(mr_ai_context.IST).date().isoformat(), "clinic_name": "PRIVATE OTHER"}]
        await self.run_reply()
        serialized = json.dumps(self.generator.call_args.args[0])
        self.assertIn("Own Clinic", serialized)
        self.assertNotIn("PRIVATE OTHER", serialized)
        self.assertNotIn("999999", serialized)

    async def test_inactive_or_foreign_mr_customers_and_wrong_session_do_not_reply(self):
        for change in ("inactive", "customer", "session", "owner"):
            with self.subTest(change=change):
                saved = copy.deepcopy((self.mr, self.conv, self.row))
                if change == "inactive": self.mr["active"] = False
                if change == "customer": self.conv["phone"] = "919000000099"
                if change == "session": self.row["session_id"] = "other"
                if change == "owner": self.row["mr_id"] = "other"
                await replies.process_reply(self.db, self.row, self.generator)
                self.assertEqual(self.send.await_count, 0)
                self.mr.clear(); self.mr.update(saved[0])
                self.conv.clear(); self.conv.update(saved[1])
                self.row.clear(); self.row.update(saved[2])

    async def test_human_takeover_optout_and_permission_revocation_prevent_sends(self):
        for change in ("human", "optout", "permission", "profile", "off"):
            with self.subTest(change=change):
                self.conv["human_takeover"] = change == "human"
                self.conv["opted_out"] = change == "optout"
                self.db.mr_ivr_profiles.records = [{"id": "dir", "value": {"ivr_enabled": False}}] if change == "profile" else []
                self.db.app_config.records[0]["value"]["ai_auto_reply"] = change != "off"
                with patch.object(replies, "permissions_for", return_value={} if change == "permission" else {"settings": ["manage"], "whatsapp": ["send"]}):
                    await replies.process_reply(self.db, self.row, self.generator)
                self.assertEqual(self.send.await_count, 0)

    async def test_numeric_answers_remain_in_the_existing_report_flow(self):
        self.msg["body"] = "1500"
        self.conv["mr_ivr"] = {"field": "sales", "data": {}}
        await self.run_reply()
        self.generator.assert_not_awaited()
        self.send.assert_not_awaited()

    async def test_capture_finishes_before_reply_claims_a_lead_was_saved(self):
        self.db.mr_lead_queue.records.append({"id": "job", "message_id": "source", "status": "pending"})
        await self.run_reply()
        self.generator.assert_not_awaited()
        self.send.assert_not_awaited()
        self.assertEqual(self.db.mr_ai_replies.records[0]["status"], "pending")

    async def test_an_offline_original_session_never_falls_back_to_another_number(self):
        replies.wa_client.wa_list_sessions.return_value = {"sessions": [{"id": "other", "status": "connected"}]}
        result = await self.run_reply()
        self.assertEqual(result["status"], "blocked_not_connected")
        self.send.assert_not_awaited()

    async def test_newer_inbound_or_human_reply_cancels_a_draft(self):
        for direction in ("inbound", "outbound"):
            later = {**self.msg, "id": "later", "direction": direction, "sender": "Fixture Manager",
                     "created_at": (datetime.now(timezone.utc) + timedelta(seconds=1)).isoformat()}
            self.db.messages.records.append(later)
            await self.run_reply()
            self.send.assert_not_awaited()
            self.db.messages.records.pop()

    async def test_human_reply_during_generation_prevents_the_send(self):
        async def generate(_):
            self.conv["human_takeover"] = True
            return "Synthetic response"
        self.generator.side_effect = generate
        result = await self.run_reply()
        self.assertEqual(result["status"], "cancelled")
        self.send.assert_not_awaited()

    async def test_concurrent_workers_reserve_only_one_send(self):
        await asyncio.gather(self.run_reply(), self.run_reply())
        self.assertEqual(self.generator.await_count, 1)
        self.assertEqual(self.send.await_count, 1)
        self.assertEqual(len(self.db.whatsapp_send_requests.records), 1)

    async def test_uncertain_sends_and_openai_failures_are_not_automatically_resent(self):
        self.send.side_effect = httpx.ReadTimeout("Synthetic timeout")
        result = await self.run_reply()
        self.assertEqual(result["status"], "uncertain")
        with patch.dict(os.environ, {"OPENAI_API_KEY": "synthetic"}), patch.object(replies, "refresh_role_definitions", AsyncMock()):
            await replies.reply_tick(self.db, self.generator)
        self.assertEqual(self.send.await_count, 1)

    async def test_model_failure_and_expired_jobs_send_nothing(self):
        self.generator.side_effect = ValueError("Synthetic extraction failure")
        result = await self.run_reply()
        self.assertEqual(result["status"], "failed_ai")
        self.send.assert_not_awaited()
        self.row["created_at"] = (datetime.now(timezone.utc) - timedelta(minutes=11)).isoformat()
        result = await self.run_reply()
        self.assertEqual(result["status"], "expired")

    async def test_report_guidance_includes_a_truthful_submission_notice(self):
        facts = {"report_draft": {"field": "sales"}}
        response = httpx.Response(200, json={"choices": [{"message": {"content": json.dumps({
            "reply": "Please enter your actual sales value.", "topic": "report"})}}]})
        client = httpx.AsyncClient(transport=httpx.MockTransport(lambda _: response))
        with patch.dict(os.environ, {"OPENAI_API_KEY": "synthetic-personal"}, clear=True), \
                patch.object(mr_ai_context.httpx, "AsyncClient", return_value=client):
            body = await mr_ai_context.generate_reply(facts)
        self.assertIn("does not submit a report", body)

    async def test_ai_cannot_restart_an_active_draft_with_invented_navigation(self):
        facts = {"report_draft": {"phase": "closing", "field": "completed_visits",
                                 "last_actual_prompt": "How many visits did you complete today?"}}
        response = httpx.Response(200, json={"choices": [{"message": {"content": json.dumps({
            "reply": "Send CLOSING then reply 1 to restart the report.", "topic": "report"})}}]})
        client = httpx.AsyncClient(transport=httpx.MockTransport(lambda _: response))
        with patch.dict(os.environ, {"OPENAI_API_KEY": "synthetic-personal"}, clear=True), \
                patch.object(mr_ai_context.httpx, "AsyncClient", return_value=client):
            body = await mr_ai_context.generate_reply(facts)
        self.assertNotIn("Send CLOSING", body)
        self.assertIn("How many visits did you complete today?", body)
        self.assertIn("does not submit a report", body)


class SettingsTests(unittest.IsolatedAsyncioTestCase):
    """Reuse the isolated API fixture without duplicating its existing tests."""
    asyncSetUp = capture_fixture.CaptureTests.asyncSetUp
    asyncTearDown = capture_fixture.CaptureTests.asyncTearDown
    async def test_auto_reply_activation_requires_confirmation_and_a_personal_key(self):
        self.db.mr_ai_replies = Collection()
        body = {"enabled": True, "authorized_messages_confirmed": True, "ai_auto_reply": True}
        with patch.dict(os.environ, {"OPENAI_API_KEY": "synthetic"}):
            response = await self.client.put("/api/lead-capture/settings", json=body)
            self.assertEqual(response.status_code, 422)
            response = await self.client.put("/api/lead-capture/settings", json={**body, "confirm_enable": True})
            self.assertEqual(response.status_code, 200)
            self.assertTrue(response.json()["ai_auto_reply"])
            self.assertTrue(response.json()["ai_reply_enabled_since"])
        with patch.dict(os.environ, {}, clear=True):
            response = await self.client.put("/api/lead-capture/settings", json={**body, "confirm_enable": True})
            self.assertEqual(response.status_code, 422)

    async def test_mr_cannot_enable_replies_or_read_other_mrs_reply_activity(self):
        self.db.mr_ai_replies = Collection()
        self.db.mr_ai_replies.records.append({"id": "private", "mr_name": "Private Other", "reply": "Private data"})
        self.actor = {"id": "mr", "role": "mr", "active": True}
        response = await self.client.get("/api/lead-capture/settings")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["ai_reply_activity"], [])
        response = await self.client.put("/api/lead-capture/settings", json={"ai_auto_reply": True})
        self.assertEqual(response.status_code, 403)
