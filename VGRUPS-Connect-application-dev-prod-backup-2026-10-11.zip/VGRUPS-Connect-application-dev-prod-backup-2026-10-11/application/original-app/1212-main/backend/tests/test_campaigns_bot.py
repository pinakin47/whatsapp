"""Backend tests for Campaigns, Bot config, Consent, WA Health, RBAC."""
import os
import time
import uuid
import requests
import pytest

BASE_URL = os.environ.get("REACT_APP_BACKEND_URL", "https://vgrups-connect.preview.emergentagent.com").rstrip("/")
ADMIN_EMAIL = "vgdisposables@gmail.com"
ADMIN_PASS = "VgrupsConnect@2026"


@pytest.fixture(scope="module")
def admin_token():
    r = requests.post(f"{BASE_URL}/api/auth/login",
                      json={"email": ADMIN_EMAIL, "password": ADMIN_PASS}, timeout=15)
    assert r.status_code == 200, r.text
    return r.json()["token"]


@pytest.fixture(scope="module")
def admin_headers(admin_token):
    return {"Authorization": f"Bearer {admin_token}", "Content-Type": "application/json"}


# ---------------- Campaigns ----------------

@pytest.fixture
def cleanup_campaigns(admin_headers):
    created = []
    yield created
    for cid in created:
        try:
            requests.delete(f"{BASE_URL}/api/campaigns/{cid}", headers=admin_headers, timeout=10)
        except Exception:
            pass


def test_create_campaign_send_now_running_with_recipients(admin_headers, cleanup_campaigns):
    name = f"TEST_camp_now_{uuid.uuid4().hex[:6]}"
    r = requests.post(f"{BASE_URL}/api/campaigns", headers=admin_headers,
                      json={"name": name, "message": "Hello TEST",
                            "audience": {"type": "all"}, "send_now": True}, timeout=15)
    assert r.status_code == 200, r.text
    c = r.json()
    cleanup_campaigns.append(c["id"])
    assert c["status"] == "running"
    assert c["stats"]["total"] > 0, f"stats.total should be >0, got {c['stats']}"

    # GET returns campaign + recipients
    g = requests.get(f"{BASE_URL}/api/campaigns/{c['id']}", headers=admin_headers, timeout=10)
    assert g.status_code == 200
    data = g.json()
    assert data["campaign"]["id"] == c["id"]
    assert isinstance(data["recipients"], list)
    assert len(data["recipients"]) == c["stats"]["total"]
    # No opted-out contacts in recipients
    for rc in data["recipients"]:
        assert rc["status"] in ("pending", "sent", "skipped", "failed")


def test_create_campaign_scheduled_future(admin_headers, cleanup_campaigns):
    future = "2099-01-01T00:00:00+00:00"
    name = f"TEST_camp_sched_{uuid.uuid4().hex[:6]}"
    r = requests.post(f"{BASE_URL}/api/campaigns", headers=admin_headers,
                      json={"name": name, "message": "Hi",
                            "audience": {"type": "all"},
                            "scheduled_at": future, "send_now": False}, timeout=15)
    assert r.status_code == 200, r.text
    c = r.json()
    cleanup_campaigns.append(c["id"])
    assert c["status"] == "scheduled"
    assert c["stats"]["total"] > 0


def test_create_campaign_draft(admin_headers, cleanup_campaigns):
    name = f"TEST_camp_draft_{uuid.uuid4().hex[:6]}"
    r = requests.post(f"{BASE_URL}/api/campaigns", headers=admin_headers,
                      json={"name": name, "message": "Hi",
                            "audience": {"type": "all"}, "send_now": False}, timeout=15)
    assert r.status_code == 200, r.text
    c = r.json()
    cleanup_campaigns.append(c["id"])
    assert c["status"] == "draft"


def test_optout_suppression(admin_headers, cleanup_campaigns):
    # Create a TEST contact with opted_out=true via POST /api/contacts
    phone = f"+9199999{uuid.uuid4().hex[:5]}"
    cr = requests.post(f"{BASE_URL}/api/contacts", headers=admin_headers,
                       json={"name": "TEST_optout", "mobile": phone,
                             "contact_type": "lead"}, timeout=10)
    if cr.status_code not in (200, 201):
        pytest.skip(f"contact create failed: {cr.status_code} {cr.text}")
    contact = cr.json()
    cid = contact.get("id") or contact.get("_id")

    # Try to update opted_out
    up = requests.put(f"{BASE_URL}/api/contacts/{cid}", headers=admin_headers,
                     json={"opted_out": True}, timeout=10)
    opted_set = up.status_code in (200, 204)

    # Create campaign with send_now
    r = requests.post(f"{BASE_URL}/api/campaigns", headers=admin_headers,
                      json={"name": f"TEST_optout_{uuid.uuid4().hex[:6]}",
                            "message": "x", "audience": {"type": "all"},
                            "send_now": True}, timeout=15)
    assert r.status_code == 200
    camp = r.json()
    cleanup_campaigns.append(camp["id"])

    g = requests.get(f"{BASE_URL}/api/campaigns/{camp['id']}", headers=admin_headers, timeout=10)
    recips = g.json()["recipients"]
    phones = [rc.get("mobile") for rc in recips]
    if opted_set:
        assert phone not in phones, "opted-out contact must not be in recipients"

    # cleanup contact
    requests.delete(f"{BASE_URL}/api/contacts/{cid}", headers=admin_headers, timeout=10)


def test_audience_filter_contact_type(admin_headers, cleanup_campaigns):
    r = requests.post(f"{BASE_URL}/api/campaigns", headers=admin_headers,
                      json={"name": f"TEST_filter_{uuid.uuid4().hex[:6]}", "message": "x",
                            "audience": {"type": "filter", "contact_type": "lead"},
                            "send_now": True}, timeout=15)
    assert r.status_code == 200
    camp = r.json()
    cleanup_campaigns.append(camp["id"])
    # Should be >=0 (not failing); if there are leads, total>0
    assert "total" in camp["stats"]


def test_campaign_no_wa_connected_stays_running_zero_sent(admin_headers, cleanup_campaigns):
    r = requests.post(f"{BASE_URL}/api/campaigns", headers=admin_headers,
                      json={"name": f"TEST_nowa_{uuid.uuid4().hex[:6]}", "message": "x",
                            "audience": {"type": "all"}, "send_now": True}, timeout=15)
    assert r.status_code == 200
    camp = r.json()
    cleanup_campaigns.append(camp["id"])
    # Wait > 1 engine tick (6s)
    time.sleep(8)
    g = requests.get(f"{BASE_URL}/api/campaigns/{camp['id']}", headers=admin_headers, timeout=10)
    cur = g.json()["campaign"]
    assert cur["status"] == "running"
    assert cur["stats"]["sent"] == 0, f"nothing should be sent without WA; got {cur['stats']}"


def test_pause_resume_delete(admin_headers, cleanup_campaigns):
    r = requests.post(f"{BASE_URL}/api/campaigns", headers=admin_headers,
                      json={"name": f"TEST_pr_{uuid.uuid4().hex[:6]}", "message": "x",
                            "audience": {"type": "all"}, "send_now": True}, timeout=15)
    cid = r.json()["id"]

    p = requests.post(f"{BASE_URL}/api/campaigns/{cid}/pause", headers=admin_headers, timeout=10)
    assert p.status_code == 200
    g = requests.get(f"{BASE_URL}/api/campaigns/{cid}", headers=admin_headers, timeout=10)
    assert g.json()["campaign"]["status"] == "paused"

    rs = requests.post(f"{BASE_URL}/api/campaigns/{cid}/resume", headers=admin_headers, timeout=10)
    assert rs.status_code == 200
    g = requests.get(f"{BASE_URL}/api/campaigns/{cid}", headers=admin_headers, timeout=10)
    assert g.json()["campaign"]["status"] == "running"

    d = requests.delete(f"{BASE_URL}/api/campaigns/{cid}", headers=admin_headers, timeout=10)
    assert d.status_code == 200
    g = requests.get(f"{BASE_URL}/api/campaigns/{cid}", headers=admin_headers, timeout=10)
    assert g.status_code == 404


# ---------------- Number Health ----------------

def test_wa_health_empty_when_no_number(admin_headers):
    r = requests.get(f"{BASE_URL}/api/wa/health", headers=admin_headers, timeout=10)
    assert r.status_code == 200
    data = r.json()
    assert "numbers" in data
    assert isinstance(data["numbers"], list)
    # expected empty when no connected number
    assert data["numbers"] == []


# ---------------- Bot config ----------------

def test_bot_config_defaults_and_update(admin_headers):
    g = requests.get(f"{BASE_URL}/api/bot/config", headers=admin_headers, timeout=10)
    assert g.status_code == 200
    cfg = g.json()
    for k in ("enabled", "welcome", "askName", "askProduct", "askQuantity", "handoff"):
        assert k in cfg

    new = {
        "enabled": True, "welcome": "TEST_welcome", "askName": "TEST_askName",
        "askProduct": "TEST_askProduct", "askQuantity": "TEST_askQuantity",
        "handoff": "TEST_handoff",
    }
    u = requests.put(f"{BASE_URL}/api/bot/config", headers=admin_headers, json=new, timeout=10)
    assert u.status_code == 200, u.text
    g2 = requests.get(f"{BASE_URL}/api/bot/config", headers=admin_headers, timeout=10)
    cfg2 = g2.json()
    for k, v in new.items():
        assert cfg2[k] == v

    # Reset
    reset = dict(new, enabled=False)
    requests.put(f"{BASE_URL}/api/bot/config", headers=admin_headers, json=reset, timeout=10)


# ---------------- Consent ----------------

def test_consent_endpoint(admin_headers):
    r = requests.get(f"{BASE_URL}/api/consent", headers=admin_headers, timeout=10)
    assert r.status_code == 200
    data = r.json()
    assert "items" in data and isinstance(data["items"], list)
    assert "opted_out_total" in data and isinstance(data["opted_out_total"], int)


# ---------------- RBAC ----------------

def test_rbac_view_only_blocked_from_campaign_create(admin_headers):
    # Create a transient view_only user
    email = f"TEST_viewer_{uuid.uuid4().hex[:6]}@example.com"
    pw = "Test@12345"
    create = requests.post(f"{BASE_URL}/api/users", headers=admin_headers,
                           json={"email": email, "password": pw, "name": "TEST viewer",
                                 "role": "view_only"}, timeout=10)
    if create.status_code not in (200, 201):
        pytest.skip(f"user create failed: {create.status_code} {create.text}")

    # Login as that user
    login = requests.post(f"{BASE_URL}/api/auth/login",
                          json={"email": email, "password": pw}, timeout=15)
    if login.status_code != 200:
        pytest.skip(f"viewer login failed: {login.status_code}")
    v_tok = login.json()["token"]
    v_headers = {"Authorization": f"Bearer {v_tok}", "Content-Type": "application/json"}

    cr = requests.post(f"{BASE_URL}/api/campaigns", headers=v_headers,
                       json={"name": "TEST_rbac", "message": "x",
                             "audience": {"type": "all"}, "send_now": False}, timeout=10)
    assert cr.status_code in (401, 403), f"viewer should be blocked, got {cr.status_code}: {cr.text}"

    # Cleanup user
    uid = create.json().get("id")
    if uid:
        requests.delete(f"{BASE_URL}/api/users/{uid}", headers=admin_headers, timeout=10)
