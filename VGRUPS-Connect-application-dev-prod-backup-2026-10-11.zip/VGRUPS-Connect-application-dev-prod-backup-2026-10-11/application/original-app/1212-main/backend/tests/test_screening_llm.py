"""Offline screening contract checks; never send resumes or keys to a provider."""
import asyncio
import json
import os
import unittest
from unittest.mock import patch

import httpx

import ai_screening
import screening_llm


class ScreeningTests(unittest.TestCase):
    def request_with(self, handler):
        # Inject a mock transport rather than patching network response methods.
        real_client = httpx.AsyncClient
        return patch.object(
            screening_llm.httpx, "AsyncClient",
            side_effect=lambda **kwargs: real_client(
                transport=httpx.MockTransport(handler), **kwargs),
        )

    def test_emergent_proxy_contract_and_score_normalization(self):
        requests = []

        def handler(request):
            requests.append(request)
            self.assertEqual(str(request.url), "https://example.test/llm/chat/completions")
            self.assertEqual(request.headers["Authorization"], "Bearer sk-emergent-test")
            self.assertEqual(request.headers["X-App-ID"], "screening-test")
            payload = json.loads(request.content)
            self.assertEqual(payload["model"], "gemini/gemini-3-flash-preview")
            self.assertEqual(payload["messages"][0]["content"], ai_screening.SYSTEM)
            self.assertIn("offline resume", payload["messages"][1]["content"])
            return httpx.Response(200, json={"choices": [{"message": {"content":
                '```json\n{"score":110,"recommendation":"invalid","summary":"Good",'
                '"strengths":["one"],"concerns":[]}\n```'}}]})

        with self.request_with(handler), patch.object(ai_screening, "EMERGENT_LLM_KEY", "sk-emergent-test"), \
                patch.dict(os.environ, {"INTEGRATION_PROXY_URL": "https://example.test/",
                                        "APP_URL": "screening-test"}):
            result = asyncio.run(ai_screening.score_candidate(
                {"title": "MR"}, {"id": "offline", "answers": []}, "offline resume"))
        self.assertEqual(len(requests), 1)
        self.assertEqual(result["score"], 100)
        self.assertEqual(result["recommendation"], "strong_fit")
        self.assertTrue(result["used_resume"])

    def test_native_gemini_key_keeps_model_and_system_prompt(self):
        def handler(request):
            self.assertEqual(request.headers["x-goog-api-key"], "native-test-key")
            self.assertEqual(request.url.host, "generativelanguage.googleapis.com")
            self.assertTrue(request.url.path.endswith("/gemini-test:generateContent"))
            self.assertEqual(json.loads(request.content)["systemInstruction"]["parts"],
                             [{"text": "system"}])
            return httpx.Response(200, json={"candidates": [{"content": {
                "parts": [{"text": "first"}, {"text": " second"}]}}]})

        with self.request_with(handler):
            result = asyncio.run(screening_llm.screening_completion(
                "native-test-key", "gemini-test", "system", "prompt"))
        self.assertEqual(result, "first second")

    def test_missing_key_fails_before_network(self):
        with patch.object(screening_llm.httpx, "AsyncClient") as client:
            with self.assertRaisesRegex(RuntimeError, "EMERGENT_LLM_KEY"):
                asyncio.run(screening_llm.screening_completion(None, "model", "system", "prompt"))
            client.assert_not_called()

    def test_provider_errors_and_empty_content_are_not_hidden(self):
        for status, payload, error in [
            (401, {"error": "unauthorized"}, httpx.HTTPStatusError),
            (200, {"choices": [{"message": {"content": ""}}]}, ValueError),
        ]:
            with self.subTest(status=status), self.request_with(
                    lambda request: httpx.Response(status, json=payload)):
                with self.assertRaises(error):
                    asyncio.run(screening_llm.screening_completion(
                        "sk-emergent-test", "model", "system", "prompt"))
