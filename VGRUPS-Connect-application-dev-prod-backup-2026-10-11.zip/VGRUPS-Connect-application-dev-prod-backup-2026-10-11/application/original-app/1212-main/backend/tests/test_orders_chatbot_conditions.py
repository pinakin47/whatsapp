"""
Backend tests for new features in this session:
- /api/chatbot/flow (GET default + PUT validation)
- /api/quotations create + convert → /api/orders (Razorpay 503 + mark-paid)
- /api/automations with IF/ELSE condition action + /test
- /api/payments/config
"""
import os
import pytest
import requests

def _load_base():
    v = os.environ.get("REACT_APP_BACKEND_URL")
    if not v:
        try:
            with open("/app/frontend/.env") as f:
                for line in f:
                    if line.startswith("REACT_APP_BACKEND_URL="):
                        v = line.split("=", 1)[1].strip()
                        break
        except Exception:
            pass
    assert v, "REACT_APP_BACKEND_URL missing"
    return v.rstrip("/")


BASE = _load_base()
ADMIN = {"email": "vgdisposables@gmail.com", "password": "VgrupsConnect@2026"}


@pytest.fixture(scope="session")
def token():
    r = requests.post(f"{BASE}/api/auth/login", json=ADMIN, timeout=20)
    assert r.status_code == 200, r.text
    return r.json()["token"]


@pytest.fixture(scope="session")
def h(token):
    return {"Authorization": f"Bearer {token}"}


# ---------------- Chatbot ----------------
class TestChatbot:
    def test_get_default_flow(self, h):
        r = requests.get(f"{BASE}/api/chatbot/flow", headers=h, timeout=20)
        assert r.status_code == 200, r.text
        data = r.json()
        assert data["enabled"] is False
        assert len(data["nodes"]) == 8
        assert data["start"] == "welcome"

    def test_put_invalid_start_rejected(self, h):
        bad = {"enabled": False, "start": "ghost",
               "nodes": [{"id": "a", "type": "message", "text": "hi", "next": None, "options": []}]}
        r = requests.put(f"{BASE}/api/chatbot/flow", headers=h, json=bad, timeout=20)
        assert r.status_code == 422

    def test_put_menu_without_options_rejected(self, h):
        bad = {"enabled": False, "start": "m",
               "nodes": [{"id": "m", "type": "menu", "text": "pick", "next": None, "options": []}]}
        r = requests.put(f"{BASE}/api/chatbot/flow", headers=h, json=bad, timeout=20)
        assert r.status_code == 422

    def test_put_valid_flow_saves(self, h):
        good = {
            "enabled": False, "start": "w",
            "nodes": [
                {"id": "w", "type": "message", "text": "hi", "next": "m", "options": []},
                {"id": "m", "type": "menu", "text": "pick", "next": None,
                 "options": [{"label": "A", "next": None}, {"label": "B", "next": None}]},
            ],
        }
        r = requests.put(f"{BASE}/api/chatbot/flow", headers=h, json=good, timeout=20)
        assert r.status_code == 200, r.text
        got = requests.get(f"{BASE}/api/chatbot/flow", headers=h, timeout=20).json()
        assert got["start"] == "w"
        assert len(got["nodes"]) == 2
        # restore default-like (keep saved; non-destructive)


# ---------------- Orders + Payments ----------------
class TestOrders:
    @pytest.fixture(scope="class")
    def product_id(self, h):
        r = requests.get(f"{BASE}/api/products", headers=h, timeout=20)
        assert r.status_code == 200
        items = r.json().get("items", [])
        assert items, "No products seeded"
        return items[0]["id"]

    @pytest.fixture(scope="class")
    def quotation(self, h, product_id):
        payload = {"contact_name": "TEST_Buyer_OC", "mobile": "+919000000999",
                   "items": [{"product_id": product_id, "qty": 2}]}
        r = requests.post(f"{BASE}/api/quotations", headers=h, json=payload, timeout=20)
        assert r.status_code == 200, r.text
        q = r.json()
        assert q["total"] > 0
        assert q["quote_no"].startswith("QT")
        return q

    def test_quotation_persisted(self, h, quotation):
        r = requests.get(f"{BASE}/api/quotations/{quotation['id']}", headers=h, timeout=20)
        assert r.status_code == 200
        assert r.json()["contact_name"] == "TEST_Buyer_OC"

    def test_convert_quotation_to_order(self, h, quotation):
        r = requests.post(f"{BASE}/api/quotations/{quotation['id']}/convert", headers=h, timeout=20)
        assert r.status_code == 200, r.text
        o = r.json()
        assert o["order_no"].startswith("VG")
        assert o["payment_status"] == "pending"
        # stash
        pytest.converted_order = o

    def test_payment_link_returns_503_when_razorpay_unconfigured(self, h):
        o = pytest.converted_order
        r = requests.post(f"{BASE}/api/orders/{o['id']}/payment-link", headers=h, timeout=20)
        assert r.status_code == 503, r.text
        assert "Razorpay" in r.json().get("detail", "")

    def test_payments_config_reports_unconfigured(self, h):
        r = requests.get(f"{BASE}/api/payments/config", headers=h, timeout=20)
        assert r.status_code == 200
        assert r.json()["razorpay_configured"] is False

    def test_mark_paid_flips_status(self, h):
        o = pytest.converted_order
        r = requests.post(f"{BASE}/api/orders/{o['id']}/mark-paid", headers=h, timeout=20)
        assert r.status_code == 200
        assert r.json()["payment_status"] == "paid"
        g = requests.get(f"{BASE}/api/orders/{o['id']}", headers=h, timeout=20).json()
        assert g["payment_status"] == "paid"

    def test_mark_paid_second_time_rejected(self, h):
        o = pytest.converted_order
        r = requests.post(f"{BASE}/api/orders/{o['id']}/mark-paid", headers=h, timeout=20)
        assert r.status_code == 400

    def test_cleanup(self, h):
        o = pytest.converted_order
        # delete quotation (orders are kept — no delete endpoint, acceptable)
        qs = requests.get(f"{BASE}/api/quotations", headers=h, timeout=20).json()["items"]
        for q in qs:
            if q.get("contact_name") == "TEST_Buyer_OC":
                requests.delete(f"{BASE}/api/quotations/{q['id']}", headers=h, timeout=20)


# ---------------- Automations IF / ELSE ----------------
class TestAutomationCondition:
    def test_list_exposes_condition_metadata(self, h):
        r = requests.get(f"{BASE}/api/automations", headers=h, timeout=20)
        assert r.status_code == 200
        data = r.json()
        keys = [a["key"] for a in data["action_types"]]
        assert "condition" in keys
        assert isinstance(data["condition_fields"], list) and data["condition_fields"]
        assert isinstance(data["condition_ops"], list) and data["condition_ops"]

    def test_create_condition_automation_and_testrun(self, h):
        payload = {
            "name": "TEST_cond_auto",
            "trigger": "new_lead",
            "enabled": True,
            "actions": [{
                "type": "condition",
                "field": "contact_type", "op": "eq", "value": "distributor",
                "then": [{"type": "send_whatsapp", "message": "Hi distributor"}],
                "otherwise": [{"type": "add_tag", "tag": "retail"}],
            }],
        }
        r = requests.post(f"{BASE}/api/automations", headers=h, json=payload, timeout=20)
        assert r.status_code == 200, r.text
        aid = r.json()["id"]
        try:
            tr = requests.post(f"{BASE}/api/automations/{aid}/test", headers=h, timeout=20)
            assert tr.status_code == 200
            executed = tr.json().get("executed", [])
            assert isinstance(executed, list) and len(executed) > 0
        finally:
            requests.delete(f"{BASE}/api/automations/{aid}", headers=h, timeout=20)

    def test_invalid_nested_action_type_rejected(self, h):
        payload = {
            "name": "TEST_bad_cond",
            "trigger": "new_lead",
            "actions": [{"type": "condition", "field": "tag", "op": "eq", "value": "x",
                         "then": [{"type": "nonsense"}], "otherwise": []}],
        }
        r = requests.post(f"{BASE}/api/automations", headers=h, json=payload, timeout=20)
        assert r.status_code == 422
