"""Backend tests for Ads webhooks, recruitment candidate whatsapp, careers deep-link apply."""
import os
import pytest
import requests

BASE = os.environ.get("REACT_APP_BACKEND_URL", "https://vgrups-connect.preview.emergentagent.com").rstrip("/")
ADMIN = {"email": "vgdisposables@gmail.com", "password": "VgrupsConnect@2026"}

created_contacts = []
created_leads = []
created_candidates = []


@pytest.fixture(scope="module")
def token():
    r = requests.post(f"{BASE}/api/auth/login", json=ADMIN, timeout=20)
    assert r.status_code == 200, r.text
    return r.json()["token"]


@pytest.fixture(scope="module")
def h(token):
    return {"Authorization": f"Bearer {token}"}


# ---------------- Ads config ----------------
def test_ads_config_get(h):
    r = requests.get(f"{BASE}/api/ads/config", headers=h, timeout=15)
    assert r.status_code == 200
    j = r.json()
    assert "verify_token" in j and "enabled" in j


def test_ads_config_put(h):
    body = {"verify_token": "vgrups_verify", "enabled": True}
    r = requests.put(f"{BASE}/api/ads/config", headers=h, json=body, timeout=15)
    assert r.status_code == 200
    assert r.json()["verify_token"] == "vgrups_verify"


# ---------------- Meta verify (public) ----------------
def test_meta_verify_success():
    r = requests.get(f"{BASE}/api/webhooks/meta-leads",
                     params={"hub.mode": "subscribe", "hub.verify_token": "vgrups_verify", "hub.challenge": "CHAL123"},
                     timeout=15)
    assert r.status_code == 200
    assert r.text == "CHAL123"


def test_meta_verify_wrong_token():
    r = requests.get(f"{BASE}/api/webhooks/meta-leads",
                     params={"hub.mode": "subscribe", "hub.verify_token": "WRONG", "hub.challenge": "X"},
                     timeout=15)
    assert r.status_code == 403


# ---------------- Public webhooks create leads ----------------
def test_generic_webhook_creates_lead():
    body = {"name": "TEST_WH Lead", "phone": "+919000111222", "source": "google", "campaign": "TEST_WH"}
    r = requests.post(f"{BASE}/api/webhooks/lead", json=body, timeout=15)
    assert r.status_code == 200
    j = r.json()
    assert j["ok"] is True and j.get("lead_id")
    created_leads.append(j["lead_id"])


def test_meta_webhook_field_data_creates_lead():
    payload = {"entry": [{"changes": [{"value": {"ad_id": "AD_TEST", "field_data": [
        {"name": "full_name", "values": ["TEST_WH Meta"]},
        {"name": "phone_number", "values": ["+919000111333"]},
        {"name": "email", "values": ["meta@test.com"]}]}}]}]}
    r = requests.post(f"{BASE}/api/webhooks/meta-leads", json=payload, timeout=15)
    assert r.status_code == 200
    assert r.json()["created"] == 1


def test_ads_leads_aggregate(h):
    r = requests.get(f"{BASE}/api/ads/leads", headers=h, timeout=15)
    assert r.status_code == 200
    j = r.json()
    assert "items" in j and "counts" in j
    assert j["counts"]["total"] >= 1


def test_ads_test_lead(h):
    r = requests.post(f"{BASE}/api/ads/test-lead", headers=h, timeout=15)
    assert r.status_code == 200
    j = r.json()
    assert j["ok"] is True and j["lead"]["id"]
    created_leads.append(j["lead"]["id"])


# ---------------- Careers deep link + candidate whatsapp ----------------
def test_careers_apply_creates_candidate(h):
    # get an open position
    r = requests.get(f"{BASE}/api/careers/positions", timeout=15)
    assert r.status_code == 200
    j = r.json()
    positions = j.get("items") if isinstance(j, dict) else j
    assert positions and len(positions) > 0, "need an open position"
    pid = positions[0]["id"]
    body = {"name": "TEST_WH Candidate", "mobile": "+919000111444", "position_id": pid}
    r = requests.post(f"{BASE}/api/careers/apply", json=body, timeout=15)
    assert r.status_code in (200, 201), r.text
    # response doesn't return id; look up the candidate we just created
    r2 = requests.get(f"{BASE}/api/recruitment/candidates", headers=h, timeout=15)
    assert r2.status_code == 200
    j2 = r2.json()
    cands = j2.get("items") if isinstance(j2, dict) else j2
    cid = next((c["id"] for c in cands if c.get("mobile") == "+919000111444"), None)
    assert cid, "candidate was not created"
    created_candidates.append(cid)

    # candidate whatsapp
    r = requests.post(f"{BASE}/api/recruitment/candidates/{cid}/whatsapp",
                      headers=h, json={"message": "Hello from test"}, timeout=20)
    assert r.status_code == 200, r.text
    j = r.json()
    # either sent:true (connected) or wa_link
    assert j.get("sent") is True or j.get("wa_link")


# ---------------- Cleanup ----------------
def test_zz_cleanup(h):
    for lid in created_leads:
        requests.delete(f"{BASE}/api/leads/{lid}", headers=h, timeout=10)
    for cid in created_candidates:
        requests.delete(f"{BASE}/api/recruitment/candidates/{cid}", headers=h, timeout=10)
    # best-effort: delete test contacts by mobile
    for mob in ["+919000111222", "+919000111333", "+919000111444"]:
        try:
            r = requests.get(f"{BASE}/api/contacts", headers=h, params={"q": mob}, timeout=10)
            if r.status_code == 200:
                for c in (r.json() if isinstance(r.json(), list) else r.json().get("items", [])):
                    if c.get("mobile") == mob:
                        requests.delete(f"{BASE}/api/contacts/{c['id']}", headers=h, timeout=10)
        except Exception:
            pass
