"""Catalogue upload authorization, durable listing and signature verification, with fake storage."""
import os
import unittest
from unittest.mock import AsyncMock, patch
import httpx
from fastapi import FastAPI
import auth
import campaign_media as media
import routes_catalog_files as routes
from test_mr_catalog_defaults_inbox import database


class FileLibrary(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.db = database()
        self.actor = {"id": "admin", "role": "super_admin", "name": "Fixture admin"}
        app = FastAPI()
        app.include_router(routes.router)
        app.dependency_overrides[auth.get_current_user] = lambda: self.actor
        original_client = httpx.AsyncClient
        self.client = original_client(transport=httpx.ASGITransport(app=app), base_url="http://fixture")
        self.signature = b"\xff\xd8\xffabc"

        def storage_response(request):
            return httpx.Response(200, headers={"content-type": "image/jpeg", "content-length": "6"},
                content=b"" if request.method == "HEAD" else self.signature)
        transport = httpx.MockTransport(storage_response)
        self.bindings = [
            patch.object(routes, "db", self.db), patch.object(media, "db", self.db),
            patch.object(routes, "log_audit", AsyncMock()),
            patch.object(media, "signed_url", AsyncMock(return_value="https://storage.googleapis.com/fixture/file")),
            patch.dict(os.environ, {"PRIVATE_OBJECT_DIR": "/fixture/private"}),
            patch.object(media.httpx, "AsyncClient", lambda **kw: original_client(transport=transport, **kw)),
        ]
        for p in self.bindings: p.start()
        self.addCleanup(lambda: [p.stop() for p in reversed(self.bindings)])

    async def asyncTearDown(self):
        await self.client.aclose()

    async def upload_request(self):
        response = await self.client.post("/api/catalog/files/request-upload",
            json={"name": "../../catalog.jpg", "content_type": "image/jpeg", "size": 6})
        self.assertEqual(response.status_code, 200)
        return response.json()["media_id"]

    async def test_verified_upload_survives_reload_and_removal_preserves_history(self):
        mid = await self.upload_request()
        self.assertEqual((await self.client.get("/api/catalog/files")).json()["items"], [])
        complete = await self.client.post(f"/api/catalog/files/{mid}/complete")
        self.assertEqual(complete.status_code, 200)
        for _ in range(2):
            listed = (await self.client.get("/api/catalog/files")).json()["items"]
            self.assertEqual(listed[0]["id"], mid)
            self.assertEqual(listed[0]["name"], "catalog.jpg")
            self.assertNotIn("object_path", listed[0])
        self.assertEqual((await self.client.get(f"/api/catalog/files/{mid}/download-url")).status_code, 200)
        self.assertEqual((await self.client.delete(f"/api/catalog/files/{mid}")).status_code, 200)
        self.assertEqual((await self.client.get("/api/catalog/files")).json()["items"], [])
        self.assertEqual((await self.client.get(f"/api/catalog/files/{mid}/download-url")).status_code, 200)
        self.assertEqual(self.db.campaign_media.records[0]["state"], "archived")

    async def test_mislabeled_bytes_rejected_before_becoming_daily_content(self):
        mid = await self.upload_request()
        self.signature = b"notimg"
        self.assertEqual((await self.client.post(f"/api/catalog/files/{mid}/complete")).status_code, 422)
        self.assertEqual(self.db.campaign_media.records[0]["state"], "pending")

    async def test_png_oversized_and_unauthorized_uploads_rejected(self):
        for mime, size in (("image/png", 6), ("image/jpeg", 6 * 1024 * 1024)):
            response = await self.client.post("/api/catalog/files/request-upload",
                json={"name": "test.jpg", "content_type": mime, "size": size})
            self.assertEqual(response.status_code, 422)
        self.actor = {"id": "viewer", "role": "view_only", "name": "Fixture viewer"}
        self.assertEqual((await self.client.post("/api/catalog/files/request-upload",
            json={"name": "test.jpg", "content_type": "image/jpeg", "size": 6})).status_code, 403)
        self.assertEqual(self.db.campaign_media.records, [])

    async def test_campaign_and_other_owners_pending_files_are_not_catalogue(self):
        self.db.campaign_media.records = [{"id": "private", "purpose": "campaign", "state": "ready",
            "owner_id": "another", "object_path": "/fixture/private/patient-file"}]
        self.assertEqual((await self.client.get("/api/catalog/files/private/download-url")).status_code, 404)
        self.assertEqual((await self.client.post("/api/catalog/files/private/complete")).status_code, 404)
        self.assertEqual((await self.client.get("/api/catalog/files")).json()["items"], [])
