"""Entirely isolated; no real database, AI request, WhatsApp delivery or voice call."""
import asyncio
import copy
import json
import re
import unittest
from contextlib import ExitStack, asynccontextmanager
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch
import httpx
from fastapi import FastAPI
import auth
import db as database_module
import routes_crm as crm
import routes_lead_capture as routes
import lead_capture_core as core
import lead_capture_delivery as delivery
import lead_capture_worker as worker
from lead_capture_extract import mobile, validate_extraction
from postgres_query import apply_update


def matches(row, query):
    for field, wanted in query.items():
        if field == "$or":
            if not any(matches(row, q) for q in wanted): return False
            continue
        actual = row.get(field)
        if isinstance(wanted, dict):
            for op, value in wanted.items():
                if op == "$ne" and actual == value: return False
                if op == "$in" and actual not in value: return False
                if op == "$nin" and actual in value: return False
                if op == "$gte" and (actual is None or actual < value): return False
                if op == "$gt" and (actual is None or actual <= value): return False
                if op == "$lte" and (actual is None or actual > value): return False
                if op == "$lt" and (actual is None or actual >= value): return False
                if op == "$regex" and not re.search(value, str(actual or ""), re.I if wanted.get("$options") == "i" else 0): return False
        elif actual != wanted:
            return False
    return True


class Cursor:
    def __init__(self, rows): self.rows = copy.deepcopy(rows)
    def sort(self, name, direction=None):
        fields = name if isinstance(name, list) else [(name, direction)]
        for field, order in reversed(fields):
            self.rows.sort(key=lambda r: str(r.get(field) or ""), reverse=order == -1)
        return self
    def skip(self, count): self.rows = self.rows[count:]; return self
    async def to_list(self, limit): return self.rows if limit is None else self.rows[:limit]


class Collection:
    def __init__(self): self.records = []
    def find(self, query=None, *_): return Cursor([r for r in self.records if matches(r, query or {})])
    async def find_one(self, query, *_):
        return next((copy.deepcopy(r) for r in self.records if matches(r, query)), None)
    async def count_documents(self, query): return sum(matches(r, query) for r in self.records)
    async def insert_one(self, row): self.records.append(copy.deepcopy(row))
    async def update_one(self, query, update, upsert=False):
        index = next((i for i, r in enumerate(self.records) if matches(r, query)), None)
        inserted = index is None and upsert
        if index is None and not upsert:
            return SimpleNamespace(modified_count=0, matched_count=0, upserted_id=None)
        before = self.records[index] if index is not None else {k: v for k, v in query.items() if not k.startswith("$") and not isinstance(v, dict)}
        after = apply_update(copy.deepcopy(before), update, inserting=inserted)
        if inserted: self.records.append(after)
        else: self.records[index] = after
        return SimpleNamespace(modified_count=int(before != after), matched_count=int(not inserted), upserted_id=after.get("id") if inserted else None)
    async def update_many(self, query, update):
        for row in list(self.records):
            if matches(row, query): await self.update_one({"id": row["id"]}, update)


@asynccontextmanager
async def no_lock(*_): yield


def fake_database():
    database = SimpleNamespace(**{n: Collection() for n in ("users", "roles", "app_config", "mr_directory", "leads", "wa_sessions",
        "messages", "conversations", "mr_lead_queue", "mr_lead_activities", "mr_lead_events",
        "mr_lead_notifications", "mr_lead_requests", "mr_lead_counters", "whatsapp_send_requests")})
    database.wa_sessions.records = [{"id": "test-qr", "phone": "15550000000", "status": "connected"}]
    return database


class CaptureTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.db = fake_database()
        self.actor = {"id": "admin", "role": "admin", "name": "Fixture Admin", "active": True}
        self.mr = {"id": "dir", "name": "Fixture MR", "employee_id": "TEST001", "email": "mr@example.test", "phone": "+919000000001", "active": True}
        self.db.mr_directory.records.append(self.mr.copy())
        self.db.users.records += [self.actor.copy(), {"id": "super", "role": "super_admin", "active": True},
                                 {"id": "mr", "role": "mr", "email": self.mr["email"], "active": True}]
        self.db.app_config.records.append({"key": "mr_lead_capture", "value": {
            "enabled": True, "authorized_messages_confirmed": True, "ask_missing_phone": False,
            "voice_enabled": False, "enabled_since": "2020-01-01T00:00:00+00:00", "approved_by": "admin"}})
        self.conv = {"id": "conv", "phone": "919000000001", "session_id": "test-qr", "is_demo": False}
        self.db.conversations.records.append(self.conv.copy())
        self.stack = ExitStack()
        # Fail closed on any undiscovered global database binding.
        self.stack.enter_context(patch.object(database_module.db, "connect", AsyncMock(side_effect=AssertionError("LIVE DATABASE IO FORBIDDEN"))))
        for module in (routes, crm, auth):
            self.stack.enter_context(patch.object(module, "db", self.db))
        self.stack.enter_context(patch.object(routes, "capture_lock", no_lock))
        self.stack.enter_context(patch.object(worker, "capture_lock", no_lock))
        self.stack.enter_context(patch.object(worker, "refresh_role_definitions", AsyncMock()))
        self.stack.enter_context(patch.object(delivery, "refresh_role_definitions", AsyncMock()))
        self.stack.enter_context(patch.object(delivery, "opted_out", AsyncMock(return_value=False)))
        self.stack.enter_context(patch.object(routes, "voice_ready", AsyncMock(return_value=False)))
        self.stack.enter_context(patch.object(crm, "log_audit", AsyncMock()))
        self.stack.enter_context(patch.object(crm, "run_automations_safe", AsyncMock()))
        self.send = self.stack.enter_context(patch.object(delivery.wa_client, "wa_send", AsyncMock(return_value={"wamid": "fake-accepted"})))
        self.sessions = self.stack.enter_context(patch.object(delivery.wa_client, "wa_list_sessions", AsyncMock(return_value={"sessions": [{"id": "test-qr", "status": "connected"}]})))
        self.stack.enter_context(patch.object(delivery, "whatsapp_configured", return_value=False))
        self.voice = self.stack.enter_context(patch.object(delivery, "voice_proxy", AsyncMock(side_effect=AssertionError("LIVE VOICE FORBIDDEN"))))
        auth.ROLE_DEFINITIONS.clear()
        app = FastAPI()
        app.include_router(routes.router)
        app.include_router(crm.router)
        app.dependency_overrides[auth.get_current_user] = lambda: self.actor
        self.client = httpx.AsyncClient(transport=httpx.ASGITransport(app), base_url="http://fixture")

    async def asyncTearDown(self):
        await self.client.aclose()
        self.stack.close()
        auth.ROLE_DEFINITIONS.clear()

    async def job(self, text, key="one", direction="inbound", **extra):
        msg = {"id": key, "wamid": key, "conversation_id": "conv", "direction": direction,
               "type": "text", "body": text, "session_id": "test-qr", "sender": "MR Fixture",
               "created_at": "2026-10-06T04:00:00+00:00", **extra}
        self.db.messages.records.append(msg)
        await core.enqueue_message(self.db, msg)
        return await self.db.mr_lead_queue.find_one({"message_id": key})

    def extract(self, **extra):
        data = {"is_business": True, "confidence": .95, "hospital_name": "Fixture Hospital",
                "contact_name": "Fixture Doctor", "requirement": "gloves", "lead_type": "Hospital",
                "priority": "normal", "mobile": None, **extra}
        return AsyncMock(return_value=data)

    async def capture(self, **extra):
        job = await self.job("Met Fixture Doctor at Fixture Hospital. Needs gloves." + (" Customer phone " + extra["mobile"] if extra.get("mobile") else ""))
        result = await core.ingest(self.db, job, self.extract(**extra))
        return result, await self.db.leads.find_one({"id": result["lead_id"]})

    def test_phone_validation(self):
        for value in ("9876543210", "919876543210", "+91 98765 43210", "+91-98765-43210"):
            self.assertEqual(mobile(value), "+919876543210")
        for value in ("555", "1234567890", "+19876543210", "987654321000", "91abc9876543210"):
            self.assertIsNone(mobile(value))

    def test_ai_cannot_invent_customer_details_or_followup(self):
        value = validate_extraction({"is_business": True, "confidence": .9, "hospital_name": "Invented Hospital",
            "contact_name": "Invented Doctor", "quantity": "1000", "priority": "urgent", "next_followup_at": "2030-01-01"},
            "Fixture Hospital needs gloves")
        self.assertIsNone(value["hospital_name"])
        self.assertIsNone(value["contact_name"])
        self.assertIsNone(value["quantity"])
        self.assertIsNone(value["mobile"])
        self.assertIsNone(value["next_followup_at"])
        self.assertEqual(value["priority"], "normal")

    async def test_missing_phone_creates_lead_evidence_and_independent_alerts(self):
        _, lead = await self.capture()
        self.assertRegex(lead["display_id"], r"^WHL-\d{4}-0001$")
        self.assertEqual(lead["capture_status"], "Phone Number Required")
        self.assertIsNone(lead["mobile"])
        self.assertEqual({r["user_id"] for r in self.db.mr_lead_notifications.records}, {"admin", "super"})
        self.assertEqual({r["channel"] for r in self.db.mr_lead_requests.records}, {"whatsapp", "voice"})
        self.assertEqual(len(self.db.mr_lead_activities.records), 1)
        self.assertEqual(lead["assigned_to"], "mr")

    async def test_phone_reply_completes_correct_lead(self):
        _, lead = await self.capture()
        job = await self.job("LEAD " + lead["display_id"] + " 9876543210", "reply")
        result = await core.ingest(self.db, job, self.extract())
        row = await self.db.leads.find_one({"id": lead["id"]})
        self.assertEqual(result["status"], "completed")
        self.assertEqual(row["mobile"], "+919876543210")
        self.assertTrue(all(r["resolution"] == "completed" for r in self.db.mr_lead_requests.records))
        self.assertEqual(len(self.db.mr_lead_activities.records), 2)
        self.assertEqual(len(self.db.mr_lead_notifications.records), 4)

    async def test_natural_phone_reply_is_matched(self):
        _, lead = await self.capture()
        job = await self.job("His number is 98765 43210.", "natural")
        result = await core.ingest(self.db, job, self.extract())
        self.assertEqual(result["status"], "completed")
        self.assertEqual((await self.db.leads.find_one({"id": lead["id"]}))["mobile"], "+919876543210")

    async def test_quoted_phone_reply_selects_pending_lead_among_several(self):
        _, lead = await self.capture()
        self.db.leads.records.append({**lead, "id": "second", "display_id": "WHL-2026-0002"})
        request = next(r for r in self.db.mr_lead_requests.records if r["channel"] == "whatsapp")
        await self.db.mr_lead_requests.update_one({"id": request["id"]}, {"$set": {"provider_id": "quoted-prompt"}})
        job = await self.job("9876543210", "quoted", reply_to_wamid="quoted-prompt")
        result = await core.ingest(self.db, job, self.extract())
        self.assertEqual(result["lead_id"], lead["id"])
        self.assertIsNone((await self.db.leads.find_one({"id": "second"}))["mobile"])

    async def test_existing_manual_lead_retains_original_source_and_gains_capture_history(self):
        self.db.leads.records.append({"id": "existing", "source": "manual", "status": "qualified", "assigned_to": "mr",
            "mobile": "98765 43210", "title": "Existing customer", "company": "Fixture Hospital", "contact_name": "Fixture Doctor"})
        job = await self.job("Fixture Hospital needs gloves. 9876543210")
        result = await core.ingest(self.db, job, self.extract(mobile="+919876543210"))
        row = await self.db.leads.find_one({"id": "existing"})
        self.assertEqual(result["lead_id"], "existing")
        self.assertEqual(row["original_source"], "manual")
        self.assertEqual(row["source"], "WhatsApp – MR")
        self.assertEqual(row["status"], "qualified")
        self.assertEqual(len(self.db.leads.records), 1)

    async def test_repeated_message_does_not_duplicate_or_notify_twice(self):
        job = await self.job("Fixture Doctor at Fixture Hospital needs gloves")
        await core.ingest(self.db, job, self.extract(mobile="+919876543210"))
        await core.ingest(self.db, job, self.extract(mobile="+919876543210"))
        self.assertEqual(len(self.db.leads.records), 1)
        self.assertEqual(len(self.db.mr_lead_activities.records), 1)
        self.assertEqual(len(self.db.mr_lead_notifications.records), 2)

    async def test_cross_mr_duplicate_cannot_overwrite_existing_lead(self):
        self.db.leads.records.append({"id": "foreign", "assigned_to": "other", "mobile": "+919876543210",
                                     "company": "Fixture Hospital", "contact_name": "Fixture Doctor"})
        job = await self.job("Fixture Hospital needs gloves. 9876543210")
        result = await core.ingest(self.db, job, self.extract(mobile="+919876543210", requirement="different goods"))
        self.assertEqual(result["status"], "ownership_conflict")
        self.assertEqual(len(self.db.leads.records), 1)
        self.assertNotIn("requirement", self.db.leads.records[0])

    async def test_new_info_appended_without_overwriting_admin_facts(self):
        _, lead = await self.capture(mobile="+919876543210")
        job = await self.job("Fixture Hospital needs masks", "two")
        await core.ingest(self.db, job, self.extract(mobile="+919876543210", requirement="masks", quantity="200 boxes"))
        current = await self.db.leads.find_one({"id": lead["id"]})
        self.assertEqual(current["requirement"], "gloves")
        self.assertEqual(current["quantity"], "200 boxes")
        self.assertEqual(current["verification_status"], "Needs Verification")
        self.assertEqual(len(self.db.mr_lead_activities.records), 2)

    async def test_low_confidence_is_review_only(self):
        job = await self.job("Fixture Hospital needs gloves")
        result = await core.ingest(self.db, job, self.extract(confidence=.3))
        self.assertEqual(result["status"], "needs_verification")
        self.assertEqual(self.db.leads.records, [])

    async def test_medium_confidence_creates_verified_review_candidate(self):
        result, lead = await self.capture(confidence=.7)
        self.assertEqual(result["status"], "needs_verification")
        self.assertEqual(lead["verification_status"], "Needs Verification")

    async def test_ai_failure_retains_original(self):
        job = await self.job("Fixture Hospital needs gloves")
        result = await core.ingest(self.db, job, AsyncMock(side_effect=RuntimeError("synthetic outage")))
        self.assertEqual(result["status"], "ai_extraction_failed")
        self.assertEqual(self.db.messages.records[0]["body"], "Fixture Hospital needs gloves")

    async def test_unauthorized_peer_not_sent_to_ai(self):
        self.db.conversations.records[0]["phone"] = "919888888888"
        job = await self.job("Fixture Hospital needs gloves")
        extractor = self.extract()
        self.assertEqual((await core.ingest(self.db, job, extractor))["status"], "skipped")
        extractor.assert_not_awaited()

    async def test_known_customer_address_is_phone_evidence_not_mr_number(self):
        self.db.conversations.records[0].update(phone="919888888888", assigned_to="mr")
        job = await self.job("Fixture Hospital needs gloves")
        result = await core.ingest(self.db, job, self.extract())
        lead = await self.db.leads.find_one({"id": result["lead_id"]})
        self.assertEqual(lead["mobile"], "+919888888888")
        self.assertEqual(self.db.mr_lead_requests.records, [])

    async def test_closing_numeric_draft_is_not_stolen(self):
        _, lead = await self.capture()
        self.db.conversations.records[0]["mr_field_state"] = {"step": "closing_sales"}
        job = await self.job("9876543210", "reply")
        result = await core.ingest(self.db, job, self.extract())
        self.assertEqual(result["status"], "skipped")
        self.assertIsNone((await self.db.leads.find_one({"id": lead["id"]}))["mobile"])

    async def test_bare_phone_ambiguous_pending_leads_require_id(self):
        _, lead = await self.capture()
        self.db.leads.records.append({**lead, "id": "second", "display_id": "WHL-2026-0002"})
        job = await self.job("9876543210", "reply")
        result = await core.ingest(self.db, job, self.extract())
        self.assertEqual(result["status"], "needs_verification")
        self.assertTrue(all(not l["mobile"] for l in self.db.leads.records))

    async def test_mr_detail_and_legacy_routes_are_ownership_scoped(self):
        _, lead = await self.capture()
        self.db.leads.records.append({**lead, "id": "foreign", "assigned_to": "other"})
        self.actor = {"id": "mr", "role": "mr"}
        self.assertEqual((await self.client.get("/api/lead-capture/leads/foreign")).status_code, 404)
        self.assertEqual((await self.client.patch("/api/leads/foreign/status", json={"status": "won"})).status_code, 404)
        self.assertEqual((await self.client.put("/api/leads/foreign", json={"title": "overwrite"})).status_code, 404)
        response = await self.client.get("/api/leads?assigned_to=other")
        self.assertEqual(response.json()["total"], 1)
        self.assertEqual((await self.client.get("/api/lead-capture/leads")).json()["total"], 1)
        self.assertEqual((await self.client.patch("/api/lead-capture/leads/" + lead["id"], json={"assigned_to": "other"})).status_code, 403)
        self.assertEqual((await self.client.patch("/api/lead-capture/leads/" + lead["id"], json={"admin_remarks": "forge"})).status_code, 403)
        self.assertEqual((await self.client.delete("/api/lead-capture/leads/" + lead["id"])).status_code, 403)

    async def test_unapproved_roles_cannot_read_captured_leads(self):
        _, lead = await self.capture()
        self.actor = {"id": "marketing", "role": "marketing"}
        self.assertEqual((await self.client.get("/api/lead-capture/leads/" + lead["id"])).status_code, 403)
        self.assertEqual((await self.client.get("/api/leads")).json()["total"], 0)
        self.assertEqual((await self.client.patch("/api/leads/" + lead["id"] + "/status", json={"status": "won"})).status_code, 404)

    async def test_configuration_requires_consent_and_new_send_confirmation(self):
        self.db.app_config.records[0]["value"]["enabled"] = False
        self.assertEqual((await self.client.put("/api/lead-capture/settings", json={"enabled": True})).status_code, 422)
        self.assertEqual((await self.client.put("/api/lead-capture/settings", json={"enabled": True, "authorized_messages_confirmed": True})).status_code, 422)
        response = await self.client.put("/api/lead-capture/settings", json={
            "enabled": True, "authorized_messages_confirmed": True, "confirm_enable": True})
        self.assertEqual(response.status_code, 200)
        self.assertEqual((await self.client.put("/api/lead-capture/settings", json={
            "enabled": True, "authorized_messages_confirmed": True, "ask_missing_phone": True})).status_code, 422)

    async def test_csv_is_admin_only_and_formula_safe(self):
        _, lead = await self.capture(mobile="+919876543210", contact_name="=FORMULA()")
        response = await self.client.get("/api/lead-capture/export")
        self.assertEqual(response.status_code, 200)
        self.assertIn("'=FORMULA()", response.text)
        self.actor = {"id": "mr", "role": "mr"}
        self.assertEqual((await self.client.get("/api/lead-capture/export")).status_code, 403)

    async def test_manual_review_approval_requires_confirmation(self):
        job = await self.job("Fixture Hospital needs gloves")
        result = await core.ingest(self.db, job, self.extract(confidence=.3))
        await self.db.mr_lead_queue.update_one({"id": job["id"]}, {"$set": result})
        endpoint = "/api/lead-capture/review/" + job["id"] + "/approve"
        self.assertEqual((await self.client.post(endpoint, json={"hospital_name": "Fixture Hospital"})).status_code, 422)
        response = await self.client.post(endpoint, json={"hospital_name": "Fixture Hospital", "requirement": "gloves", "confirm_verified": True})
        self.assertEqual(response.status_code, 200, response.text)
        lead = await self.db.leads.find_one({"id": response.json()["lead_id"]})
        self.assertEqual(lead["verification_status"], "Admin verified")

    async def test_review_corrects_existing_candidate_without_creating_duplicate(self):
        result, lead = await self.capture(confidence=.7)
        job = await self.db.mr_lead_queue.find_one({"message_id": "one"})
        await self.db.mr_lead_queue.update_one({"id": job["id"]}, {"$set": result})
        response = await self.client.post("/api/lead-capture/review/" + job["id"] + "/approve", json={
            "hospital_name": "Corrected Hospital", "requirement": "Corrected requirement", "mobile": "9876543210", "confirm_verified": True})
        self.assertEqual(response.status_code, 200, response.text)
        row = await self.db.leads.find_one({"id": lead["id"]})
        self.assertEqual(len(self.db.leads.records), 1)
        self.assertEqual(row["hospital_name"], "Corrected Hospital")
        self.assertEqual(row["company"], "Corrected Hospital")
        self.assertEqual(row["requirement"], "Corrected requirement")
        self.assertEqual(row["mobile"], "+919876543210")

    async def test_later_full_report_with_phone_completes_requests_and_alerts(self):
        _, lead = await self.capture()
        job = await self.job("Fixture Doctor at Fixture Hospital needs gloves. Customer phone 9876543210", "full")
        await core.ingest(self.db, job, self.extract(mobile="+919876543210"))
        self.assertTrue(all(r["resolution"] == "completed" for r in self.db.mr_lead_requests.records))
        self.assertTrue(any(r["title"] == "PHONE NUMBER RECEIVED" for r in self.db.mr_lead_notifications.records))

    async def test_mr_own_number_in_report_is_not_assumed_to_be_customer(self):
        _, lead = await self.capture(mobile=self.mr["phone"])
        self.assertIsNone(lead["mobile"])

    async def test_clearing_completed_phone_starts_a_new_request_episode(self):
        _, lead = await self.capture()
        await self.client.patch("/api/lead-capture/leads/" + lead["id"], json={"mobile": "9876543210"})
        await self.client.patch("/api/lead-capture/leads/" + lead["id"], json={"mobile": ""})
        response = await self.client.post("/api/lead-capture/leads/" + lead["id"] + "/request-phone")
        self.assertEqual(response.status_code, 200, response.text)
        self.assertEqual(len(self.db.mr_lead_requests.records), 4)
        self.assertEqual(sum(r["resolution"] == "pending" for r in self.db.mr_lead_requests.records), 2)

    async def test_detail_history_can_reach_records_after_first_thousand(self):
        _, lead = await self.capture()
        self.db.mr_lead_activities.records = [{"id": str(i), "lead_id": lead["id"], "created_at": str(i).zfill(5)} for i in range(1002)]
        response = await self.client.get("/api/lead-capture/leads/" + lead["id"] + "?activity_page=21")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["activity_total"], 1002)
        self.assertEqual(len(response.json()["activities"]), 2)

    async def test_offline_assigned_qr_does_not_switch_to_cloud(self):
        await self.capture()
        self.db.messages.records[0]["created_at"] = "2020-01-01T00:00:00+00:00"
        self.db.app_config.records[0]["value"]["ask_missing_phone"] = True
        self.sessions.return_value = {"sessions": []}
        row = next(r for r in self.db.mr_lead_requests.records if r["channel"] == "whatsapp")
        with patch.object(delivery, "whatsapp_configured", return_value=True), patch.object(delivery, "send_whatsapp_text", AsyncMock(side_effect=AssertionError("LIVE CLOUD FORBIDDEN"))) as cloud:
            await delivery.deliver_request(self.db, row)
            cloud.assert_not_awaited()
        saved = await self.db.mr_lead_requests.find_one({"id": row["id"]})
        self.assertEqual(saved["status"], "pending")
        self.assertNotIn("attempted_at", saved)

    async def test_inbound_peer_identity_precedes_unrelated_assignment(self):
        self.db.users.records.append({"id": "other", "role": "mr", "email": "other@example.test", "active": True})
        self.db.mr_directory.records.insert(0, {"id": "other-dir", "name": "Other", "email": "other@example.test", "phone": "+919111111111", "active": True})
        self.db.conversations.records[0]["assigned_to"] = "other"
        result, lead = await self.capture()
        self.assertEqual(lead["assigned_to"], "mr")

    async def test_accepted_whatsapp_request_does_not_send_again(self):
        _, lead = await self.capture()
        self.db.app_config.records[0]["value"]["ask_missing_phone"] = True
        row = next(r for r in self.db.mr_lead_requests.records if r["channel"] == "whatsapp")
        await delivery.deliver_request(self.db, copy.deepcopy(row))
        await delivery.deliver_request(self.db, copy.deepcopy(row))
        self.assertEqual(self.send.await_count, 1)
        reservation = await self.db.whatsapp_send_requests.find_one({"id": row["id"]})
        self.assertEqual(reservation["provider"], "qr")
        self.assertEqual(reservation["recipient_address"], self.send.call_args.args[0])
        self.assertEqual(reservation["state"], "accepted")
        row = await self.db.mr_lead_requests.find_one({"id": row["id"]})
        self.assertEqual(row["status"], "accepted")
        self.assertEqual(row["provider_id"], "fake-accepted")

    async def test_uncertain_send_is_not_retried(self):
        await self.capture()
        self.db.app_config.records[0]["value"]["ask_missing_phone"] = True
        self.send.side_effect = httpx.ReadTimeout("synthetic timeout")
        row = next(r for r in self.db.mr_lead_requests.records if r["channel"] == "whatsapp")
        await delivery.deliver_request(self.db, copy.deepcopy(row))
        await delivery.deliver_request(self.db, copy.deepcopy(row))
        self.assertEqual(self.send.await_count, 1)
        row = await self.db.mr_lead_requests.find_one({"id": row["id"]})
        self.assertEqual(row["status"], "uncertain")

    async def test_offline_whatsapp_remains_pending_without_io(self):
        await self.capture()
        self.db.app_config.records[0]["value"]["ask_missing_phone"] = True
        self.sessions.return_value = {"sessions": []}
        row = next(r for r in self.db.mr_lead_requests.records if r["channel"] == "whatsapp")
        await delivery.deliver_request(self.db, row.copy())
        self.send.assert_not_awaited()
        row = await self.db.mr_lead_requests.find_one({"id": row["id"]})
        self.assertEqual(row["status"], "pending")

    async def test_missing_voice_provider_is_truthfully_blocked(self):
        await self.capture()
        self.db.app_config.records[0]["value"]["voice_enabled"] = True
        with patch.object(delivery, "voice_ready", AsyncMock(return_value=False)):
            row = next(r for r in self.db.mr_lead_requests.records if r["channel"] == "voice")
            await delivery.deliver_request(self.db, row.copy())
        self.voice.assert_not_awaited()
        row = await self.db.mr_lead_requests.find_one({"id": row["id"]})
        self.assertEqual(row["status"], "blocked_not_connected")

    async def test_disabled_capture_never_processes_or_sends(self):
        await self.job("Fixture Hospital needs gloves")
        self.db.app_config.records[0]["value"]["enabled"] = False
        extractor = self.extract()
        await worker.capture_tick(self.db, extractor)
        extractor.assert_not_awaited()
        self.send.assert_not_awaited()

    async def test_voice_callback_signature_and_call_id_are_required(self):
        self.assertEqual((await self.client.post("/api/lead-capture/voice/unknown", data={"Digits": "9876543210"})).status_code, 403)
        with patch.object(routes, "valid_voice_token", return_value=True):
            self.assertEqual((await self.client.post("/api/lead-capture/voice/unknown", data={"CallSid": "forged", "Digits": "9876543210"})).status_code, 403)

    async def test_lead_soft_delete_preserves_evidence(self):
        _, lead = await self.capture()
        self.assertEqual((await self.client.delete("/api/lead-capture/leads/" + lead["id"])).status_code, 200)
        self.assertEqual(len(self.db.mr_lead_activities.records), 1)
        self.assertEqual((await self.client.get("/api/lead-capture/leads")).json()["total"], 0)


if __name__ == "__main__":
    unittest.main()
