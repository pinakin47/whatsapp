"""VGRUPS CONNECT backend regression tests.

Run with:
    pytest /app/backend/tests/test_backend.py -v \
        --junitxml=/app/test_reports/pytest/pytest_results.xml
"""
import os
import time
import uuid
import pytest
import requests

BASE_URL = os.environ.get("REACT_APP_BACKEND_URL", "").rstrip("/")
if not BASE_URL:
    with open("/app/frontend/.env") as f:
        for line in f:
            if line.startswith("REACT_APP_BACKEND_URL"):
                BASE_URL = line.split("=", 1)[1].strip().strip('"').rstrip("/")
                break
assert BASE_URL, "REACT_APP_BACKEND_URL not configured"

ADMIN_EMAIL = "vgdisposables@gmail.com"
ADMIN_PASSWORD = "VgrupsConnect@2026"


# ------------------------------- Fixtures -------------------------------
@pytest.fixture(scope="session")
def api():
    s = requests.Session()
    s.headers.update({"Content-Type": "application/json"})
    return s


@pytest.fixture(scope="session")
def admin_token(api):
    r = api.post(f"{BASE_URL}/api/auth/login",
                 json={"email": ADMIN_EMAIL, "password": ADMIN_PASSWORD})
    assert r.status_code == 200, f"Admin login failed: {r.status_code} {r.text}"
    data = r.json()
    assert "token" in data and data["user"]["role"] == "super_admin"
    return data["token"]


@pytest.fixture(scope="session")
def admin(api, admin_token):
    s = requests.Session()
    s.headers.update({"Content-Type": "application/json",
                      "Authorization": f"Bearer {admin_token}"})
    return s


# ------------------------------- Auth -------------------------------
class TestAuth:
    def test_login_success(self, api):
        r = api.post(f"{BASE_URL}/api/auth/login",
                     json={"email": ADMIN_EMAIL, "password": ADMIN_PASSWORD})
        assert r.status_code == 200
        d = r.json()
        assert "token" in d and d["user"]["email"] == ADMIN_EMAIL
        assert "permissions" in d["user"]

    def test_login_invalid(self, api):
        r = api.post(f"{BASE_URL}/api/auth/login",
                     json={"email": ADMIN_EMAIL, "password": "wrong"},
                     headers={"X-Forwarded-For": f"10.0.0.{uuid.uuid4().int % 250}"})
        assert r.status_code == 401

    def test_me(self, admin):
        r = admin.get(f"{BASE_URL}/api/auth/me")
        assert r.status_code == 200
        assert r.json()["role"] == "super_admin"

    def test_brute_force_lockout(self, api):
        ip = f"10.9.{uuid.uuid4().int % 250}.{uuid.uuid4().int % 250}"
        headers = {"X-Forwarded-For": ip, "Content-Type": "application/json"}
        for _ in range(5):
            r = requests.post(f"{BASE_URL}/api/auth/login",
                              json={"email": "nobody@vgrups.in", "password": "bad"},
                              headers=headers)
            assert r.status_code == 401
        r = requests.post(f"{BASE_URL}/api/auth/login",
                          json={"email": "nobody@vgrups.in", "password": "bad"},
                          headers=headers)
        assert r.status_code == 429, f"Expected lockout got {r.status_code}"


# ------------------------------- OTP -------------------------------
class TestOTP:
    def test_send_and_verify_demo(self, api):
        ident = f"+9199{uuid.uuid4().int % 100000000:08d}"
        r = api.post(f"{BASE_URL}/api/auth/send-otp",
                     json={"identifier": ident, "channel": "whatsapp", "purpose": "login"})
        assert r.status_code == 200
        d = r.json()
        assert d["demo_mode"] is True and "demo_code" in d
        code = d["demo_code"]
        r2 = api.post(f"{BASE_URL}/api/auth/verify-otp",
                      json={"identifier": ident, "code": code, "purpose": "login"})
        assert r2.status_code == 200 and r2.json()["verified"] is True

    def test_verify_wrong_code(self, api):
        ident = f"+9198{uuid.uuid4().int % 100000000:08d}"
        api.post(f"{BASE_URL}/api/auth/send-otp",
                 json={"identifier": ident, "channel": "sms", "purpose": "login"})
        r = api.post(f"{BASE_URL}/api/auth/verify-otp",
                     json={"identifier": ident, "code": "000000", "purpose": "login"})
        assert r.status_code == 400


# ------------------------------- Dashboard -------------------------------
class TestDashboard:
    def test_stats(self, admin):
        r = admin.get(f"{BASE_URL}/api/dashboard/stats?rng=30days")
        assert r.status_code == 200
        d = r.json()
        for k in ["total_contacts", "new_leads", "open_conversations",
                  "orders", "revenue", "conversion_rate"]:
            assert k in d
        assert d["total_contacts"] >= 50

    def test_charts(self, admin):
        r = admin.get(f"{BASE_URL}/api/dashboard/charts?rng=30days")
        assert r.status_code == 200
        d = r.json()
        for k in ["lead_trend", "sales_trend", "conversation_trend",
                  "lead_source", "customer_type", "campaign_performance", "mr_performance"]:
            assert k in d and isinstance(d[k], list)


# ------------------------------- CRM / Contacts -------------------------------
class TestContacts:
    def test_list(self, admin):
        r = admin.get(f"{BASE_URL}/api/contacts")
        assert r.status_code == 200
        assert r.json()["total"] >= 50

    def test_create_get_delete(self, admin):
        name = f"TEST_Contact_{uuid.uuid4().hex[:6]}"
        payload = {"name": name, "mobile": "+919999900001", "contact_type": "lead"}
        r = admin.post(f"{BASE_URL}/api/contacts", json=payload)
        assert r.status_code == 200, r.text
        cid = r.json()["id"]
        g = admin.get(f"{BASE_URL}/api/contacts/{cid}")
        assert g.status_code == 200 and g.json()["name"] == name
        d = admin.delete(f"{BASE_URL}/api/contacts/{cid}")
        assert d.status_code == 200
        # soft-deleted → not in list
        lst = admin.get(f"{BASE_URL}/api/contacts").json()["items"]
        assert all(c["id"] != cid for c in lst)

    def test_search_and_filter(self, admin):
        r = admin.get(f"{BASE_URL}/api/contacts?contact_type=doctor")
        assert r.status_code == 200
        for c in r.json()["items"]:
            assert c["contact_type"] == "doctor"


# ------------------------------- Leads -------------------------------
class TestLeads:
    def test_board_grouped(self, admin):
        r = admin.get(f"{BASE_URL}/api/leads")
        assert r.status_code == 200
        d = r.json()
        assert "board" in d and "statuses" in d
        assert all(s in d["board"] for s in d["statuses"])

    def test_create_and_move(self, admin):
        payload = {"title": f"TEST_Lead_{uuid.uuid4().hex[:5]}", "status": "new",
                   "source": "manual", "value": 1000}
        r = admin.post(f"{BASE_URL}/api/leads", json=payload)
        assert r.status_code == 200
        lid = r.json()["id"]
        p = admin.patch(f"{BASE_URL}/api/leads/{lid}/status", json={"status": "qualified"})
        assert p.status_code == 200 and p.json()["status"] == "qualified"
        admin.delete(f"{BASE_URL}/api/leads/{lid}")


# ------------------------------- WhatsApp -------------------------------
class TestWhatsApp:
    def test_templates_list(self, admin):
        r = admin.get(f"{BASE_URL}/api/whatsapp/templates")
        assert r.status_code == 200
        assert isinstance(r.json()["items"], list)

    def test_create_template_draft(self, admin):
        payload = {"name": f"test_tpl_{uuid.uuid4().hex[:5]}", "category": "MARKETING",
                   "language": "en_US", "body": "Hello {{1}}", "variables": ["name"]}
        r = admin.post(f"{BASE_URL}/api/whatsapp/templates", json=payload)
        assert r.status_code == 200 and r.json()["status"] == "draft"
        tid = r.json()["id"]
        # submit should 503 since not configured
        s = admin.post(f"{BASE_URL}/api/whatsapp/templates/{tid}/submit")
        assert s.status_code == 503

    def test_conversations_list(self, admin):
        r = admin.get(f"{BASE_URL}/api/whatsapp/conversations?folder=all")
        assert r.status_code == 200
        items = r.json()["items"]
        assert isinstance(items, list)
        if items:
            cid = items[0]["id"]
            # fetch messages
            m = admin.get(f"{BASE_URL}/api/whatsapp/conversations/{cid}/messages")
            assert m.status_code == 200
            # Try sending => 503 not configured
            s = admin.post(f"{BASE_URL}/api/whatsapp/conversations/{cid}/send",
                           json={"body": "hi"})
            assert s.status_code == 503
            # star
            f = admin.post(f"{BASE_URL}/api/whatsapp/conversations/{cid}/flag?action=star")
            assert f.status_code == 200


# ------------------------------- Integrations -------------------------------
class TestIntegrations:
    def test_integrations_list(self, admin):
        r = admin.get(f"{BASE_URL}/api/integrations")
        assert r.status_code == 200
        d = r.json()
        for key in ["whatsapp", "brevo", "razorpay", "ai", "sms"]:
            assert key in d and d[key]["configured"] is False

    def test_integration_test(self, admin):
        r = admin.post(f"{BASE_URL}/api/integrations/whatsapp/test")
        assert r.status_code == 200
        assert r.json()["status"] == "not_configured"


# ------------------------------- Users / RBAC -------------------------------
class TestRBAC:
    def test_roles_matrix(self, admin):
        r = admin.get(f"{BASE_URL}/api/roles")
        assert r.status_code == 200
        d = r.json()
        role_keys = [x["key"] for x in d["roles"]]
        assert "super_admin" in role_keys and "view_only" in role_keys
        assert "contacts" in d["modules"]

    def test_create_user(self, admin):
        email = f"TEST_{uuid.uuid4().hex[:8]}@vgrups.in"
        r = admin.post(f"{BASE_URL}/api/users",
                       json={"name": "T", "email": email, "password": "Welcome@123",
                             "role": "view_only"})
        assert r.status_code == 200 and r.json()["email"] == email.lower()

    def test_view_only_cannot_create_contact(self, api):
        """Login as a seeded demo view_only or create one, then try to create contact."""
        # Try demo users to find a view_only or restricted role
        # Create a test view_only user via admin
        admin_resp = api.post(f"{BASE_URL}/api/auth/login",
                              json={"email": ADMIN_EMAIL, "password": ADMIN_PASSWORD})
        token = admin_resp.json()["token"]
        email = f"TEST_vo_{uuid.uuid4().hex[:6]}@vgrups.in"
        api.post(f"{BASE_URL}/api/users",
                 json={"name": "VO", "email": email, "password": "Welcome@123",
                       "role": "view_only"},
                 headers={"Authorization": f"Bearer {token}"})
        # login as view_only
        lr = api.post(f"{BASE_URL}/api/auth/login",
                      json={"email": email, "password": "Welcome@123"})
        assert lr.status_code == 200
        vt = lr.json()["token"]
        r = api.post(f"{BASE_URL}/api/contacts",
                     json={"name": "x", "mobile": "+91", "contact_type": "lead"},
                     headers={"Authorization": f"Bearer {vt}"})
        assert r.status_code == 403

    def test_marketing_can_create_contact(self, api):
        """Review spec says marketing role should be ALLOWED to create contacts.

        Contacts endpoint requires perm 'crm:create' but marketing's permission
        dict only lists 'contacts' not 'crm' — this surfaces the module naming bug.
        """
        admin_resp = api.post(f"{BASE_URL}/api/auth/login",
                              json={"email": ADMIN_EMAIL, "password": ADMIN_PASSWORD})
        token = admin_resp.json()["token"]
        email = f"TEST_mk_{uuid.uuid4().hex[:6]}@vgrups.in"
        api.post(f"{BASE_URL}/api/users",
                 json={"name": "MK", "email": email, "password": "Welcome@123",
                       "role": "marketing"},
                 headers={"Authorization": f"Bearer {token}"})
        lr = api.post(f"{BASE_URL}/api/auth/login",
                      json={"email": email, "password": "Welcome@123"})
        mt = lr.json()["token"]
        r = api.post(f"{BASE_URL}/api/contacts",
                     json={"name": "mkc", "mobile": "+919000000002", "contact_type": "lead"},
                     headers={"Authorization": f"Bearer {mt}"})
        assert r.status_code == 200, (
            f"Marketing expected to create contact per spec, got {r.status_code} {r.text}"
        )


# ------------------------------- Platform resources -------------------------------
class TestPlatform:
    def test_tasks(self, admin):
        r = admin.get(f"{BASE_URL}/api/tasks")
        assert r.status_code == 200
        items = r.json()["items"]
        assert isinstance(items, list)
        if items:
            tid = items[0]["id"]
            p = admin.patch(f"{BASE_URL}/api/tasks/{tid}?status=done")
            assert p.status_code == 200

    def test_products(self, admin):
        r = admin.get(f"{BASE_URL}/api/products")
        assert r.status_code == 200
        assert len(r.json()["items"]) >= 15

    def test_orders(self, admin):
        r = admin.get(f"{BASE_URL}/api/orders")
        assert r.status_code == 200
        assert len(r.json()["items"]) >= 15

    def test_campaigns(self, admin):
        r = admin.get(f"{BASE_URL}/api/campaigns")
        assert r.status_code == 200
        assert len(r.json()["items"]) >= 5

    def test_search(self, admin):
        r = admin.get(f"{BASE_URL}/api/search?q=a")
        assert r.status_code == 200
        d = r.json()
        for k in ["contacts", "leads", "products", "orders"]:
            assert k in d

    def test_audit_logs(self, admin):
        r = admin.get(f"{BASE_URL}/api/audit-logs")
        assert r.status_code == 200
        assert len(r.json()["items"]) > 0


# ------------------------------- WhatsApp webhook -------------------------------
class TestWebhook:
    def test_verify_webhook(self):
        token = "vgrups_verify_token"
        r = requests.get(f"{BASE_URL}/api/webhooks/whatsapp",
                         params={"hub.mode": "subscribe",
                                 "hub.challenge": "challenge123",
                                 "hub.verify_token": token})
        assert r.status_code == 200 and r.text == "challenge123"

    def test_verify_webhook_bad_token(self):
        r = requests.get(f"{BASE_URL}/api/webhooks/whatsapp",
                         params={"hub.mode": "subscribe",
                                 "hub.challenge": "x", "hub.verify_token": "wrong"})
        assert r.status_code == 403
