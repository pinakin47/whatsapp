"""No live DB access: verify the atomic cleanup's safety contract."""
import unittest
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock
from demo_cleanup import remove_all_demo_data


def fixture(admins):
    connection = SimpleNamespace(
        fetch=AsyncMock(side_effect=[admins, [{"collection_name": "products", "removed": 3}]]),
        execute=AsyncMock(),
    )
    transaction = MagicMock()
    transaction.__aenter__ = AsyncMock()
    transaction.__aexit__ = AsyncMock(return_value=False)
    connection.transaction = MagicMock(return_value=transaction)
    acquire = MagicMock()
    acquire.__aenter__ = AsyncMock(return_value=connection)
    acquire.__aexit__ = AsyncMock(return_value=False)
    database = SimpleNamespace(connect=AsyncMock(return_value=SimpleNamespace(
        acquire=MagicMock(return_value=acquire))))
    return database, connection, transaction


class AppDemoCleanup(unittest.IsolatedAsyncioTestCase):
    async def test_exact_marker_only_all_modules_credentials_protected(self):
        db, conn, transaction = fixture([{"document_id": "real-admin"}])
        self.assertEqual(await remove_all_demo_data(db), {"products": 3})
        sql = conn.execute.call_args.args[0]
        self.assertIn("document->'is_demo'='true'::jsonb", sql)
        self.assertIn("collection_name <> 'wa_auth'", sql)
        self.assertNotIn("email", sql)
        self.assertNotIn("name LIKE", sql)
        admin_sql = conn.fetch.call_args_list[0].args[0]
        self.assertIn("FOR UPDATE", admin_sql)
        self.assertIn("document->'deleted'", admin_sql)
        self.assertIn("document->'active'", admin_sql)
        transaction.__aenter__.assert_awaited_once()
        transaction.__aexit__.assert_awaited_once()

    async def test_no_real_active_admin_aborts_without_deleting_anything(self):
        db, conn, _ = fixture([])
        with self.assertRaisesRegex(RuntimeError, "real active administrator"):
            await remove_all_demo_data(db)
        conn.execute.assert_not_awaited()
