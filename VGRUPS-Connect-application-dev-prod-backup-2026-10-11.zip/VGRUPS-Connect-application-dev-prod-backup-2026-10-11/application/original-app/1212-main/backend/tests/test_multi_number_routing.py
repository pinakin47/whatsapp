"""No real providers, credentials, databases or production changes."""
import copy
import unittest
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch
from fastapi import HTTPException
from test_lead_capture import Collection
import whatsapp_routing as routing
import contact_catalogue as catalogue
import contact_directory as contacts
import inbox_scope
import routes_whatsapp
import routes_contact_actions as actions
import routes_campaigns as campaigns
from routes_campaigns import CampaignIn, DripIn


def fake_database():
    db = SimpleNamespace(**{n: Collection() for n in (
        "wa_sessions", "app_config", "users", "mr_directory", "contacts", "consent_records",
        "leads", "orders", "quotations", "candidates", "conversations", "messages", "products",
        "campaign_media", "contact_catalogue_runs", "contact_catalogue_parts", "whatsapp_send_requests")})

    async def page(specs, search, contact_type, offset, limit, key=None):
        rows = []
        for spec in specs:
            for source in await getattr(db, spec[0]).find(spec[5]).to_list(None):
                rows.extend(contacts.source_rows(source, spec))
        merged = contacts.merge_rows(rows)
        if key is not None:
            merged = [r for r in merged if (contacts.phone_key(r["mobile"]) or r["id"]) == key]
        return {"items": merged[offset:offset + limit], "total": len(merged)}

    async def source(collection, source_id, selector, projection):
        return await getattr(db, collection).find_one({**selector, "id": source_id}, projection)

    async def opted_out(phone):
        return any(r.get("opted_out") and phone in (contacts.phone_key(r.get("mobile")), contacts.phone_key(r.get("phone")))
                   for r in db.contacts.records)

    db.contact_directory_page = page
    db.contact_directory_source = source
    db.contact_phone_opted_out = opted_out
    return db


class MultipleNumbers(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.db = fake_database()
        self.admin = {"id": "actor", "name": "Fixture Actor", "role": "super_admin", "active": True}
        self.db.users.records = [self.admin.copy()]
        self.one = {"id": "mr-number", "name": "MR", "phone": "15551111111", "status": "connected"}
        self.two = {"id": "sales-number", "name": "Sales", "phone": "15552222222", "status": "connected"}
        self.live = {"sessions": [self.one.copy(), self.two.copy()], "connected": True}
        self.db.wa_sessions.records = copy.deepcopy(self.live["sessions"])
        self.db.app_config.records = [{"key": routing.CONFIG_KEY, "value": {
            "mr_session_id": self.one["id"], "general_session_id": self.two["id"]}}]
        self.db.contacts.records = [{"id": "person", "name": "Fixture Customer", "mobile": "+15553333333"}]
        self.db.mr_directory.records = [{"id": "staff", "name": "Fixture MR", "phone": "+15554444444"}]
        self.db.conversations.records = [
            {"id": "chat-one", "phone": "15553333333", "name": "Same Customer", "session_id": self.one["id"]},
            {"id": "chat-two", "phone": "15553333333", "name": "Other Alias", "session_id": self.two["id"]}]
        self.patch = patch.object(routing.wa_client, "wa_list_sessions", AsyncMock(side_effect=lambda: copy.deepcopy(self.live)))
        self.patch.start()
        self.addCleanup(self.patch.stop)

    async def test_roles_and_explicit_sender_are_independent(self):
        self.assertEqual((await routing.sender(self.db, purpose="mr"))["id"], self.one["id"])
        self.assertEqual((await routing.sender(self.db))["id"], self.two["id"])
        self.assertEqual((await routing.sender(self.db, self.one["id"]))["id"], self.one["id"])
        self.assertTrue(await routing.mr_session_allowed(self.db, self.one["id"]))
        self.assertFalse(await routing.mr_session_allowed(self.db, self.two["id"]))

    async def test_offline_mr_does_not_fall_back_to_sales(self):
        self.live["sessions"][0]["status"] = "disconnected"
        self.assertIsNone(await routing.sender_or_none(self.db, purpose="mr"))
        self.assertIsNone(await routing.sender_or_none(self.db, self.one["id"]))
        self.assertEqual((await routing.sender(self.db))["id"], self.two["id"])

    async def test_sole_sender_preserved_when_second_number_is_linked(self):
        self.db.app_config.records = []
        self.db.wa_sessions.records = [self.one.copy()]
        self.live["sessions"] = [self.one.copy()]
        self.assertEqual((await routing.sender(self.db))["id"], self.one["id"])
        self.db.wa_sessions.records.append(self.two.copy())
        self.live["sessions"].append(self.two.copy())
        self.assertEqual((await routing.sender(self.db, purpose="mr"))["id"], self.one["id"])

    async def test_two_unassigned_numbers_are_not_guessed(self):
        self.db.app_config.records = []
        with self.assertRaises(HTTPException):
            await routing.sender(self.db)

    async def test_unlinked_number_history_survives_without_exposing_other_threads(self):
        before = copy.deepcopy(self.db.conversations.records)
        self.db.wa_sessions.records[0].update(deleted=True, status="deleted")
        self.live["sessions"] = [self.two.copy()]
        saved = await routing.accounts(self.db, include_archived=True)
        self.assertEqual(len(saved), 2)
        chat, session = await inbox_scope.scoped_conversation("chat-one", self.db, self.one["id"])
        self.assertEqual(chat["id"], "chat-one")
        self.assertNotEqual(session["status"], "connected")
        with self.assertRaises(HTTPException):
            await inbox_scope.scoped_conversation("chat-one", self.db, self.two["id"])
        with self.assertRaises(HTTPException):
            await routing.sender(self.db, self.one["id"])
        self.assertEqual(self.db.conversations.records, before)

    async def test_directory_merges_both_histories_and_preserves_mr_and_crm(self):
        before = copy.deepcopy(self.db.contacts.records)
        rows = await contacts.directory(self.db, self.admin)
        customer = next(r for r in rows if r["id"] == "person")
        self.assertIn("Other Alias", customer["aliases"])
        self.assertIn("conversations:chat-two", customer["directory_refs"])
        self.assertTrue(any(r["id"] == "mr_directory:staff" for r in rows))
        self.assertEqual(self.db.contacts.records, before)

    async def test_virtual_contact_sends_on_chosen_number_and_rejects_changed_phone(self):
        with patch.object(actions, "db", self.db), patch.object(actions, "send_to_recipient", AsyncMock(return_value={"wamid": "fixture"})) as send:
            body = actions.MessageIn(body="Hello", expected_phone="+15554444444",
                                     request_key="fixture-key-12345678", session_id=self.two["id"])
            await actions.send_message("mr_directory:staff", body, self.admin)
            self.assertEqual(send.call_args.args[0].session_id, self.two["id"])
            self.assertEqual(send.call_args.args[0].phone, "+15554444444")
            body.expected_phone = "+15559999999"
            with self.assertRaises(HTTPException):
                await actions.send_message("mr_directory:staff", body, self.admin)
            self.assertEqual(send.await_count, 1)

    async def test_sender_is_part_of_recovery_identity(self):
        payload = dict(body="Hello", phone="+15553333333", request_key="fixture-key-12345678")
        a = routes_whatsapp.RecipientMessageIn(**payload, session_id=self.one["id"])
        b = routes_whatsapp.RecipientMessageIn(**payload, session_id=self.two["id"])
        self.assertNotEqual(routes_whatsapp._request_identity(a, self.admin)[1],
                            routes_whatsapp._request_identity(b, self.admin)[1])
        self.assertEqual(CampaignIn(name="Fixture", message="Hello", sender_session_id=self.two["id"]).sender_session_id, self.two["id"])
        self.assertEqual(DripIn(name="Fixture", sender_session_id=self.one["id"]).sender_session_id, self.one["id"])

    async def test_reply_on_other_number_does_not_stop_drip(self):
        self.db.messages.records = [{"conversation_id": "chat-one", "direction": "inbound", "created_at": "2026-10-07"}]
        enrollment = {"contact_id": "person", "phone": "15553333333", "enrolled_at": "2026-10-06"}
        with patch.object(campaigns, "db", self.db):
            self.assertIsNone(await campaigns._drip_should_stop(enrollment, self.two["id"]))
            self.assertEqual(await campaigns._drip_should_stop(enrollment, self.one["id"]), "replied")

    async def test_catalogue_job_pins_sender_and_does_not_retry_uncertain_parts(self):
        self.db.products.records = [{"id": "product", "name": "Fixture Product",
                                     "image": "https://images.unsplash.com/photo-fixture"}]
        job = await catalogue.enqueue(self.db, self.admin, "person", "fixture-key-12345678",
                                      "+15553333333", self.two["id"])
        replay = await catalogue.enqueue(self.db, self.admin, "person", "fixture-key-12345678",
                                         "+15553333333", self.two["id"])
        self.assertEqual(job["id"], replay["id"])
        self.assertEqual(len(self.db.contact_catalogue_runs.records), 1)
        with self.assertRaises(HTTPException):
            await catalogue.enqueue(self.db, self.admin, "person", "fixture-key-12345678",
                                    "+15553333333", self.one["id"])
        with patch.object(catalogue, "refresh_role_definitions", AsyncMock()), patch.object(catalogue.wa_client, "wa_send_media", AsyncMock(side_effect=TimeoutError())) as send:
            self.live["sessions"][1]["status"] = "disconnected"
            await catalogue.catalogue_tick(self.db)
            send.assert_not_awaited()
            self.live["sessions"][1]["status"] = "connected"
            await catalogue.catalogue_tick(self.db)
            self.assertEqual(send.call_args.kwargs["session_id"], self.two["id"])
            await catalogue.catalogue_tick(self.db)
            await catalogue.catalogue_tick(self.db)
            self.assertEqual(send.await_count, 1)
            self.assertEqual(self.db.contact_catalogue_runs.records[0]["status"], "needs_review")


if __name__ == "__main__":
    unittest.main()
