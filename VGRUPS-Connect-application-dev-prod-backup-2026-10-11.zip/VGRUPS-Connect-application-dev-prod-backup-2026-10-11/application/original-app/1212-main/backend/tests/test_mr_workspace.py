"""No real provider IO or customer records: isolated individual MR workspace tests."""
from contextlib import ExitStack
import asyncio
from datetime import datetime, timedelta
import json
from types import SimpleNamespace
from unittest.mock import AsyncMock, Mock, patch
import unittest
import httpx
from fastapi import FastAPI
import auth
import routes_campaigns as campaigns
import routes_mr_reporting as reporting
import routes_mr_workspace as workspace
import test_settings_campaigns
from test_settings_campaigns import Collection, fake_lock
from test_mr_reporting import matches
from test_campaign_report_history import ConnectionPool
from db import db as live_database
from postgres_store import PostgresDatabase
from mr_activity_query import activity_query


async def fixture_activity_candidates(database, collection, owner, start):
    """Mirror the bounded SQL selection without allowing real database IO."""
    lower = (start.date() - timedelta(days=2)).isoformat()
    upper = (start.date() + timedelta(days=2)).isoformat()
    return [r.copy() for r in getattr(database, collection).records
            if r.get("created_by") == owner and isinstance(r.get("created_at"), str)
            and lower <= r["created_at"] < upper
            and r.get("deleted") is not True and r.get("is_demo") is not True
            and (collection != "orders" or r.get("status") not in ("draft", "cancelled"))]


class SerialConnectionPool(ConnectionPool):
    """Concurrent activity reads share one isolated transaction connection."""
    def __init__(self, conn):
        super().__init__(conn)
        self.lock = asyncio.Lock()

    async def fetch(self, *args):
        async with self.lock:
            return await super().fetch(*args)


class WorkspaceTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.actor = {"id": "owner", "role": "super_admin", "active": True, "name": "Synthetic admin"}
        self.db = SimpleNamespace(**{n: Collection() for n in (
            "users", "roles", "mr_directory", "mr_ivr_profiles", "mr_daily_reports", "field_visits", "app_config", "wa_sessions",
            "field_targets", "orders", "quotations", "mr_push_notifications", "consent_records",
            "contacts", "messages", "conversations", "whatsapp_send_requests",
            "mr_field_days", "mr_leave_requests", "mr_manager_requests", "mr_field_entries")})
        self.db.users.records.append(self.actor.copy())
        self.db.mr_directory.records.append({"id": "mr", "name": "Synthetic MR", "employee_id": "MR001",
            "email": "mr@example.com", "phone": "+15550001111", "active": True})
        self.stack = ExitStack()
        for mod in (workspace, reporting, campaigns, auth):
            self.stack.enter_context(patch.object(mod, "db", self.db))
        self.stack.enter_context(patch.object(test_settings_campaigns, "matches", matches))
        self.stack.enter_context(patch.object(workspace, "log_audit", AsyncMock()))
        self.stack.enter_context(patch.object(workspace, "activity_candidates", fixture_activity_candidates))
        self.stack.enter_context(patch.object(workspace, "mr_lock", fake_lock))
        self.stack.enter_context(patch.object(workspace, "refresh_role_definitions", AsyncMock()))
        self.stack.enter_context(patch.object(workspace.asyncio, "sleep", AsyncMock()))
        self.send = self.stack.enter_context(patch.object(workspace.wa_client, "wa_send", AsyncMock(return_value={"wamid": "mock-id"})))
        self.sessions = self.stack.enter_context(patch.object(workspace.wa_client, "wa_list_sessions", AsyncMock(return_value={
            "sessions": [{"id": "mock-qr", "status": "connected"}]})))
        app = FastAPI()
        app.include_router(workspace.router)
        app.dependency_overrides[auth.get_current_user] = lambda: self.actor
        self.client = httpx.AsyncClient(transport=httpx.ASGITransport(app), base_url="http://mock")

    async def asyncTearDown(self):
        await self.client.aclose()
        self.stack.close()

    async def test_directory_batches_without_truncation_or_per_mr_reads(self):
        self.db.mr_directory.records[:] = [
            {"id": f"mr{i}", "name": f"MR {i:04d}", "email": f"MR{i}@example.com"}
            for i in range(2005)]
        self.db.users.records.extend([
            {"id": "linked", "email": "mr2004@example.com", "role": "mr", "active": True},
            {"id": "inactive", "email": "mr1@example.com", "role": "mr", "active": False},
            {"id": "demo", "email": "mr2@example.com", "role": "mr", "is_demo": True},
            {"id": "deleted", "email": "mr3@example.com", "role": "mr", "deleted": True},
            {"id": "admin", "email": "mr4@example.com", "role": "admin"},
        ])
        self.db.mr_directory.records.extend([
            {"id": "demo-dir", "is_demo": True}, {"id": "deleted-dir", "deleted": True}])
        self.db.mr_ivr_profiles.records.append({"id": "mr2004", "value": {"greeting": "Private greeting"}})
        self.db.mr_field_days.records.append({"id": "2026-10-05:mr2004", "status": "started"})
        trackers = {}
        for name in ("mr_directory", "users", "mr_ivr_profiles", "mr_field_days"):
            collection = getattr(self.db, name)
            trackers[name] = self.stack.enter_context(patch.object(collection, "find", Mock(wraps=collection.find)))
            self.stack.enter_context(patch.object(collection, "find_one", AsyncMock(
                side_effect=AssertionError("Directory loading must not read one MR at a time"))))
        with patch.object(workspace, "day_value", return_value="2026-10-05") as clock:
            items = (await workspace.list_mrs(self.actor))["items"]
        self.assertEqual(clock.call_count, 1)
        self.assertEqual(len(items), 2005)
        self.assertEqual(items[-1]["mr_id"], "linked")
        self.assertEqual(items[-1]["profile"]["greeting"], "Private greeting")
        self.assertEqual(items[-1]["field_day"]["status"], "started")
        self.assertEqual(items[0]["profile"], workspace.DEFAULT_PROFILE)
        self.assertIsNone(items[0]["field_day"])
        for i in range(1, 5):
            self.assertEqual(items[i]["mr_id"], f"directory:mr{i}")
        self.assertEqual(trackers["mr_directory"].call_count, 1)
        for name in ("users", "mr_ivr_profiles", "mr_field_days"):
            self.assertEqual(trackers[name].call_count, 9)
        for tracker in trackers.values():
            tracker.reset_mock()
        self.actor.update(role="mr", id="linked")
        items = (await workspace.list_mrs(self.actor))["items"]
        self.assertEqual([item["id"] for item in items], ["mr2004"])
        self.assertEqual(trackers["mr_ivr_profiles"].call_count, 1)
        self.assertEqual(trackers["mr_field_days"].call_count, 1)
        self.actor["id"] = "directory:mr0"
        self.assertEqual([item["id"] for item in (await workspace.list_mrs(self.actor))["items"]], ["mr0"])

    async def test_scope_activity_preview_and_profile_validation(self):
        self.db.field_visits.records.append({"id": "visit", "mr_id": "directory:mr", "planned_date": "2026-10-05",
            "doctor_name": "Doctor", "city": "City", "status": "planned"})
        r = await self.client.get("/api/mr-ivr/mrs/mr?date=2026-10-05")
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.json()["next_destination"]["city"], "City")
        self.assertFalse(r.json()["profile"]["enabled"])
        self.assertIsNone(r.json()["summary"]["achievement_pct"])
        self.assertIn("Doctor", (await self.client.get("/api/mr-ivr/mrs/mr/preview?date=2026-10-05&kind=push")).json()["message"])
        for body in ({"enabled": True}, {"encouragement_template": "{name.__class__}"}, {"days": [8]}, {"push_time": "11:00"}):
            self.assertEqual((await self.client.put("/api/mr-ivr/mrs/mr/profile", json=body)).status_code, 422)
        self.actor["role"] = "mr"
        self.assertEqual((await self.client.get("/api/mr-ivr/mrs/mr")).status_code, 403)
        self.assertEqual((await self.client.get("/api/mr-ivr/mrs")).json()["items"], [])

    async def test_manual_confirmation_idempotency_uncertainty_and_inbox(self):
        body = {"message": "Keep progressing", "request_id": "fixture-request-1234"}
        self.assertEqual((await self.client.post("/api/mr-ivr/mrs/mr/messages", json=body)).status_code, 422)
        body["confirm_send"] = True
        for _ in range(2):
            r = await self.client.post("/api/mr-ivr/mrs/mr/messages", json=body)
            self.assertEqual(r.json()["status"], "sent")
        self.assertEqual(self.send.await_count, 1)
        self.assertEqual(len(self.db.messages.records), 1)
        reservation = self.db.whatsapp_send_requests.records[0]
        self.assertEqual(reservation["state"], "accepted")
        self.assertEqual(reservation["message_body"], body["message"])
        self.assertEqual(len(reservation["id"]), 64)
        self.assertEqual((await self.client.post("/api/mr-ivr/mrs/mr/messages", json={**body, "message": "Changed"})).status_code, 409)
        self.send.side_effect = RuntimeError("Synthetic ambiguous timeout")
        body["request_id"] = "fixture-request-5678"
        for _ in range(2):
            self.assertEqual((await self.client.post("/api/mr-ivr/mrs/mr/messages", json=body)).json()["status"], "uncertain")
        self.assertEqual(self.send.await_count, 2)

    async def test_schedule_off_optin_weekday_once_reset_and_consent(self):
        day = datetime(2026, 10, 5, 11, tzinfo=workspace.IST)
        await workspace.coaching_tick(day)
        self.send.assert_not_awaited()
        body = {**workspace.DEFAULT_PROFILE, "enabled": True, "opt_in": True, "confirm_enable": True}
        r = await self.client.put("/api/mr-ivr/mrs/mr/profile", json=body)
        self.assertEqual(r.status_code, 200, r.text)
        await workspace.coaching_tick(day.replace(hour=10))
        self.send.assert_not_awaited()
        await workspace.coaching_tick(day)
        await workspace.coaching_tick(day)
        self.assertEqual(self.send.await_count, 1)
        await workspace.coaching_tick(day.replace(hour=16))
        self.assertEqual(self.send.await_count, 2)
        self.assertEqual((await self.client.delete("/api/mr-ivr/mrs/mr/profile")).status_code, 200)
        await workspace.coaching_tick(day.replace(day=6))
        self.assertEqual(self.send.await_count, 2)
        self.db.contacts.records.append({"mobile": "+15550001111", "opted_out": True})
        r = await self.client.post("/api/mr-ivr/mrs/mr/messages", json={"message": "Hello", "confirm_send": True, "request_id": "fixture-request-9999"})
        self.assertEqual(r.status_code, 409)

    async def test_midday_configuration_confirmation_and_scoped_manager_visibility(self):
        body = {**workspace.DEFAULT_PROFILE, "field_flow_enabled": True, "midday_enabled": True}
        self.assertEqual((await self.client.put("/api/mr-ivr/mrs/mr/profile", json=body)).status_code, 422)
        body.update(opt_in=True, confirm_enable=True)
        for patch_value in ({"field_flow_enabled": False}, {"ivr_enabled": False}, {"reminder_minutes": 14},
                            {"midday_time": "25:00"}, {"closing_deadline": "12:00"}):
            self.assertEqual((await self.client.put("/api/mr-ivr/mrs/mr/profile", json={**body, **patch_value})).status_code, 422)
        self.assertEqual((await self.client.put("/api/mr-ivr/mrs/mr/profile", json=body)).status_code, 200)
        day = "2026-10-05"
        self.db.mr_field_days.records.append({"id": f"{day}:mr", "status": "started", "closing_status": "pending"})
        self.db.mr_leave_requests.records.append({"mr_directory_id": "mr", "date": day, "reason": "Synthetic reason"})
        self.db.mr_manager_requests.records.append({"mr_id": "mr", "date": day, "reason": "Order Issue"})
        self.db.mr_field_entries.records.append({"mr_directory_id": "mr", "date": day, "kind": "order"})
        r = (await self.client.get(f"/api/mr-ivr/mrs/mr?date={day}")).json()
        self.assertEqual(r["field_day"]["closing_status"], "pending")
        self.assertEqual(len(r["field_entries"]), 1)
        self.assertEqual(len(r["manager_requests"]), 1)
        self.assertEqual(len(r["leave_requests"]), 1)
        reset = (await self.client.delete("/api/mr-ivr/mrs/mr/profile")).json()
        self.assertFalse(reset["field_flow_enabled"])
        self.assertFalse(reset["midday_enabled"])
        self.assertFalse(reset["ivr_enabled"])

    async def test_midday_send_once_reminder_only_after_acceptance_and_stop_after_response(self):
        day = datetime(2026, 10, 5, 13, tzinfo=workspace.IST)
        body = {**workspace.DEFAULT_PROFILE, "field_flow_enabled": True, "midday_enabled": True, "opt_in": True, "confirm_enable": True}
        self.assertEqual((await self.client.put("/api/mr-ivr/mrs/mr/profile", json=body)).status_code, 200)
        with patch.object(workspace, "now_iso", return_value=day.isoformat()):
            await workspace.coaching_tick(day)
            await workspace.coaching_tick(day)
        self.assertEqual(self.send.await_count, 1)
        self.assertEqual(self.db.conversations.records[0]["mr_field_invitation"]["date"], "2026-10-05")
        await workspace.coaching_tick(day.replace(minute=29))
        self.assertEqual(self.send.await_count, 1)
        with patch.object(workspace, "now_iso", return_value=day.replace(minute=30).isoformat()):
            await workspace.coaching_tick(day.replace(minute=30))
            await workspace.coaching_tick(day.replace(minute=31))
        self.assertEqual(self.send.await_count, 2)
        self.assertEqual(self.db.conversations.records[0]["mr_field_invitation"]["kind"], "midday_reminder")
        # A response stops tomorrow's synthetic check before any IO.
        self.db.mr_field_days.records.append({"id": "2026-10-06:mr", "midday_updated_at": "synthetic"})
        await workspace.coaching_tick(day.replace(day=6))
        self.assertEqual(self.send.await_count, 2)
        self.db.mr_field_days.records[:] = [{"id": "2026-10-07:mr", "status": "on_leave"}]
        await workspace.coaching_tick(day.replace(day=7))
        self.assertEqual(self.send.await_count, 2)

    async def test_uncertain_midday_has_no_reminder_or_retry_and_late_reply_revokes_reserved_send(self):
        day = datetime(2026, 10, 5, 13, tzinfo=workspace.IST)
        body = {**workspace.DEFAULT_PROFILE, "field_flow_enabled": True, "midday_enabled": True, "opt_in": True, "confirm_enable": True}
        await self.client.put("/api/mr-ivr/mrs/mr/profile", json=body)
        self.send.side_effect = RuntimeError("Ambiguous synthetic acceptance")
        await workspace.coaching_tick(day)
        await workspace.coaching_tick(day.replace(minute=30))
        self.assertEqual(self.send.await_count, 1)
        self.assertEqual(self.db.mr_push_notifications.records[0]["status"], "uncertain")
        self.db.mr_push_notifications.records.clear()
        original = self.db.whatsapp_send_requests.update_one
        async def reply_during_reservation(*args, **kwargs):
            result = await original(*args, **kwargs)
            self.db.mr_field_days.records.append({"id": "2026-10-05:mr", "midday_updated_at": "synthetic"})
            return result
        self.send.reset_mock()
        with patch.object(self.db.whatsapp_send_requests, "update_one", reply_during_reservation):
            await workspace.coaching_tick(day)
        self.send.assert_not_awaited()
        self.assertEqual(self.db.mr_push_notifications.records[0]["status"], "uncertain")


class WorkspaceHistoryTests(unittest.IsolatedAsyncioTestCase):
    """Real SQL over transaction-local synthetic data; never write customer tables."""

    async def asyncSetUp(self):
        self.pool = await live_database.connect()
        self.conn = await self.pool.acquire()
        self.tx = self.conn.transaction()
        await self.tx.start()
        await self.conn.execute("""CREATE TEMP TABLE app_documents (
            collection_name text, document_id text, document jsonb,
            PRIMARY KEY (collection_name, document_id)) ON COMMIT DROP""")
        await self.conn.execute("""CREATE INDEX mr_activity_test_idx ON app_documents
            (collection_name, (document->>'created_by'), (document->>'created_at'))
            WHERE collection_name IN ('orders', 'quotations')""")
        self.database = PostgresDatabase()
        self.database.pool = SerialConnectionPool(self.conn)
        self.binding = patch.object(workspace, "db", self.database)
        self.binding.start()
        self.mr = {"id": "synthetic-mr", "mr_id": "synthetic-account"}

    async def asyncTearDown(self):
        self.binding.stop()
        await self.tx.rollback()
        await self.pool.release(self.conn)
        await live_database.close()

    async def insert(self, collection, records):
        await self.conn.copy_records_to_table("app_documents",
            records=[(collection, r["id"], json.dumps(r)) for r in records],
            columns=["collection_name", "document_id", "document"])

    async def test_large_history_indexed_day_and_complete_totals(self):
        for collection in ("orders", "quotations"):
            await self.insert(collection, [
                {"id": f"old{i}", "created_by": self.mr["mr_id"],
                 "created_at": "2024-01-01T12:00:00+00:00", "total": 999999}
                for i in range(30000)])
            await self.insert(collection, [
                {"id": f"today{i}", "created_by": self.mr["mr_id"],
                 "created_at": "2026-10-05T12:00:00+05:30", "total": 2.5}
                for i in range(2505)])
            await self.insert(collection, [
                {"id": "someone-else", "created_by": "other-account",
                 "created_at": "2026-10-05T12:00:00Z", "total": 999999},
                {"id": "deleted", "created_by": self.mr["mr_id"], "deleted": True,
                 "created_at": "2026-10-05T12:00:00Z", "total": 999999},
                {"id": "demo", "created_by": self.mr["mr_id"], "is_demo": True,
                 "created_at": "2026-10-05T12:00:00Z", "total": 999999},
            ])
        await self.insert("orders", [
            {"id": s, "created_by": self.mr["mr_id"], "status": s,
             "created_at": "2026-10-05T12:00:00Z", "total": 999999}
            for s in ("draft", "cancelled")])
        await self.insert("field_visits", [
            {"id": f"visit{i}", "mr_id": self.mr["mr_id"],
             "planned_date": "2026-10-05", "status": "visited" if i < 550 else "planned"}
            for i in range(601)])
        await self.conn.execute("ANALYZE app_documents")
        data = await workspace.activity(self.mr, "2026-10-05")
        self.assertEqual(len(data["orders"]), 2505)
        self.assertEqual(len(data["quotations"]), 2505)
        self.assertEqual(data["summary"]["sales"], 6262.5)
        self.assertEqual(data["summary"]["planned_visits"], 601)
        self.assertEqual(data["summary"]["completed_visits"], 550)
        self.assertEqual(data["summary"]["pending_visits"], 51)
        for collection in ("orders", "quotations"):
            plan = await self.conn.fetch("EXPLAIN " + activity_query(collection),
                self.mr["mr_id"], "2026-10-03", "2026-10-07")
            text = "\n".join(row[0] for row in plan)
            self.assertIn("mr_activity_test_idx", text)
            self.assertIn("Index Cond:", text)
            self.assertIn("created_by", text)
            self.assertIn("created_at", text)
        await self.insert("mr_daily_reports", [{
            "id": "2026-10-05:synthetic-mr",
            "plan": {"planned_visits": 700, "expected_sales": 200},
            "closing": {"completed_visits": 600, "sales": 123},
        }])
        data = await workspace.activity(self.mr, "2026-10-05")
        self.assertEqual(data["summary"], {
            "planned_visits": 700, "completed_visits": 600, "pending_visits": 100,
            "sales": 123, "daily_goal": 200, "achievement_pct": 61.5})

    async def test_offset_timestamps_exact_ist_boundaries_and_ownership(self):
        included = [
            "2026-10-04T18:30:00Z", "2026-10-05T00:00:00+05:30",
            "2026-10-04T19:00:00-12:00", "2026-10-06T00:00:00+14:00",
            "2026-10-06T12:00:00+23:59", "2026-10-04T00:01:00-23:59",
            "2026-10-03T20:00:00-23:00",
            "2026-10-05T18:29:59.999999+00:00",
        ]
        excluded = [
            "2026-10-04T18:29:59.999999Z", "2026-10-05T18:30:00Z",
            "2026-10-06T00:00:00+05:30", "2026-10-05T00:00:00+14:00",
            "2026-10-05T23:00:00-12:00", "2026-10-05T12:00:00",
            "2026-10-05-invalid", "2026-10-05T12:00:00+99:00", "", None,
            "2026-10-03T18:29:59-23:59",
        ]
        for collection in ("orders", "quotations"):
            await self.insert(collection, [
                {"id": f"{group}{i}", "created_by": self.mr["mr_id"],
                 "created_at": stamp, "total": 10}
                for group, stamps in (("yes", included), ("no", excluded))
                for i, stamp in enumerate(stamps)])
            await self.insert(collection, [
                {"id": "foreign", "created_by": "directory:synthetic-mr",
                 "created_at": included[0], "total": 999}])
        data = await workspace.activity(self.mr, "2026-10-05")
        expected = {f"yes{i}" for i in range(len(included))}
        self.assertEqual({r["id"] for r in data["orders"]}, expected)
        self.assertEqual({r["id"] for r in data["quotations"]}, expected)
        self.assertEqual(data["summary"]["sales"], 80)
        fallback = await workspace.activity({**self.mr, "mr_id": "directory:synthetic-mr"}, "2026-10-05")
        self.assertEqual([r["id"] for r in fallback["orders"]], ["foreign"])
        self.assertEqual(fallback["summary"]["sales"], 999)
        empty = await workspace.activity(self.mr, "2026-10-10")
        self.assertEqual(empty["orders"], [])
        self.assertEqual(empty["quotations"], [])
        self.assertEqual(empty["summary"]["sales"], 0)
