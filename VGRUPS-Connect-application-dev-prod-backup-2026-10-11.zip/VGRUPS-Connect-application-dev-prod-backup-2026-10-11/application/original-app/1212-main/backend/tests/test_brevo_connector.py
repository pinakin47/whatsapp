import os
import unittest
from unittest.mock import AsyncMock, patch

import brevo_client
import integrations


class BrevoConnectorTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        environment = patch.dict(os.environ, {
            "BREVO_USE_CONNECTOR": "true",
            "BREVO_API_KEY": "",
            "BREVO_SENDER_EMAIL": "sender@example.com",
        })
        environment.start()
        self.addCleanup(environment.stop)

    async def test_connector_configuration_without_copied_api_key(self):
        self.assertTrue(brevo_client.configured())

    async def test_otp_uses_managed_proxy(self):
        bridge = AsyncMock(return_value={"messageId": "accepted"})
        with patch.object(integrations, "brevo_connector_request", bridge):
            result = await integrations.send_email_otp("recipient@example.com", "123456")
        self.assertEqual(result["messageId"], "accepted")
        self.assertEqual(bridge.call_args.args[0], "send-email")
        self.assertIn("123456", bridge.call_args.args[1]["textContent"])

    async def test_other_transactional_mail_uses_same_proxy(self):
        bridge = AsyncMock(return_value={"messageId": "accepted"})
        with patch.object(integrations, "brevo_connector_request", bridge):
            status = await brevo_client.send_email("recipient@example.com", "Member", "Welcome", "<p>Hello</p>")
        self.assertEqual(status, "Sent")
        self.assertEqual(bridge.call_args.args[0], "send-email")

    async def test_provider_failure_is_not_reported_as_sent(self):
        with patch.object(brevo_client, "send_brevo_email", AsyncMock(side_effect=RuntimeError("Brevo email delivery failed (HTTP 400)."))):
            status = await brevo_client.send_email("recipient@example.com", "Member", "Welcome", "<p>Hello</p>")
        self.assertEqual(status, "Failed")