"""Isolated Sales tests: no live database writes, products, accounts or sends."""
import copy
import io
import unittest
import xml.etree.ElementTree as ET
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch
from zipfile import ZipFile

from fastapi import FastAPI
from fastapi.testclient import TestClient
import auth
import db as database_module
import routes_sales as routes
import sales_service as service
from postgres_query import apply_update
from test_lead_capture import matches


class Cursor:
    def __init__(self, rows):
        self.rows = copy.deepcopy(rows)
        self.offset = 0
    def sort(self, field, direction=None):
        pairs = field if isinstance(field, list) else [(field, direction)]
        for key, direction in reversed(pairs):
            self.rows.sort(key=lambda r: r.get(key, ""), reverse=direction < 0)
        return self
    def skip(self, offset):
        self.offset = offset
        return self
    async def to_list(self, length=None):
        rows = self.rows[self.offset:]
        return rows if length is None else rows[:length]


class Collection:
    def __init__(self, rows=()):
        self.rows = list(copy.deepcopy(rows))
    def find(self, query=None, *_):
        return Cursor([r for r in self.rows if matches(r, query or {})])
    async def find_one(self, query, *_):
        return next((copy.deepcopy(r) for r in self.rows if matches(r, query)), None)
    async def count_documents(self, query):
        return len([r for r in self.rows if matches(r, query)])
    async def find_one_and_update(self, query, update, upsert=False, return_document=True):
        index = next((i for i, r in enumerate(self.rows) if matches(r, query)), None)
        if index is None and not upsert:
            return None
        inserted = index is None
        before = copy.deepcopy(self.rows[index]) if not inserted else dict(query)
        after = apply_update(copy.deepcopy(before), update, inserting=inserted)
        if inserted:
            self.rows.append(after)
        else:
            self.rows[index] = after
        return copy.deepcopy(after if return_document else before)


class SalesTests(unittest.TestCase):
    def setUp(self):
        self.actor = {"id": "first", "name": "Fixture MR", "role": "mr"}
        self.db = SimpleNamespace(
            sales=Collection(),
            products=Collection([{"id": "product-a", "name": "Catalog A", "selling_price": 250},
                                 {"id": "product-b", "name": "Catalog B", "selling_price": 500}]),
            users=Collection([self.actor, {"id": "second", "name": "Other MR", "role": "mr"}]),
            app_config=Collection())
        self.saved_roles = copy.deepcopy(auth.ROLE_DEFINITIONS)
        auth.ROLE_DEFINITIONS.clear()
        self.patches = [
            patch.object(routes, "db", self.db),
            patch.object(database_module.db, "connect", AsyncMock(side_effect=AssertionError("Live DB forbidden"))),
            patch.object(service, "report", AsyncMock(return_value={
                "summary": {"today_value": 0, "month_value": 0, "total_value": 0, "count": 0},
                "customer_sales": [], "product_sales": [], "breakdowns_truncated": False}))]
        for p in self.patches:
            p.start()
        app = FastAPI()
        app.include_router(routes.router)
        app.dependency_overrides[auth.get_current_user] = lambda: self.actor
        self.client = TestClient(app)
        self.body = {"customer_name": "Test Customer", "phone": "9876543210", "email": "",
                     "address": "", "request_key": "fixture-request-12345678",
                     "items": [{"product_id": "product-a", "quantity": 10, "unit_price": 250}]}

    def tearDown(self):
        self.client.close()
        for p in reversed(self.patches):
            p.stop()
        auth.ROLE_DEFINITIONS.clear()
        auth.ROLE_DEFINITIONS.update(self.saved_roles)

    def create(self, body=None):
        response = self.client.post("/api/sales", json=body or self.body)
        self.assertEqual(response.status_code, 200, response.text)
        return response.json()

    def test_server_owned_identity_amounts_and_repeat_save(self):
        sale = self.create()
        self.assertEqual(sale["grand_total"], 2500)
        self.assertEqual(sale["mr_id"], "first")
        self.assertEqual(sale["mr_name"], "Fixture MR")
        self.assertEqual(sale["phone"], "+919876543210")
        self.assertEqual(sale["status"], "Submitted")
        self.assertEqual(self.create()["id"], sale["id"])
        self.assertEqual(len(self.db.sales.rows), 1)
        status = self.client.get("/api/sales/save-status", params={"request_key": self.body["request_key"]}).json()
        self.assertTrue(status["found"])
        self.assertEqual(status["id"], sale["id"])
        changed = {**self.body, "customer_name": "Different"}
        self.assertEqual(self.client.post("/api/sales", json=changed).status_code, 409)
        for field in ("grand_total", "mr_id", "status", "created_at"):
            self.assertEqual(self.client.post("/api/sales", json={**self.body, field: "spoof"}).status_code, 422)

    def test_multi_product_decimal_totals(self):
        body = {**self.body, "items": self.body["items"] + [
            {"product_id": "product-b", "quantity": 5, "unit_price": 500}]}
        sale = self.create(body)
        self.assertEqual(sale["grand_total"], 5000)
        self.assertEqual(sale["quantity"], 15)
        body["request_key"] = "another-request-12345678"
        body["items"] = [{"product_id": "product-a", "quantity": 3, "unit_price": 0.1}]
        self.assertEqual(self.create(body)["grand_total"], 0.3)

    def test_validation_and_unknown_catalog_products(self):
        for patch_value in ({"customer_name": " "}, {"phone": "12345"}, {"email": "invalid"},
                            {"items": []}, {"items": [{"product_id": "product-a", "quantity": 0, "unit_price": 1}]},
                            {"items": [{"product_id": "product-a", "quantity": 1.5, "unit_price": 1}]},
                            {"items": [{"product_id": "product-a", "quantity": 1, "unit_price": -1}]},
                            {"items": [{"product_id": "product-a", "quantity": 1, "unit_price": 1.001}]},
                            {"items": [{"product_id": "missing", "quantity": 1, "unit_price": 1}]}):
            self.assertEqual(self.client.post("/api/sales", json={**self.body, **patch_value}).status_code, 422)
        self.assertEqual(len(self.db.sales.rows), 0)
        self.body["items"][0]["unit_price"] = 0
        self.assertEqual(self.create()["grand_total"], 0)

    def test_other_mr_cannot_read_list_details_or_edit(self):
        sale = self.create()
        self.actor = {"id": "second", "name": "Other MR", "role": "mr"}
        self.assertFalse(self.client.get("/api/sales/save-status",
            params={"request_key": self.body["request_key"]}).json()["found"])
        self.assertEqual(self.client.get("/api/sales").json()["items"], [])
        self.assertEqual(self.client.get("/api/sales/" + sale["id"]).status_code, 404)
        self.assertEqual(self.client.get("/api/sales?mr_id=first").status_code, 403)
        self.assertEqual(self.client.patch("/api/sales/" + sale["id"], json={"revision": 1, "status": "Completed"}).status_code, 403)
        self.assertEqual(self.client.delete("/api/sales/" + sale["id"] + "?revision=1").status_code, 403)
        self.assertEqual(self.client.get("/api/sales/export?format=xlsx").status_code, 403)
        auth.ROLE_DEFINITIONS["mr"] = {"permissions": {"sales": ["view", "edit", "delete"]}}
        self.assertEqual(self.client.patch("/api/sales/" + sale["id"], json={"revision": 1, "status": "Completed"}).status_code, 404)
        self.assertEqual(self.client.delete("/api/sales/" + sale["id"] + "?revision=1").status_code, 404)

    def test_admin_changes_conflicts_audit_and_soft_delete(self):
        sale = self.create()
        self.actor = {"id": "admin", "name": "Fixture Admin", "role": "admin"}
        self.assertEqual(self.client.get("/api/sales").json()["total"], 1)
        response = self.client.patch("/api/sales/" + sale["id"], json={"revision": 1, "status": "Confirmed"})
        self.assertEqual(response.status_code, 200, response.text)
        self.assertEqual(response.json()["revision"], 2)
        self.assertEqual(self.client.patch("/api/sales/" + sale["id"], json={"revision": 1, "status": "Completed"}).status_code, 409)
        self.assertEqual(self.client.patch("/api/sales/" + sale["id"], json={"revision": 2, "status": None}).status_code, 422)
        detail = self.client.get("/api/sales/" + sale["id"]).json()
        self.assertEqual(detail["audit"][-1]["changes"]["status"]["before"], "Submitted")
        self.assertEqual(self.client.delete("/api/sales/" + sale["id"] + "?revision=2").status_code, 200)
        self.assertTrue(self.db.sales.rows[0]["deleted"])
        self.assertEqual(self.client.get("/api/sales").json()["total"], 0)
        self.assertEqual(self.db.sales.rows[0]["audit"][-1]["action"], "deleted")

    def test_admin_edit_recalculates_and_preserves_archived_product(self):
        sale = self.create()
        self.actor = {"id": "admin", "name": "Fixture Admin", "role": "admin"}
        self.db.products.rows = []
        body = {k: v for k, v in self.body.items() if k != "request_key"}
        body["items"][0]["quantity"] = 2
        body["revision"] = 1
        response = self.client.patch("/api/sales/" + sale["id"], json=body)
        self.assertEqual(response.status_code, 200, response.text)
        self.assertEqual(response.json()["grand_total"], 500)
        self.assertEqual(response.json()["items"][0]["product_name"], "Catalog A")

    def test_new_catalog_product_immediately_available(self):
        self.db.products.rows.append({"id": "new", "name": "New Catalog Product", "selling_price": 90})
        rows = self.client.get("/api/sales/products").json()["items"]
        self.assertTrue(any(r["id"] == "new" for r in rows))

    def test_filtered_exports_are_real_excel_and_pdf(self):
        sale = self.create()
        self.actor = {"id": "admin", "name": "Fixture Admin", "role": "admin"}
        self.assertEqual(self.client.get("/api/sales?mr_id=first&status=Submitted").json()["total"], 1)
        self.assertEqual(self.client.get("/api/sales?mr_id=second").json()["total"], 0)
        self.assertEqual(self.client.get("/api/sales?date_from=2026-02-30").status_code, 422)
        excel = self.client.get("/api/sales/export?format=xlsx&mr_id=first")
        self.assertEqual(excel.status_code, 200, excel.text[:100] if excel.status_code != 200 else "")
        with ZipFile(io.BytesIO(excel.content)) as archive:
            text = archive.read("xl/worksheets/sheet1.xml")
            ET.fromstring(text)
            self.assertIn(sale["sale_id"].encode(), text)
            self.assertIn(b"2500", text)
        excluded = self.client.get("/api/sales/export?format=xlsx&mr_id=second")
        with ZipFile(io.BytesIO(excluded.content)) as archive:
            self.assertNotIn(sale["sale_id"].encode(), archive.read("xl/worksheets/sheet1.xml"))
        pdf = self.client.get("/api/sales/export?format=pdf")
        self.assertEqual(pdf.status_code, 200)
        self.assertTrue(pdf.content.startswith(b"%PDF-"))


if __name__ == "__main__":
    unittest.main()
