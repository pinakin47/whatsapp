"""Synthetic report reads/exports only; all storage and providers fail closed."""
import csv
import io
import unittest
from contextlib import ExitStack
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch

import httpx
from fastapi import FastAPI
import auth
import contact_catalogue
import routes_contact_actions as contacts
import routes_catalog_files as catalog
import routes_mr_reporting as reporting
import whatsapp_routing as routing
from postgres_store import PostgresDatabase
from test_lead_capture import Collection


class SenderReports(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        names = ("wa_sessions", "messages", "conversations", "app_config", "users",
                 "roles", "mr_daily_reports", "mr_report_notifications", "whatsapp_receipts",
                 "mr_report_submissions", "mr_catalog_runs", "mr_catalog_parts",
                 "contact_catalogue_runs", "contact_catalogue_parts")
        self.db = SimpleNamespace(**{name: Collection() for name in names})
        self.db.wa_sessions.records = [
            {"id": "one", "phone": "15550000001"}, {"id": "two", "phone": "+15550000002"},
            {"id": "old", "phone": "+15550000003", "deleted": True, "status": "logged_out"}]
        self.db.app_config.records = [{"key": routing.CONFIG_KEY, "value": {
            "general_session_id": "two", "mr_session_id": "two"}}]
        self.actor = {"id": "admin", "role": "super_admin", "active": True}
        self.stack = ExitStack()
        self.addCleanup(self.stack.close)
        for module in (auth, contacts, catalog, reporting):
            self.stack.enter_context(patch.object(module, "db", self.db))
        self.no_database = self.stack.enter_context(patch.object(PostgresDatabase, "connect",
            AsyncMock(side_effect=AssertionError("Live database forbidden"))))
        self.no_gateway = self.stack.enter_context(patch.object(routing.wa_client, "wa_send",
            AsyncMock(side_effect=AssertionError("Live gateway forbidden"))))
        for operation in ("wa_list_sessions", "wa_send_media"):
            self.stack.enter_context(patch.object(routing.wa_client, operation,
                AsyncMock(side_effect=AssertionError("Live gateway forbidden"))))
        self.app = FastAPI()
        for router in (reporting.router, contacts.router, catalog.router):
            self.app.include_router(router)
        self.app.dependency_overrides[auth.get_current_user] = lambda: self.actor
        self.client = httpx.AsyncClient(transport=httpx.ASGITransport(self.app), base_url="http://test")
        self.addAsyncCleanup(self.client.aclose)

    async def test_mr_parts_sender_numbers_receipts_and_csv(self):
        self.db.mr_daily_reports.records = [{"id": "r", "date": "2026-10-07", "mr_id": "mr",
                                             "mr_name": "Fixture MR"}]
        for sid in ("one", "two", "old", None):
            key = sid or "unknown"
            self.db.mr_report_notifications.records += [
                {"id": key, "report_id": "r", "channel": "whatsapp", "status": "sent",
                 "submission_id": key, "user_id": "admin", "required_parts": 1},
                {"id": f"{key}:part:0", "report_id": "r", "channel": "whatsapp", "status": "sent",
                 "submission_id": key, "user_id": "admin", "attempt_id": key, "part": 1, "wamid": key}]
            # Recover from message/conversation provenance, not current MR assignment.
            self.db.messages.records += [{"wamid": key, "conversation_id": key,
                "direction": "outbound", "status": "read", "read_at": "2026-10-07T08:00:08Z"}]
            if sid:
                self.db.conversations.records += [{"id": key, "session_id": sid, "deleted": True}]
        data = (await self.client.get("/api/field/daily-reports?date=2026-10-07")).json()
        by_id = {n["id"]: n for n in data["items"][0]["notifications"]}
        for key, number in (("one", "+15550000001"), ("two", "+15550000002"),
                            ("old", "+15550000003"), ("unknown", "Unknown")):
            for identity in (key, f"{key}:part:0"):
                self.assertEqual(by_id[identity]["sender_number"], number)
                self.assertEqual(by_id[identity]["delivery"]["status"], "read")
                self.assertIsNone(by_id[identity]["delivery"]["delivered_at"])
        result = await self.client.get("/api/field/daily-reports.csv?date=2026-10-07")
        self.assertEqual(result.status_code, 200)
        rows = {r["Attempt"]: r for r in csv.DictReader(io.StringIO(result.text))}
        self.assertEqual(rows["old"]["Sender number"], "'+15550000003")
        self.assertEqual(rows["unknown"]["Sender number"], "Unknown")
        self.assertEqual(rows["one"]["Delivered at"], "")
        self.no_gateway.assert_not_called()
        self.no_database.assert_not_called()

    async def test_catalogue_status_exports_and_ownership(self):
        for sid in ("one", "two", "old", None):
            key = f"fixture_request_{sid or 'unknown'}"
            job = {"id": contact_catalogue.attempt_id("admin", key), "user_id": "admin",
                "status": "accepted", "phone": "+15559999999", "total_parts": 1,
                "session_id": sid}
            self.db.contact_catalogue_runs.records.append(job)
            self.db.contact_catalogue_parts.records.append({"id": key, "run_id": job["id"], "status": "accepted"})
            expected = {"one": "+15550000001", "two": "+15550000002", "old": "+15550000003",
                        None: "Unknown"}[sid]
            path = f"/api/contacts/catalogue-attempts/{key}"
            response = await self.client.get(path)
            self.assertEqual(response.status_code, 200)
            self.assertEqual(response.json()["sender_number"], expected)
            csv_result = await self.client.get(path + "/report.csv")
            self.assertEqual(csv_result.status_code, 200)
            row = next(csv.DictReader(io.StringIO(csv_result.text)))
            self.assertEqual(row["Sender number"].lstrip("'"), expected)
            self.db.mr_catalog_runs.records.append({**job, "mr_name": "Fixture", "date": "2026-10-07"})
        daily = await self.client.get("/api/catalog/daily-mr")
        self.assertEqual({r["sender_number"] for r in daily.json()["items"]},
                         {"+15550000001", "+15550000002", "+15550000003", "Unknown"})
        exported = await self.client.get("/api/catalog/daily-mr.csv")
        self.assertEqual(exported.status_code, 200)
        self.assertEqual(len(list(csv.DictReader(io.StringIO(exported.text)))), 4)
        self.actor = {"id": "other", "role": "super_admin", "active": True}
        self.assertEqual((await self.client.get(path)).status_code, 404)
        self.assertEqual((await self.client.get(path + "/report.csv")).status_code, 404)
        self.no_gateway.assert_not_called()
        self.no_database.assert_not_called()

    async def test_exports_require_export_and_view_permissions(self):
        self.actor = {"id": "admin", "role": "synthetic", "active": True}
        for actions in (["view"], ["export"]):
            with patch.dict(auth.ROLE_DEFINITIONS, {"synthetic": {"permissions": {
                    "field_sales": actions, "catalog": actions, "crm": actions}}}):
                for path in ("/api/field/daily-reports.csv", "/api/catalog/daily-mr.csv",
                             "/api/contacts/catalogue-attempts/fixture_request_key/report.csv"):
                    self.assertEqual((await self.client.get(path)).status_code, 403, path)

    async def test_pinned_unknown_conflicts_and_snapshot(self):
        records = [{"id": "pin", "session_id": "missing", "wamid": "message"},
                   {"id": "conflict", "wamid": "conflict"},
                   {"id": "snapshot", "session_id": "missing", "sender_phone": "+15550000005"},
                   {"id": "inbound", "wamid": "incoming"}]
        self.db.messages.records = [
            {"wamid": "message", "session_id": "two", "direction": "outbound"},
            {"wamid": "conflict", "session_id": "one", "direction": "outbound"},
            {"wamid": "conflict", "session_id": "two", "direction": "outbound"},
            {"wamid": "incoming", "session_id": "one", "direction": "inbound"}]
        await routing.attach_report_senders(self.db, records)
        self.assertEqual([r["sender_number"] for r in records],
                         ["Unknown", "Unknown", "+15550000005", "Unknown"])
        self.no_gateway.assert_not_called()
        self.no_database.assert_not_called()
