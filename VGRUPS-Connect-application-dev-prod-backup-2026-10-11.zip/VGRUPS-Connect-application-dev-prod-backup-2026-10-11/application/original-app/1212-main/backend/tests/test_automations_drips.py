"""Backend tests for Automations, Drips, Campaign CSV, Template Broadcasts, RBAC."""
import os
import time
import uuid
import pytest
import requests

def _load_frontend_env():
    try:
        with open("/app/frontend/.env") as f:
            for line in f:
                if line.startswith("REACT_APP_BACKEND_URL="):
                    return line.split("=", 1)[1].strip()
    except Exception:
        return None
    return None

BASE_URL = (os.environ.get("REACT_APP_BACKEND_URL") or _load_frontend_env()).rstrip("/")
ADMIN_EMAIL = "vgdisposables@gmail.com"
ADMIN_PASS = "VgrupsConnect@2026"


@pytest.fixture(scope="session")
def admin_token():
    r = requests.post(f"{BASE_URL}/api/auth/login",
                      json={"email": ADMIN_EMAIL, "password": ADMIN_PASS}, timeout=15)
    assert r.status_code == 200, r.text
    return r.json()["token"]


@pytest.fixture(scope="session")
def admin(admin_token):
    s = requests.Session()
    s.headers.update({"Authorization": f"Bearer {admin_token}", "Content-Type": "application/json"})
    return s


@pytest.fixture(scope="session")
def viewer(admin):
    """Create transient view_only user, yield session, cleanup."""
    uniq = f"TEST_viewer_{uuid.uuid4().hex[:6]}@example.com"
    pwd = "ViewOnly@123"
    r = admin.post(f"{BASE_URL}/api/users",
                   json={"name": "TEST Viewer", "email": uniq, "password": pwd, "role": "view_only"})
    if r.status_code not in (200, 201):
        pytest.skip(f"Could not create view_only user: {r.status_code} {r.text}")
    uid = r.json().get("id")
    tok = requests.post(f"{BASE_URL}/api/auth/login",
                        json={"email": uniq, "password": pwd}).json().get("token")
    s = requests.Session()
    s.headers.update({"Authorization": f"Bearer {tok}", "Content-Type": "application/json"})
    yield s
    if uid:
        admin.delete(f"{BASE_URL}/api/users/{uid}")


# ---------------- Automations ----------------
class TestAutomations:
    def test_create_toggle_test_delete(self, admin):
        payload = {
            "name": f"TEST_auto_{uuid.uuid4().hex[:6]}",
            "trigger": "new_lead", "enabled": True,
            "actions": [
                {"type": "send_whatsapp", "message": "Hi {name}"},
                {"type": "add_tag", "tag": "TEST_auto_tag"},
                {"type": "create_follow_up", "title": "TEST FU"},
            ],
        }
        r = admin.post(f"{BASE_URL}/api/automations", json=payload)
        assert r.status_code == 200, r.text
        a = r.json()
        aid = a["id"]
        assert a["enabled"] is True and a["trigger"] == "new_lead"
        assert len(a["actions"]) == 3

        # test run
        tr = admin.post(f"{BASE_URL}/api/automations/{aid}/test")
        assert tr.status_code == 200
        executed = tr.json()["executed"]
        assert any("send_whatsapp" in e for e in executed)
        assert any("add_tag" in e for e in executed)

        # toggle
        tg = admin.post(f"{BASE_URL}/api/automations/{aid}/toggle")
        assert tg.status_code == 200 and tg.json()["enabled"] is False
        admin.post(f"{BASE_URL}/api/automations/{aid}/toggle")  # back on

        # delete
        d = admin.delete(f"{BASE_URL}/api/automations/{aid}")
        assert d.status_code == 200

    def test_event_hook_new_lead_tags_and_task(self, admin):
        tag = f"TEST_tag_{uuid.uuid4().hex[:6]}"
        auto = admin.post(f"{BASE_URL}/api/automations", json={
            "name": f"TEST_hook_{uuid.uuid4().hex[:6]}",
            "trigger": "new_lead", "enabled": True,
            "actions": [
                {"type": "add_tag", "tag": tag},
                {"type": "create_follow_up", "title": "TEST hook FU"},
            ],
        }).json()
        aid = auto["id"]

        tasks_before = len(admin.get(f"{BASE_URL}/api/tasks").json().get("items", []))

        lead_resp = admin.post(f"{BASE_URL}/api/leads", json={
            "title": f"TEST_lead_{uuid.uuid4().hex[:6]}",
            "contact_name": "Auto Test",
            "mobile": "9999999999",
            "status": "new",
        })
        assert lead_resp.status_code in (200, 201), lead_resp.text
        lead_id = lead_resp.json().get("id")

        time.sleep(1.0)
        board = admin.get(f"{BASE_URL}/api/leads").json().get("board", {})
        all_leads = [l for lst in board.values() for l in lst]
        got = next((x for x in all_leads if x.get("id") == lead_id), None)
        assert got, f"Lead {lead_id} not found in list"
        tags = got.get("tags") or []
        assert tag in tags, f"Expected tag '{tag}' in lead tags {tags}"

        tasks_after = len(admin.get(f"{BASE_URL}/api/tasks").json().get("items", []))
        assert tasks_after > tasks_before, f"Expected task count to increase ({tasks_before} -> {tasks_after})"

        # cleanup
        admin.delete(f"{BASE_URL}/api/automations/{aid}")
        admin.delete(f"{BASE_URL}/api/leads/{lead_id}")


# ---------------- Drips ----------------
class TestDrips:
    def test_full_drip_lifecycle(self, admin):
        payload = {
            "name": f"TEST_drip_{uuid.uuid4().hex[:6]}",
            "audience": {"type": "all"},
            "steps": [
                {"day": 0, "message": "Hi {name}, welcome"},
                {"day": 1, "message": "Day 1 check-in"},
                {"day": 3, "message": "Day 3 nudge"},
                {"day": 7, "message": "Day 7 final"},
            ],
        }
        r = admin.post(f"{BASE_URL}/api/drips", json=payload)
        assert r.status_code == 200, r.text
        d = r.json()
        did = d["id"]
        assert d["status"] == "draft"
        assert len(d["steps"]) == 4

        act = admin.post(f"{BASE_URL}/api/drips/{did}/activate")
        assert act.status_code == 200, act.text
        n = act.json()["enrolled"]
        assert n >= 1, f"Expected some enrolled contacts, got {n}"

        lst = admin.get(f"{BASE_URL}/api/drips").json()["items"]
        active = [x for x in lst if x["id"] == did][0]
        assert active["status"] == "active"

        p = admin.post(f"{BASE_URL}/api/drips/{did}/pause")
        assert p.status_code == 200
        rs = admin.post(f"{BASE_URL}/api/drips/{did}/resume")
        assert rs.status_code == 200

        dl = admin.delete(f"{BASE_URL}/api/drips/{did}")
        assert dl.status_code == 200

    def test_activate_empty_steps_rejected(self, admin):
        r = admin.post(f"{BASE_URL}/api/drips",
                       json={"name": f"TEST_empty_{uuid.uuid4().hex[:6]}", "steps": []})
        did = r.json()["id"]
        act = admin.post(f"{BASE_URL}/api/drips/{did}/activate")
        assert act.status_code == 400
        admin.delete(f"{BASE_URL}/api/drips/{did}")


# ---------------- Template Broadcast + CSV ----------------
class TestTemplateAndCsv:
    def test_template_broadcast_and_csv(self, admin):
        payload = {
            "name": f"TEST_tpl_{uuid.uuid4().hex[:6]}",
            "message": "Hello {name} from {city}",
            "template_name": "welcome_offer_v1",
            "variables": {"product": "Disposables"},
            "audience": {"type": "all"},
            "send_now": True,
        }
        r = admin.post(f"{BASE_URL}/api/campaigns", json=payload)
        assert r.status_code == 200, r.text
        c = r.json()
        cid = c["id"]
        assert c["template_name"] == "welcome_offer_v1"
        assert "{name}" in c["message"]
        assert c["status"] == "running"

        # recipients materialized
        detail = admin.get(f"{BASE_URL}/api/campaigns/{cid}").json()
        assert len(detail["recipients"]) >= 1

        # CSV
        csv_r = admin.get(f"{BASE_URL}/api/campaigns/{cid}/report.csv")
        assert csv_r.status_code == 200
        assert "text/csv" in csv_r.headers.get("content-type", "")
        assert "attachment" in csv_r.headers.get("content-disposition", "").lower()
        body = csv_r.text
        header = body.splitlines()[0]
        assert header == "Name,Phone,Status,Delivery,Replied,Sent At,Error"
        assert len(body.splitlines()) >= 2  # header + >=1 row

        admin.delete(f"{BASE_URL}/api/campaigns/{cid}")


# ---------------- RBAC ----------------
class TestRBAC:
    def test_viewer_blocked_from_automation_create(self, viewer):
        r = viewer.post(f"{BASE_URL}/api/automations",
                        json={"name": "TEST_viewer_auto", "trigger": "new_lead", "actions": []})
        assert r.status_code == 403, f"Expected 403, got {r.status_code}: {r.text}"

    def test_viewer_blocked_from_drip_create(self, viewer):
        r = viewer.post(f"{BASE_URL}/api/drips",
                        json={"name": "TEST_viewer_drip", "steps": [{"day": 0, "message": "hi"}]})
        assert r.status_code == 403

    def test_viewer_blocked_from_campaign_export(self, admin, viewer):
        c = admin.post(f"{BASE_URL}/api/campaigns", json={
            "name": f"TEST_rbac_{uuid.uuid4().hex[:6]}", "message": "x",
            "audience": {"type": "all"}, "send_now": True,
        }).json()
        cid = c["id"]
        r = viewer.get(f"{BASE_URL}/api/campaigns/{cid}/report.csv")
        assert r.status_code == 403
        admin.delete(f"{BASE_URL}/api/campaigns/{cid}")
