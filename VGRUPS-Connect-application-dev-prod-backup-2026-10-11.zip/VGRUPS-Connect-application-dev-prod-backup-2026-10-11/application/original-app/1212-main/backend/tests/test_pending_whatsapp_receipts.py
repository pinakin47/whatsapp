"""No real sends or database: early events and concurrent persistence."""
import asyncio
import unittest
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch

from receipt_fixture import MemoryDatabase
from whatsapp_receipts import save_receipt, reconcile_receipts
from mr_report_receipts import receipt_index, delivery_evidence
import routes_mr_reporting as reporting
import routes_whatsapp


class PendingReceipts(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.db = MemoryDatabase()
        self.messages = self.db.messages

    async def persist(self, wamid="exact"):
        await self.messages.update_one({"wamid": wamid}, {"$setOnInsert": {
            "wamid": wamid, "id": "message", "conversation_id": "conversation",
            "direction": "outbound", "body": "fixture", "status": "sent",
            "created_at": "2020-01-01T00:00:00Z"}}, upsert=True)

    async def test_cloud_webhook_before_message_reconciles_without_partial_inbox_row(self):
        request = SimpleNamespace(body=AsyncMock(return_value=b"fixture"), headers={},
            json=AsyncMock(return_value={"entry": [{"changes": [{"value": {"statuses": [
                {"id": "exact", "status": "read", "timestamp": "1791187208"},
                {"id": "exact", "status": "delivered", "timestamp": "1791187203"},
            ]}}]}]}))
        with patch.object(routes_whatsapp, "db", self.db), \
                patch.object(routes_whatsapp, "_valid_signature", return_value=True):
            self.assertEqual(await routes_whatsapp.receive_webhook(request), {"ok": True})
        self.assertEqual(self.messages.records, [])
        self.assertEqual(len(self.db.whatsapp_receipts.records), 1)
        # Later message persistence reads retained evidence rather than local state.
        await self.persist()
        row = await self.messages.find_one({"wamid": "exact"})
        self.assertEqual(row["body"], "fixture")
        self.assertEqual(row["status"], "read")
        self.assertEqual(row["read_at"], "2026-10-05T08:00:08.000Z")
        self.assertEqual(row["delivered_at"], "2026-10-05T08:00:03.000Z")

    async def test_concurrent_first_receipts_and_persistence_keep_all_evidence(self):
        await asyncio.gather(
            save_receipt(self.messages, "exact", "read", 1791187208),
            save_receipt(self.messages, "exact", "delivered", 1791187203),
            save_receipt(self.messages, "exact", "read", 1791187212),
            save_receipt(self.messages, "exact", "failed", 1791187210),
            self.persist(), self.persist())
        self.assertEqual(len(self.messages.records), 1)
        self.assertEqual(len(self.db.whatsapp_receipts.records), 1)
        row = self.messages.records[0]
        self.assertEqual(row["status"], "read")
        self.assertEqual(row["status_at"], row["read_at"])
        self.assertEqual(row["read_at"], "2026-10-05T08:00:08.000Z")
        self.assertEqual(row["delivered_at"], "2026-10-05T08:00:03.000Z")
        await self.persist()
        self.assertEqual(self.messages.records[0]["status"], "read")

    async def test_no_time_or_similar_id_can_supply_missing_evidence(self):
        await save_receipt(self.messages, "exact", "read", None)
        await save_receipt(self.messages, "exact-other", "delivered", 1791187203)
        await self.persist()
        row = self.messages.records[0]
        self.assertEqual(row["status"], "read")
        self.assertIsNone(row["read_at"])
        self.assertIsNone(row["delivered_at"])
        self.assertIsNone(row["status_at"])
        await reconcile_receipts(self.messages, "unknown")
        self.assertEqual(len(self.messages.records), 1)

    async def test_report_query_reads_pending_and_saved_stage_evidence_together(self):
        await save_receipt(self.messages, "exact", "read", 1791187208)
        # Route reads only these two collections for explicit-part claims.
        class Cursor:
            def __init__(self, rows): self.rows = rows
            async def to_list(self, limit): return self.rows
        messages = [{"wamid": "exact", "status": "delivered",
                     "delivered_at": "2026-10-05T08:00:03.000Z"}]
        saved = SimpleNamespace(find=lambda *args: Cursor(messages))
        pending = SimpleNamespace(find=lambda *args: Cursor(self.db.whatsapp_receipts.records))
        claims = [{"channel": "whatsapp", "wamid": "exact", "part": 1, "required_parts": 1}]
        with patch.object(reporting, "db", SimpleNamespace(messages=saved, whatsapp_receipts=pending)):
            receipts, _ = await reporting.load_report_receipts(claims)
        result = delivery_evidence(claims, 1, receipts)
        self.assertEqual(result["status"], "read")
        self.assertEqual(result["delivered_at"], messages[0]["delivered_at"])
        self.assertEqual(result["read_at"], "2026-10-05T08:00:08.000Z")
        self.assertEqual(delivery_evidence([{"wamid": "other"}], 1, receipts)["status"], "unknown")
        self.assertEqual(receipt_index(self.db.whatsapp_receipts.records)["exact"]["status"], "read")
