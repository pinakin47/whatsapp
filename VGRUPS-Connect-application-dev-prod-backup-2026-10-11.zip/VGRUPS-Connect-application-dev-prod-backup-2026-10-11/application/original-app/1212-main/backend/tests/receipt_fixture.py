"""Isolated storage: real persistence hooks, no pool or provider connections."""
import asyncio
import copy
from types import SimpleNamespace

from postgres_store import Collection


class MemoryCollection(Collection):
    def __init__(self, database, name):
        super().__init__(database, name)
        self.records = []
        self.lock = asyncio.Lock()

    async def find_one(self, selector=None, projection=None, sort=None):
        return next((copy.deepcopy(row) for row in self.records
                     if all(row.get(k) == v for k, v in (selector or {}).items())), None)

    async def _update(self, selector, update, upsert=False, many=False):
        # Yield reads before atomic writes to exercise real CAS retries.
        await asyncio.sleep(0)
        async with self.lock:
            row = next((r for r in self.records
                        if all(r.get(k) == v for k, v in selector.items())), None)
            before = copy.deepcopy(row)
            inserted = row is None and upsert
            if inserted:
                row = {**selector, **update.get("$setOnInsert", {})}
                self.records.append(row)
            if row is not None:
                row.update(copy.deepcopy(update.get("$set", {})))
            return (SimpleNamespace(matched_count=int(before is not None),
                                    modified_count=int(row != before),
                                    upserted_id="fixture" if inserted else None),
                    before, copy.deepcopy(row))


class MemoryDatabase:
    def __init__(self):
        self.collections = {}

    def __getitem__(self, name):
        if name not in self.collections:
            self.collections[name] = MemoryCollection(self, name)
        return self.collections[name]

    def __getattr__(self, name):
        return self[name]
