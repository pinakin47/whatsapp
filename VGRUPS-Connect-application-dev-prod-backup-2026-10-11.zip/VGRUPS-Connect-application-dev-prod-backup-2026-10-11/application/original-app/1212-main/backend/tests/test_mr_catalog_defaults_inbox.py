"""Isolated fixtures only: no real database, files, OpenAI requests or WhatsApp sends."""
import unittest
from datetime import datetime
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch
from fastapi import HTTPException
import inbox_scope as inbox
import mr_catalog_daily as catalog
from mr_automation_defaults import ensure_automatic_mrs
from routes_mr_settings import IST
from lead_capture_core import stable
from test_lead_capture import Collection


def database():
    return SimpleNamespace(**{name: Collection() for name in (
        "app_config", "users", "mr_directory", "mr_ivr_profiles", "contacts", "consent_records",
        "products", "campaign_media", "mr_catalog_runs", "mr_catalog_parts",
        "whatsapp_send_requests", "messages", "conversations", "wa_sessions")})


class CatalogueAndDefaults(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.db = database()
        self.now = datetime(2026, 10, 6, 9, 1, tzinfo=IST)
        self.db.users.records = [{"id": "admin", "role": "super_admin", "active": True}]
        self.db.mr_directory.records = [
            {"id": "one", "name": "Fixture MR 1", "phone": "+15550000001", "active": True},
            {"id": "two", "name": "Fixture MR 2", "phone": "+15550000002", "active": True},
            {"id": "off", "name": "Inactive fixture", "phone": "+15550000003", "active": False},
            {"id": "deleted", "name": "Deleted fixture", "phone": "+15550000004", "active": True, "deleted": True},
            {"id": "demo", "name": "Demo fixture", "phone": "+15550000005", "active": True, "is_demo": True},
        ]
        self.db.products.records = [
            {"id": "p1", "name": "Product 1", "image": "https://images.unsplash.com/photo-1",
             "images": ["https://images.unsplash.com/photo-2"]},
            {"id": "p2", "name": "Product 2", "image": "https://images.unsplash.com/photo-1"},
        ]
        self.db.campaign_media.records = [
            {"id": "jpg", "purpose": "catalog", "state": "ready", "name": "catalog.jpg",
             "content_type": "image/jpeg", "object_path": "/fixture/catalog/jpg"},
            {"id": "pdf", "purpose": "catalog", "state": "ready", "name": "catalog.pdf",
             "content_type": "application/pdf", "object_path": "/fixture/catalog/pdf"},
            {"id": "pending", "purpose": "catalog", "state": "pending"},
            {"id": "campaign", "purpose": "campaign", "state": "ready"},
        ]
        self.session = {"id": "original", "phone": "+15550000999", "status": "connected"}
        self.sends = AsyncMock(side_effect=lambda *a, **kw: {"wamid": kw["request_id"]})
        self.patches = [
            patch.object(catalog, "refresh_role_definitions", AsyncMock()),
            patch.object(catalog.wa_client, "wa_list_sessions", AsyncMock(return_value={"sessions": [self.session]})),
            patch.object(catalog.wa_client, "wa_send_media", self.sends),
            patch.object(catalog, "signed_url", AsyncMock(return_value="https://storage.googleapis.com/fixture/catalog/file")),
        ]
        for p in self.patches: p.start()
        self.addCleanup(lambda: [p.stop() for p in reversed(self.patches)])

    async def test_development_does_not_enable_live_automation(self):
        await ensure_automatic_mrs(self.db, production=False)
        self.assertEqual(self.db.app_config.records, [])

    async def test_production_defaults_all_once_and_preserves_subsequent_pause(self):
        await ensure_automatic_mrs(self.db, production=True)
        values = {r["key"]: r["value"] for r in self.db.app_config.records if "value" in r}
        self.assertTrue(values["mr_ivr"]["enabled"])
        self.assertTrue(values["mr_lead_capture"]["ai_auto_reply"])
        self.assertTrue(values["mr_lead_capture"]["authorized_messages_confirmed"])
        self.assertTrue(values["mr_catalog_daily"]["enabled"])
        self.assertEqual(values["mr_catalog_daily"]["time"], "09:00")
        await self.db.app_config.update_one({"key": "mr_catalog_daily"}, {"$set": {"value": {"enabled": False}}})
        await ensure_automatic_mrs(self.db, production=True)
        self.assertFalse((await self.db.app_config.find_one({"key": "mr_catalog_daily"}))["value"]["enabled"])

    async def test_all_active_mrs_get_all_images_jpg_and_pdf_once(self):
        await ensure_automatic_mrs(self.db, production=True)
        for _ in range(12):
            await catalog.catalog_tick(self.db, self.now)
        self.assertEqual(self.sends.await_count, 8)  # 2 distinct images + JPEG + PDF, for each MR.
        self.assertEqual({r["mr_id"] for r in self.db.mr_catalog_runs.records}, {"one", "two"})
        self.assertTrue(all(r["status"] == "accepted" for r in self.db.mr_catalog_runs.records))
        self.assertEqual(sum(c.args[2] == "application/pdf" for c in self.sends.await_args_list), 2)
        self.assertTrue(all(c.kwargs["session_id"] == "original" for c in self.sends.await_args_list))
        self.assertTrue(all(m["capture_skip"] for m in self.db.messages.records))
        self.assertEqual(len(self.db.whatsapp_send_requests.records), 8)

    async def test_before_schedule_and_offline_make_no_reservations(self):
        await ensure_automatic_mrs(self.db, production=True)
        await catalog.catalog_tick(self.db, self.now.replace(hour=8))
        with patch.object(catalog.wa_client, "wa_list_sessions", AsyncMock(return_value={"sessions": []})):
            await catalog.catalog_tick(self.db, self.now)
        self.sends.assert_not_awaited()
        self.assertEqual(self.db.mr_catalog_runs.records, [])

    async def test_opt_out_pause_and_revoked_permission_excluded(self):
        await ensure_automatic_mrs(self.db, production=True)
        self.db.contacts.records = [{"mobile": "+15550000001", "opted_out": True}]
        self.db.mr_ivr_profiles.records = [{"id": "two", "value": {"ivr_enabled": False}}]
        await catalog.catalog_tick(self.db, self.now)
        self.sends.assert_not_awaited()
        self.assertEqual(self.db.mr_catalog_runs.records, [])
        self.db.contacts.records = []
        self.db.mr_ivr_profiles.records = []
        self.db.users.records[0]["active"] = False
        await catalog.catalog_tick(self.db, self.now)
        self.sends.assert_not_awaited()

    async def test_timeout_is_not_retried_or_switched_to_other_number(self):
        await ensure_automatic_mrs(self.db, production=True)
        self.sends.side_effect = TimeoutError()
        await catalog.catalog_tick(self.db, self.now)
        self.assertEqual(self.db.mr_catalog_parts.records[0]["status"], "uncertain")
        with patch.object(catalog.wa_client, "wa_list_sessions", AsyncMock(return_value={"sessions": [
                {"id": "different", "status": "connected", "phone": "+15550000888"}]})):
            await catalog.catalog_tick(self.db, self.now)
        self.assertEqual(self.sends.await_count, 1)
        for _ in range(10):
            await catalog.catalog_tick(self.db, self.now)
        keys = [c.kwargs["request_id"] for c in self.sends.await_args_list]
        self.assertEqual(len(keys), len(set(keys)))
        self.assertTrue(all(r["status"] == "needs_review" for r in self.db.mr_catalog_runs.records))

    async def test_file_removed_before_send_consumes_part_without_provider_io(self):
        await ensure_automatic_mrs(self.db, production=True)
        part = (await catalog.catalogue_snapshot(self.db))[-1]
        await self.db.campaign_media.update_one({"id": "pdf"}, {"$set": {"state": "archived", "deleted": True}})
        job = {"id": "fixture-job", "mr_id": "one", "phone": "+15550000001", "date": "2026-10-06"}
        await catalog.deliver_part(self.db, job, part, self.session)
        await catalog.deliver_part(self.db, job, part, self.session)
        self.sends.assert_not_awaited()
        self.assertEqual(self.db.mr_catalog_parts.records[0]["media_key"], part["key"])
        self.assertEqual(self.db.mr_catalog_parts.records[0]["status"], "removed")


class SavedInbox(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.db = database()
        self.db.wa_sessions.records = [
            {"id": "main", "phone": "+15550000999", "name": "Fixture WhatsApp", "status": "connected"},
            {"id": "other", "phone": "+15550000888", "status": "disconnected"},
        ]
        self.db.conversations.records = [
            {"id": "own", "session_id": "main", "is_demo": False},
            {"id": "unrelated", "session_id": "other", "is_demo": False},
        ]
        self.bind = patch.object(inbox, "db", self.db)
        self.bind.start()
        self.addCleanup(self.bind.stop)

    async def test_connected_then_refresh_offline_preserves_only_same_number(self):
        with patch.object(inbox.wa_client, "wa_list_sessions", AsyncMock(return_value={"sessions": [self.db.wa_sessions.records[0]]})):
            self.assertEqual((await inbox.linked_session())["id"], "main")
        with patch.object(inbox.wa_client, "wa_list_sessions", AsyncMock(return_value={"sessions": [], "service_down": True})):
            session = await inbox.linked_session()
            self.assertEqual(session["id"], "main")
            self.assertEqual(session["status"], "disconnected")
            conv, _ = await inbox.scoped_conversation("own")
            self.assertEqual(conv["id"], "own")
            with self.assertRaises(HTTPException):
                await inbox.scoped_conversation("unrelated")

    async def test_explicit_logout_and_deleted_session_do_not_expose_history(self):
        self.db.app_config.records = [{"key": "inbox_linked_account", "value": self.db.wa_sessions.records[0]}]
        with patch.object(inbox.wa_client, "wa_list_sessions", AsyncMock(return_value={"sessions": [{"id": "main", "status": "logged_out"}]})):
            self.assertIsNone(await inbox.linked_session())
        self.db.wa_sessions.records = [self.db.wa_sessions.records[1]]
        with patch.object(inbox.wa_client, "wa_list_sessions", AsyncMock(return_value={"sessions": []})):
            self.assertIsNone(await inbox.linked_session())

    async def test_ambiguous_legacy_accounts_are_not_guessed(self):
        self.db.wa_sessions.records[0]["status"] = "disconnected"
        with patch.object(inbox.wa_client, "wa_list_sessions", AsyncMock(return_value={"sessions": []})):
            self.assertIsNone(await inbox.linked_session())
