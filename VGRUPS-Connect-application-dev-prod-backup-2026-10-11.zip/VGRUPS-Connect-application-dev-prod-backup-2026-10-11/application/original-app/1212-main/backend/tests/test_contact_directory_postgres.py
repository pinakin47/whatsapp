"""Real PostgreSQL fixtures on a disposable Unix-socket cluster, never app data.

Run: PYTHONPATH=original-app/1212-main/backend python -m unittest discover
     -s original-app/1212-main/backend/tests -p test_contact_directory_postgres.py
"""
import json
import shutil
import subprocess
import tempfile
import time
import unittest
from pathlib import Path
from unittest.mock import AsyncMock, patch

import asyncpg
from fastapi import HTTPException
import contact_directory as directory
import routes_contact_actions as actions
import whatsapp_routing
from postgres_store import PostgresDatabase


class ContactDirectoryPostgres(unittest.IsolatedAsyncioTestCase):
    @classmethod
    def setUpClass(cls):
        if not all(shutil.which(tool) for tool in ("initdb", "pg_ctl")):
            raise unittest.SkipTest("PostgreSQL tools are required for isolated directory fixtures")
        cls.tmp = tempfile.TemporaryDirectory(prefix="contacts-fixture-")
        cls.root = Path(cls.tmp.name)
        cls.data = cls.root / "data"
        subprocess.run(["initdb", "-D", str(cls.data), "-A", "trust", "--locale=C.UTF-8"],
                       check=True, capture_output=True)
        subprocess.run(["pg_ctl", "-D", str(cls.data), "-l", str(cls.root / "postgres.log"),
                        "-o", f"-k {cls.root} -p 6543 -c listen_addresses='' -c fsync=off", "-w", "start"],
                       check=True, capture_output=True)
        cls.addClassCleanup(cls.stop_cluster)

    @classmethod
    def stop_cluster(cls):
        subprocess.run(["pg_ctl", "-D", str(cls.data), "-m", "immediate", "-w", "stop"],
                       check=True, capture_output=True)
        cls.tmp.cleanup()

    async def asyncSetUp(self):
        self.pool = await asyncpg.create_pool(host=str(self.root), port=6543, database="postgres",
                                             user="runner", min_size=1, max_size=2)
        await self.pool.execute(Path(__file__).parents[1].joinpath("postgres_schema.sql").read_text())
        await self.pool.execute("TRUNCATE app_documents")  # Disposable cluster only.
        self.db = PostgresDatabase()
        self.db.pool = self.pool
        self.user = {"id": "actor", "role": "super_admin"}
        self.sessions = [{"id": "a", "phone": "15550000001", "status": "connected"},
                         {"id": "b", "phone": "15550000002", "status": "deleted", "deleted": True}]
        self.gateway = patch.object(whatsapp_routing.wa_client, "wa_list_sessions",
                                    AsyncMock(return_value={"sessions": []}))
        self.gateway.start()
        self.addCleanup(self.gateway.stop)
        for session in self.sessions:
            await self.insert("wa_sessions", session)

    async def asyncTearDown(self):
        await self.pool.close()

    async def insert(self, collection, row):
        # Direct SQL bypasses application write hooks and external audit/delivery.
        await self.pool.execute("INSERT INTO app_documents(collection_name, document_id, document) VALUES($1, $2, $3::jsonb)",
                                collection, row["id"], json.dumps(row))

    async def test_generated_phone_columns_match_original_expressions_and_refresh(self):
        from postgres_directory import first_value, normalized_phone
        variants = [
            {}, {"mobile": "", "phone": "+1 (555) 111-1111"},
            {"mobile": None, "phone": "\t+1555.111.1111\n"},
            {"mobile": " ", "phone": "+15552222222"},
            {"mobile": "++15551111111", "phone": "+15552222222"},
            {"mobile": "", "phone": "", "alternative_phone": "+1 (555) 333-3333"},
            {"mobile": "+15551111111", "alternative_phone": "+15552222222"},
        ]
        expressions = {
            "directory_mobile_key": "COALESCE(document->>'mobile', '')",
            "directory_phone_key": "COALESCE(document->>'phone', '')",
            "directory_mobile_first_key": first_value(("mobile", "phone")),
            "directory_phone_first_key": first_value(("phone", "mobile")),
            "directory_lead_phone_key": first_value(("mobile", "phone", "alternative_phone")),
            "directory_alternate_phone_key": "COALESCE(document->>'alternative_phone', '')",
        }
        for n, values in enumerate(variants):
            await self.insert("contacts", {"id": f"generated-{n}", **values})
        equality = " AND ".join(
            f"{column} IS NOT DISTINCT FROM {normalized_phone(raw)}"
            for column, raw in expressions.items())
        self.assertEqual(await self.pool.fetchval(
            f"SELECT count(*) FROM app_documents WHERE NOT ({equality})"), 0)
        await self.pool.execute("""UPDATE app_documents SET document =
            document || '{"mobile":"+15554444444","phone":"+15556666666"}'::jsonb
            WHERE collection_name='contacts' AND document_id='generated-0'""")
        row = await self.pool.fetchrow("""SELECT directory_mobile_key, directory_phone_key
            FROM app_documents WHERE collection_name='contacts' AND document_id='generated-0'""")
        self.assertEqual(row["directory_mobile_key"], "15554444444")
        self.assertEqual(row["directory_phone_key"], "15556666666")
        # Reproduce the name/text COALESCE used by migration index introspection.
        # No index key may be truncated; that would generate invalid CREATE INDEX.
        truncated = await self.pool.fetchval("""SELECT count(*)
            FROM pg_index i JOIN pg_class c ON c.oid=i.indexrelid
            CROSS JOIN LATERAL generate_series(1,i.indnkeyatts) k
            LEFT JOIN pg_attribute a ON a.attrelid=i.indrelid AND a.attnum=i.indkey[k-1]
            WHERE c.relname LIKE 'app_directory_%'
            AND COALESCE(a.attname,pg_get_indexdef(i.indexrelid,k,false))::text
                IS DISTINCT FROM COALESCE(a.attname::text,pg_get_indexdef(i.indexrelid,k,false))""")
        self.assertEqual(truncated, 0)

    async def fixture(self):
        await self.insert("contacts", {"id": "crm", "name": "Canonical", "mobile": "+1 (555) 111-1111",
                                      "contact_type": "doctor", "company": "First company"})
        for collection, row in [
            ("mr_directory", {"id": "mr", "name": "MR Alias", "phone": "15551111111"}),
            ("users", {"id": "team", "name": "Team Alias", "mobile": "15551111111", "password_hash": "private"}),
            ("leads", {"id": "lead", "contact_name": "Lead Alias", "mobile": "15551111111",
                       "alternative_phone": "+15552222222", "assigned_to": "actor", "email": "first@example.test"}),
            ("orders", {"id": "order", "customer_name": "Order Alias", "phone": "15551111111",
                        "company": "Ignored company"}),
            ("quotations", {"id": "quote", "contact_name": "Quote Alias", "mobile": "15551111111"}),
            ("candidates", {"id": "candidate", "name": "Candidate Alias", "phone": "15551111111",
                            "resume": "private", "email": "ignored@example.test"}),
            ("conversations", {"id": "z-chat-a", "name": "Chat A", "phone": "15551111111", "session_id": "a"}),
            ("conversations", {"id": "a-chat-b", "name": "Chat B", "phone": "15551111111", "session_id": "b"}),
            ("conversations", {"id": "unknown", "name": "Not an account", "phone": "15553333333", "session_id": "unknown"}),
            ("contacts", {"id": "no-phone", "name": "Nameless phone"}),
            ("contacts", {"id": "deleted", "name": "Deleted", "mobile": "15551111111", "deleted": True, "opted_out": True}),
            ("contacts", {"id": "demo", "name": "Demo", "mobile": "15551111111", "is_demo": True, "opted_out": True}),
            ("contacts", {"id": "unicode", "name": "Straße Σς ﬃ", "mobile": "15554444444"}),
        ]:
            await self.insert(collection, row)

    async def test_pages_match_reference_across_sources_aliases_and_unicode(self):
        await self.fixture()
        expected = await directory.directory(self.db, self.user)
        for search in ("", "Chat B", "Lead Alias", "First company", "Ignored company",
                       "first@example.test", "ignored@example.test", "%", "STRASSE", "σσ", "ffi", "1555222"):
            for kind in ("all", "doctor", "lead", "mr"):
                term = search.casefold()
                filtered = [r for r in expected if (kind == "all" or r["contact_type"] == kind)
                            and (not term or term in " ".join(str(r.get(k) or "") for k in
                                 ("name", "mobile", "company", "email")).casefold()
                                 or any(term in a.casefold() for a in r["aliases"]))]
                for offset in (0, 1, 999):
                    result = await directory.directory_page(self.db, self.user, search, kind, offset, 2)
                    self.assertEqual(result["items"], filtered[offset:offset + 2], (search, kind, offset))
                    self.assertEqual(result["total"], len(filtered))
        canonical = next(r for r in expected if r["id"] == "crm")
        self.assertIn("conversations:a-chat-b", canonical["directory_refs"])
        self.assertEqual(len(canonical["sources"]), 8)
        self.assertNotIn("password_hash", json.dumps(expected))
        self.assertNotIn("resume", json.dumps(expected))

    async def test_role_scopes_and_exact_recipient_rechecks(self):
        await self.fixture()
        await self.insert("leads", {"id": "other-owner", "name": "Hidden owner", "mobile": "15557777777", "assigned_to": "other"})
        await self.insert("leads", {"id": "mr-capture", "name": "Private capture", "mobile": "15558888888", "source": "WhatsApp – MR"})
        for role in ("mr", "sales_manager", "view_only", "hr", "accounts"):
            user = {**self.user, "role": role}
            try:
                expected = await directory.directory(self.db, user)
            except HTTPException as error:
                with self.assertRaises(HTTPException) as actual:
                    await directory.directory_page(self.db, user)
                self.assertEqual(actual.exception.status_code, error.status_code)
                continue
            actual = await directory.directory_page(self.db, user)
            self.assertEqual(actual["items"], expected, role)
        row = await directory.recipient(self.db, "leads:lead:alternative_phone", self.user)
        self.assertEqual(row["mobile"], "+15552222222")
        row = await directory.recipient(self.db, "conversations:a-chat-b", self.user)
        self.assertEqual(row["id"], "crm")
        await self.pool.execute("""UPDATE app_documents SET document=jsonb_set(document, '{phone}', '"15559999999"')
                                   WHERE collection_name='conversations' AND document_id='a-chat-b'""")
        with patch.object(actions, "db", self.db), patch.object(actions, "send_to_recipient", AsyncMock()) as send:
            with self.assertRaises(HTTPException) as error:
                await actions.send_message("conversations:a-chat-b", actions.MessageIn(
                    body="Fixture", expected_phone="+15551111111", request_key="fixture-request-key"), self.user)
            self.assertEqual(error.exception.status_code, 409)
            send.assert_not_awaited()
        await self.pool.execute("""UPDATE app_documents SET document=document || '{"deleted":true}'::jsonb
                                   WHERE collection_name='leads' AND document_id='lead'""")
        with self.assertRaises(HTTPException) as error:
            await directory.recipient(self.db, "leads:lead", self.user)
        self.assertEqual(error.exception.status_code, 404)

    async def test_opt_outs_are_global_and_never_cached(self):
        await self.fixture()
        row = await directory.recipient(self.db, "conversations:a-chat-b", self.user)
        self.assertEqual(await directory.check_consent(self.db, row), "+15551111111")
        await self.insert("contacts", {"id": "optout", "name": "Global optout", "phone": "+1 (555) 111-1111", "opted_out": True})
        with self.assertRaises(HTTPException) as error:
            await directory.check_consent(self.db, row)
        self.assertEqual(error.exception.status_code, 409)
        fresh = await directory.recipient(self.db, "conversations:a-chat-b", self.user)
        self.assertTrue(fresh["opted_out"])
        await self.insert("consent_records", {"id": "consent", "phone": "15552222222",
                                              "status": "opted_out", "created_at": "2026-10-07"})
        alternate = await directory.recipient(self.db, "leads:lead:alternative_phone", self.user)
        with self.assertRaises(HTTPException):
            await directory.check_consent(self.db, alternate)

    async def test_large_history_stays_bounded_with_duplicate_account_phones(self):
        collections = ["contacts", "leads", "mr_directory", "users", "candidates", "orders", "quotations", "conversations"]
        await self.pool.execute("""
            INSERT INTO app_documents(collection_name, document_id, document)
            SELECT collection, lpad(n::text, 8, '0'), jsonb_build_object(
                'id', lpad(n::text, 8, '0'), 'name', 'Fixture ' || lpad(n::text, 8, '0'),
                'phone', '+155' || lpad((CASE WHEN collection='conversations' THEN n/2 ELSE n+rank*20000 END)::text, 8, '0'),
                'session_id', CASE WHEN n%2=0 THEN 'a' ELSE 'b' END,
                'assigned_to', 'actor', 'password_hash', 'must-not-leave-db', 'resume', 'must-not-leave-db')
            FROM unnest($1::text[]) WITH ORDINALITY AS c(collection, rank)
            CROSS JOIN generate_series(0, 14999) AS n
        """, collections)
        await self.pool.execute("ANALYZE app_documents")
        start = time.perf_counter()
        page = await directory.directory_page(self.db, self.user, offset=40000, limit=100)
        elapsed = time.perf_counter() - start
        self.assertEqual(len(page["items"]), 100)
        self.assertEqual(page["total"], 112500)
        self.assertLess(elapsed, 8, f"120,000-row page took {elapsed:.2f}s")
        self.assertLess(len(json.dumps(page)), 180000)
        start = time.perf_counter()
        match = await directory.directory_page(self.db, self.user, search="Fixture 00014999", limit=100)
        search_elapsed = time.perf_counter() - start
        self.assertEqual(match["total"], 8)
        self.assertLess(search_elapsed, 8)
        start = time.perf_counter()
        recipient = await directory.recipient(self.db, "conversations:00000000", self.user)
        recipient_elapsed = time.perf_counter() - start
        self.assertEqual(recipient["directory_refs"], ["conversations:00000000", "conversations:00000001"])
        self.assertLess(recipient_elapsed, 1)
        self.assertNotIn("must-not-leave-db", json.dumps(page))
        self.assertIn("Fixture 00000001", recipient["aliases"])
        print(f"Directory fixture: 120000 sources; page={elapsed:.3f}s search={search_elapsed:.3f}s "
              f"recipient={recipient_elapsed:.3f}s response={len(json.dumps(page))} bytes")


if __name__ == "__main__":
    unittest.main()
