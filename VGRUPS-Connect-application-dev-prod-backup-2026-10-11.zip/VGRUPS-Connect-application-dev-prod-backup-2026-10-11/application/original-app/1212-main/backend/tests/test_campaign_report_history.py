"""Real PostgreSQL aggregation on isolated, rollback-only synthetic histories.

Run: PYTHONPATH=original-app/1212-main/backend uv run python -m unittest
     discover -s original-app/1212-main/backend/tests -p test_campaign_report_history.py
No persistent test records, scheduler execution, or provider sends.
"""
import csv
import io
import json
import unittest
from contextlib import asynccontextmanager
from unittest.mock import patch

import httpx
from fastapi import FastAPI
import auth
import routes_campaign_reports as reports
import routes_campaigns as campaigns
from db import db
from postgres_store import PostgresDatabase


class ConnectionPool:
    """Keep all queries on the session whose temp table shadows app_documents."""
    def __init__(self, conn):
        self.conn = conn

    async def fetch(self, *args):
        return await self.conn.fetch(*args)

    async def fetchrow(self, *args):
        return await self.conn.fetchrow(*args)

    async def fetchval(self, *args):
        return await self.conn.fetchval(*args)

    @asynccontextmanager
    async def acquire(self):
        yield self.conn


class HistoryTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.pool = await db.connect()
        self.conn = await self.pool.acquire()
        self.tx = self.conn.transaction(isolation="repeatable_read")
        await self.tx.start()
        await self.conn.execute("""CREATE TEMP TABLE app_documents (
            collection_name text, document_id text, document jsonb,
            PRIMARY KEY(collection_name, document_id)) ON COMMIT DROP""")
        await self.conn.execute("""CREATE INDEX ON app_documents ((document->>'wamid'))
            WHERE collection_name = 'messages'""")
        self.database = PostgresDatabase()
        self.database.pool = ConnectionPool(self.conn)
        self.actor = {"id": "synthetic-admin", "role": "super_admin", "active": True}
        self.patches = [patch.object(m, "db", self.database) for m in (reports, campaigns, auth)]
        for p in self.patches:
            p.start()
        self.app = FastAPI()
        self.app.include_router(reports.router)
        self.app.include_router(campaigns.router)
        self.app.dependency_overrides[auth.get_current_user] = lambda: self.actor
        self.client = httpx.AsyncClient(transport=httpx.ASGITransport(self.app), base_url="http://test")
        await self.insert("campaigns", [{"id": "history", "name": "Synthetic history"}])
        await self.insert("drips", [{"id": "history", "name": "Synthetic drip"}])

    async def asyncTearDown(self):
        await self.client.aclose()
        for p in reversed(self.patches):
            p.stop()
        await self.tx.rollback()
        await self.pool.release(self.conn)
        # unittest creates a fresh event loop for each test.
        await db.close()

    async def insert(self, collection, docs):
        await self.conn.copy_records_to_table("app_documents",
            records=[(collection, d["id"], json.dumps(d)) for d in docs],
            columns=["collection_name", "document_id", "document"])

    async def seed_history(self, drip=False):
        records, messages = [], []
        # Includes rows past both the old recipient limit and receipt limit.
        for i in range(12005):
            kind = i % 7
            record = {"id": f"r{i:05d}", "name": f"Synthetic {i:05d}",
                      "mobile": f"+1555{i:07d}", "contact_id": f"c{i}", "phone": f"1555{i:07d}"}
            if drip:
                record.update(drip_id="history", status="active")
                if kind == 3:
                    record["send_status"] = "uncertain"
                if kind == 4:
                    record["status"] = "stopped"
            else:
                record.update(campaign_id="history",
                    status={3: "uncertain", 4: "skipped", 5: "pending"}.get(kind, "sent"))
            if kind not in (4, 5):
                wids = [f"w{i}-{j}" for j in range(4)]
                if not drip:
                    record["part_wamids"] = wids
                statuses = {
                    0: ["read"] * 4,
                    1: ["read", "delivered", "played", "read"],
                    2: ["read", "sent", "delivered", "read"],
                    3: ["read"] * 4,
                    6: ["read", "error", "delivered", "read"],
                }[kind]
                for wid, status in zip(wids, statuses):
                    message = {"id": wid, "wamid": wid, "status": status}
                    if drip:
                        message.update(drip_id="history", contact_id=record["contact_id"])
                    messages.append(message)
            records.append(record)
        await self.insert("drip_enrollments" if drip else "campaign_recipients", records)
        await self.insert("messages", messages)
        await self.conn.execute("ANALYZE app_documents")
        return {"total": 12005, "sent": 6860, "delivered": 3430, "read": 1715,
                "failed": 1715, "skipped": 1715, "uncertain": 1715, "pending": 1715}

    async def assert_history(self, drip):
        expected = await self.seed_history(drip)
        path = f"/api/{'drips' if drip else 'campaigns'}/history/report"
        first = await self.client.get(path)
        self.assertEqual(first.status_code, 200, first.text)
        data = first.json()
        self.assertEqual(data["summary"], expected)
        self.assertEqual(len(data["recipients"]), 50)
        self.assertEqual(len(data["recipients"][0]["part_deliveries"]), 4)
        self.assertEqual(data["recipients"][0]["delivery"], "read")
        self.assertEqual(data["recipients"][2]["delivery"], "sent")
        self.assertEqual(data["pagination"], {"page": 1, "page_size": 50, "total": 12005, "pages": 241})
        last = (await self.client.get(path, params={"page": 61, "page_size": 200})).json()
        self.assertEqual(last["summary"], expected)
        self.assertEqual(len(last["recipients"]), 5)
        self.assertEqual(last["recipients"][-1]["id"], "r12004")
        filtered = (await self.client.get(path, params={"delivery": "read", "page": 9})).json()
        self.assertEqual(filtered["summary"], expected)
        self.assertEqual(filtered["pagination"]["total"], 1715)
        self.assertTrue(all(r["delivery"] == "read" for r in filtered["recipients"]))
        uncertain = (await self.client.get(path, params={"delivery": "uncertain"})).json()
        self.assertEqual(uncertain["pagination"]["total"], 1715)
        self.assertTrue(all(r["delivery"] == "uncertain" for r in uncertain["recipients"]))
        empty = (await self.client.get(path, params={"search": "%_"})).json()
        self.assertEqual(empty["summary"], expected)
        self.assertEqual(empty["pagination"]["total"], 0)
        self.assertEqual(empty["recipients"], [])
        found = (await self.client.get(path, params={"search": "synthetic 12004"})).json()
        self.assertEqual(found["pagination"]["total"], 1)
        full_csv = await self.client.get(path + ".csv", params={"page": 61, "page_size": 1})
        self.assertEqual(full_csv.status_code, 200, full_csv.text[:200])
        rows = list(csv.reader(io.StringIO(full_csv.text)))
        self.assertEqual(len(rows), 12006)
        self.assertEqual(rows[-1][0], "Synthetic 12004")
        selected_csv = await self.client.get(path + ".csv", params={"delivery": "read", "page": 9})
        selected_rows = list(csv.reader(io.StringIO(selected_csv.text)))
        self.assertEqual(len(selected_rows), 1716)
        self.assertTrue(all(r[3] == "read" for r in selected_rows[1:]))
        combined_csv = await self.client.get(path + ".csv",
            params={"search": "synthetic 11998", "delivery": "read"})
        combined = list(csv.reader(io.StringIO(combined_csv.text)))[1:]
        self.assertEqual(len(combined), 1)
        self.assertEqual(combined[0][0], "Synthetic 11998")

    async def test_campaign_complete_history(self):
        await self.assert_history(False)

    async def test_drip_complete_history(self):
        await self.assert_history(True)

    async def test_missing_parts_uncertainty_and_legacy_drip_phone(self):
        await self.insert("campaign_recipients", [
            {"id": "missing", "campaign_id": "history", "status": "sent", "part_wamids": ["known", "missing"]},
            {"id": "sending", "campaign_id": "history", "status": "sending", "wamid": "known"},
            {"id": "none", "campaign_id": "history", "status": "sent"},
            {"id": "formula", "campaign_id": "history", "status": "failed", "name": "=SUM(1,2)",
             "mobile": "+15550000000", "error": "@formula"}])
        await self.insert("messages", [{"id": "known", "wamid": "known", "status": "played"}])
        result = (await self.client.get("/api/campaigns/history/report")).json()
        self.assertEqual(result["summary"]["delivered"], 0)
        self.assertEqual(result["summary"]["uncertain"], 1)
        missing = next(r for r in result["recipients"] if r["id"] == "missing")
        self.assertEqual(missing["part_deliveries"][1]["status"], "unknown")
        csv_r = await self.client.get("/api/campaigns/history/report.csv")
        self.assertIn("'=SUM(1,2)", csv_r.text)
        self.assertIn("'+15550000000", csv_r.text)
        self.assertIn("'@formula", csv_r.text)
        await self.insert("drip_enrollments", [
            {"id": "phone", "drip_id": "history", "phone": "15550000000", "status": "active"},
            {"id": "no-contact", "drip_id": "history", "status": "active"},
            {"id": "uncertain", "contact_id": "u", "drip_id": "history", "status": "active", "send_status": "sending"}])
        await self.insert("conversations", [{"id": "conv", "phone": "+1 (555) 000-0000"}])
        await self.insert("messages", [
            {"id": "phone-msg", "drip_id": "history", "conversation_id": "conv", "wamid": "p", "status": "delivered"},
            {"id": "demo", "drip_id": "history", "conversation_id": "conv", "wamid": "demo", "status": "sent", "is_demo": True},
            {"id": "u", "drip_id": "history", "contact_id": "u", "wamid": "u", "status": "read"},
            {"id": "unrelated", "drip_id": "history", "contact_id": "other", "wamid": "other", "status": "failed"}])
        drip = (await self.client.get("/api/drips/history/report")).json()
        by_id = {r["id"]: r for r in drip["recipients"]}
        self.assertEqual(by_id["phone"]["delivery"], "delivered")
        self.assertEqual(by_id["phone"]["message_count"], 1)
        self.assertEqual(by_id["no-contact"]["delivery"], "pending")
        self.assertEqual(by_id["uncertain"]["delivery"], "uncertain")

    async def test_validation_and_permissions(self):
        for kind in ("campaigns", "drips"):
            path = f"/api/{kind}/history/report"
            for params in ({"page": 0}, {"page": 10**30}, {"page_size": 201}, {"page_size": 0},
                           {"delivery": "invalid"}, {"search": "a" * 201}):
                self.assertEqual((await self.client.get(path, params=params)).status_code, 422)
            self.assertEqual((await self.client.get(path + ".csv", params={"delivery": "bad"})).status_code, 422)
            self.assertEqual((await self.client.get(f"/api/{kind}/missing/report")).status_code, 404)
        self.actor = {"id": "viewer", "role": "viewer", "active": True}
        for kind in ("campaigns", "drips"):
            # Explicit view-only role proves export does not reuse view permission.
            with patch.dict(auth.ROLE_DEFINITIONS, {"viewer": {"permissions": {"campaigns": ["view"]}}}):
                self.assertEqual((await self.client.get(f"/api/{kind}/history/report")).status_code, 200)
                self.assertEqual((await self.client.get(f"/api/{kind}/history/report.csv")).status_code, 403)
            self.actor["role"] = "unknown-role"
            self.assertEqual((await self.client.get(f"/api/{kind}/history/report")).status_code, 403)
            self.actor["role"] = "viewer"

    async def test_sender_numbers_use_pins_exact_messages_and_archived_accounts(self):
        await self.insert("wa_sessions", [
            {"id": "one", "phone": "15550000001"},
            {"id": "two", "phone": "+15550000002"},
            {"id": "archived", "phone": "+15550000003", "deleted": True, "status": "logged_out"},
            {"id": "demo", "phone": "+15550000004", "is_demo": True}])
        await self.insert("app_config", [{"id": "routing", "key": "whatsapp_number_routing",
            "value": {"general_session_id": "two", "mr_session_id": "two"}}])
        await self.insert("conversations", [{"id": "old-chat", "session_id": "archived", "deleted": True}])
        for drip in (False, True):
            collection, field = ("drip_enrollments", "drip_id") if drip else ("campaign_recipients", "campaign_id")
            docs = []
            for name in ("one", "two", "archived", "unknown", "conflict", "demo", "pinned"):
                docs.append({"id": name, field: "history", "name": name, "contact_id": name,
                    "status": "completed" if drip else "sent",
                    "part_wamids": [f"{drip}-{name}"],
                    **({"sender_session_id": "one"} if name == "pinned" else {})})
            await self.insert(collection, docs)
            messages = [{"id": f"{drip}-{name}", "wamid": f"{drip}-{name}",
                "drip_id": "history" if drip else None, "contact_id": name,
                "direction": "outbound", "status": "read",
                **({"session_id": name} if name in ("one", "two", "demo") else {}),
                **({"conversation_id": "old-chat"} if name == "archived" else {})}
                for name in ("one", "two", "archived", "unknown", "conflict", "demo", "pinned")]
            # Different session copies of the same provider ID are not proof.
            messages += [{"id": f"{drip}-conflict-{s}", "wamid": f"{drip}-conflict",
                          "session_id": s, "status": "sent"} for s in ("one", "two")]
            await self.insert("messages", messages)
            path = f"/api/{'drips' if drip else 'campaigns'}/history/report"
            data = (await self.client.get(path)).json()
            numbers = {r["id"]: r["sender_number"] for r in data["recipients"]}
            self.assertEqual(numbers, {"one": "+15550000001", "two": "+15550000002",
                "archived": "+15550000003", "unknown": "Unknown", "conflict": "Unknown",
                "demo": "Unknown", "pinned": "+15550000001"})
            self.assertTrue(all(r["delivery"] == "read" for r in data["recipients"]))
            exported = list(csv.DictReader(io.StringIO((await self.client.get(path + ".csv")).text)))
            self.assertEqual({r["Name"]: r["Sender number"].lstrip("'") for r in exported}, numbers)
            expected_options = ["+15550000001", "+15550000002", "+15550000003", "Unknown"]
            self.assertEqual(data["sender_numbers"], expected_options)
            for sender in expected_options:
                expected_ids = {rid for rid, number in numbers.items() if number == sender}
                selected = (await self.client.get(path, params={
                    "sender": sender, "page_size": 1, "delivery": "read"})).json()
                self.assertEqual(selected["summary"], data["summary"])
                self.assertEqual(selected["sender_numbers"], expected_options)
                self.assertEqual(selected["pagination"]["total"], len(expected_ids))
                self.assertEqual(len(selected["recipients"]), 1)
                self.assertIn(selected["recipients"][0]["id"], expected_ids)
                csv_rows = list(csv.DictReader(io.StringIO((await self.client.get(
                    path + ".csv", params={"sender": sender, "delivery": "read"})).text)))
                self.assertEqual({r["Name"] for r in csv_rows}, expected_ids)
                self.assertTrue(all(r["Sender number"].lstrip("'") == sender for r in csv_rows))
            combined = (await self.client.get(path, params={
                "sender": "1 (555) 000-0003", "search": "archived", "delivery": "read"})).json()
            self.assertEqual([r["id"] for r in combined["recipients"]], ["archived"])
            no_match = (await self.client.get(path, params={
                "sender": "+15550000003", "delivery": "failed"})).json()
            self.assertEqual(no_match["pagination"]["total"], 0)
            self.assertEqual(no_match["recipients"], [])
            self.assertEqual(no_match["sender_numbers"], expected_options)
            for invalid in ("not-a-phone", "1555", "' OR true --", "1" * 65):
                for endpoint in (path, path + ".csv"):
                    self.assertEqual((await self.client.get(endpoint, params={"sender": invalid})).status_code, 422)
            # Campaign and drip-level pins are read from their own parent only.
            parent = self.database.drips if drip else self.database.campaigns
            await parent.update_one({"id": "history"}, {"$set": {"sender_session_id": "two"}})
            pinned = (await self.client.get(path)).json()
            self.assertEqual(pinned["campaign"]["sender_number"], "+15550000002")
            self.assertEqual(next(r for r in pinned["recipients"] if r["id"] == "pinned")["sender_number"], "+15550000001")
            self.assertEqual(next(r for r in pinned["recipients"] if r["id"] == "unknown")["sender_number"], "+15550000002")

    async def test_sender_snapshot_multipart_and_missing_pin_filter_parity(self):
        import whatsapp_routing as routing
        phones = {"one": "+15550000001", "two": "+15550000002", "alias": "+15550000001"}
        await self.insert("wa_sessions", [{"id": sid, "phone": number} for sid, number in phones.items()])
        records = [
            {"id": "snapshot", "sender_phone": "(+1) 555-000.0003", "sender_session_id": "missing"},
            {"id": "invalid-snapshot", "sender_phone": "wrong", "sender_session_id": "two"},
            {"id": "missing-pin", "sender_session_id": "missing"},
            {"id": "multi"}, {"id": "partial"}, {"id": "alias"}]
        evidence = {
            "snapshot": [], "invalid-snapshot": [], "missing-pin": [["one"]],
            "multi": [["one"], ["two"]], "partial": [["one"], [None]],
            "alias": [["alias"], ["one"]]}
        for record in records:
            parts = [f"{record['id']}-{i}" for i, _ in enumerate(evidence[record["id"]])]
            await self.insert("campaign_recipients", [{
                **record, "name": record["id"], "campaign_id": "history",
                "status": "sent", "part_wamids": parts}])
            for wid, sessions in zip(parts, evidence[record["id"]]):
                await self.insert("messages", [{"id": wid, "wamid": wid, "status": "read",
                    "session_id": sessions[0]}])
        path = "/api/campaigns/history/report"
        data = (await self.client.get(path)).json()
        expected = {r["id"]: routing.report_sender(r, phones, evidence[r["id"]]) for r in records}
        self.assertEqual({r["id"]: r["sender_number"] for r in data["recipients"]}, expected)
        self.assertEqual(data["sender_numbers"], [*sorted(set(phones.values())), "+15550000003", "Unknown"])
        for sender in data["sender_numbers"]:
            ids = {rid for rid, number in expected.items() if sender in number.split(", ")}
            filtered = (await self.client.get(path, params={"sender": sender})).json()
            self.assertEqual({r["id"] for r in filtered["recipients"]}, ids)
            rows = list(csv.DictReader(io.StringIO((await self.client.get(
                path + ".csv", params={"sender": sender})).text)))
            self.assertEqual({r["Name"] for r in rows}, ids)

    async def test_historical_gateway_echo_receipts_are_not_lost(self):
        await self.insert("drip_enrollments", [
            {"id": "read-enrollment", "contact_id": "read-contact", "drip_id": "history", "status": "completed"},
            {"id": "delivered-enrollment", "contact_id": "delivered-contact", "drip_id": "history", "status": "completed"},
            {"id": "partial-enrollment", "contact_id": "partial-contact", "drip_id": "history", "status": "completed"},
            {"id": "uncertain-enrollment", "contact_id": "uncertain-contact", "drip_id": "history", "status": "uncertain"}])
        messages = []
        for name, receipt in (("read", "read"), ("delivered", "delivered"),
                              ("partial", "read"), ("uncertain", "played")):
            messages.extend([
                {"id": f"echo-{name}", "wamid": name, "status": receipt,
                 "created_at": "2026-01-01T00:00:00Z"},
                {"id": f"engine-{name}", "wamid": name, "status": "sent",
                 "drip_id": "history", "contact_id": f"{name}-contact",
                 "created_at": "2026-01-01T00:00:01Z"}])
        messages.extend([
            # An extra historical engine copy must not inflate message_count.
            {"id": "extra-engine-read", "wamid": "read", "status": "sent",
             "drip_id": "history", "contact_id": "read-contact"},
            {"id": "partial-second-part", "wamid": "not-received", "status": "sent",
             "drip_id": "history", "contact_id": "partial-contact"},
            # Demo evidence cannot turn an unconfirmed part into success.
            {"id": "demo-receipt", "wamid": "not-received", "status": "read", "is_demo": True}])
        await self.insert("messages", messages)
        path = "/api/drips/history/report"
        result = (await self.client.get(path)).json()
        self.assertEqual(result["summary"]["delivered"], 2)
        self.assertEqual(result["summary"]["read"], 1)
        self.assertEqual(result["summary"]["uncertain"], 1)
        rows = {r["id"]: r for r in result["recipients"]}
        self.assertEqual(rows["read-enrollment"]["message_count"], 1)
        self.assertEqual(rows["read-enrollment"]["part_deliveries"][0]["status"], "read")
        self.assertEqual(rows["partial-enrollment"]["message_count"], 2)
        self.assertEqual(rows["partial-enrollment"]["delivery"], "sent")
        self.assertEqual(rows["uncertain-enrollment"]["delivery"], "uncertain")
        for outcome, recipient in (("read", "read-enrollment"), ("delivered", "delivered-enrollment")):
            filtered = (await self.client.get(path, params={"delivery": outcome})).json()
            self.assertEqual(filtered["pagination"]["total"], 1)
            self.assertEqual(filtered["recipients"][0]["id"], recipient)
            exported = await self.client.get(path + ".csv", params={"delivery": outcome})
            csv_rows = list(csv.reader(io.StringIO(exported.text)))
            self.assertEqual(len(csv_rows), 2)
            self.assertEqual(csv_rows[1][3], outcome)
            self.assertEqual(csv_rows[1][7], "1")
        # Broadcasts must also ignore a newer stale copy of the exact same ID.
        await self.insert("campaign_recipients", [
            {"id": "broadcast", "campaign_id": "history", "status": "sent", "wamid": "read"}])
        broadcast = (await self.client.get("/api/campaigns/history/report")).json()
        self.assertEqual(broadcast["summary"]["read"], 1)

    async def test_echo_first_drip_metadata_upsert_preserves_receipts(self):
        enrollment = {"id": "enrollment", "contact_id": "contact", "drip_id": "history", "status": "completed"}
        await self.insert("drip_enrollments", [enrollment])
        await self.insert("messages", [
            {"id": "gateway-echo", "wamid": "existing", "status": "read",
             "status_at": "2026-01-01T00:00:00Z", "body": "Original gateway body"}])
        await campaigns._persist_drip_message("history", enrollment, {"id": "synthetic-session"},
                                             "synthetic-conversation", "existing", "New worker body")
        existing = await self.database.messages.find_one({"wamid": "existing"})
        self.assertEqual(await self.database.messages.count_documents({"wamid": "existing"}), 1)
        self.assertEqual(existing["status"], "read")
        self.assertEqual(existing["status_at"], "2026-01-01T00:00:00Z")
        self.assertEqual(existing["body"], "Original gateway body")
        self.assertEqual(existing["drip_id"], "history")
        self.assertEqual(existing["contact_id"], "contact")
        path = "/api/drips/history/report"
        self.assertEqual((await self.client.get(path)).json()["summary"]["read"], 1)
        # Worker-first persistence followed by the gateway's exact-ID receipt.
        await campaigns._persist_drip_message("history", enrollment, {"id": "synthetic-session"},
                                             "synthetic-conversation", "subsequent", "Synthetic")
        result = (await self.client.get(path)).json()
        self.assertEqual(result["summary"]["delivered"], 0)  # second part still sent
        await self.database.messages.update_one({"wamid": "subsequent"}, {"$set": {"status": "delivered"}})
        result = (await self.client.get(path, params={"delivery": "delivered"})).json()
        self.assertEqual(result["summary"]["delivered"], 1)
        self.assertEqual(result["summary"]["read"], 0)
        self.assertEqual(result["pagination"]["total"], 1)
        await self.database.messages.update_one({"wamid": "subsequent"}, {"$set": {"status": "read"}})
        await campaigns._persist_drip_message("history", enrollment, {"id": "synthetic-session"},
                                             "synthetic-conversation", "subsequent", "Synthetic")
        self.assertEqual(await self.database.messages.count_documents({"wamid": "subsequent"}), 1)
        result = (await self.client.get(path, params={"delivery": "read"})).json()
        self.assertEqual(result["summary"]["read"], 1)
        self.assertEqual(result["recipients"][0]["message_count"], 2)
        csv_r = await self.client.get(path + ".csv", params={"delivery": "read"})
        self.assertEqual(list(csv.reader(io.StringIO(csv_r.text)))[1][3], "read")


if __name__ == "__main__":
    unittest.main()