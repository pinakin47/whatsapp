"""Isolated API/scheduler checks; every delivery and database is an in-memory mock."""
import copy
import asyncio
import unittest
from contextlib import ExitStack
from datetime import datetime, timedelta
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch
from fastapi import FastAPI
import httpx
import auth
import routes_mr_reporting as reporting
import routes_mr_settings as legacy
import routes_campaigns as campaigns
from test_settings_campaigns import Collection, fake_lock
import test_settings_campaigns


def matches(row, query):
    for key, expected in query.items():
        value = row.get(key)
        if isinstance(expected, dict):
            for op, operand in expected.items():
                if op == "$ne" and value == operand: return False
                if op == "$in" and value not in operand: return False
                if op == "$lt" and (value is None or value >= operand): return False
                if op == "$gte" and (value is None or value < operand): return False
                if op == "$exists" and (key in row) != operand: return False
        elif value != expected:
            return False
    return True


class ReportingTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.actor = {"id": "owner", "role": "super_admin", "name": "Synthetic administrator",
                      "active": True, "email": "admin@example.com", "phone": "+15550002222"}
        names = ("users", "roles", "app_config", "mr_directory", "mr_daily_reports", "wa_sessions",
                 "mr_report_submissions", "mr_report_notifications", "mr_ivr_invites",
                 "consent_records", "contacts", "whatsapp_send_requests", "messages",
                 "conversations", "audit_logs", "mr_reminder_runs", "mr_ivr_profiles",
                 "whatsapp_receipts")
        self.db = SimpleNamespace(**{n: Collection() for n in names})
        # Generic fake supports single-row updates; supply a safe multi-row implementation.
        async def update_many(query, update):
            for row in list(self.db.mr_report_notifications.records):
                if matches(row, query):
                    await self.db.mr_report_notifications.update_one({"id": row["id"]}, update)
        self.db.mr_report_notifications.update_many = update_many
        self.db.users.records.append(self.actor.copy())
        self.mr = {"id": "mr", "name": "Synthetic MR", "employee_id": "MR001",
                   "phone": "+15550001111", "email": "mr@example.com", "active": True}
        self.db.mr_directory.records.append(self.mr.copy())
        self.stack = ExitStack()
        self.stack.enter_context(patch.object(test_settings_campaigns, "matches", matches))
        for module in (auth, reporting, legacy, campaigns):
            self.stack.enter_context(patch.object(module, "db", self.db))
        self.stack.enter_context(patch.object(reporting, "mr_lock", fake_lock))
        self.stack.enter_context(patch.object(reporting, "log_audit", AsyncMock()))
        self.stack.enter_context(patch.object(legacy, "log_audit", AsyncMock()))
        self.stack.enter_context(patch.object(reporting.asyncio, "sleep", AsyncMock()))
        self.stack.enter_context(patch.object(reporting, "refresh_role_definitions", AsyncMock()))
        self.sessions = self.stack.enter_context(patch.object(reporting.wa_client, "wa_list_sessions",
            AsyncMock(return_value={"sessions": [{"id": "qr-mock", "status": "connected"}]})))
        self.send = self.stack.enter_context(patch.object(reporting.wa_client, "wa_send",
            AsyncMock(return_value={"wamid": "mock-message"})))
        self.email = self.stack.enter_context(patch.object(reporting.brevo_client, "send_email",
            AsyncMock(return_value="Sent")))
        self.stack.enter_context(patch.object(reporting.brevo_client, "configured", return_value=True))
        self.day = datetime(2026, 10, 5, 8, 0, tzinfo=reporting.IST)
        app = FastAPI()
        app.include_router(reporting.router)
        app.dependency_overrides[auth.get_current_user] = lambda: self.actor
        self.client = httpx.AsyncClient(transport=httpx.ASGITransport(app), base_url="http://mock")

    async def asyncTearDown(self):
        await self.client.aclose()
        self.stack.close()

    async def enable(self, **extra):
        response = await self.client.put("/api/settings/mr-ivr", json={
            **reporting.DEFAULT_CONFIG, "enabled": True, "confirm_enable": True, **extra})
        self.assertEqual(response.status_code, 200, response.text)

    def qr_fixture(self, kind):
        """Reset only isolated collections; no real DB, gateway or email access."""
        for collection in vars(self.db).values():
            collection.records.clear()
        self.db.users.records.extend([
            self.actor.copy(),
            {**self.actor, "id": "recipient", "phone": "+15550003333"},
        ])
        self.db.mr_directory.records.append(self.mr.copy())
        self.db.app_config.records.append({
            "key": "mr_ivr", "approved_by": "owner",
            "value": {**reporting.DEFAULT_CONFIG, "enabled": True},
        })
        claim = {"id": "queued", "user_id": "recipient", "channel": "whatsapp"}
        phone = "+15550003333"
        collection = self.db.mr_report_notifications
        if kind == "manual":
            claim.update(original_notification_id="original", requested_by="owner")
        elif kind == "invitation":
            claim = {"id": "queued", "mr_id": "mr", "date": "2026-10-05", "phase": "plan"}
            phone = self.mr["phone"]
            collection = self.db.mr_ivr_invites
        return claim, phone, collection

    def revoke_qr(self, change, kind, phone, denied):
        config = self.db.app_config.records[0]
        actor = self.db.users.records[0]
        recipient = (self.db.mr_directory.records[0] if kind == "invitation"
                     else self.db.users.records[1])
        if change in ("enabled", "whatsapp_reports"):
            config["value"][change] = False
        elif change == "approval":
            config["approved_by"] = "another-owner"
        elif change.startswith("actor_"):
            actor[change.removeprefix("actor_")] = change != "actor_active"
        elif change.startswith("permission_"):
            denied.append(tuple(change.removeprefix("permission_").split(":")))
        elif change.startswith("recipient_"):
            flag = change.removeprefix("recipient_")
            recipient[flag] = False if flag == "active" else (
                "mr" if flag == "role" else "+15550004444" if flag == "phone" else True)
        elif change == "missing_recipient":
            (self.db.mr_directory if kind == "invitation" else self.db.users).records.remove(recipient)
        elif change == "consent":
            self.db.consent_records.records.append({"phone": phone.lstrip("+"), "status": "opted_out"})
        elif change == "contact_opt_out":
            self.db.contacts.records.append({"mobile": phone, "opted_out": True})
        elif change == "individual_disabled":
            self.db.mr_ivr_profiles.records.append({"id": "mr", "value": {"ivr_enabled": False}})
        elif change == "submitted":
            self.db.mr_daily_reports.records.append({
                "id": "2026-10-05:mr", "plan_submitted_at": self.day.isoformat()})
        else:
            self.fail(f"Unknown authorization mutation: {change}")

    def qr_permissions(self, denied):
        def current(role):
            perms = copy.deepcopy(auth.permissions_for(role))
            for module, action in denied:
                perms.get(module, []).remove(action)
            return perms
        return current

    async def test_qr_rechecks_after_each_reservation_and_never_reuses_consumed_claims(self):
        common = ("enabled", "whatsapp_reports", "actor_active", "actor_deleted", "actor_is_demo",
                  "permission_settings:manage", "permission_whatsapp:send",
                  "recipient_active", "recipient_deleted", "recipient_is_demo", "recipient_phone",
                  "missing_recipient", "consent", "contact_opt_out")
        for kind in ("scheduled", "manual", "invitation"):
            changes = common + (("individual_disabled", "submitted", "approval") if kind == "invitation"
                                else ("recipient_role", "approval") if kind == "scheduled"
                                else ("recipient_role", "permission_reports:manage",
                                      "permission_reports:send", "permission_field_sales:view"))
            for stage in ("claim", "gateway"):
                for change in changes:
                    with self.subTest(kind=kind, stage=stage, change=change):
                        claim, phone, collection = self.qr_fixture(kind)
                        baseline = {name: copy.deepcopy(c.records) for name, c in vars(self.db).items()}
                        denied = []
                        target = collection if stage == "claim" else self.db.whatsapp_send_requests
                        update = target.update_one

                        async def reserve_then_revoke(query, value, **kwargs):
                            result = await update(query, value, **kwargs)
                            if result.upserted_id:
                                self.revoke_qr(change, kind, phone, denied)
                            return result

                        self.send.reset_mock()
                        with patch.object(target, "update_one", side_effect=reserve_then_revoke), \
                                patch.object(reporting, "permissions_for", side_effect=self.qr_permissions(denied)):
                            await reporting.send_qr(collection, claim, phone, "Saved report",
                                                    {"id": "qr-mock"}, self.actor)
                        self.send.assert_not_awaited()
                        saved = await collection.find_one({"id": claim["id"]})
                        self.assertEqual(saved["status"], "uncertain")
                        self.assertEqual(len(self.db.whatsapp_send_requests.records), 1)
                        request = copy.deepcopy(self.db.whatsapp_send_requests.records[0])
                        # Restore authorization only, keeping both consumed reservations.
                        for name, records in baseline.items():
                            if name not in ("mr_report_notifications", "mr_ivr_invites",
                                            "whatsapp_send_requests"):
                                getattr(self.db, name).records[:] = records
                        await reporting.send_qr(collection, claim, phone, "Saved report",
                                                {"id": "qr-mock"}, self.actor)
                        self.send.assert_not_awaited()
                        self.assertEqual(await collection.find_one({"id": claim["id"]}), saved)
                        self.assertEqual(self.db.whatsapp_send_requests.records, [request])

    async def test_scheduled_qr_revocation_during_parent_reservation_blocks_delivery(self):
        for change in ("enabled", "whatsapp_reports", "approval", "actor_active",
                       "permission_whatsapp:send", "recipient_role", "consent"):
            with self.subTest(change=change):
                _, phone, collection = self.qr_fixture("scheduled")
                self.db.mr_directory.records.clear()
                self.submission()
                self.db.app_config.records[0]["value"]["email_reports"] = False
                denied = []
                update = collection.update_one

                async def reserve_parent_then_revoke(query, value, **kwargs):
                    result = await update(query, value, **kwargs)
                    if result.upserted_id:
                        self.revoke_qr(change, "scheduled", phone, denied)
                    return result

                # Only the distinct recipient is selected for this scheduled snapshot.
                find = self.db.users.find
                def recipients(query, *args):
                    return find({**query, "id": "recipient"}, *args)

                self.send.reset_mock()
                with patch.object(collection, "update_one", side_effect=reserve_parent_then_revoke), \
                        patch.object(self.db.users, "find", side_effect=recipients), \
                        patch.object(reporting, "permissions_for", side_effect=self.qr_permissions(denied)):
                    await reporting.reporting_tick(self.day.replace(hour=12))
                self.send.assert_not_awaited()
                self.email.assert_not_awaited()
                self.assertEqual(len(collection.records), 1)
                parent = collection.records[0]
                self.assertEqual(parent["status"], "uncertain")
                self.assertEqual(self.db.whatsapp_send_requests.records, [])
                # A later tick after restoring permission must not reuse the parent.
                self.db.app_config.records[0]["value"].update(enabled=True, whatsapp_reports=True)
                self.db.app_config.records[0]["approved_by"] = "owner"
                self.db.users.records[0] = self.actor.copy()
                self.db.users.records[1]["role"] = "super_admin"
                self.db.consent_records.records.clear()
                with patch.object(self.db.users, "find", side_effect=recipients):
                    await reporting.reporting_tick(self.day.replace(hour=12))
                self.send.assert_not_awaited()
                self.assertEqual(collection.records, [parent])

    async def test_multipart_revocation_preserves_accepted_parts_and_blocks_next_provider_call(self):
        for kind in ("scheduled", "manual"):
            for stage in ("claim", "gateway"):
                with self.subTest(kind=kind, stage=stage):
                    claim, phone, collection = self.qr_fixture(kind)
                    collection.records.append({**claim, "status": "sending"})
                    target = collection if stage == "claim" else self.db.whatsapp_send_requests
                    update = target.update_one
                    reservations = 0

                    async def disable_on_second_part(query, value, **kwargs):
                        nonlocal reservations
                        result = await update(query, value, **kwargs)
                        if result.upserted_id:
                            reservations += 1
                            if reservations == 2:
                                self.db.app_config.records[0]["value"]["whatsapp_reports"] = False
                        return result

                    report = {"id": "report", "date": "2026-10-05", "mr_name": "Synthetic MR",
                              "closing": {"remarks": "x" * 6500}}
                    config = self.db.app_config.records[0]["value"].copy()
                    self.send.reset_mock()
                    with patch.object(target, "update_one", side_effect=disable_on_second_part):
                        await reporting.deliver_report(claim, report, phone, {"id": "qr-mock"},
                                                       self.actor, config)
                    self.assertEqual(self.send.await_count, 1)
                    parent = await collection.find_one({"id": "queued"})
                    first = await collection.find_one({"id": "queued:part:0"})
                    second = await collection.find_one({"id": "queued:part:1"})
                    self.assertEqual((parent["status"], parent["required_parts"]), ("uncertain", 3))
                    self.assertEqual((first["status"], first["wamid"]), ("sent", "mock-message"))
                    self.assertEqual(second["status"], "uncertain")
                    self.assertIsNone(await collection.find_one({"id": "queued:part:2"}))
                    self.assertEqual([r["state"] for r in self.db.whatsapp_send_requests.records],
                                     ["accepted", "sending"])
                    requests = copy.deepcopy(self.db.whatsapp_send_requests.records)
                    self.db.app_config.records[0]["value"]["whatsapp_reports"] = True
                    await reporting.deliver_report(claim, report, phone, {"id": "qr-mock"},
                                                   self.actor, config)
                    self.assertEqual(self.send.await_count, 1)
                    self.assertEqual(await collection.find_one({"id": first["id"]}), first)
                    self.assertEqual(await collection.find_one({"id": second["id"]}), second)
                    self.assertEqual(self.db.whatsapp_send_requests.records, requests)

    def submission(self):
        self.db.mr_report_submissions.records.append({
            "id": "submission", "submitted_at": self.day.isoformat(), "report": {
                "id": "2026-10-05:mr", "date": "2026-10-05", "mr_id": "account",
                "mr_name": "Synthetic MR", "employee_id": "MR001",
                "plan": {"planned_visits": 8, "expected_sales": 50000},
                "closing": {"completed_visits": 7, "sales": 45000, "problems": "<script>bad</script>"},
                "summary": {"planned_visits": 8, "completed_visits": 7, "sales": 45000},
            }})

    def large_history(self, report_count, attempts):
        """Multiple original/manual copies share each immutable two-part snapshot."""
        for collection in (self.db.mr_daily_reports, self.db.mr_report_notifications,
                           self.db.mr_report_submissions, self.db.messages):
            collection.records.clear()
        for r in range(report_count):
            report = {"id": f"report-{r}", "date": "2026-10-05",
                      "mr_id": "owner" if r == 0 else f"mr-{r}", "mr_name": f"MR {r:03}"}
            self.db.mr_daily_reports.records.append(report)
            for a in range(attempts):
                sid = f"snapshot-{r}-{a}"
                self.db.mr_report_submissions.records.append({
                    "id": sid, "report": {**report, "closing": {"remarks": "x" * 4000}}})
                for manual in (False, True):
                    cid = f"attempt-{r}-{a}" + (":manual" if manual else "")
                    base = {"report_id": report["id"], "submission_id": sid,
                            "user_id": "owner", "channel": "whatsapp", "status": "uncertain",
                            "created_at": f"2026-10-05T08:{a:02}:00Z"}
                    parent = {**base, "id": cid}
                    if manual:
                        parent["original_notification_id"] = f"attempt-{r}-{a}"
                    # Invalid historical counts must all use the immutable snapshot.
                    if a % 3 == 0:
                        parent["required_parts"] = True
                    elif a % 3 == 1:
                        parent["required_parts"] = 0
                    self.db.mr_report_notifications.records.append(parent)
                    for p in range(2):
                        # Originals lack part 2. Manual copies must not fill it.
                        if p == 1 and not manual:
                            continue
                        wid = f"wamid-{r}-{a}-{p}" if manual else f"original-{r}-{a}"
                        part = {**base, "id": f"{cid}:part:{p}", "part": p + 1,
                                "attempt_id": cid, "wamid": wid}
                        if manual and a % 4 == 1 and p == 1:
                            part["wamid"] = f"wamid-{r}-{a}-0"  # duplicate cannot complete
                        if manual and a % 4 == 2 and p == 1:
                            part["user_id"] = "wrong-recipient"
                        self.db.mr_report_notifications.records.append(part)
                        self.db.messages.records.extend([
                            {"wamid": wid, "status": "read", "read_at": f"2026-10-05T08:00:0{p + 3}Z",
                             "delivered_at": f"2026-10-05T08:00:0{p + 1}Z"},
                            {"wamid": wid, "status": "sent"},  # stale duplicate must not downgrade
                            {"wamid": wid, "status": "failed"},
                        ])
                self.db.mr_report_notifications.records.append({
                    "id": f"email-{r}-{a}", "report_id": report["id"], "submission_id": sid,
                    "user_id": "owner", "channel": "email", "status": "unavailable",
                    "provider_io": False, "created_at": "2026-10-05T07:00:00Z"})
        self.db.messages.records.extend([
            {"wamid": "unrelated", "status": "read"},
            {"wamid": "original-0-0", "status": "read", "is_demo": True}])

    def track_history_reads(self, stack):
        reads = {}
        for name in ("mr_daily_reports", "mr_report_notifications", "messages", "mr_report_submissions"):
            collection = getattr(self.db, name)
            reads[name] = stack.enter_context(patch.object(collection, "find", wraps=collection.find))
            # A find_one loop must never be substituted for the batch.
            stack.enter_context(patch.object(collection, "find_one",
                side_effect=AssertionError("History must use batched reads")))
        return reads

    async def test_large_history_has_four_reads_and_preserves_delivery_and_resend_decisions(self):
        for report_count, attempts in ((2, 2), (60, 20)):
            with self.subTest(reports=report_count, attempts=attempts):
                self.large_history(report_count, attempts)
                before = copy.deepcopy(vars(self.db))
                with ExitStack() as stack:
                    reads = self.track_history_reads(stack)
                    render = stack.enter_context(patch.object(reporting, "report_text",
                                                              wraps=reporting.report_text))
                    response = await self.client.get("/api/field/daily-reports?date=2026-10-05")
                    self.assertEqual(response.status_code, 200, response.text)
                    self.assertEqual([m.call_count for m in reads.values()], [1, 1, 1, 1])
                    self.assertEqual(render.call_count, report_count * attempts)
                    query = reads["messages"].call_args.args[0]
                    expected_ids = {c["wamid"] for c in self.db.mr_report_notifications.records
                                    if c.get("wamid")}
                    self.assertEqual(set(query["wamid"]["$in"]), expected_ids)
                    self.assertEqual(query["is_demo"], {"$ne": True})
                    self.assertEqual(set(reads["mr_report_submissions"].call_args.args[0]["id"]["$in"]),
                                     {s["id"] for s in self.db.mr_report_submissions.records})
                rows = response.json()["items"]
                self.assertEqual(len(rows), report_count)
                for row in rows:
                    r = int(row["id"].split("-")[1])
                    claims = {c["id"]: c for c in row["notifications"]}
                    for a in range(attempts):
                        original = claims[f"attempt-{r}-{a}"]
                        manual = claims[f"attempt-{r}-{a}:manual"]
                        self.assertEqual(original["delivery"]["status"], "partial")
                        self.assertEqual(original["delivery"]["required_parts"], 2)
                        self.assertIsNone(original["delivery"]["read_at"])
                        complete = a % 4 in (0, 3)
                        self.assertEqual(manual["delivery"]["status"], "read" if complete else "partial")
                        self.assertEqual(manual["delivery"]["delivered_at"],
                                         "2026-10-05T08:00:02.000Z" if complete else None)
                        self.assertEqual(manual["delivery"]["read_at"],
                                         "2026-10-05T08:00:04.000Z" if complete else None)
                        self.assertEqual(original["status"], "uncertain")
                        self.assertEqual(manual["status"], "uncertain")
                        self.assertFalse(original["can_send_now"])
                        self.assertFalse(manual["can_send_now"])
                        email = claims[f"email-{r}-{a}"]
                        self.assertTrue(email["can_send_now"])
                        self.assertNotIn("delivery", email)
                for name in vars(self.db):
                    self.assertEqual(getattr(self.db, name).records, getattr(before[name], "records"))
                self.send.assert_not_awaited()
                self.email.assert_not_awaited()
                reporting.log_audit.assert_not_awaited()

    async def test_batched_history_reads_are_scoped_to_selected_reports(self):
        self.large_history(40, 8)
        for role, selected, params in (
                ("mr", 0, "&mr_id=mr-9"),  # an MR cannot select someone else's history
                ("super_admin", 9, "&mr_id=mr-9")):
            with self.subTest(role=role):
                self.actor["role"] = role
                with ExitStack() as stack:
                    reads = self.track_history_reads(stack)
                    response = await self.client.get("/api/field/daily-reports?date=2026-10-05" + params)
                    self.assertEqual(response.status_code, 200, response.text)
                    self.assertEqual([r["id"] for r in response.json()["items"]], [f"report-{selected}"])
                    self.assertEqual(reads["mr_report_notifications"].call_args.args[0],
                                     {"report_id": {"$in": [f"report-{selected}"]}})
                    wamids = set(reads["messages"].call_args.args[0]["wamid"]["$in"])
                    expected = {c["wamid"] for c in self.db.mr_report_notifications.records
                                if c["report_id"] == f"report-{selected}" and c.get("wamid")}
                    self.assertEqual(wamids, expected)
                    self.assertEqual(set(reads["mr_report_submissions"].call_args.args[0]["id"]["$in"]),
                                     {f"snapshot-{selected}-{a}" for a in range(8)})
        with ExitStack() as stack:
            reads = self.track_history_reads(stack)
            response = await self.client.get("/api/field/daily-reports?date=2026-10-06")
            self.assertEqual(response.json()["items"], [])
            self.assertEqual([m.call_count for m in reads.values()], [1, 0, 0, 0])

    async def test_batch_missing_and_wrong_snapshots_do_not_borrow_other_reports_counts(self):
        self.large_history(2, 1)
        # A wrong snapshot must not even be rendered (it may lack report fields).
        self.db.mr_report_submissions.records[0]["report"] = {"id": "report-1"}
        self.db.mr_report_submissions.records.pop()
        response = await self.client.get("/api/field/daily-reports?date=2026-10-05")
        self.assertEqual(response.status_code, 200, response.text)
        for row in response.json()["items"]:
            for claim in row["notifications"]:
                if claim["channel"] == "whatsapp" and not claim.get("part"):
                    self.assertIsNone(claim["delivery"]["required_parts"])
                    self.assertIn(claim["delivery"]["status"], ("partial", "unknown"))
                    self.assertIsNone(claim["delivery"]["read_at"])
                    self.assertFalse(claim["can_send_now"])
        self.send.assert_not_awaited()
        self.email.assert_not_awaited()

    async def test_exact_multipart_receipts_stay_separate_from_send_and_retry(self):
        self.submission()
        report = copy.deepcopy(self.db.mr_report_submissions.records[0]["report"])
        self.db.mr_daily_reports.records.append(report)
        base = {"report_id": report["id"], "submission_id": "submission",
                "user_id": "owner", "channel": "whatsapp", "status": "uncertain"}
        claims = [
            {**base, "id": "original", "required_parts": 2},
            {**base, "id": "original:part:0", "part": 1, "attempt_id": "original", "wamid": "a", "status": "sent"},
            {**base, "id": "original:manual", "original_notification_id": "original", "required_parts": 2},
            {**base, "id": "original:manual:part:0", "part": 1, "attempt_id": "original:manual", "wamid": "b"},
            {**base, "id": "original:manual:part:1", "part": 2, "attempt_id": "original:manual", "wamid": "c"},
            {**base, "id": "email", "channel": "email", "status": "sent"},
        ]
        self.db.mr_report_notifications.records.extend(claims)
        self.db.messages.records.extend([
            {"wamid": "a", "status": "read"},
            {"wamid": "a", "status": "sent"},  # newer stale copies do not downgrade
            {"wamid": "b", "status": "delivered"},
            {"wamid": "c", "status": "sent"},
            {"wamid": "c", "status": "read", "is_demo": True},
            {"wamid": "unrelated", "status": "read", "body": "same report"},
        ])

        async def history():
            response = await self.client.get("/api/field/daily-reports", params={"date": report["date"]})
            self.assertEqual(response.status_code, 200, response.text)
            return {c["id"]: c for c in response.json()["items"][0]["notifications"]}

        rows = await history()
        self.assertEqual(rows["original"]["delivery"], {
            "status": "partial", "required_parts": 2, "delivered_parts": 1,
            "read_parts": 1, "failed_parts": 0, "delivered_at": None, "read_at": None})
        self.assertEqual(rows["original:manual"]["delivery"]["status"], "partial")
        self.assertEqual(rows["original:part:0"]["delivery"]["status"], "read")
        self.assertNotIn("delivery", rows["email"])
        self.db.messages.records.append({"wamid": "c", "status": "read"})
        rows = await history()
        self.assertEqual(rows["original:manual"]["delivery"]["status"], "delivered")
        self.db.messages.records.append({"wamid": "b", "status": "played"})
        rows = await history()
        self.assertEqual(rows["original:manual"]["delivery"]["status"], "read")
        self.assertEqual(rows["original:manual"]["status"], "uncertain")
        self.assertFalse(any(c["can_send_now"] for c in rows.values()))
        response = await self.client.post("/api/field/report-notifications/original/send-now",
                                          json={"confirm": True})
        self.assertEqual(response.status_code, 409)
        self.send.assert_not_awaited()
        self.email.assert_not_awaited()
        self.assertEqual(self.db.mr_report_notifications.records, claims)

    async def test_stage_times_require_every_part_and_use_last_completion_not_creation(self):
        self.submission()
        report = self.db.mr_report_submissions.records[0]["report"]
        self.db.mr_daily_reports.records.append(copy.deepcopy(report))
        base = {"report_id": report["id"], "submission_id": "submission", "user_id": "owner",
                "channel": "whatsapp", "status": "uncertain", "created_at": "2020-01-01T00:00:00Z"}
        self.db.mr_report_notifications.records.extend([
            {**base, "id": "timed", "required_parts": 2},
            {**base, "id": "timed:part:0", "attempt_id": "timed", "part": 1, "wamid": "time-a"},
            {**base, "id": "timed:part:1", "attempt_id": "timed", "part": 2, "wamid": "time-b"},
        ])
        self.db.messages.records.extend([
            {"wamid": "time-a", "status": "read", "delivered_at": "2026-10-05T08:00:02Z",
             "read_at": "2026-10-05T08:00:08Z"},
            {"wamid": "time-a", "status": "sent", "delivered_at": "2026-10-05T08:00:04Z"},
            {"wamid": "time-b", "status": "delivered", "created_at": "2020-01-01T00:00:00Z",
             "status_at": "2026-10-05T08:00:10Z"},  # old processing time is NOT evidence
            {"wamid": "time-b", "status": "read", "read_at": "2026-10-05T08:00:05Z", "is_demo": True},
        ])

        async def history():
            response = await self.client.get("/api/field/daily-reports", params={"date": report["date"]})
            self.assertEqual(response.status_code, 200)
            return {c["id"]: c for c in response.json()["items"][0]["notifications"]}

        rows = await history()
        self.assertEqual(rows["timed"]["delivery"]["status"], "delivered")
        self.assertIsNone(rows["timed"]["delivery"]["delivered_at"])
        self.assertIsNone(rows["timed"]["delivery"]["read_at"])
        self.assertEqual(rows["timed:part:0"]["delivery"]["read_at"], "2026-10-05T08:00:08.000Z")
        self.db.messages.records.append({"wamid": "time-b", "status": "read",
            "read_at": "2026-10-05T08:00:06Z", "delivered_at": "2026-10-05T08:00:03+00:00"})
        rows = await history()
        self.assertEqual(rows["timed"]["delivery"]["delivered_at"], "2026-10-05T08:00:03.000Z")
        self.assertEqual(rows["timed"]["delivery"]["read_at"], "2026-10-05T08:00:08.000Z")
        self.assertEqual(rows["timed"]["status"], "uncertain")
        self.send.assert_not_awaited()
        self.email.assert_not_awaited()
        self.db.mr_report_notifications.records[0]["required_parts"] = 3
        rows = await history()
        self.assertIsNone(rows["timed"]["delivery"]["delivered_at"])
        self.assertIsNone(rows["timed"]["delivery"]["read_at"])

    async def test_legacy_receipts_need_snapshot_and_duplicate_wamids_do_not_count_twice(self):
        self.submission()
        report = self.db.mr_report_submissions.records[0]["report"]
        report["closing"]["remarks"] = "x" * 4000  # two required parts
        base = {"report_id": report["id"], "submission_id": "submission",
                "user_id": "owner", "channel": "whatsapp", "status": "sent"}
        claims = [{**base, "id": "legacy"},
                  {**base, "id": "legacy:part:0", "part": 1, "wamid": "same"},
                  {**base, "id": "legacy:part:1", "part": 2, "wamid": "same"},
                  {**base, "id": "unknown", "submission_id": "missing"},
                  {**base, "id": "unknown:part:0", "part": 1, "attempt_id": "unknown", "wamid": "same"}]
        self.db.messages.records.append({"wamid": "same", "status": "read"})
        await reporting.attach_report_receipts(claims)
        self.assertEqual(claims[0]["delivery"]["required_parts"], 2)
        self.assertEqual(claims[0]["delivery"]["status"], "partial")
        self.assertIsNone(claims[3]["delivery"]["required_parts"])
        self.assertEqual(claims[3]["delivery"]["status"], "partial")
        claims[2]["wamid"] = "second"
        self.db.messages.records.append({"wamid": "second", "status": "failed"})
        await reporting.attach_report_receipts(claims)
        self.assertEqual(claims[0]["delivery"]["status"], "failed")
        self.db.messages.records.append({"wamid": "second", "status": "delivered"})
        await reporting.attach_report_receipts(claims)
        self.assertEqual(claims[0]["delivery"]["status"], "delivered")

    async def test_required_part_count_is_saved_before_first_provider_call(self):
        self.submission()
        report = self.db.mr_report_submissions.records[0]["report"]
        report["closing"]["remarks"] = "x" * 6500
        claim = {"id": "interrupted", "channel": "whatsapp", "status": "sending"}
        self.db.mr_report_notifications.records.append(claim.copy())

        async def stop_at_first_part(*args):
            saved = await self.db.mr_report_notifications.find_one({"id": claim["id"]})
            self.assertEqual(saved["required_parts"], 3)
            # Simulate an unresolved first part without any external IO.
        with patch.object(reporting, "send_qr", side_effect=stop_at_first_part):
            await reporting.deliver_report(claim, report, "+15550000000", {"id": "qr"},
                                           self.actor, reporting.DEFAULT_CONFIG)
        saved = await self.db.mr_report_notifications.find_one({"id": claim["id"]})
        self.assertEqual(saved["status"], "uncertain")
        self.assertEqual(saved["required_parts"], 3)
        self.send.assert_not_awaited()

    async def test_defaults_confirmation_and_schedule_validation(self):
        config = (await self.client.get("/api/settings/mr-ivr")).json()
        self.assertFalse(config["enabled"])
        self.assertEqual((config["morning_time"], config["closing_time"]), ("08:00", "20:00"))
        await reporting.reporting_tick(self.day)
        self.send.assert_not_awaited()
        response = await self.client.put("/api/settings/mr-ivr", json={**config, "enabled": True})
        self.assertEqual(response.status_code, 422)
        response = await self.client.put("/api/settings/mr-ivr", json={**config, "morning_time": "25:00"})
        self.assertEqual(response.status_code, 422)
        response = await self.client.put("/api/settings/mr-ivr", json={**config, "closing_time": "08:00"})
        self.assertEqual(response.status_code, 422)

    async def test_scheduled_email_revocation_after_claim_blocks_io_without_releasing(self):
        for revoke in ("reporting", "email", "recipient", "approver", "approval", "contact", "permissions"):
            with self.subTest(revoke=revoke):
                await self.enable(whatsapp_reports=False)
                self.db.mr_directory.records.clear()
                self.db.mr_report_notifications.records.clear()
                self.db.mr_report_submissions.records.clear()
                self.db.users.records[:] = [
                    {"id": "owner", "role": "super_admin", "active": True, "name": "Synthetic administrator",
                     "email": "admin@example.com", "phone": "+15550002222"},
                    {"id": "recipient", "role": "admin", "active": True, "email": "second@example.com"},
                ]
                self.submission()
                original = self.db.mr_report_notifications.update_one
                async def reserve_then_revoke(query, update, upsert=False):
                    result = await original(query, update, upsert)
                    row = update.get("$setOnInsert", {})
                    if row.get("channel") == "email":
                        config = self.db.app_config.records[0]
                        if revoke == "reporting": config["value"]["enabled"] = False
                        if revoke == "email": config["value"]["email_reports"] = False
                        if revoke == "recipient":
                            next(u for u in self.db.users.records if u["id"] == row["user_id"])["active"] = False
                        if revoke == "approver": self.db.users.records[0]["active"] = False
                        if revoke == "approval": config["approved_by"] = "another-admin"
                        if revoke == "contact":
                            next(u for u in self.db.users.records if u["id"] == row["user_id"])["email"] = "changed@example.com"
                        if revoke == "permissions": self.db.users.records[0]["role"] = "mr"
                    return result
                self.email.reset_mock()
                with patch.object(self.db.mr_report_notifications, "update_one", reserve_then_revoke):
                    await reporting.reporting_tick(self.day.replace(hour=12))
                self.email.assert_not_awaited()
                rows = self.db.mr_report_notifications.records
                self.assertEqual(len(rows), 1)
                self.assertEqual(rows[0]["status"], "uncertain")
                # Restoring permissions does not free or retry an already-consumed claim.
                self.db.users.records[:] = [
                    {"id": "owner", "role": "super_admin", "active": True, "name": "Synthetic administrator",
                     "email": "admin@example.com", "phone": "+15550002222"}]
                self.db.app_config.records[0]["approved_by"] = "owner"
                self.db.app_config.records[0]["value"].update(enabled=True, email_reports=True)
                await reporting.reporting_tick(self.day.replace(hour=12))
                self.email.assert_not_awaited()
    async def test_both_invites_once_per_phase_and_legacy_suppressed(self):
        await self.enable()
        await reporting.reporting_tick(self.day - timedelta(seconds=1))
        self.send.assert_not_awaited()
        await reporting.reporting_tick(self.day)
        await reporting.reporting_tick(self.day)
        self.assertEqual(self.send.await_count, 1)
        await reporting.reporting_tick(self.day.replace(hour=20))
        await reporting.reporting_tick(self.day.replace(hour=20))
        self.assertEqual(self.send.await_count, 2)
        self.assertEqual({r["phase"] for r in self.db.mr_ivr_invites.records}, {"plan", "closing"})
        self.assertTrue(all(len(r["gateway_request_id"]) == 64 for r in self.db.mr_ivr_invites.records))
        await legacy.reminder_tick(self.day.replace(hour=9))
        self.assertEqual(self.send.await_count, 2)

    async def test_daily_invites_include_new_mrs_and_confirm_completed_reports(self):
        await self.enable()
        self.db.mr_daily_reports.records.append({
            "id": "2026-10-05:mr", "plan_submitted_at": self.day.isoformat(),
            "closing_submitted_at": self.day.replace(hour=19).isoformat(),
        })

        async def tick_until_idle(when):
            for _ in range(4):
                await reporting.reporting_tick(when)

        # A submitted report still gets a message, but not a redundant prompt.
        await reporting.reporting_tick(self.day)
        self.assertIn("already been submitted", self.send.await_args.args[1])
        self.assertNotIn("mr_invitation", self.db.conversations.records[0])

        # The current active directory is re-read, so a new MR joins this day's
        # remaining schedule without changing or re-enabling the schedule.
        newcomer = {**self.mr, "id": "mr-new", "name": "New Synthetic MR",
                    "employee_id": "MR002", "phone": "+15550001112"}
        self.db.mr_directory.records.append(newcomer)
        await tick_until_idle(self.day)
        await tick_until_idle(self.day.replace(hour=20))
        sent = [(call.args[0], call.args[1]) for call in self.send.await_args_list]
        self.assertEqual(sum(phone == self.mr["phone"] and "Your plan for today has already" in text
                             for phone, text in sent), 1)
        self.assertEqual(sum(phone == newcomer["phone"] and "Start today's plan" in text
                             for phone, text in sent), 1)
        self.assertEqual(sum(phone == self.mr["phone"] and "day-end report has already" in text
                             for phone, text in sent), 1)
        self.assertEqual(sum(phone == newcomer["phone"] and "Start day closing" in text
                             for phone, text in sent), 1)

        # Each active MR receives both phases again on the following day.
        next_day = self.day + timedelta(days=1)
        await tick_until_idle(next_day)
        await tick_until_idle(next_day.replace(hour=20))
        self.assertEqual(len(self.db.mr_ivr_invites.records), 8)
        self.assertEqual(self.send.await_count, 8)

    async def test_individually_disabled_menu_does_not_receive_reporting_invitations(self):
        await self.enable()
        self.db.mr_ivr_profiles.records.append({"id": "mr", "value": {"ivr_enabled": False}})
        await reporting.reporting_tick(self.day)
        await reporting.reporting_tick(self.day.replace(hour=20))
        self.send.assert_not_awaited()

    async def test_opt_out_inactive_late_and_revoked_approver_prevent_invites(self):
        await self.enable()
        self.db.contacts.records.append({"mobile": self.mr["phone"], "opted_out": True})
        await reporting.reporting_tick(self.day)
        self.send.assert_not_awaited()
        self.db.contacts.records.clear()
        await reporting.reporting_tick(self.day.replace(hour=11))
        self.send.assert_not_awaited()
        self.db.mr_directory.records[0]["active"] = False
        await reporting.reporting_tick(self.day)
        self.send.assert_not_awaited()
        self.db.mr_directory.records[0]["active"] = True
        self.db.users.records[0]["active"] = False
        await reporting.reporting_tick(self.day)
        self.send.assert_not_awaited()

    async def test_uncertain_invitation_is_not_retried(self):
        await self.enable()
        self.send.side_effect = RuntimeError("Synthetic timeout after possible acceptance")
        await reporting.reporting_tick(self.day)
        await reporting.reporting_tick(self.day)
        self.assertEqual(self.send.await_count, 1)
        self.assertEqual(self.db.mr_ivr_invites.records[0]["status"], "uncertain")

    async def test_all_active_admins_independent_channels_and_no_duplicate_notifications(self):
        await self.enable()
        self.db.mr_directory.records.clear()  # this check covers only report notifications
        self.db.users.records += [
            {"id": "second", "role": "admin", "active": True, "email": "second@example.com"},
            {"id": "inactive", "role": "admin", "active": False, "email": "inactive@example.com"},
            {"id": "demo", "role": "admin", "is_demo": True, "email": "demo@example.com"},
            {"id": "manager", "role": "sales_manager", "email": "manager@example.com"},
        ]
        self.submission()
        for _ in range(8):
            await reporting.reporting_tick(self.day.replace(hour=12))
        self.assertEqual(self.email.await_count, 2)
        self.assertEqual(self.send.await_count, 1)
        notifications = self.db.mr_report_notifications.records
        self.assertEqual({r["user_id"] for r in notifications}, {"owner", "second"})
        self.assertTrue(any(r["status"] == "unavailable" and r["user_id"] == "second" for r in notifications))
        self.assertIn("&lt;script&gt;", self.email.call_args_list[0].args[3])
        self.assertTrue(self.db.mr_report_submissions.records[0]["notified_complete"])

    async def test_email_continues_when_gateway_down_and_uncertainty_not_retried(self):
        await self.enable()
        self.db.mr_directory.records.clear()
        self.sessions.side_effect = RuntimeError("Synthetic offline gateway")
        self.email.side_effect = RuntimeError("Synthetic ambiguous email timeout")
        self.submission()
        for _ in range(3):
            await reporting.reporting_tick(self.day.replace(hour=12))
        self.assertEqual(self.email.await_count, 1)
        self.send.assert_not_awaited()
        self.assertEqual(self.db.mr_report_notifications.records[0]["status"], "uncertain")

    async def test_scheduled_invalid_emails_are_unavailable_without_provider_io(self):
        await self.enable(whatsapp_reports=False)
        self.db.mr_directory.records.clear()
        self.submission()
        invalid = ("", "   ", "bad address", "no-at-sign", "admin@", "admin@example",
                   "admin@@example.com", None, 123, ["admin@example.com"])
        self.db.users.records[0].pop("email")  # missing historical contact
        self.db.users.records.extend(
            {"id": f"invalid-{i}", "role": "admin", "active": True, "email": email}
            for i, email in enumerate(invalid))
        snapshots = copy.deepcopy(self.db.mr_report_submissions.records[0]["report"])
        for _ in range(3):
            await reporting.reporting_tick(self.day.replace(hour=12))
        claims = self.db.mr_report_notifications.records
        self.assertEqual(len(claims), len(invalid) + 1)
        self.assertEqual({c["user_id"] for c in claims},
                         {u["id"] for u in self.db.users.records})
        for claim in claims:
            self.assertEqual(claim["status"], "unavailable")
            self.assertIs(claim["provider_io"], False)
            self.assertEqual(claim["error"], reporting.UNAVAILABLE_ERROR)
            self.assertEqual(claim["channel"], "email")
            self.assertEqual(claim["submission_id"], "submission")
            self.assertEqual(claim["report_id"], snapshots["id"])
            self.assertTrue(reporting.recoverable(claim, claims))
        self.assertEqual(self.db.mr_report_submissions.records[0]["report"], snapshots)
        self.assertTrue(self.db.mr_report_submissions.records[0]["notified_complete"])
        self.email.assert_not_awaited()
        self.send.assert_not_awaited()
        # Correcting contacts must not release even the no-IO scheduler reservations.
        before = copy.deepcopy(claims)
        for admin in self.db.users.records:
            admin["email"] = "corrected@example.com"
        self.db.mr_report_submissions.records[0]["notified_complete"] = False
        await reporting.reporting_tick(self.day.replace(hour=12))
        self.assertEqual(self.db.mr_report_notifications.records, before)
        self.email.assert_not_awaited()

    async def test_scheduled_invalid_emails_preserve_existing_reservations(self):
        await self.enable(whatsapp_reports=False)
        self.db.mr_directory.records.clear()
        self.submission()
        self.db.users.records[0]["email"] = "malformed"
        statuses = ("sending", "sent", "uncertain", "unavailable")
        self.db.users.records.extend(
            {"id": status, "role": "admin", "email": "malformed"} for status in statuses)
        claims = [
            {"id": f"mr-report:submission:{status}:email", "submission_id": "submission",
             "report_id": "2026-10-05:mr", "user_id": status, "channel": "email",
             "created_at": self.day.replace(hour=12).isoformat(), "status": status,
             "provider_io": status != "unavailable", "error": "Preserve original evidence"}
            for status in statuses]
        self.db.mr_report_notifications.records.extend(copy.deepcopy(claims))
        for _ in range(2):
            await reporting.reporting_tick(self.day.replace(hour=12))
        self.assertEqual(self.db.mr_report_notifications.records[:len(claims)], claims)
        self.assertEqual(len(self.db.mr_report_notifications.records), len(claims) + 1)
        self.email.assert_not_awaited()
        self.send.assert_not_awaited()

    async def test_scheduled_email_uses_normalized_address_and_reserves_once(self):
        await self.enable(whatsapp_reports=False)
        self.db.mr_directory.records.clear()
        self.submission()
        self.db.users.records[0]["email"] = "  admin@EXAMPLE.COM  "
        key = "mr-report:submission:owner:email"

        async def accepted(address, *args):
            self.assertEqual(address, "admin@example.com")
            claim = await self.db.mr_report_notifications.find_one({"id": key})
            self.assertEqual(claim["status"], "sending")
            return "Sent"

        self.email.side_effect = accepted
        for _ in range(3):
            await reporting.reporting_tick(self.day.replace(hour=12))
        self.email.assert_awaited_once()
        self.send.assert_not_awaited()
        claim = await self.db.mr_report_notifications.find_one({"id": key})
        self.assertEqual(claim["status"], "sent")

    async def test_report_scope_and_computed_summary_ignore_stale_cache(self):
        self.db.mr_daily_reports.records += [
            {"id": "own", "date": "2026-10-05", "mr_id": "owner", "mr_name": "Own MR",
             "plan": {"planned_visits": 8, "expected_sales": 50000},
             "closing": {"completed_visits": 7, "sales": 45000}, "summary": {"achievement_pct": 0}},
            {"id": "other", "date": "2026-10-05", "mr_id": "other", "mr_name": "Other MR"},
        ]
        self.actor["role"] = "mr"
        response = await self.client.get("/api/field/daily-reports?date=2026-10-05&mr_id=other")
        self.assertEqual(response.status_code, 200, response.text)
        self.assertEqual([r["id"] for r in response.json()["items"]], ["own"])
        self.assertEqual(response.json()["items"][0]["summary"]["achievement_pct"], 90)
        self.assertEqual((await self.client.get("/api/field/daily-reports?date=bad")).status_code, 422)
        self.assertEqual((await self.client.put("/api/settings/mr-ivr", json=reporting.DEFAULT_CONFIG)).status_code, 403)

    async def test_offline_whatsapp_backlog_does_not_block_new_email_reports(self):
        await self.enable()
        self.db.mr_directory.records.clear()
        self.sessions.return_value = {"sessions": []}
        self.submission()
        original = self.db.mr_report_submissions.records.pop()
        for i in range(51):
            self.db.mr_report_submissions.records.append({**copy.deepcopy(original), "id": f"submission-{i}"})
        for _ in range(54):
            await reporting.reporting_tick(self.day.replace(hour=12))
        self.assertEqual(self.email.await_count, 51)
        self.send.assert_not_awaited()

    async def missed(self, channel="email"):
        await self.enable()
        self.submission()
        self.db.mr_daily_reports.records.append(copy.deepcopy(self.db.mr_report_submissions.records[0]["report"]))
        claim = {"id": f"missed:{channel}", "report_id": "2026-10-05:mr",
                 "submission_id": "submission", "user_id": "owner", "channel": channel,
                 "created_at": self.day.isoformat(), "status": "unavailable",
                 "provider_io": False, "error": reporting.UNAVAILABLE_ERROR}
        self.db.mr_report_notifications.records.append(claim)
        return claim

    async def manual(self, claim, confirm=True):
        return await self.client.post(f"/api/field/report-notifications/{claim['id']}/send-now",
                                      json={"confirm": confirm})

    async def test_manual_confirmation_snapshot_corrected_contact_audit_and_history(self):
        claim = await self.missed()
        before = copy.deepcopy(claim)
        self.db.users.records[0]["email"] = "corrected@example.com"
        self.db.mr_daily_reports.records[0]["closing"]["sales"] = 999999
        snapshots = copy.deepcopy(self.db.mr_report_submissions.records)
        reports = copy.deepcopy(self.db.mr_daily_reports.records)
        self.assertEqual((await self.manual(claim, False)).status_code, 422)
        self.email.assert_not_awaited()
        response = await self.manual(claim)
        self.assertEqual(response.status_code, 200, response.text)
        attempt = response.json()["attempt"]
        self.assertEqual(attempt["original_notification_id"], claim["id"])
        self.assertEqual(attempt["requested_by"], "owner")
        self.assertEqual(attempt["recipient_address"], "corrected@example.com")
        self.assertEqual(attempt["status"], "sent")
        self.assertEqual(self.email.call_args.args[0], "corrected@example.com")
        self.assertIn("45000", self.email.call_args.args[3])
        self.assertNotIn("999999", self.email.call_args.args[3])
        reporting.log_audit.assert_awaited()
        self.assertEqual(claim, before)
        self.assertEqual(self.db.mr_report_submissions.records, snapshots)
        self.assertEqual(self.db.mr_daily_reports.records, reports)
        self.assertEqual((await self.manual(claim)).status_code, 409)
        self.assertEqual(self.email.await_count, 1)
        detail = (await self.client.get("/api/field/daily-reports?date=2026-10-05")).json()
        self.assertEqual(len(detail["items"][0]["notifications"]), 2)
        self.assertFalse(any(n["can_send_now"] for n in detail["items"][0]["notifications"]))

    async def test_manual_permissions_and_recipient_revalidation(self):
        claim = await self.missed()
        for role in ("mr", "sales_manager", "view_only"):
            self.actor["role"] = role
            self.db.users.records[0]["role"] = role
            self.assertEqual((await self.manual(claim)).status_code, 403)
        self.actor["role"] = self.db.users.records[0]["role"] = "admin"
        for module, action in (("settings", "manage"), ("reports", "manage"), ("reports", "send")):
            perms = auth.permissions_for("admin")
            perms[module].remove(action)
            with patch.object(reporting, "permissions_for", return_value=perms):
                self.assertEqual((await self.manual(claim)).status_code, 403)
        for flag in ("active", "deleted", "is_demo"):
            self.db.users.records[0][flag] = flag != "active"
            self.assertEqual((await self.manual(claim)).status_code, 403)
            self.db.users.records[0].pop(flag)
        self.db.users.records.append({"id": "recipient", "role": "admin", "email": "new@example.com"})
        claim["user_id"] = "recipient"
        for key, value in (("active", False), ("is_demo", True), ("deleted", True), ("role", "mr")):
            self.db.users.records[-1][key] = value
            self.assertEqual((await self.manual(claim)).status_code, 409)
            self.db.users.records[-1].pop(key)
            self.db.users.records[-1]["role"] = "admin"
        self.email.assert_not_awaited()
        self.send.assert_not_awaited()

    async def test_manual_unavailable_email_settings_contacts_and_snapshot(self):
        claim = await self.missed()
        config = self.db.app_config.records[0]["value"]
        for key in ("enabled", "email_reports"):
            config[key] = False
            self.assertEqual((await self.manual(claim)).status_code, 409)
            config[key] = True
        for email in ("", "bad address", "no-at-sign"):
            self.db.users.records[0]["email"] = email
            self.assertEqual((await self.manual(claim)).status_code, 409)
        self.db.users.records[0]["email"] = "fixed@example.com"
        with patch.object(reporting.brevo_client, "configured", return_value=False):
            self.assertEqual((await self.manual(claim)).status_code, 409)
        self.db.mr_report_submissions.records.clear()
        self.assertEqual((await self.manual(claim)).status_code, 409)
        self.assertEqual(len(self.db.mr_report_notifications.records), 1)
        self.email.assert_not_awaited()

    async def test_manual_whatsapp_validates_consent_channel_and_send_permission(self):
        claim = await self.missed("whatsapp")
        perms = auth.permissions_for("admin")
        perms["whatsapp"].remove("send")
        with patch.object(reporting, "permissions_for", return_value=perms):
            self.assertEqual((await self.manual(claim)).status_code, 403)
        self.db.app_config.records[0]["value"]["whatsapp_reports"] = False
        self.assertEqual((await self.manual(claim)).status_code, 409)
        self.db.app_config.records[0]["value"]["whatsapp_reports"] = True
        self.db.users.records[0]["phone"] = "not-a-phone"
        self.assertEqual((await self.manual(claim)).status_code, 409)
        self.db.users.records[0]["phone"] = "+1 (555) 000-3333"
        self.db.consent_records.records.append({"phone": "15550003333", "status": "opted_out"})
        self.assertEqual((await self.manual(claim)).status_code, 409)
        self.db.consent_records.records.clear()
        self.db.contacts.records.append({"mobile": "+15550003333", "opted_out": True})
        self.assertEqual((await self.manual(claim)).status_code, 409)
        self.db.contacts.records.clear()
        self.sessions.return_value = {"sessions": []}
        self.assertEqual((await self.manual(claim)).status_code, 409)
        self.sessions.side_effect = RuntimeError("Synthetic offline")
        self.assertEqual((await self.manual(claim)).status_code, 409)
        self.send.assert_not_awaited()
        self.assertEqual(len(self.db.mr_report_notifications.records), 1)

    async def test_manual_blocks_unknown_sent_sending_uncertain_and_partial_evidence(self):
        claim = await self.missed()
        for status in ("sent", "sending", "uncertain", "failed", "partially_accepted"):
            claim["status"] = status
            self.assertEqual((await self.manual(claim)).status_code, 409)
        claim["status"] = "unavailable"
        claim["provider_io"] = True
        self.assertEqual((await self.manual(claim)).status_code, 409)
        claim.pop("provider_io")
        claim["error"] = "Unknown legacy provenance"
        self.assertEqual((await self.manual(claim)).status_code, 409)
        claim["error"] = reporting.UNAVAILABLE_ERROR
        self.db.mr_report_notifications.records.append({**claim, "id": "partial", "part": 1, "status": "sent", "wamid": "known"})
        self.assertEqual((await self.manual(claim)).status_code, 409)
        self.db.mr_report_notifications.records.pop()
        self.db.whatsapp_send_requests.records.append({"id": reporting.hashlib.sha256(claim["id"].encode()).hexdigest()})
        self.assertEqual((await self.manual(claim)).status_code, 409)
        self.email.assert_not_awaited()

    async def test_manual_duplicate_clicks_reserve_before_provider_io(self):
        claim = await self.missed()
        started, finish = asyncio.Event(), asyncio.Event()
        async def delayed_send(*args):
            self.assertEqual(self.db.mr_report_notifications.records[-1]["status"], "sending")
            reporting.log_audit.assert_awaited()
            started.set()
            await finish.wait()
            return "Sent"
        self.email.side_effect = delayed_send
        first = asyncio.create_task(self.manual(claim))
        await started.wait()
        second = await self.manual(claim)
        self.assertEqual(second.status_code, 409)
        finish.set()
        self.assertEqual((await first).status_code, 200)
        self.assertEqual(self.email.await_count, 1)

    async def test_manual_email_uncertainty_blocks_provider_switch_and_retry(self):
        claim = await self.missed()
        self.email.side_effect = RuntimeError("Synthetic acceptance timeout")
        response = await self.manual(claim)
        self.assertEqual(response.json()["attempt"]["status"], "uncertain")
        self.assertEqual((await self.manual(claim)).status_code, 409)
        self.assertEqual(self.email.await_count, 1)
        self.send.assert_not_awaited()

    async def test_manual_qr_multipart_keeps_accepted_and_uncertain_claims(self):
        claim = await self.missed("whatsapp")
        self.db.mr_report_submissions.records[0]["report"]["closing"]["remarks"] = "x" * 8000
        self.send.side_effect = [{"wamid": "accepted-first"}, RuntimeError("Synthetic second-part timeout")]
        response = await self.manual(claim)
        self.assertEqual(response.status_code, 200, response.text)
        self.assertEqual(response.json()["attempt"]["status"], "uncertain")
        parts = [r for r in self.db.mr_report_notifications.records if r.get("part")]
        self.assertEqual([r["status"] for r in parts], ["sent", "uncertain"])
        self.assertEqual(parts[0]["wamid"], "accepted-first")
        self.assertTrue(all(r["attempt_id"] == f"{claim['id']}:manual" for r in parts))
        self.assertEqual((await self.manual(claim)).status_code, 409)
        self.assertEqual(self.send.await_count, 2)
        self.assertEqual(claim["status"], "unavailable")

    async def test_manual_other_administrator_can_send_qr_and_legacy_no_io_is_eligible(self):
        claim = await self.missed("whatsapp")
        claim.pop("provider_io")
        self.actor["id"] = "other-admin"
        self.db.users.records.append({**self.actor})
        response = await self.manual(claim)
        self.assertEqual(response.status_code, 200, response.text)
        self.assertEqual(response.json()["attempt"]["status"], "sent")
        self.assertEqual(self.send.await_count, 1)
        self.assertEqual(self.send.call_args.kwargs["session_id"], "qr-mock")

    async def test_manual_revocation_after_reservation_never_calls_provider(self):
        claim = await self.missed()
        async def revoke(*args, **kwargs):
            self.db.app_config.records[0]["value"]["enabled"] = False
        reporting.log_audit.side_effect = revoke
        response = await self.manual(claim)
        self.assertEqual(response.json()["attempt"]["status"], "uncertain")
        self.email.assert_not_awaited()
        self.assertEqual((await self.manual(claim)).status_code, 409)

    async def test_manual_multipart_consent_revocation_stops_later_parts(self):
        claim = await self.missed("whatsapp")
        self.db.mr_report_submissions.records[0]["report"]["closing"]["remarks"] = "x" * 8000
        async def accept_then_opt_out(*args, **kwargs):
            self.db.contacts.records.append({"mobile": self.actor["phone"], "opted_out": True})
            return {"wamid": "accepted-first"}
        self.send.side_effect = accept_then_opt_out
        response = await self.manual(claim)
        self.assertEqual(response.json()["attempt"]["status"], "uncertain")
        self.assertEqual(self.send.await_count, 1)
        self.assertEqual((await self.manual(claim)).status_code, 409)