"""No real database, provider requests, webhook secrets, or delivery side effects."""
import copy
import unittest
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch

from whatsapp_receipts import save_receipt, provider_time
import routes_whatsapp
from receipt_fixture import MemoryDatabase


class MemoryMessages:
    def __init__(self):
        self.database = MemoryDatabase()
        self.row = {"wamid": "exact", "status": "sent", "created_at": "2020-01-01T00:00:00Z"}
        self.conflict = False

    async def find_one(self, selector):
        return copy.deepcopy(self.row) if selector["wamid"] == self.row["wamid"] else None

    async def update_one(self, selector, update):
        if self.conflict:
            self.conflict = False
            self.row.update(status="read", read_at="2026-10-05T08:00:08.000Z",
                            status_at="2026-10-05T08:00:08.000Z")
            return SimpleNamespace(matched_count=0)
        matches = all(self.row.get(k) == v for k, v in selector.items())
        if matches:
            self.row.update(update["$set"])
        return SimpleNamespace(matched_count=int(matches))


class ReceiptTimes(unittest.IsolatedAsyncioTestCase):
    async def test_reordered_duplicate_and_failed_events_preserve_strongest_status(self):
        messages = MemoryMessages()
        await save_receipt(messages, "exact", "read", 1791187208)
        await save_receipt(messages, "exact", "delivered", 1791187203)
        await save_receipt(messages, "exact", "sent", 1791187201)
        await save_receipt(messages, "exact", "failed", 1791187210)
        await save_receipt(messages, "exact", "delivered", 1791187205)
        await save_receipt(messages, "exact", "read", 1791187212)
        self.assertEqual(messages.row["status"], "read")
        self.assertEqual(messages.row["delivered_at"], "2026-10-05T08:00:03.000Z")
        self.assertEqual(messages.row["read_at"], "2026-10-05T08:00:08.000Z")
        self.assertEqual(messages.row["status_at"], messages.row["read_at"])
        await save_receipt(messages, "exact", "read", 1791187206)
        self.assertEqual(messages.row["read_at"], "2026-10-05T08:00:06.000Z")

    async def test_missing_and_invalid_times_never_use_creation_or_local_time(self):
        for value in (None, 0, -1, True, "bad", "2026-10-05T08:00:00", float("inf")):
            self.assertIsNone(provider_time(value))
            messages = MemoryMessages()
            await save_receipt(messages, "exact", "read", value)
            self.assertEqual(messages.row["status"], "read")
            self.assertIsNone(messages.row["read_at"])
            self.assertIsNone(messages.row["delivered_at"])
            self.assertIsNone(messages.row["status_at"])

    async def test_concurrent_read_receipt_cannot_be_downgraded(self):
        messages = MemoryMessages()
        messages.conflict = True
        await save_receipt(messages, "exact", "delivered", 1791187203)
        self.assertEqual(messages.row["status"], "read")
        self.assertEqual(messages.row["status_at"], messages.row["read_at"])
        self.assertEqual(messages.row["delivered_at"], "2026-10-05T08:00:03.000Z")

    async def test_webhook_ingests_provider_timestamp_without_real_signature_or_database(self):
        messages = MemoryMessages()
        request = SimpleNamespace(body=AsyncMock(return_value=b"fixture"), headers={},
            json=AsyncMock(return_value={"entry": [{"changes": [{"value": {"statuses": [
                {"id": "exact", "status": "read", "timestamp": "1791187208"},
                {"id": "exact", "status": "delivered", "timestamp": "1791187203"},
                {"id": "exact", "status": "sent", "timestamp": "1791187201"},
            ]}}]}]}))
        with patch.object(routes_whatsapp, "db", SimpleNamespace(messages=messages)), \
                patch.object(routes_whatsapp, "_valid_signature", return_value=True):
            self.assertEqual(await routes_whatsapp.receive_webhook(request), {"ok": True})
        self.assertEqual(messages.row["status"], "read")
        self.assertEqual(messages.row["read_at"], "2026-10-05T08:00:08.000Z")
        self.assertEqual(messages.row["delivered_at"], "2026-10-05T08:00:03.000Z")
