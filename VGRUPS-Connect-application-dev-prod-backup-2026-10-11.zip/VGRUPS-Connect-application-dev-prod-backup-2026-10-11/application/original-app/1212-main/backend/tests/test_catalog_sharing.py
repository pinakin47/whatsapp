"""Isolated API contract tests: no live database, gateway, or customer messages."""
import unittest
import asyncio
import copy
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch

import httpx
from fastapi import FastAPI
import routes_whatsapp as routes
import wa_client
from auth import get_current_user
from test_lead_capture import Collection


class CatalogSharingTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.user = {"id": "test-user", "name": "Test sender", "role": "super_admin"}
        self.conv = {"id": "test-chat", "phone": "919876543210"}
        self.database = SimpleNamespace(
            app_config=Collection(), wa_sessions=Collection(),
            contacts=SimpleNamespace(find_one=AsyncMock(return_value={
                "id": "real-contact", "name": "Consenting fixture", "mobile": "+919876543210"})),
            conversations=SimpleNamespace(find_one=AsyncMock(return_value=self.conv), update_one=AsyncMock()),
            messages=SimpleNamespace(
                update_one=AsyncMock(), insert_one=AsyncMock(),
                find_one=AsyncMock(side_effect=lambda *_args, **_kwargs: {
                    "id": "test-message", "wamid": "mock-accepted", "status": "sent",
                    "conversation_id": "test-chat", "body": "Synthetic product details",
                    "created_at": "2026-10-04T00:00:00+00:00",
                })),
        )
        self.requests = {}

        async def find_request(selector, *_args):
            return copy.deepcopy(self.requests.get(selector["id"]))

        async def update_request(selector, update, upsert=False):
            key = selector["id"]
            inserted = key not in self.requests and upsert
            if key in self.requests and any(self.requests[key].get(k) != v for k, v in selector.items()):
                return SimpleNamespace(upserted_id=None, matched_count=0)
            if inserted:
                self.requests[key] = copy.deepcopy(update.get("$setOnInsert", {}))
            if key in self.requests:
                self.requests[key].update(copy.deepcopy(update.get("$set", {})))
            return SimpleNamespace(upserted_id=key if inserted else None, matched_count=1 if key in self.requests else 0)

        self.database.whatsapp_send_requests = SimpleNamespace(
            find_one=AsyncMock(side_effect=find_request),
            update_one=AsyncMock(side_effect=update_request),
        )
        self.patches = [
            patch.object(routes, "db", self.database),
            patch.object(routes, "log_audit", AsyncMock()),
            patch.object(wa_client, "wa_connected", AsyncMock(return_value=True)),
            patch.object(wa_client, "wa_list_sessions", AsyncMock(return_value={"sessions": [], "connected": False})),
            patch.object(wa_client, "wa_send", AsyncMock(return_value={"wamid": "mock-accepted"})),
            patch.object(routes, "whatsapp_configured", return_value=False),
            patch.object(routes, "send_whatsapp_text", AsyncMock(return_value={"messages": [{"id": "mock-cloud"}]})),
        ]
        for replacement in self.patches:
            replacement.start()
        app = FastAPI()
        app.include_router(routes.router)
        app.dependency_overrides[get_current_user] = lambda: self.user
        self.client = httpx.AsyncClient(transport=httpx.ASGITransport(app=app), base_url="http://test")
        self.payload = {"body": "Synthetic product details", "phone": "+91 98765 43210"}

    async def asyncTearDown(self):
        await self.client.aclose()
        for replacement in reversed(self.patches):
            replacement.stop()

    async def test_phone_uses_existing_send_flow_and_records_accepted_message(self):
        response = await self.client.post("/api/whatsapp/send", json=self.payload)
        self.assertEqual(response.status_code, 200, response.text)
        self.assertEqual(response.json()["wamid"], "mock-accepted")
        wa_client.wa_send.assert_awaited_once_with("919876543210", self.payload["body"])
        self.database.messages.update_one.assert_awaited_once()
        routes.log_audit.assert_awaited_once()

    async def test_contact_preserves_existing_lid_conversation(self):
        self.conv["phone"] = "fixture-peer@lid"
        response = await self.client.post("/api/whatsapp/send", json={
            "body": self.payload["body"], "contact_id": "real-contact"})
        self.assertEqual(response.status_code, 200, response.text)
        wa_client.wa_send.assert_awaited_once_with("fixture-peer@lid", self.payload["body"])
        selector = self.database.contacts.find_one.call_args.args[0]
        self.assertEqual(selector["is_demo"], {"$ne": True})
        self.assertEqual(selector["deleted"], {"$ne": True})

    async def test_new_recipient_creates_inbox_conversation(self):
        self.database.conversations.find_one.side_effect = [None, self.conv, self.conv]
        response = await self.client.post("/api/whatsapp/send", json=self.payload)
        self.assertEqual(response.status_code, 200, response.text)
        first_write = self.database.conversations.update_one.call_args_list[0]
        self.assertEqual(first_write.args[0], {"phone": "919876543210", "session_id": None,
            "is_demo": {"$ne": True}, "deleted": {"$ne": True}})
        self.assertTrue(first_write.kwargs["upsert"])

    async def test_invalid_numbers_and_ambiguous_recipients_never_send(self):
        for phone in ("9876543210", "+01234567890", "+123", "+1234567890123456", "+91abc9876543210"):
            response = await self.client.post("/api/whatsapp/send", json={**self.payload, "phone": phone})
            self.assertEqual(response.status_code, 422, phone)
        for payload in (
            {"body": "test"}, {**self.payload, "contact_id": "real-contact"},
            {**self.payload, "body": "  "},
        ):
            self.assertEqual((await self.client.post("/api/whatsapp/send", json=payload)).status_code, 422)
        wa_client.wa_send.assert_not_awaited()

    async def test_missing_contact_and_invalid_contact_mobile(self):
        self.database.contacts.find_one.return_value = None
        payload = {"body": "test", "contact_id": "missing"}
        self.assertEqual((await self.client.post("/api/whatsapp/send", json=payload)).status_code, 404)
        self.database.contacts.find_one.return_value = {"id": "missing", "mobile": "invalid"}
        self.assertEqual((await self.client.post("/api/whatsapp/send", json=payload)).status_code, 422)
        wa_client.wa_send.assert_not_awaited()

    async def test_send_permission_is_enforced(self):
        self.user["role"] = "view_only"
        self.assertEqual((await self.client.post("/api/whatsapp/send", json=self.payload)).status_code, 403)
        wa_client.wa_send.assert_not_awaited()

    async def test_crm_view_permission_is_enforced(self):
        with patch.object(routes, "permissions_for", return_value={"inbox": ["send"]}):
            response = await self.client.post("/api/whatsapp/send", json={"body": "test", "contact_id": "real-contact"})
        self.assertEqual(response.status_code, 403)
        self.database.contacts.find_one.assert_not_awaited()

    async def test_disconnected_never_records_success(self):
        wa_client.wa_connected.return_value = False
        response = await self.client.post("/api/whatsapp/send", json=self.payload)
        self.assertEqual(response.status_code, 503)
        wa_client.wa_send.assert_not_awaited()
        self.database.messages.update_one.assert_not_awaited()

    async def test_gateway_failure_never_records_success_or_switches_provider(self):
        wa_client.wa_send.side_effect = RuntimeError("Synthetic gateway failure")
        response = await self.client.post("/api/whatsapp/send", json=self.payload)
        self.assertEqual(response.status_code, 502)
        self.assertIn("Synthetic gateway failure", response.text)
        self.database.messages.update_one.assert_not_awaited()
        routes.send_whatsapp_text.assert_not_awaited()

    async def test_missing_acceptance_never_records_success(self):
        wa_client.wa_send.return_value = {"ok": True}
        response = await self.client.post("/api/whatsapp/send", json=self.payload)
        self.assertEqual(response.status_code, 502)
        self.database.messages.update_one.assert_not_awaited()

    async def test_cloud_api_fallback_uses_existing_contract(self):
        wa_client.wa_connected.return_value = False
        routes.whatsapp_configured.return_value = True
        response = await self.client.post("/api/whatsapp/send", json=self.payload)
        self.assertEqual(response.status_code, 200, response.text)
        routes.send_whatsapp_text.assert_awaited_once_with("919876543210", self.payload["body"])
        self.assertEqual(self.database.messages.update_one.call_args.args[0], {"wamid": "mock-cloud"})
        wa_client.wa_send.assert_not_awaited()

    async def test_lost_response_retry_replays_persisted_acceptance_for_both_providers(self):
        for cloud in (False, True):
            with self.subTest(cloud=cloud):
                self.requests.clear()
                wa_client.wa_send.reset_mock()
                routes.send_whatsapp_text.reset_mock()
                wa_client.wa_connected.return_value = not cloud
                routes.whatsapp_configured.return_value = cloud
                payload = {**self.payload, "request_key": "stable-lost-response-key"}
                # Discard the first HTTP response, like a client that lost it.
                first = await self.client.post("/api/whatsapp/send", json=payload)
                self.assertEqual(first.status_code, 200, first.text)
                # Acceptance survives provider disconnection and fresh requests.
                wa_client.wa_connected.return_value = False
                routes.whatsapp_configured.return_value = False
                retry = await self.client.post("/api/whatsapp/send", json=payload)
                self.assertEqual(retry.status_code, 200, retry.text)
                self.assertEqual(retry.json(), first.json())
                self.assertEqual(wa_client.wa_send.await_count, 0 if cloud else 1)
                self.assertEqual(routes.send_whatsapp_text.await_count, 1 if cloud else 0)

    async def test_acceptance_is_saved_before_inbox_failure_and_retry_repairs_it(self):
        self.database.messages.update_one.side_effect = RuntimeError("Synthetic storage outage")
        payload = {**self.payload, "request_key": "stable-inbox-failure-key"}
        with self.assertRaisesRegex(RuntimeError, "storage outage"):
            await self.client.post("/api/whatsapp/send", json=payload)
        saved = next(iter(self.requests.values()))
        self.assertEqual(saved["state"], "accepted")
        self.assertEqual(saved["response"]["wamid"], "mock-accepted")
        self.database.messages.update_one.side_effect = None
        response = await self.client.post("/api/whatsapp/send", json=payload)
        self.assertEqual(response.status_code, 200, response.text)
        wa_client.wa_send.assert_awaited_once()

    async def test_uncertain_provider_results_never_resend_or_switch_providers(self):
        for cloud in (False, True):
            for missing_id in (False, True):
                with self.subTest(cloud=cloud, missing_id=missing_id):
                    self.requests.clear()
                    wa_client.wa_send.reset_mock()
                    routes.send_whatsapp_text.reset_mock()
                    wa_client.wa_connected.return_value = not cloud
                    routes.whatsapp_configured.return_value = cloud
                    provider = routes.send_whatsapp_text if cloud else wa_client.wa_send
                    provider.side_effect = None if missing_id else TimeoutError("Synthetic lost provider response")
                    provider.return_value = {}
                    payload = {**self.payload, "request_key": "stable-uncertain-result"}
                    self.assertEqual((await self.client.post("/api/whatsapp/send", json=payload)).status_code, 502)
                    retry = await self.client.post("/api/whatsapp/send", json=payload)
                    self.assertEqual(retry.status_code, 409, retry.text)
                    self.assertIn("No second message", retry.text)
                    provider.assert_awaited_once()
                    other = wa_client.wa_send if cloud else routes.send_whatsapp_text
                    other.assert_not_awaited()
                    self.database.messages.update_one.assert_not_awaited()
                    provider.side_effect = None

    async def test_concurrent_identical_requests_only_call_provider_once(self):
        started, release = asyncio.Event(), asyncio.Event()

        async def slow_send(*_args, **_kwargs):
            started.set()
            await release.wait()
            return {"wamid": "mock-accepted"}

        wa_client.wa_send.side_effect = slow_send
        payload = {**self.payload, "request_key": "stable-concurrent-key"}
        first = asyncio.create_task(self.client.post("/api/whatsapp/send", json=payload))
        await asyncio.wait_for(started.wait(), timeout=2)
        try:
            second = await self.client.post("/api/whatsapp/send", json=payload)
            self.assertEqual(second.status_code, 409, second.text)
        finally:
            release.set()
            result = await first
        self.assertEqual(result.status_code, 200, result.text)
        wa_client.wa_send.assert_awaited_once()

    async def test_key_reuse_with_changed_payload_is_rejected(self):
        payload = {**self.payload, "request_key": "stable-conflict-key"}
        self.assertEqual((await self.client.post("/api/whatsapp/send", json=payload)).status_code, 200)
        for change in ({"body": "Different product"}, {"phone": "+441234567890"}):
            retry = await self.client.post("/api/whatsapp/send", json={**payload, **change})
            self.assertEqual(retry.status_code, 409, retry.text)
        wa_client.wa_send.assert_awaited_once()

    async def test_replay_still_requires_inbox_and_contact_permissions(self):
        payload = {"body": "Synthetic product", "contact_id": "real-contact", "request_key": "stable-permission-key"}
        self.assertEqual((await self.client.post("/api/whatsapp/send", json=payload)).status_code, 200)
        self.user["role"] = "view_only"
        self.assertEqual((await self.client.post("/api/whatsapp/send", json=payload)).status_code, 403)
        self.user["role"] = "super_admin"
        with patch.object(routes, "permissions_for", return_value={"inbox": ["send"]}):
            self.assertEqual((await self.client.post("/api/whatsapp/send", json=payload)).status_code, 403)
        wa_client.wa_send.assert_awaited_once()

    async def test_keys_are_user_scoped_and_new_keys_allow_intentional_sends(self):
        payload = {**self.payload, "request_key": "stable-user-scoped-key"}
        self.assertEqual((await self.client.post("/api/whatsapp/send", json=payload)).status_code, 200)
        self.user["id"] = "another-user"
        self.assertEqual((await self.client.post("/api/whatsapp/send", json=payload)).status_code, 200)
        payload["request_key"] = "new-intentional-send-key"
        self.assertEqual((await self.client.post("/api/whatsapp/send", json=payload)).status_code, 200)
        self.assertEqual(wa_client.wa_send.await_count, 3)

    async def test_disconnected_request_does_not_consume_key(self):
        payload = {**self.payload, "request_key": "stable-disconnected-key"}
        wa_client.wa_connected.return_value = False
        self.assertEqual((await self.client.post("/api/whatsapp/send", json=payload)).status_code, 503)
        self.assertFalse(self.requests)
        wa_client.wa_connected.return_value = True
        self.assertEqual((await self.client.post("/api/whatsapp/send", json=payload)).status_code, 200)
        wa_client.wa_send.assert_awaited_once()

    async def test_acceptance_storage_failure_never_allows_resend(self):
        original_update = self.database.whatsapp_send_requests.update_one.side_effect

        async def fail_acceptance(selector, update, **kwargs):
            if update.get("$set", {}).get("state") == "accepted":
                raise RuntimeError("Synthetic acceptance storage failure")
            return await original_update(selector, update, **kwargs)

        self.database.whatsapp_send_requests.update_one.side_effect = fail_acceptance
        payload = {**self.payload, "request_key": "stable-acceptance-failure"}
        with self.assertRaisesRegex(RuntimeError, "acceptance storage"):
            await self.client.post("/api/whatsapp/send", json=payload)
        self.database.whatsapp_send_requests.update_one.side_effect = original_update
        self.assertEqual((await self.client.post("/api/whatsapp/send", json=payload)).status_code, 409)
        wa_client.wa_send.assert_awaited_once()

    async def uncertain(self, cloud=False):
        wa_client.wa_connected.return_value = not cloud
        routes.whatsapp_configured.return_value = cloud
        provider = routes.send_whatsapp_text if cloud else wa_client.wa_send
        provider.side_effect = TimeoutError("Synthetic uncertain provider")
        payload = {**self.payload, "request_key": "stable-recovery-key"}
        self.assertEqual((await self.client.post("/api/whatsapp/send", json=payload)).status_code, 502)
        return payload, next(iter(self.requests.values()))

    async def test_recovery_uses_gateway_receipt_without_resending(self):
        payload, saved = await self.uncertain()
        saved.update(gateway_accepted_wamid="mock-accepted", gateway_accepted_at="2026-10-04T00:00:00+00:00")
        response = await self.client.post("/api/whatsapp/send/recover", json=payload)
        self.assertEqual(response.status_code, 200, response.text)
        self.assertEqual(response.json()["state"], "accepted")
        self.assertEqual(response.json()["evidence"], "gateway_receipt")
        self.assertEqual(saved["state"], "completed")
        again = await self.client.post("/api/whatsapp/send/recover", json=payload)
        self.assertEqual(again.json()["message"], response.json()["message"])
        wa_client.wa_send.assert_awaited_once()
        routes.send_whatsapp_text.assert_not_awaited()

    async def test_recovery_requires_exact_ack_not_text_or_age(self):
        payload, saved = await self.uncertain()
        saved.update(gateway_message_id="mock-accepted", gateway_session_id="original-session",
                     created_at="2000-01-01T00:00:00+00:00")
        echo = {"wamid": "mock-accepted", "id": "mock-message", "conversation_id": "test-chat",
                "direction": "outbound", "is_demo": False, "session_id": "original-session",
                "body": self.payload["body"], "provider_status": 2, "status": "sent",
                "created_at": "2026-10-04T00:00:00+00:00"}
        self.database.messages.find_one.side_effect = None
        for change in ({"provider_status": 1}, {"provider_status": None},
                       {"session_id": "other-session"}, {"direction": "inbound"},
                       {"is_demo": True}, {"body": "Same recipient, different message"}):
            self.database.messages.find_one.return_value = {**echo, **change}
            response = await self.client.post("/api/whatsapp/send/recover", json=payload)
            self.assertEqual(response.json()["state"], "unresolved", change)
            self.assertEqual(saved["state"], "sending")
        self.database.messages.find_one.return_value = echo
        response = await self.client.post("/api/whatsapp/send/recover", json=payload)
        self.assertEqual(response.json()["evidence"], "linked_phone_ack")
        self.assertEqual(response.json()["state"], "accepted")
        wa_client.wa_send.assert_awaited_once()

    async def test_old_reservations_and_cloud_unknowns_remain_protected(self):
        for legacy, cloud in ((True, False), (False, True)):
            self.requests.clear()
            payload, saved = await self.uncertain(cloud=cloud)
            if legacy:
                for key in ("provider", "conversation_id", "message_body", "user_id", "recipient_address"):
                    saved.pop(key)
            saved["created_at"] = "2000-01-01T00:00:00+00:00"
            for _ in range(2):
                result = await self.client.post("/api/whatsapp/send/recover", json=payload)
                self.assertEqual(result.json()["state"], "unresolved")
                self.assertEqual(saved["state"], "sending")
            self.assertEqual((await self.client.post("/api/whatsapp/send", json=payload)).status_code, 409)
        self.assertEqual(wa_client.wa_send.await_count, 1)
        self.assertEqual(routes.send_whatsapp_text.await_count, 1)

    async def test_recovery_checks_user_payload_and_permissions(self):
        payload, saved = await self.uncertain()
        self.assertEqual((await self.client.post("/api/whatsapp/send/recover", json={**payload, "body": "Changed"})).status_code, 409)
        self.user["id"] = "different-user"
        self.assertEqual((await self.client.post("/api/whatsapp/send/recover", json=payload)).status_code, 404)
        self.user["id"] = "test-user"
        self.user["role"] = "view_only"
        self.assertEqual((await self.client.post("/api/whatsapp/send/recover", json=payload)).status_code, 403)
        self.user["role"] = "super_admin"
        with patch.object(routes, "permissions_for", return_value={"inbox": ["send"]}):
            self.assertEqual((await self.client.post("/api/whatsapp/send/recover", json={
                "body": "test", "contact_id": "real-contact", "request_key": payload["request_key"]})).status_code, 403)
        self.assertEqual((await self.client.post("/api/whatsapp/send/recover", json=self.payload)).status_code, 422)
        self.assertEqual(saved["state"], "sending")
        wa_client.wa_send.assert_awaited_once()

    async def test_recovery_acceptance_survives_inbox_failure(self):
        payload, saved = await self.uncertain()
        saved["gateway_accepted_wamid"] = "mock-accepted"
        self.database.messages.update_one.side_effect = RuntimeError("Synthetic Inbox failure")
        with self.assertRaisesRegex(RuntimeError, "Inbox failure"):
            await self.client.post("/api/whatsapp/send/recover", json=payload)
        self.assertEqual(saved["state"], "accepted")
        self.database.messages.update_one.side_effect = None
        result = await self.client.post("/api/whatsapp/send/recover", json=payload)
        self.assertEqual(result.json()["state"], "accepted")
        wa_client.wa_send.assert_awaited_once()

    async def test_recovery_replays_cloud_saved_acceptance_without_a_provider(self):
        wa_client.wa_connected.return_value = False
        routes.whatsapp_configured.return_value = True
        payload = {**self.payload, "request_key": "cloud-known-acceptance"}
        self.assertEqual((await self.client.post("/api/whatsapp/send", json=payload)).status_code, 200)
        routes.whatsapp_configured.return_value = False
        self.assertEqual((await self.client.post("/api/whatsapp/send/recover", json=payload)).json()["state"], "accepted")
        routes.send_whatsapp_text.assert_awaited_once()
        wa_client.wa_send.assert_not_awaited()


if __name__ == "__main__":
    unittest.main()