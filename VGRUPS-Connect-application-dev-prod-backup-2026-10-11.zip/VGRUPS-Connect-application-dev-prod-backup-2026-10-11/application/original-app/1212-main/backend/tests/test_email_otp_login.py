import asyncio
import copy
import os
import unittest
from datetime import timedelta
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch

import jwt
from fastapi import HTTPException
from starlette.requests import Request

import auth
import otp_login


class Collection:
    """Atomic in-memory fixture with the selectors used by OTP login."""
    def __init__(self, documents=()):
        self.documents = list(copy.deepcopy(documents))
        self.lock = asyncio.Lock()

    def matches(self, document, selector):
        for key, expected in selector.items():
            value = document.get(key)
            if isinstance(expected, dict):
                for op, bound in expected.items():
                    if op == "$ne" and value == bound:
                        return False
                    if op == "$gt" and (value is None or value <= bound):
                        return False
                    if op == "$lt" and (value is None or value >= bound):
                        return False
            elif value != expected:
                return False
        return True

    async def find_one(self, selector, sort=None):
        rows = [d for d in self.documents if self.matches(d, selector)]
        if sort:
            key, direction = sort[0]
            rows.sort(key=lambda d: d[key], reverse=direction < 0)
        return copy.deepcopy(rows[0]) if rows else None

    async def insert_one(self, document):
        self.documents.append(copy.deepcopy(document))

    async def find_one_and_update(self, selector, update, upsert=False, **_):
        async with self.lock:
            found = next((d for d in self.documents if self.matches(d, selector)), None)
            if found is None and upsert:
                found = {**selector, **update.get("$setOnInsert", {})}
                self.documents.append(found)
            if found is None:
                return None
            found.update(update.get("$set", {}))
            for key, increment in update.get("$inc", {}).items():
                found[key] = found.get(key, 0) + increment
            return copy.deepcopy(found)

    async def update_one(self, selector, update):
        return await self.find_one_and_update(selector, update)

    async def update_many(self, selector, update):
        for d in self.documents:
            if self.matches(d, selector):
                d.update(update["$set"])

    async def delete_many(self, selector):
        self.documents[:] = [d for d in self.documents if not self.matches(d, selector)]

    async def delete_one(self, selector):
        await self.delete_many(selector)


class EmailOtpTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.user = {"id": "otp-test-user", "email": "member@example.com", "name": "OTP Test", "role": "view_only", "active": True}
        self.db = SimpleNamespace(users=Collection([self.user]), otp_requests=Collection(), otp_rate_limits=Collection())
        self.mail = AsyncMock(return_value={"messageId": "test-message"})
        self.patches = [
            patch.object(otp_login, "db", self.db),
            patch.object(otp_login, "send_email_otp", self.mail),
            patch.object(otp_login, "integration_status", return_value={"brevo": {"configured": True}}),
            patch.object(otp_login, "log_audit", AsyncMock()),
            patch.dict(os.environ, {"APP_ENV": "development", "NODE_ENV": "development", "JWT_SECRET": "test-only-otp-signing-secret-32bytes"}),
        ]
        for p in self.patches:
            p.start()
            self.addCleanup(p.stop)
        self.request = Request({"type": "http", "headers": [], "client": ("127.0.0.1", 1000)})

    async def send(self, email="member@example.com"):
        return await otp_login.send_login_otp(auth.SendOtpIn(identifier=email, channel="email"), self.request)

    async def verify(self, sent, code=None, email="member@example.com"):
        return await otp_login.verify_login_otp(
            auth.VerifyOtpIn(identifier=email, code=code or self.mail.call_args.args[1], channel="email", otp_id=sent["otp_id"]),
            self.request,
        )

    async def test_send_normalizes_email_and_never_returns_code(self):
        sent = await self.send(" MEMBER@example.com ")
        self.assertEqual(self.mail.call_args.args[0], "member@example.com")
        self.assertNotIn("demo_code", sent)
        self.assertNotIn("code", sent)
        self.assertFalse(sent["demo_mode"])
        self.assertTrue(self.db.otp_requests.documents[0]["delivered"])

    async def test_success_issues_session_and_replay_fails(self):
        sent = await self.send()
        result = await self.verify(sent)
        decoded = jwt.decode(result["token"], os.environ["JWT_SECRET"], algorithms=["HS256"])
        self.assertEqual(decoded["sub"], self.user["id"])
        self.assertEqual(result["user"]["role"], "view_only")
        self.assertNotIn("password_hash", result["user"])
        with self.assertRaises(HTTPException):
            await self.verify(sent)

    async def test_concurrent_code_consumption_issues_only_one_session(self):
        sent = await self.send()
        results = await asyncio.gather(*(self.verify(sent) for _ in range(10)), return_exceptions=True)
        self.assertEqual(sum(isinstance(r, dict) for r in results), 1)

    async def test_concurrent_wrong_attempts_stop_at_five(self):
        sent = await self.send()
        actual = self.mail.call_args.args[1]
        wrong = "000000" if actual != "000000" else "000001"
        await asyncio.gather(*(self.verify(sent, wrong) for _ in range(20)), return_exceptions=True)
        self.assertEqual(self.db.otp_requests.documents[0]["attempts"], 5)
        with self.assertRaises(HTTPException):
            await self.verify(sent)

    async def test_expired_code_fails(self):
        sent = await self.send()
        self.db.otp_requests.documents[0]["expires_at"] = (auth.utcnow() - timedelta(seconds=1)).isoformat()
        with self.assertRaises(HTTPException):
            await self.verify(sent)

    async def test_email_binding(self):
        sent = await self.send()
        with self.assertRaises(HTTPException):
            await self.verify(sent, email="another@example.com")

    async def test_unknown_email_does_not_send_or_create_account(self):
        sent = await self.send("unknown@example.com")
        self.assertEqual(sent["message"], otp_login.SEND_MESSAGE)
        self.mail.assert_not_called()
        self.assertEqual(len(self.db.users.documents), 1)
        self.assertEqual(len(self.db.otp_requests.documents), 0)

    async def test_disabled_account_cannot_request_code(self):
        self.db.users.documents[0]["active"] = False
        await self.send()
        self.mail.assert_not_called()

    async def test_disabled_after_delivery_cannot_sign_in(self):
        sent = await self.send()
        self.db.users.documents[0]["active"] = False
        with self.assertRaises(HTTPException):
            await self.verify(sent)

    async def test_production_demo_account_cannot_request_code(self):
        os.environ["APP_ENV"] = "production"
        self.db.users.documents[0]["is_demo"] = True
        await self.send()
        self.mail.assert_not_called()

    async def test_production_public_password_account_cannot_request_code(self):
        os.environ["APP_ENV"] = "production"
        self.db.users.documents[0]["password_hash"] = auth.hash_password("admin123")
        await self.send()
        self.mail.assert_not_called()

    async def test_delivery_failure_has_no_usable_challenge(self):
        self.mail.side_effect = RuntimeError("Provider refused delivery")
        with self.assertRaises(HTTPException) as caught:
            await self.send()
        self.assertEqual(caught.exception.status_code, 502)
        self.assertEqual(self.db.otp_requests.documents, [])

    async def test_resend_is_throttled(self):
        await self.send()
        with self.assertRaises(HTTPException) as caught:
            await self.send()
        self.assertEqual(caught.exception.status_code, 429)
        self.assertEqual(self.mail.call_count, 1)

    async def test_missing_provider_fails_without_demo_code(self):
        with patch.object(otp_login, "integration_status", return_value={"brevo": {"configured": False}}):
            with self.assertRaises(HTTPException) as caught:
                await self.send()
        self.assertEqual(caught.exception.status_code, 503)

    async def test_invalid_email_is_rejected(self):
        with self.assertRaises(HTTPException) as caught:
            await self.send("not-an-email")
        self.assertEqual(caught.exception.status_code, 422)


if __name__ == "__main__":
    unittest.main()