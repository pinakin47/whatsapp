"""Chrome Extension CRM lookup + website WhatsApp widget (snippet, click tracking, stats)."""
import io
import os
import re
import time
import zipfile
import logging
from pathlib import Path

from fastapi import APIRouter, Depends, Request
from fastapi.responses import Response, StreamingResponse
from pydantic import BaseModel
from typing import Optional

from db import db, new_id, now_iso
from auth import require_perm

logger = logging.getLogger("vgrups.ext")
router = APIRouter(prefix="/api", tags=["extension-widget"])

EXT_DIR = Path(__file__).parent.parent / "chrome-extension"
_click_hits: dict[str, list[float]] = {}


def _digits(s: str) -> str:
    return re.sub(r"\D", "", s or "")


def _throttle(ip: str, limit: int = 60, window: int = 60):
    now = time.time()
    hits = [t for t in _click_hits.get(ip, []) if now - t < window]
    hits.append(now)
    _click_hits[ip] = hits
    return len(hits) <= limit


# ---------------- Chrome Extension ----------------
@router.get("/ext/lookup/{phone}")
async def ext_lookup(phone: str, user: dict = Depends(require_perm("contacts", "view"))):
    d = _digits(phone)[-10:]
    if len(d) < 10:
        return {"found": False, "phone": phone, "wa_link": None}
    rx = re.compile(re.escape(d) + "$")
    contact = await db.contacts.find_one({"mobile": {"$regex": rx}, "deleted": {"$ne": True}}, {"_id": 0})
    leads, orders = [], []
    if contact:
        leads = await db.leads.find({"contact_id": contact["id"], "deleted": {"$ne": True}}, {"_id": 0})\
            .sort("created_at", -1).to_list(5)
        orders = await db.orders.find({"contact_id": contact["id"]}, {"_id": 0}).sort("created_at", -1).to_list(5)
    else:
        leads = await db.leads.find({"mobile": {"$regex": rx}, "deleted": {"$ne": True}}, {"_id": 0})\
            .sort("created_at", -1).to_list(5)
    return {
        "found": bool(contact or leads),
        "phone": phone,
        "contact": contact,
        "leads": [{"id": l["id"], "title": l.get("title"), "status": l.get("status"), "value": l.get("value")} for l in leads],
        "orders": [{"id": o["id"], "number": o.get("number"), "status": o.get("status"), "total": o.get("total")} for o in orders],
        "wa_link": f"https://wa.me/{d}",
    }


class ExtLeadIn(BaseModel):
    phone: str
    name: Optional[str] = None
    note: Optional[str] = None
    page: Optional[str] = None


@router.post("/ext/capture")
async def ext_capture(body: ExtLeadIn, user: dict = Depends(require_perm("contacts", "create"))):
    d = _digits(body.phone)
    mobile = "+" + d
    contact = await db.contacts.find_one({"mobile": {"$regex": re.compile(re.escape(d[-10:]) + "$")}, "deleted": {"$ne": True}}, {"_id": 0})
    if contact:
        cid = contact["id"]
    else:
        cid = new_id()
        await db.contacts.insert_one({
            "id": cid, "name": body.name or f"Lead {d[-4:]}", "mobile": mobile, "email": None, "company": None,
            "contact_type": "lead", "address": None, "city": None, "state": None, "pincode": None, "gst": None,
            "category": None, "source": "chrome_extension", "assigned_to": user.get("id"),
            "tags": ["extension"], "notes": body.note or "", "opted_out": False, "is_demo": False,
            "deleted": False, "created_at": now_iso(), "updated_at": now_iso()})
    await db.leads.insert_one({
        "id": new_id(), "title": f"Extension lead {d[-4:]}", "contact_id": cid, "contact_name": body.name or f"Lead {d[-4:]}",
        "mobile": mobile, "company": None, "status": "new", "source": "chrome_extension", "value": 0, "specialty": None,
        "assigned_to": user.get("id"), "tags": ["extension"], "notes": (body.note or "") + (f" | from {body.page}" if body.page else ""),
        "is_demo": False, "deleted": False, "created_at": now_iso(), "updated_at": now_iso(), "last_contact": now_iso()})
    return {"ok": True, "contact_id": cid}


@router.get("/ext/download")
async def ext_download(user: dict = Depends(require_perm("contacts", "view"))):
    if not EXT_DIR.exists():
        return Response(status_code=404, content="extension not built")
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for p in EXT_DIR.rglob("*"):
            if p.is_file():
                z.write(p, p.relative_to(EXT_DIR))
    buf.seek(0)
    return StreamingResponse(buf, media_type="application/zip",
                             headers={"Content-Disposition": 'attachment; filename="vgrups-crm-extension.zip"'})


# ---------------- Website WhatsApp widget ----------------
async def _widget_number() -> str:
    try:
        import wa_client
        data = await wa_client.wa_list_sessions()
        for s in data.get("sessions", []):
            if s.get("status") == "connected" and s.get("phone"):
                return _digits(s["phone"])
    except Exception:
        pass
    return ""


@router.get("/widget.js")
async def widget_js(request: Request, number: Optional[str] = None, source: str = "website",
                    text: str = "Hi! I'd like to know more about VGRUPS Healthcare products."):
    num = _digits(number) if number else await _widget_number()
    js = """(function(){
  var NUM="%s", SRC="%s", TXT=%s;
  if(!NUM){return;}
  var cur=document.currentScript||(function(){var s=document.getElementsByTagName('script');for(var i=0;i<s.length;i++){if((s[i].src||'').indexOf('/api/widget.js')>-1)return s[i];}return null;})();
  var API=cur?cur.src.split('/api/widget.js')[0]:location.origin;
  var qs=new URLSearchParams(location.search);
  var utm=qs.get('utm_source')||qs.get('utm_campaign')||SRC;
  var btn=document.createElement('div');
  btn.setAttribute('data-vg-widget','1');
  btn.style.cssText='position:fixed;bottom:22px;right:22px;z-index:99999;background:#25D366;color:#fff;width:58px;height:58px;border-radius:50%%;display:flex;align-items:center;justify-content:center;box-shadow:0 6px 20px rgba(0,0,0,.25);cursor:pointer;transition:transform .2s;';
  btn.onmouseenter=function(){btn.style.transform='scale(1.08)';};
  btn.onmouseleave=function(){btn.style.transform='scale(1)';};
  btn.innerHTML='<svg width="30" height="30" viewBox="0 0 24 24" fill="#fff"><path d="M.057 24l1.687-6.163a11.867 11.867 0 01-1.587-5.945C.16 5.335 5.495 0 12.05 0a11.817 11.817 0 018.413 3.488 11.824 11.824 0 013.48 8.414c-.003 6.557-5.338 11.892-11.893 11.892a11.9 11.9 0 01-5.688-1.448L.057 24zm6.597-3.807c1.676.995 3.276 1.591 5.392 1.592 5.448 0 9.886-4.434 9.889-9.885.002-5.462-4.415-9.89-9.881-9.892-5.452 0-9.887 4.434-9.889 9.884a9.86 9.86 0 001.516 5.26l-.999 3.648 3.472-.957zm11.387-5.464c-.074-.124-.272-.198-.57-.347-.297-.149-1.758-.868-2.031-.967-.272-.099-.47-.149-.669.149-.198.297-.768.967-.941 1.165-.173.198-.347.223-.644.074-.297-.149-1.255-.462-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.297-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.372-.025-.521-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51l-.57-.01c-.198 0-.52.074-.792.372s-1.04 1.016-1.04 2.479 1.065 2.876 1.213 3.074c.149.198 2.095 3.2 5.076 4.487.709.306 1.263.489 1.694.626.712.226 1.36.194 1.872.118.571-.085 1.758-.719 2.006-1.413.248-.695.248-1.29.173-1.414z"/></svg>';
  btn.onclick=function(){
    try{fetch(API+"/api/widget/click",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({source:SRC,utm:utm,page:location.href,ref:document.referrer})});}catch(e){}
    window.open("https://wa.me/"+NUM+"?text="+encodeURIComponent(TXT),"_blank");
  };
  document.body.appendChild(btn);
})();""" % (num, source.replace('"', ''), ('"' + text.replace('"', '\\"') + '"'))
    return Response(content=js, media_type="application/javascript",
                    headers={"Cache-Control": "public, max-age=300"})


class ClickIn(BaseModel):
    source: Optional[str] = "website"
    utm: Optional[str] = None
    page: Optional[str] = None
    ref: Optional[str] = None


@router.post("/widget/click")
async def widget_click(body: ClickIn, request: Request):
    ip = request.client.host if request.client else "unknown"
    if not _throttle(ip):
        return {"ok": True}
    await db.widget_events.insert_one({
        "id": new_id(), "type": "click", "source": body.source or "website", "utm": body.utm,
        "page": body.page, "ref": body.ref, "ip": ip, "created_at": now_iso()})
    return {"ok": True}


@router.get("/widget/stats")
async def widget_stats(user: dict = Depends(require_perm("contacts", "view"))):
    total = await db.widget_events.count_documents({"type": "click"})
    pipeline = [{"$match": {"type": "click"}}, {"$group": {"_id": "$utm", "count": {"$sum": 1}}},
                {"$sort": {"count": -1}}, {"$limit": 10}]
    by_src = await db.widget_events.aggregate(pipeline).to_list(10)
    number = await _widget_number()
    return {"total_clicks": total, "by_source": [{"source": r["_id"] or "direct", "count": r["count"]} for r in by_src],
            "number": number}
