"""Delivery reports are derived from provider receipts, never simulated counters."""
import csv
import io
import re
from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import StreamingResponse
from auth import require_perm
from db import db
from campaign_report_query import fetch_report, export_rows
from whatsapp_routing import report_sender, report_sender_phones, readable_sender_phone

router = APIRouter(prefix="/api", tags=["campaign delivery reports"])
DELIVERIES = {"", "sent", "delivered", "read", "failed", "skipped", "uncertain", "pending"}


def delivery_for(parts, state):
    if state != "sent":
        return state
    statuses = [p["status"] for p in parts]
    if any(s in ("failed", "error") for s in statuses):
        return "failed"
    if statuses and all(s in ("read", "played") for s in statuses):
        return "read"
    if statuses and all(s in ("delivered", "read", "played") for s in statuses):
        return "delivered"
    return "sent"


def validate_filters(search, delivery, sender=""):
    if delivery not in DELIVERIES:
        raise HTTPException(422, "Invalid delivery filter.")
    if len(search) > 200:
        raise HTTPException(422, "Search must be at most 200 characters.")
    if not sender:
        return ""
    if sender.lower() == "unknown":
        return "Unknown"
    number = readable_sender_phone(sender)
    if not number or len(sender) > 64:
        raise HTTPException(422, "Sender must be a phone number or Unknown.")
    return number


async def get_campaign(cid, drip):
    campaign = await (db.drips if drip else db.campaigns).find_one({"id": cid}, {"_id": 0})
    if not campaign:
        raise HTTPException(404, "Campaign not found.")
    result = {k: campaign.get(k) for k in ("id", "name", "status", "message_gap_seconds", "scheduled_at", "sender_session_id")}
    result["sender_number"] = report_sender(campaign, await report_sender_phones(db))
    return result


async def delivery_report(cid, drip=False, page=1, page_size=50, search="", delivery="", sender=""):
    sender = validate_filters(search, delivery, sender)
    campaign = await get_campaign(cid, drip)
    report = await fetch_report(db, cid, drip, page, page_size, search.strip(), delivery, sender)
    return {"campaign": campaign, **report}


def csv_line(values):
    out = io.StringIO()
    # Preserve formula protection for all fields, including phone numbers.
    csv.writer(out).writerow([
        ("'" + str(v)) if str(v or "").startswith(("=", "+", "-", "@", "\t", "\r"))
        else ("" if v is None else v) for v in values
    ])
    return out.getvalue()


async def report_csv(cid, drip=False, search="", delivery="", sender=""):
    sender = validate_filters(search, delivery, sender)
    campaign = await get_campaign(cid, drip)

    async def chunks():
        yield csv_line(["Name", "Phone", "Send Status", "Delivery", "Replied", "Sent At", "Error", "Messages", "Sender number"])
        async for row in export_rows(db, cid, drip, search.strip(), delivery, sender):
            yield csv_line([row["name"], row["mobile"], row["status"], row["delivery"],
                            "yes" if row["replied"] else "no", row["sent_at"],
                            row["error"], row["message_count"], row["sender_number"]])

    name = re.sub(r"[^a-zA-Z0-9_-]+", "_", campaign["name"] or "campaign")[:80]
    return StreamingResponse(chunks(), media_type="text/csv",
        headers={"Content-Disposition": f'attachment; filename="{name}_delivery_report.csv"'})


@router.get("/campaigns/{cid}/report")
async def campaign_report(cid: str, page: int = Query(1, ge=1, le=2147483647),
                          page_size: int = Query(50, ge=1, le=200),
                          search: str = Query("", max_length=200), delivery: str = "",
                          sender: str = Query("", max_length=64),
                          user=Depends(require_perm("campaigns", "view"))):
    return await delivery_report(cid, page=page, page_size=page_size, search=search, delivery=delivery, sender=sender)


@router.get("/drips/{cid}/report")
async def drip_report(cid: str, page: int = Query(1, ge=1, le=2147483647),
                      page_size: int = Query(50, ge=1, le=200),
                      search: str = Query("", max_length=200), delivery: str = "",
                      sender: str = Query("", max_length=64),
                      user=Depends(require_perm("campaigns", "view"))):
    return await delivery_report(cid, True, page, page_size, search, delivery, sender)


@router.get("/drips/{cid}/report.csv")
async def drip_csv(cid: str, search: str = Query("", max_length=200), delivery: str = "",
                   sender: str = Query("", max_length=64),
                   user=Depends(require_perm("campaigns", "export"))):
    return await report_csv(cid, True, search, delivery, sender)