"""Remove explicitly marked demo data without guessing from names or addresses."""
from datetime import datetime, timezone


async def remove_demo_contacts(database):
    result = await database.contacts.update_many(
        {"is_demo": True, "deleted": {"$ne": True}},
        {"$set": {"deleted": True, "updated_at": datetime.now(timezone.utc).isoformat()}},
    )
    return result.modified_count


async def remove_demo_users(database):
    # Never remove the only working administrator, even in legacy datasets.
    real_admins = await database.users.count_documents({
        "is_demo": {"$ne": True}, "deleted": {"$ne": True},
        "active": {"$ne": False}, "role": {"$in": ["admin", "super_admin"]},
    })
    if not real_admins:
        raise RuntimeError("A real active administrator is required before removing demo users.")
    result = await database.users.update_many(
        {"is_demo": True, "$or": [{"deleted": {"$ne": True}}, {"active": {"$ne": False}}]},
        {"$set": {"deleted": True, "active": False,
                  "updated_at": datetime.now(timezone.utc).isoformat()}},
    )
    return result.modified_count


async def remove_demo_inbox(database):
    timestamp = datetime.now(timezone.utc).isoformat()
    for collection in (database.conversations, database.messages):
        await collection.update_many({"is_demo": True, "deleted": {"$ne": True}},
            {"$set": {"deleted": True, "updated_at": timestamp}})


async def remove_all_demo_data(database):
    """User-authorized app-wide cleanup, atomic and guarded by a real admin."""
    pool = await database.connect()
    async with pool.acquire() as connection:
        async with connection.transaction():
            admins = await connection.fetch(
                """SELECT document_id FROM app_documents
                WHERE collection_name='users'
                AND document->'is_demo' IS DISTINCT FROM 'true'::jsonb
                AND document->'deleted' IS DISTINCT FROM 'true'::jsonb
                AND document->'active' IS DISTINCT FROM 'false'::jsonb
                AND document->>'role'=ANY($1::text[]) FOR UPDATE""",
                ["admin", "super_admin"],
            )
            if not admins:
                raise RuntimeError("A real active administrator is required before demo cleanup.")
            # The credential store is never a cleanup target.
            counts = await connection.fetch(
                """SELECT collection_name, count(*) AS removed FROM app_documents
                WHERE document->'is_demo'='true'::jsonb AND collection_name <> 'wa_auth'
                GROUP BY collection_name"""
            )
            await connection.execute(
                """DELETE FROM app_documents
                WHERE document->'is_demo'='true'::jsonb AND collection_name <> 'wa_auth'"""
            )
            return {r["collection_name"]: r["removed"] for r in counts}