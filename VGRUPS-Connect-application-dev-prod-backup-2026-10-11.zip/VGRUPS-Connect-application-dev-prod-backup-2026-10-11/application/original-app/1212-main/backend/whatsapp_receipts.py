"""Monotonic receipt state and explicit provider stage times (never local clock times)."""
from datetime import datetime, timezone

RANKS = {"sent": 1, "failed": 2, "error": 2, "delivered": 3, "read": 4, "played": 4}
FIELDS = ("status", "status_at", "sent_at", "delivered_at", "read_at", "failed_at")


def provider_time(value):
    if value is None or isinstance(value, bool):
        return None
    try:
        if isinstance(value, str) and not value.replace(".", "", 1).isdigit():
            dt = datetime.fromisoformat(value.replace("Z", "+00:00"))
            if dt.tzinfo is None:
                return None
        else:
            seconds = float(value)
            if seconds <= 0:
                return None
            dt = datetime.fromtimestamp(seconds, timezone.utc)
        return dt.astimezone(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")
    except (ValueError, TypeError, OverflowError, OSError):
        return None


def merge_receipt(message, status, timestamp):
    fields = {key: message.get(key) for key in FIELDS}
    at = provider_time(timestamp)
    stage = {"played": "read", "error": "failed"}.get(status, status)
    key = f"{stage}_at"
    # Earliest explicit event for each stage survives duplicates and reordered events.
    if at:
        old = provider_time(fields.get(key))
        fields[key] = min(old, at) if old else at
    if RANKS[status] > RANKS.get(fields["status"], 0):
        fields["status"] = status
        fields["status_at"] = fields.get(key)
    elif stage == {"played": "read", "error": "failed"}.get(fields["status"], fields["status"]):
        fields["status_at"] = fields.get(key)
    return fields


async def apply_receipt(messages, wamid, status, timestamp):
    if not wamid or status not in RANKS:
        return
    # Compare-and-swap protects against simultaneous gateway/webhook updates.
    while True:
        message = await messages.find_one({"wamid": wamid})
        if not message:
            return
        fields = merge_receipt(message, status, timestamp)
        if all(message.get(k) == v for k, v in fields.items()):
            return
        selector = {"wamid": wamid, **{k: message.get(k) for k in FIELDS}}
        result = await messages.update_one(selector, {"$set": fields})
        if result.matched_count:
            return


async def reconcile_receipts(messages, wamid):
    """Evidence is retained, so concurrent reconciliation cannot consume it."""
    evidence = await messages.database["whatsapp_receipts"].find_one({"wamid": wamid})
    if not evidence:
        return
    # Apply each explicit stage independently; a read does not date delivery.
    for stage in ("sent", "failed", "delivered", "read"):
        if evidence.get(f"{stage}_at"):
            await apply_receipt(messages, wamid, stage, evidence[f"{stage}_at"])
    if evidence.get("status") in RANKS:
        await apply_receipt(messages, wamid, evidence["status"], None)


async def save_receipt(messages, wamid, status, timestamp):
    if not wamid or status not in RANKS:
        return
    evidence = messages.database["whatsapp_receipts"]
    # Upsert only the exact key, not a CAS selector: otherwise a race can insert
    # multiple evidence rows. Both stores serialize this upsert across runtimes.
    await evidence.update_one({"wamid": wamid}, {"$setOnInsert": {"wamid": wamid}}, upsert=True)
    await apply_receipt(evidence, wamid, status, timestamp)
    await reconcile_receipts(messages, wamid)
