import random
from datetime import timedelta

from db import db, new_id, now_iso, utcnow
from auth import hash_password

CITIES = [("Mumbai", "Maharashtra"), ("Pune", "Maharashtra"), ("Delhi", "Delhi"),
          ("Bengaluru", "Karnataka"), ("Chennai", "Tamil Nadu"), ("Hyderabad", "Telangana"),
          ("Ahmedabad", "Gujarat"), ("Jaipur", "Rajasthan"), ("Kolkata", "West Bengal"),
          ("Lucknow", "Uttar Pradesh")]
CTYPES = ["lead", "customer", "doctor", "hospital", "pharmacy", "distributor", "cf", "medical_shop", "institution"]
SOURCES = ["whatsapp", "website", "google", "meta", "facebook", "qr", "chrome_extension", "referral", "campaign", "api"]
SPECIALTIES = ["Cardiology", "Orthopedics", "General Medicine", "Pediatrics", "Gynecology", "ENT", "Dermatology"]
LEAD_STATUSES = ["new", "contacted", "qualified", "interested", "quotation", "negotiation", "won", "lost", "follow_up"]
FIRST = ["Rajesh", "Ananya", "Vikram", "Priya", "Arjun", "Sneha", "Karan", "Divya", "Amit", "Pooja",
         "Suresh", "Neha", "Rohit", "Kavya", "Manish", "Ritu", "Deepak", "Anjali", "Sanjay", "Meera"]
LAST = ["Sharma", "Verma", "Patel", "Nair", "Reddy", "Gupta", "Mehta", "Iyer", "Joshi", "Kumar"]
COMPANIES = ["Apollo Clinic", "MedPlus Pharmacy", "City Hospital", "LifeCare Diagnostics", "Wellness Pharma",
             "Sunrise Medicos", "Metro Distributors", "HealthFirst C&F", "Care Medical Store", "Nova Institute"]

PRODUCTS = [
    ("VD3K2", "Vitamin D3 + K2 Supplement", "Supplements", 450, 380, 12, "3004"),
    ("VFOLIC", "VFolic Folic Acid Tablets", "Supplements", 120, 95, 12, "3004"),
    ("VCOMPLEX", "VComplex Multivitamin", "Supplements", 320, 270, 12, "3004"),
    ("NG-100", "Nitrile Examination Gloves (100)", "Disposables", 650, 540, 18, "4015"),
    ("SM-50", "3-Ply Surgical Masks (50)", "Disposables", 250, 180, 18, "6307"),
    ("N95-20", "N95 Respirator Masks (20)", "Disposables", 900, 720, 18, "6307"),
    ("AD-10", "Adult Diapers Large (10)", "Personal Care", 420, 350, 12, "9619"),
    ("WW-80", "Wet Wipes Pack (80)", "Personal Care", 150, 110, 18, "3401"),
    ("SAN-500", "Hand Sanitizer 500ml", "Personal Care", 180, 130, 18, "3808"),
    ("ECG-250", "ECG Electrode Gel 250ml", "Diagnostics", 220, 170, 12, "3006"),
    ("SONO-250", "Sonography Ultrasound Gel 250ml", "Diagnostics", 200, 150, 12, "3006"),
    ("BP-01", "Digital BP Monitor", "Devices", 1800, 1450, 18, "9018"),
    ("OXY-01", "Fingertip Pulse Oximeter", "Devices", 1200, 950, 18, "9018"),
    ("THERMO-01", "Infrared Thermometer", "Devices", 1500, 1150, 18, "9025"),
    ("GLUCO-01", "Glucometer Kit", "Devices", 900, 720, 12, "9018"),
]


def _dt(days_ago):
    return (utcnow() - timedelta(days=days_ago, hours=random.randint(0, 20))).isoformat()


_IMG = lambda pid: f"https://images.unsplash.com/photo-{pid}?auto=format&fit=crop&w=500&q=70"
PRODUCT_IMAGES = {
    "VD3K2": _IMG("1655976515592-ade289fd4881"),
    "VFOLIC": _IMG("1550572017-26b5655c1e8c"),
    "VCOMPLEX": _IMG("1701201632697-7ec41bfee65f"),
    "NG-100": _IMG("1584820927498-cfe5211fd8bf"),
    "SM-50": _IMG("1614290501125-d72aeb735c10"),
    "N95-20": _IMG("1586975949231-9374052a0d63"),
    "AD-10": _IMG("1712842955521-55c8c01ef148"),
    "WW-80": _IMG("1633265484557-e298493cb162"),
    "SAN-500": _IMG("1583947582886-f40ec95dd752"),
    "ECG-250": _IMG("1673193420417-082eef2ac9f9"),
    "SONO-250": _IMG("1691933880096-4046bc9e2fa0"),
    "BP-01": _IMG("1615486511484-92e172cc4fe0"),
    "OXY-01": _IMG("1626851528990-fee2c2e6fadb"),
    "THERMO-01": _IMG("1615486511369-31ff08672204"),
    "GLUCO-01": _IMG("1683727186226-910f31a9da45"),
}


async def seed_product_images():
    """Attach a distinct stock photo to every catalog product (one per SKU)."""
    for code, url in PRODUCT_IMAGES.items():
        await db.products.update_one({"code": code}, {"$set": {"image": url}})


async def seed_demo():
    if await db.contacts.count_documents({"is_demo": True}) > 0:
        return

    # Employees (10)
    emp_ids = []
    roles = ["sales_manager", "mr", "mr", "mr", "marketing", "customer_support", "accounts", "distributor", "cf", "medical_shop"]
    for i in range(10):
        name = f"{random.choice(FIRST)} {random.choice(LAST)}"
        uid = new_id()
        emp_ids.append((uid, roles[i], name))
        await db.users.insert_one({
            "id": uid, "name": name, "email": f"demo.user{i+1}@vgrups.in",
            "password_hash": hash_password("Welcome@123"), "role": roles[i],
            "phone": f"+9198{random.randint(10000000, 99999999)}", "active": True,
            "is_demo": True, "avatar": None, "created_at": _dt(90), "updated_at": now_iso()})
    mr_ids = [e[0] for e in emp_ids if e[1] == "mr"]

    # Products (15)
    for code, name, cat, mrp, sp, gst, hsn in PRODUCTS:
        await db.products.insert_one({
            "id": new_id(), "code": code, "name": name, "category": cat, "subcategory": "",
            "description": f"{name} — VGRUPS Healthcare quality assured.", "pack_size": "1 unit",
            "unit": "pcs", "mrp": mrp, "selling_price": sp, "gst": gst, "hsn": hsn,
            "stock": random.randint(50, 800), "manufacturer": "VGRUPS Healthcare", "brand": "VGRUPS",
            "images": [], "is_demo": True, "deleted": False, "created_at": _dt(120), "updated_at": now_iso()})

    # Contacts (50)
    contact_ids = []
    for i in range(50):
        city, state = random.choice(CITIES)
        ctype = random.choice(CTYPES)
        name = f"{'Dr. ' if ctype == 'doctor' else ''}{random.choice(FIRST)} {random.choice(LAST)}"
        cid = new_id()
        contact_ids.append((cid, name, ctype))
        await db.contacts.insert_one({
            "id": cid, "name": name, "mobile": f"+9197{random.randint(10000000, 99999999)}",
            "email": f"contact{i+1}@example.in", "company": random.choice(COMPANIES),
            "contact_type": ctype, "address": f"{random.randint(1,99)}, Health St",
            "city": city, "state": state, "pincode": f"{random.randint(100000, 999999)}",
            "gst": f"27ABCDE{random.randint(1000,9999)}F1Z5", "category": random.choice(SPECIALTIES),
            "source": random.choice(SOURCES), "assigned_to": random.choice(mr_ids) if mr_ids else None,
            "tags": random.sample(["vip", "wholesale", "repeat", "new", "priority"], k=random.randint(0, 2)),
            "notes": "", "is_demo": True, "deleted": False, "created_at": _dt(random.randint(0, 60)), "updated_at": now_iso()})

    # Leads (25)
    for i in range(25):
        c = random.choice(contact_ids)
        await db.leads.insert_one({
            "id": new_id(), "title": f"{random.choice(['Bulk order', 'Sample request', 'Quotation', 'New enquiry', 'Repeat order'])} - {c[1]}",
            "contact_id": c[0], "contact_name": c[1], "mobile": f"+9197{random.randint(10000000, 99999999)}",
            "company": random.choice(COMPANIES), "status": random.choice(LEAD_STATUSES),
            "source": random.choice(SOURCES), "value": random.choice([5000, 12000, 25000, 48000, 75000, 120000]),
            "specialty": random.choice(SPECIALTIES), "assigned_to": random.choice(mr_ids) if mr_ids else None,
            "tags": [], "notes": "", "is_demo": True, "deleted": False,
            "created_at": _dt(random.randint(0, 45)), "updated_at": now_iso(), "last_contact": _dt(random.randint(0, 10))})

    # Conversations (20) + messages
    sample_in = ["Hello, I need product details", "What is the price for bulk order?", "Please share catalog",
                 "Is this in stock?", "Can you send a quotation?", "Thanks for the info"]
    sample_out = ["Hi! Thanks for reaching out to VGRUPS Healthcare.", "Sure, sharing the details now.",
                  "Here is our latest catalog.", "Yes, it's available. How many units?", "Quotation shared on email."]
    for i in range(20):
        c = random.choice(contact_ids)
        conv_id = new_id()
        last = _dt(random.randint(0, 5))
        unread = random.choice([0, 0, 1, 2, 3])
        await db.conversations.insert_one({
            "id": conv_id, "phone": f"+9197{random.randint(10000000, 99999999)}", "name": c[1],
            "contact_id": c[0], "contact_type": c[2], "assigned_to": random.choice(mr_ids) if mr_ids else None,
            "unread": unread, "starred": random.random() < 0.2, "archived": False, "status": "open",
            "last_message": random.choice(sample_in), "last_message_at": last,
            "is_demo": True, "created_at": _dt(random.randint(5, 30))})
        n = random.randint(3, 7)
        for j in range(n):
            inbound = j % 2 == 0
            await db.messages.insert_one({
                "id": new_id(), "conversation_id": conv_id, "wamid": None,
                "direction": "inbound" if inbound else "outbound", "type": "text",
                "body": random.choice(sample_in if inbound else sample_out),
                "status": "received" if inbound else "read", "is_demo": True,
                "sender": c[1] if inbound else "VGRUPS Team",
                "created_at": (utcnow() - timedelta(days=1, minutes=(n - j) * 7)).isoformat()})

    # Orders (15)
    statuses = ["new", "confirmed", "processing", "packed", "shipped", "delivered"]
    pay = ["paid", "pending", "paid", "paid", "pending"]
    for i in range(15):
        c = random.choice(contact_ids)
        total = random.choice([4500, 9800, 15600, 23400, 56000, 89000])
        await db.orders.insert_one({
            "id": new_id(), "order_no": f"VG{10000 + i}", "contact_id": c[0], "contact_name": c[1],
            "status": random.choice(statuses), "payment_status": random.choice(pay),
            "total": total, "items_count": random.randint(1, 6), "is_demo": True,
            "created_at": _dt(random.randint(0, 40)), "updated_at": now_iso()})

    # Campaigns (5)
    for i, nm in enumerate(["Diwali Pharma Offer", "New Product Launch - VD3K2", "Distributor Reactivation",
                            "Monsoon Health Kit", "Year End Clearance"]):
        sent = random.randint(500, 5000)
        delivered = int(sent * random.uniform(0.9, 0.99))
        read = int(delivered * random.uniform(0.6, 0.85))
        replies = int(read * random.uniform(0.05, 0.2))
        await db.campaigns.insert_one({
            "id": new_id(), "name": nm, "template": "promo_template", "audience": "all",
            "status": random.choice(["completed", "running", "scheduled"]),
            "stats": {"sent": sent, "delivered": delivered, "read": read, "failed": sent - delivered,
                      "replies": replies, "leads": int(replies * 0.4), "orders": int(replies * 0.15)},
            "is_demo": True, "created_at": _dt(random.randint(5, 30)), "updated_at": now_iso()})

    # WhatsApp Templates
    for nm, cat, body in [
        ("welcome_lead", "MARKETING", "Hi {name}, welcome to VGRUPS Healthcare! How can we help you today?"),
        ("order_confirmation", "UTILITY", "Hi {name}, your order {order_id} is confirmed. Total: {1}."),
        ("otp_authentication", "AUTHENTICATION", "Your VGRUPS verification code is {1}. Valid for 5 minutes."),
        ("quotation_followup", "MARKETING", "Hi {name}, following up on the quotation for {product}. Shall we proceed?"),
    ]:
        await db.whatsapp_templates.insert_one({
            "id": new_id(), "name": nm, "category": cat, "language": "en_US", "header": None,
            "body": body, "footer": "VGRUPS Healthcare", "buttons": [], "variables": ["name"],
            "status": random.choice(["approved", "pending", "draft"]), "is_demo": True, "deleted": False,
            "created_at": _dt(30), "updated_at": now_iso()})

    # Tasks / follow-ups
    for i in range(12):
        c = random.choice(contact_ids)
        await db.tasks.insert_one({
            "id": new_id(), "title": f"Follow up with {c[1]}",
            "task_type": random.choice(["lead_follow_up", "customer_call", "quotation_follow_up", "payment_follow_up"]),
            "contact_id": c[0], "contact_name": c[1], "assigned_to": random.choice(mr_ids) if mr_ids else None,
            "priority": random.choice(["low", "medium", "high"]),
            "due_date": (utcnow() + timedelta(days=random.randint(-2, 5))).isoformat(),
            "status": random.choice(["pending", "pending", "done"]), "notes": "", "is_demo": True,
            "created_by": None, "created_at": _dt(random.randint(0, 10)), "updated_at": now_iso()})
