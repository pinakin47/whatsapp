"""User-requested automatic enrollment. Apply once on publication, never to live data from development."""
import os
from auth import permissions_for
from db import now_iso


async def ensure_automatic_mrs(database, production=None):
    if production is None:
        production = (os.environ.get("REPLIT_DEPLOYMENT") == "1" or
            os.environ.get("APP_ENV") == "production" or os.environ.get("NODE_ENV") == "production")
    if not production:
        return
    marker = await database.app_config.find_one({"key": "automatic_registered_mrs"})
    if marker:
        return
    actors = await database.users.find({"role": {"$in": ["super_admin", "admin"]},
        "active": {"$ne": False}, "deleted": {"$ne": True}, "is_demo": {"$ne": True}}).to_list(None)
    actor = next((u for u in actors if "manage" in permissions_for(u["role"]).get("settings", []) and
        "send" in permissions_for(u["role"]).get("whatsapp", [])), None)
    if not actor:
        return
    now = now_iso()
    for key, patch in (
        ("mr_ivr", {"enabled": True}),
        ("mr_catalog_daily", {"enabled": True, "time": "09:00"}),
        ("mr_lead_capture", {"enabled": True, "authorized_messages_confirmed": True, "ai_auto_reply": True})):
        old = (await database.app_config.find_one({"key": key}) or {}).get("value", {})
        value = {**old, **patch}
        if key == "mr_lead_capture":
            value.update(approved_by=actor["id"], enabled_since=(old.get("enabled_since") if old.get("enabled") else None) or now,
                         ai_reply_enabled_since=old.get("ai_reply_enabled_since") or now)
        await database.app_config.update_one({"key": key}, {"$set": {
            "key": key, "value": value, "approved_by": actor["id"], "updated_at": now}}, upsert=True)
    await database.app_config.update_one({"key": "automatic_registered_mrs"}, {"$setOnInsert": {
        "key": "automatic_registered_mrs", "applied_at": now, "approved_by": actor["id"]}}, upsert=True)
