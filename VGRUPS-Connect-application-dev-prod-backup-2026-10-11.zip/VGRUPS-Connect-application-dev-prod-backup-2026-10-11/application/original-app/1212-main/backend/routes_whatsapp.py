import hashlib
import hmac
import json
import os
import re
from datetime import datetime, timezone
from fastapi import APIRouter, Depends, HTTPException, Request, Query
from fastapi.responses import PlainTextResponse
from pydantic import BaseModel, Field, model_validator
from typing import Optional

from db import db, new_id, now_iso, log_audit
from auth import get_current_user, require_perm, permissions_for
from integrations import integration_status, whatsapp_configured, send_whatsapp_text
from inbox_scope import linked_session, scoped_conversation
from whatsapp_routing import sender, qr_configured
from whatsapp_receipts import save_receipt

router = APIRouter(prefix="/api/whatsapp", tags=["whatsapp"])
webhook_router = APIRouter(prefix="/api/webhooks", tags=["webhooks"])


@router.get("/status")
async def status(user: dict = Depends(get_current_user)):
    from wa_client import wa_list_sessions
    st = integration_status()["whatsapp"]
    sessions = await wa_list_sessions()
    st["qr_connected"] = bool(sessions.get("connected"))
    st["qr_sessions"] = sessions.get("sessions", [])
    st["active"] = st["configured"] or st["qr_connected"]
    return st


# ---------------- Templates ----------------
class TemplateIn(BaseModel):
    name: str
    category: str = "MARKETING"  # UTILITY | MARKETING | AUTHENTICATION
    language: str = "en_US"
    header: Optional[str] = None
    body: str
    footer: Optional[str] = None
    buttons: list[dict] = []
    variables: list[str] = []


@router.get("/templates")
async def list_templates(user: dict = Depends(get_current_user)):
    items = await db.whatsapp_templates.find({"deleted": {"$ne": True}}, {"_id": 0}).sort("created_at", -1).to_list(200)
    return {"items": items}


@router.post("/templates")
async def create_template(body: TemplateIn, user: dict = Depends(require_perm("whatsapp", "create"))):
    doc = body.model_dump()
    doc.update({"id": new_id(), "status": "draft", "is_demo": False, "deleted": False,
                "created_by": user["id"], "created_at": now_iso(), "updated_at": now_iso()})
    await db.whatsapp_templates.insert_one(doc)
    await log_audit(user, "create", "whatsapp", doc["id"], detail=body.name)
    doc.pop("_id", None)
    return doc


@router.put("/templates/{tid}")
async def update_template(tid: str, body: TemplateIn, user: dict = Depends(require_perm("whatsapp", "edit"))):
    upd = body.model_dump()
    upd["updated_at"] = now_iso()
    res = await db.whatsapp_templates.update_one({"id": tid}, {"$set": upd})
    if res.matched_count == 0:
        raise HTTPException(status_code=404, detail="Template not found")
    return await db.whatsapp_templates.find_one({"id": tid}, {"_id": 0})


@router.post("/templates/{tid}/submit")
async def submit_template(tid: str, user: dict = Depends(require_perm("whatsapp", "approve"))):
    # Submitting to Meta requires configured WABA. Without it, stays local.
    if not whatsapp_configured():
        raise HTTPException(status_code=503, detail="Connect WhatsApp Cloud API to submit templates to Meta for approval.")
    await db.whatsapp_templates.update_one({"id": tid}, {"$set": {"status": "pending", "updated_at": now_iso()}})
    return {"ok": True, "status": "pending"}


@router.delete("/templates/{tid}")
async def delete_template(tid: str, user: dict = Depends(require_perm("whatsapp", "delete"))):
    await db.whatsapp_templates.update_one({"id": tid}, {"$set": {"deleted": True}})
    return {"ok": True}


# ---------------- Conversations / Inbox ----------------
@router.get("/conversations")
async def list_conversations(user: dict = Depends(require_perm("inbox", "view")), folder: str = "all", search: Optional[str] = None, session_id: Optional[str] = None):
    session = await linked_session(db, session_id=session_id)
    if not session:
        return {"items": [], "linked": False, "linked_session": None, "empty_reason": "no_linked_number"}
    q: dict = {"session_id": session["id"], "is_demo": {"$ne": True}, "deleted": {"$ne": True}}
    if folder == "unread":
        q["unread"] = {"$gt": 0}
    elif folder == "assigned_me":
        q["assigned_to"] = user["id"]
    elif folder == "unassigned":
        q["assigned_to"] = None
    elif folder == "starred":
        q["starred"] = True
    elif folder == "archived":
        q["archived"] = True
    elif folder in ("customer", "lead", "distributor", "medical_shop", "hospital", "doctor"):
        q["contact_type"] = folder
    if folder != "archived":
        q.setdefault("archived", {"$ne": True})
    if search:
        q["$or"] = [{"name": {"$regex": search, "$options": "i"}},
                    {"phone": {"$regex": search, "$options": "i"}}]
    items = await db.conversations.find(q, {"_id": 0}).sort("last_message_at", -1).to_list(200)
    return {"items": items, "linked": True,
            "connected": session.get("status") == "connected",
            "linked_session": {k: session.get(k) for k in ("id", "name", "phone", "status")},
            "empty_reason": None if items else "no_real_chats"}


@router.get("/conversations/{cid}/messages")
async def get_messages(cid: str, user: dict = Depends(require_perm("inbox", "view")), session_id: Optional[str] = None):
    conv, session = await scoped_conversation(cid, db, session_id=session_id)
    msgs = await db.messages.find({"conversation_id": cid, "session_id": session["id"],
                                  "is_demo": {"$ne": True}, "deleted": {"$ne": True}}, {"_id": 0}).sort("created_at", -1).to_list(500)
    msgs.reverse()  # Keep the newest history on refresh, in chronological display order.
    await db.conversations.update_one({"id": cid}, {"$set": {"unread": 0}})
    contact = None
    if conv.get("contact_id"):
        contact = await db.contacts.find_one({"id": conv["contact_id"]}, {"_id": 0})
    return {"conversation": conv, "messages": msgs, "contact": contact}


class SendMessageIn(BaseModel):
    body: str


class RecipientMessageIn(BaseModel):
    body: str = Field(min_length=1, max_length=10000)
    contact_id: Optional[str] = None
    phone: Optional[str] = None
    request_key: Optional[str] = Field(default=None, min_length=16, max_length=128, pattern=r"^[A-Za-z0-9_-]+$")
    session_id: Optional[str] = None

    @model_validator(mode="after")
    def validate_recipient(self):
        if bool(self.contact_id) == bool(self.phone):
            raise ValueError("Choose one contact or enter one international phone number.")
        if not self.body.strip():
            raise ValueError("Message cannot be blank.")
        if self.phone:
            self.phone = re.sub(r"[\s().-]", "", self.phone)
            if not re.fullmatch(r"\+[1-9][0-9]{7,14}", self.phone):
                raise ValueError("Use an international number with + and country code (8–15 digits).")
        return self


class RecoverMessageIn(RecipientMessageIn):
    request_key: str = Field(min_length=16, max_length=128, pattern=r"^[A-Za-z0-9_-]+$")


def _request_identity(body, user):
    fields = [body.contact_id, body.phone, body.body]
    if body.session_id:
        fields.append(body.session_id)
    return (
        hashlib.sha256(f"{user['id']}:{body.request_key}".encode()).hexdigest(),
        hashlib.sha256(json.dumps(
            fields, ensure_ascii=False).encode()).hexdigest(),
    )


@router.post("/send/recover")
async def recover_send(body: RecoverMessageIn, user: dict = Depends(require_perm("inbox", "send"))):
    """Check persisted evidence only. This endpoint never contacts a send provider."""
    if body.contact_id and "view" not in permissions_for(user.get("role", "view_only")).get("crm", []):
        raise HTTPException(status_code=403, detail="You do not have permission to view contacts.")
    request_id, fingerprint = _request_identity(body, user)
    existing = await db.whatsapp_send_requests.find_one({"id": request_id}, {"_id": 0})
    if not existing:
        raise HTTPException(status_code=404, detail="No reservation found for this account and request. This is not proof that a delayed send was never accepted.")
    if existing["fingerprint"] != fingerprint:
        raise HTTPException(status_code=409, detail="This request key belongs to a different message or recipient.")
    from whatsapp_send_recovery import reconcile_send
    return await reconcile_send(existing, user, db, _record_sent_message)


@router.post("/send")
async def send_to_recipient(body: RecipientMessageIn, user: dict = Depends(require_perm("inbox", "send"))):
    session = await sender(db, body.session_id) if body.session_id or await qr_configured(db) else None
    scope = {"session_id": session["id"] if session else None, "is_demo": {"$ne": True}, "deleted": {"$ne": True}}
    """Resolve a recipient, then use the same authorized provider flow as Inbox."""
    contact = None
    if body.contact_id:
        if "view" not in permissions_for(user.get("role", "view_only")).get("crm", []):
            raise HTTPException(status_code=403, detail="You do not have permission to view contacts.")
        contact = await db.contacts.find_one(
            {"id": body.contact_id, "deleted": {"$ne": True}, "is_demo": {"$ne": True}}, {"_id": 0})
        if not contact:
            raise HTTPException(status_code=404, detail="Real contact not found.")
        phone = re.sub(r"[\s().-]", "", contact.get("mobile") or "")
        # Stored CRM numbers may omit the +, but must still include a country code.
        if not re.fullmatch(r"\+?[1-9][0-9]{7,14}", phone):
            raise HTTPException(status_code=422, detail="Contact needs a valid international mobile number. Enter it manually with + and country code.")
        phone = phone.lstrip("+")
        conv = await db.conversations.find_one({"contact_id": contact["id"], **scope}, {"_id": 0})
    else:
        phone = body.phone.lstrip("+")
        conv = None
    if not conv:
        conv = await db.conversations.find_one({"phone": {"$in": [phone, "+" + phone]}, **scope}, {"_id": 0})
    if not conv:
        candidate = {
            "id": new_id(), "phone": phone, "name": contact["name"] if contact else "+" + phone,
            "contact_id": contact["id"] if contact else None,
            "contact_type": contact.get("contact_type", "customer") if contact else "customer",
            "status": "open", "unread": 0, "assigned_to": None, "archived": False,
            "starred": False, **scope, "is_demo": False, "deleted": False, "created_at": now_iso(),
            "last_message": "", "last_message_at": now_iso(),
        }
        await db.conversations.update_one({"phone": phone, **scope}, {"$setOnInsert": candidate}, upsert=True)
        conv = await db.conversations.find_one({"phone": phone, **scope}, {"_id": 0})
    request_id = None
    fingerprint = None
    if body.request_key:
        request_id, fingerprint = _request_identity(body, user)
    return await _send_message(conv["id"], SendMessageIn(body=body.body), user, request_id, fingerprint)


@router.post("/conversations/{cid}/send")
async def send_message(cid: str, body: SendMessageIn, user: dict = Depends(require_perm("inbox", "send")), session_id: Optional[str] = None):
    _, session = await scoped_conversation(cid, db, session_id=session_id)
    if session.get("status") != "connected":
        raise HTTPException(409, "WhatsApp is offline. Reconnect the linked number to send.")
    return await _send_message(cid, body, user)


async def _send_message(cid, body, user, request_id=None, fingerprint=None):
    conv = await db.conversations.find_one({"id": cid}, {"_id": 0})
    if not conv:
        raise HTTPException(status_code=404, detail="Conversation not found")
    from wa_client import wa_connected, wa_send
    if request_id:
        existing = await db.whatsapp_send_requests.find_one({"id": request_id}, {"_id": 0})
        if existing:
            return await _replay_send(existing, fingerprint, user)
    # Check availability before reserving the key: a disconnected request is safe to retry.
    if conv.get("session_id"):
        await sender(db, conv["session_id"])
        qr_connected = True
    else:
        qr_connected = await wa_connected()
    if not qr_connected and not whatsapp_configured():
        raise HTTPException(status_code=503,
                            detail="No WhatsApp connection. Scan a WhatsApp QR in WhatsApp → Connections (or configure Cloud API) to send messages.")
    if request_id:
        claim = await db.whatsapp_send_requests.update_one(
            {"id": request_id}, {"$setOnInsert": {
                "id": request_id, "fingerprint": fingerprint, "state": "sending",
                "created_at": now_iso(), "user_id": user["id"],
                "conversation_id": cid, "message_body": body.body,
                "recipient_address": conv["phone"], "provider": "qr" if qr_connected else "cloud",
                "selected_session_id": conv.get("session_id"),
            }}, upsert=True)
        if not claim.upserted_id:
            existing = await db.whatsapp_send_requests.find_one({"id": request_id}, {"_id": 0})
            return await _replay_send(existing, fingerprint, user)
    # A durable 'sending' reservation is never expired automatically. A timeout
    # or process crash can occur after provider acceptance; resending is unsafe.
    wamid = None
    if qr_connected:
        try:
            options = {"session_id": conv["session_id"]} if conv.get("session_id") else {}
            resp = await wa_send(conv["phone"], body.body, request_id=request_id, **options) if request_id else await wa_send(conv["phone"], body.body, **options)
            wamid = resp.get("wamid")
        except Exception as e:
            raise HTTPException(status_code=502, detail=f"WhatsApp send failed: {e}")
    elif whatsapp_configured():
        try:
            resp = await send_whatsapp_text(conv["phone"], body.body)
            wamid = resp.get("messages", [{}])[0].get("id")
        except Exception as e:
            raise HTTPException(status_code=502, detail=f"Send failed: {e}")
    if not wamid:
        raise HTTPException(status_code=502, detail="WhatsApp did not confirm acceptance. Check Inbox before retrying to avoid a duplicate message.")
    msg = {"id": new_id(), "conversation_id": cid, "wamid": wamid, "direction": "outbound",
           "type": "text", "body": body.body, "status": "sent", "is_demo": False,
           "sender": user["name"], "sender_user_id": user["id"],
           "authorized_provider": "qr" if qr_connected else "meta", "created_at": now_iso()}
    if qr_connected and resp.get("session_id"):
        msg["session_id"] = resp["session_id"]
    if request_id:
        # Commit acceptance BEFORE Inbox/audit work or the HTTP response. If
        # later work fails, retry repairs the Inbox without calling the provider.
        await db.whatsapp_send_requests.update_one(
            {"id": request_id}, {"$set": {"state": "accepted", "response": msg, "accepted_at": now_iso()}})
    return await _record_sent_message(msg, user, request_id)


async def _replay_send(existing, fingerprint, user):
    if existing["fingerprint"] != fingerprint:
        raise HTTPException(status_code=409, detail="This request key belongs to a different message or recipient.")
    if existing["state"] == "completed":
        return existing["response"]
    if existing["state"] == "accepted":
        return await _record_sent_message(existing["response"], user, existing["id"])
    raise HTTPException(status_code=409, detail=(
        "This send is still in progress or its result is uncertain. No second message was sent. Check Inbox before starting another send."))


async def _record_sent_message(msg, user, request_id=None):
    cid, wamid = msg["conversation_id"], msg["wamid"]
    if wamid:
        # The linked-phone echo may have arrived before this API request finished.
        update = {"$setOnInsert": msg}
        if msg.get("session_id"):
            update["$set"] = {"session_id": msg["session_id"]}
        if msg.get("sender_user_id"):
            update.setdefault("$set", {}).update(sender_user_id=msg["sender_user_id"],
                                                authorized_provider=msg.get("authorized_provider"))
        await db.messages.update_one({"wamid": wamid}, update, upsert=True)
        msg = await db.messages.find_one({"wamid": wamid}, {"_id": 0})
    else:
        await db.messages.insert_one(msg)
    from lead_capture_core import safe_enqueue_message
    await safe_enqueue_message(db, msg)
    cid = msg["conversation_id"]
    if msg.get("session_id"):
        await db.conversations.update_one({"id": cid}, {"$set": {"session_id": msg["session_id"]}})
    # Repairing an older accepted send must not replace a newer Inbox preview.
    await db.conversations.update_one(
        {"id": cid, "$or": [{"last_message_at": {"$lte": msg["created_at"]}}, {"last_message_at": None}]},
        {"$set": {"last_message": msg["body"], "last_message_at": msg["created_at"]}})
    await log_audit(user, "send_message", "whatsapp", cid)
    msg.pop("_id", None)
    if request_id:
        await db.whatsapp_send_requests.update_one(
            {"id": request_id}, {"$set": {"state": "completed", "response": msg}})
    return msg


class AssignIn(BaseModel):
    assigned_to: Optional[str] = None


@router.post("/conversations/{cid}/assign")
async def assign_conversation(cid: str, body: AssignIn, user: dict = Depends(require_perm("inbox", "assign")), session_id: Optional[str] = None):
    await scoped_conversation(cid, db, session_id=session_id)
    res = await db.conversations.update_one({"id": cid}, {"$set": {"assigned_to": body.assigned_to, "updated_at": now_iso()}})
    if res.matched_count == 0:
        raise HTTPException(status_code=404, detail="Conversation not found")
    await log_audit(user, "assign", "inbox", cid, detail=body.assigned_to)
    return {"ok": True}


@router.post("/conversations/{cid}/flag")
async def flag_conversation(cid: str, action: str = Query(...), user: dict = Depends(require_perm("inbox", "edit")), session_id: Optional[str] = None):
    await scoped_conversation(cid, db, session_id=session_id)
    updates = {
        "star": {"starred": True}, "unstar": {"starred": False},
        "archive": {"archived": True}, "unarchive": {"archived": False},
        "close": {"status": "closed"},
    }.get(action)
    if updates is None:
        raise HTTPException(status_code=422, detail="Invalid action")
    updates["updated_at"] = now_iso()
    await db.conversations.update_one({"id": cid}, {"$set": updates})
    return {"ok": True}


# ---------------- Webhook ----------------
@webhook_router.get("/whatsapp", response_class=PlainTextResponse)
async def verify_webhook(
    hub_mode: Optional[str] = Query(None, alias="hub.mode"),
    hub_challenge: Optional[str] = Query(None, alias="hub.challenge"),
    hub_verify_token: Optional[str] = Query(None, alias="hub.verify_token"),
):
    verify = (os.environ.get("META_WEBHOOK_VERIFY_TOKEN") or "").strip()
    if hub_mode == "subscribe" and verify and hmac.compare_digest(hub_verify_token or "", verify):
        return hub_challenge or ""
    raise HTTPException(status_code=403, detail="verification failed")


def _valid_signature(raw: bytes, header: Optional[str]) -> bool:
    secret = (os.environ.get("META_APP_SECRET") or "").strip()
    if not secret or not header or not header.startswith("sha256="):
        return False
    expected = hmac.new(secret.encode(), raw, hashlib.sha256).hexdigest()
    return hmac.compare_digest(expected, header[7:])


@webhook_router.post("/whatsapp")
async def receive_webhook(request: Request):
    raw = await request.body()
    if not _valid_signature(raw, request.headers.get("x-hub-signature-256")):
        raise HTTPException(status_code=401, detail="invalid signature")
    data = await request.json()
    for entry in data.get("entry", []):
        for change in entry.get("changes", []):
            value = change.get("value", {})
            contacts_meta = {c.get("wa_id"): c.get("profile", {}).get("name") for c in value.get("contacts", [])}
            for m in value.get("messages", []):
                phone = m.get("from")
                conv = await db.conversations.find_one({"phone": phone})
                if not conv:
                    conv = {"id": new_id(), "phone": phone, "name": contacts_meta.get(phone) or phone,
                            "contact_type": "lead", "assigned_to": None, "unread": 0,
                            "starred": False, "archived": False, "is_demo": False,
                            "created_at": now_iso(), "last_message_at": now_iso()}
                    await db.conversations.insert_one(conv)
                text = m.get("text", {}).get("body", "") if m.get("type") == "text" else f"[{m.get('type')}]"
                previous = await db.messages.find_one({"wamid": m.get("id")})
                if previous:
                    from lead_capture_core import safe_enqueue_message
                    await safe_enqueue_message(db, previous)
                    continue
                inbound = {
                    "id": new_id(), "conversation_id": conv["id"], "wamid": m.get("id"),
                    "direction": "inbound", "type": m.get("type"), "body": text,
                    "status": "received", "is_demo": False, "payload": m,
                    "reply_to_wamid": (m.get("context") or {}).get("id"),
                    "authorized_provider": "meta", "created_at": now_iso()}
                await db.messages.insert_one(inbound)
                from lead_capture_core import safe_enqueue_message
                await safe_enqueue_message(db, inbound)
                await db.conversations.update_one({"id": conv["id"]},
                    {"$set": {"last_message": text, "last_message_at": now_iso()}, "$inc": {"unread": 1}})
            for st in value.get("statuses", []):
                await save_receipt(db.messages, st.get("id"), st.get("status"), st.get("timestamp"))
    return {"ok": True}
