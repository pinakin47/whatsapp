"""Asynchronous, authorized MR replies with durable no-resend reservations."""
import asyncio
import logging
import os
import re
import time
from datetime import datetime, timezone

from auth import permissions_for, refresh_role_definitions
from db import db, now_iso
from lead_capture_core import REAL, MANAGERS, settings_for, resolve_message_mr, stable
from mr_ai_context import conversation_facts, generate_reply
import wa_client

COMMANDS = re.compile(r"^(?:\d+(?:\.\d+)?|plan|morning|closing|close|day closing|report|field|day visit|pending|status|help|resume|later|cancel|back|done|confirm|menu|start|stop|unsubscribe|subscribe|opt ?out|opt ?in|manager|agent|human)$", re.I)
QUESTION = re.compile(r"^(?:(?:what|how|why|which|when|where|can you|can i|could you|could i|should i|please explain|explain)\b|कसे|काय|क्यों|कैसे|क्या|समजाव)", re.I)


def timestamp(value):
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
        return parsed.replace(tzinfo=timezone.utc).timestamp() if parsed.tzinfo is None else parsed.timestamp()
    except (ValueError, AttributeError):
        return 0


async def authorized(database, row):
    config = await settings_for(database)
    if not config["enabled"] or not config["authorized_messages_confirmed"] or not config["ai_auto_reply"] or not config.get("ai_reply_enabled_since"):
        return None
    actor = await database.users.find_one({"id": config.get("approved_by"), "active": {"$ne": False}, **REAL})
    if not actor or actor.get("role") not in MANAGERS:
        return None
    permissions = permissions_for(actor["role"])
    if "manage" not in permissions.get("settings", []) or "send" not in permissions.get("whatsapp", []):
        return None
    message = await database.messages.find_one({"id": row["message_id"], "direction": "inbound", "type": "text", **REAL})
    conversation = await database.conversations.find_one({"id": row["conversation_id"], **REAL})
    if not message or not conversation or message.get("conversation_id") != conversation["id"] or \
            not message.get("session_id") or message["session_id"] != conversation.get("session_id") or \
            message["session_id"] != row["session_id"] or message.get("capture_skip") or \
            conversation.get("human_takeover") or conversation.get("opted_out"):
        return None
    if timestamp(message.get("created_at")) < timestamp(config.get("ai_reply_enabled_since")):
        return None
    mr, direct = await resolve_message_mr(database, conversation, message)
    if not mr or not direct or mr["mr_id"] != row["mr_id"]:
        return None
    profile = await database.mr_ivr_profiles.find_one({"id": mr["id"]}) or {}
    if profile.get("value", {}).get("ivr_enabled") is False:
        return None
    contact = await database.contacts.find_one({"mobile": {"$in": [mr["phone"], mr["phone"].lstrip("+")]}, "opted_out": True, **REAL})
    if contact:
        return None
    text = message["body"].strip()
    drafting = (conversation.get("mr_ivr") or {}).get("field", "menu") != "menu" or \
        (conversation.get("mr_field_state") or {}).get("step", "menu") != "menu"
    if not row.get("phone_reply") and (COMMANDS.fullmatch(text) or drafting and not QUESTION.match(text)):
        return None
    # A staff answer or a newer inbound message supersedes an unsent AI response.
    later = await database.messages.find({"conversation_id": conversation["id"], "session_id": row["session_id"],
        "created_at": {"$gt": message["created_at"]}, **REAL}).sort("created_at", -1).to_list(30)
    for item in later:
        if item["direction"] == "inbound" or item["direction"] == "outbound" and not item.get("capture_skip") and not \
                str(item.get("sender", "")).startswith(("MR AI", "MR IVR", "MR field", "MR reporting", "MR coaching", "Lead capture", "IVR", "Chatbot", "System")):
            return None
    return mr, conversation, message


async def process_reply(database, row, generator=generate_reply):
    async def state(status, **fields):
        await database.mr_ai_replies.update_one({"id": row["id"]}, {"$set": {"status": status, "updated_at": now_iso(), **fields}})

    if time.time() - timestamp(row["created_at"]) > 600:
        await state("expired", error="Reply expired; no message sent")
        return
    evidence = await authorized(database, row)
    if not evidence:
        await state("cancelled", error="Reply superseded, paused or no longer authorized")
        return
    mr, conversation, message = evidence
    # Let capture finish before the AI describes the lead's actual state.
    source = await database.mr_lead_queue.find_one({"message_id": message["id"]})
    if source and source.get("status") in ("pending", "retry_pending") and time.time() - timestamp(row["created_at"]) < 120:
        return
    try:
        sessions = await wa_client.wa_list_sessions()
        connected = any(s.get("id") == row["session_id"] and s.get("status") == "connected" for s in sessions.get("sessions", []))
    except Exception:
        connected = False
    if not connected:
        await state("blocked_not_connected", error="Original WhatsApp session is offline; no send attempted")
        return
    claim = await database.mr_ai_replies.update_one({"id": row["id"], "status": row["status"]},
        {"$set": {"status": "generating", "updated_at": now_iso()}})
    if not claim.modified_count:
        return
    try:
        facts = await conversation_facts(database, mr, conversation, message)
        reply = await generator(facts)
        if not isinstance(reply, str) or not reply.strip() or len(reply) > 2000:
            raise ValueError("Invalid AI reply")
    except Exception:
        await state("failed_ai", error="OpenAI reply unavailable; no WhatsApp send attempted")
        return
    if not await authorized(database, row):
        await state("cancelled", reply=reply, error="A newer message, staff reply or authorization change superseded this draft")
        return
    reservation = stable("mr-ai-send", row["id"])
    await database.whatsapp_send_requests.update_one({"id": reservation}, {"$setOnInsert": {
        "id": reservation, "state": "sending", "provider": "qr", "recipient_address": mr["phone"],
        "message_body": reply, "gateway_message_id": None, "created_at": now_iso(), "source": "mr_ai",
        "conversation_id": conversation["id"],
    }}, upsert=True)
    await state("sending", reply=reply, reservation_id=reservation)
    try:
        response = await wa_client.wa_send(mr["phone"], reply, request_id=reservation, session_id=row["session_id"])
        wamid = response.get("wamid")
        if not wamid:
            raise RuntimeError("Provider acceptance unresolved")
        await database.messages.update_one({"wamid": wamid}, {"$setOnInsert": {
            "id": stable("mr-ai-out", row["id"]), "wamid": wamid, "conversation_id": conversation["id"],
            "direction": "outbound", "type": "text", "body": reply, "created_at": now_iso(),
            "is_demo": False, "session_id": row["session_id"], "status": "sent",
        }, "$set": {"sender": "MR AI assistant", "capture_skip": True, "ai_reply_id": row["id"]}}, upsert=True)
        await database.messages.update_one({"wamid": wamid, "status": {"$in": ["sending", None]}},
            {"$set": {"status": "sent"}})
        await database.conversations.update_one({"id": conversation["id"]}, {"$set": {
            "last_message": reply, "last_message_at": now_iso()}})
        await database.whatsapp_send_requests.update_one({"id": reservation}, {"$set": {"state": "accepted", "provider_id": wamid}})
        await state("accepted", provider_id=wamid, error=None, accepted_at=now_iso())
    except Exception:
        await database.whatsapp_send_requests.update_one({"id": reservation}, {"$set": {"state": "uncertain"}})
        await state("uncertain", error="Send outcome unresolved. No automatic resend; verify the Inbox/provider.")


async def reply_tick(database=db, generator=generate_reply):
    if not os.environ.get("OPENAI_API_KEY"):
        return
    config = await settings_for(database)
    if not config["enabled"] or not config["ai_auto_reply"]:
        return
    await refresh_role_definitions()
    for stale in await database.mr_ai_replies.find({"status": {"$in": ["generating", "sending"]}}).to_list(50):
        if time.time() - timestamp(stale.get("updated_at") or stale["created_at"]) > 180:
            status = "uncertain" if stale["status"] == "sending" else "failed_ai"
            await database.mr_ai_replies.update_one({"id": stale["id"], "status": stale["status"]}, {"$set": {
                "status": status, "error": "Interrupted attempt; no automatic resend. Verify the Inbox/provider.",
                "updated_at": now_iso()}})
    # A crashed generating/sending attempt is intentionally never reset into a resend.
    for row in await database.mr_ai_replies.find({"status": {"$in": ["pending", "blocked_not_connected"]}}).sort("created_at", 1).to_list(10):
        await process_reply(database, row, generator)


async def start_mr_ai_replies():
    while True:
        try:
            await reply_tick()
        except Exception:
            logging.getLogger("vgrups.mr_ai").error("MR AI reply cycle failed; send reservations retained.")
        await asyncio.sleep(3)
