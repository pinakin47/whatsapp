"""Brevo (Sendinblue) transactional email. No-ops gracefully when unconfigured."""
import os
import logging
from integrations import integration_status, send_brevo_email

logger = logging.getLogger("vgrups.brevo")


def configured() -> bool:
    return integration_status()["brevo"]["configured"]


async def send_email(to_email: str, to_name: str, subject: str, html: str) -> str:
    sender_email = (os.environ.get("BREVO_SENDER_EMAIL") or "").strip()
    sender_name = (os.environ.get("BREVO_SENDER_NAME") or "VGRUPS Healthcare").strip()
    if not configured() or not to_email:
        return "Not Configured"
    payload = {
        "sender": {"email": sender_email, "name": sender_name},
        "to": [{"email": to_email, "name": to_name or "there"}],
        "subject": subject,
        "htmlContent": html,
    }
    try:
        await send_brevo_email(payload)
        return "Sent"
    except Exception as e:
        logger.warning("Brevo transactional send failed (%s)", type(e).__name__)
        return "Failed"
