"""Campaign files use Replit App Storage; only metadata lives in PostgreSQL."""
import os
from datetime import timedelta
import httpx
from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import RedirectResponse
from pydantic import BaseModel, Field
from db import db, new_id, now_iso, utcnow
from auth import require_perm

router = APIRouter(prefix="/api/campaigns/media", tags=["campaign files"])
TYPES = {"image/jpeg": 5, "image/png": 5, "image/webp": 5, "application/pdf": 10}


async def signed_url(path, method="GET"):
    # Same managed sidecar signing protocol as the official storage blueprint.
    parts = path.lstrip("/").split("/", 1)
    if len(parts) != 2:
        raise HTTPException(503, "Campaign storage is not configured.")
    async with httpx.AsyncClient(timeout=30) as client:
        response = await client.post("http://127.0.0.1:1106/object-storage/signed-object-url",
                                     json={"bucket_name": parts[0], "object_name": parts[1],
                                           "method": method,
                                           "expires_at": (utcnow() + timedelta(minutes=15)).isoformat().replace("+00:00", "Z")})
    if not response.is_success:
        raise HTTPException(503, "File storage is unavailable. No campaign was sent.")
    return response.json()["signed_url"]


class UploadIn(BaseModel):
    name: str = Field(min_length=1, max_length=200)
    content_type: str
    size: int = Field(gt=0, le=10 * 1024 * 1024)


@router.post("/request-upload")
async def request_upload(body: UploadIn, actor=Depends(require_perm("campaigns", "create"))):
    if body.content_type not in TYPES or body.size > TYPES.get(body.content_type, 0) * 1024 * 1024:
        raise HTTPException(422, "Use JPG, PNG or WebP up to 5 MB, or PDF up to 10 MB.")
    directory = os.environ.get("PRIVATE_OBJECT_DIR", "").rstrip("/")
    if not directory:
        raise HTTPException(503, "Campaign file storage is not configured.")
    mid = new_id()
    path = f"{directory}/campaigns/{mid}"
    url = await signed_url(path, "PUT")
    await db.campaign_media.insert_one({"id": mid, "object_path": path,
        "name": body.name.replace("\\", "/").rsplit("/", 1)[-1], "content_type": body.content_type,
        "size": body.size, "owner_id": actor["id"], "state": "pending", "created_at": now_iso()})
    return {"media_id": mid, "upload_url": url}


@router.post("/{mid}/complete")
async def complete_upload(mid: str, actor=Depends(require_perm("campaigns", "create"))):
    record = await db.campaign_media.find_one({"id": mid, "owner_id": actor["id"]}, {"_id": 0})
    if not record:
        raise HTTPException(404, "Upload not found.")
    url = await signed_url(record["object_path"], "HEAD")
    async with httpx.AsyncClient(timeout=30) as client:
        response = await client.head(url)
        if (not response.is_success or response.headers.get("content-type", "").split(";")[0] != record["content_type"]
                or response.headers.get("content-length") != str(record["size"])):
            raise HTTPException(422, "Uploaded file size or type does not match. Upload it again.")
        read_url = await signed_url(record["object_path"])
        signature = (await client.get(read_url, headers={"Range": "bytes=0-15"})).content[:16]
    valid = {"application/pdf": signature.startswith(b"%PDF-"),
             "image/jpeg": signature.startswith(b"\xff\xd8\xff"),
             "image/png": signature.startswith(b"\x89PNG\r\n\x1a\n"),
             "image/webp": signature.startswith(b"RIFF") and signature[8:12] == b"WEBP"}
    if not valid[record["content_type"]]:
        raise HTTPException(422, "File contents do not match the selected image/PDF type.")
    await db.campaign_media.update_one({"id": mid}, {"$set": {"state": "ready"}})
    return {k: record[k] for k in ("id", "name", "content_type", "size")} | {"state": "ready"}


async def resolve_attachments(ids, owner_id=None):
    result = []
    for mid in ids:
        selector = {"id": mid, "state": "ready"}
        if owner_id:
            selector["owner_id"] = owner_id
        record = await db.campaign_media.find_one(selector, {"_id": 0})
        if not record:
            raise HTTPException(422, "An attachment is missing, unfinished, or belongs to another account.")
        result.append(record)
    return result


@router.get("/{mid}/download")
async def download(mid: str, actor=Depends(require_perm("campaigns", "view"))):
    record = await db.campaign_media.find_one({"id": mid, "state": "ready"}, {"_id": 0})
    if not record or (record["owner_id"] != actor["id"] and
                     not await db.campaigns.find_one({"attachments": mid})):
        raise HTTPException(404, "Attachment not found.")
    return RedirectResponse(await signed_url(record["object_path"]))