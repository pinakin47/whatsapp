"""Read-only receipt evidence. Provider acceptance and retry policy stay separate."""
from whatsapp_receipts import provider_time


def receipt_index(messages):
    ranks = {"read": 6, "played": 6, "delivered": 5, "failed": 4,
             "error": 4, "sent": 3}
    result = {}
    for message in messages:
        wamid = message.get("wamid")
        if not wamid or message.get("is_demo"):
            continue
        status = message.get("status", "unknown")
        evidence = result.setdefault(wamid, {"status": "unknown", "delivered_at": None, "read_at": None})
        if ranks.get(status, 0) > ranks.get(evidence["status"], 0):
            evidence["status"] = status
        for stage in ("delivered", "read"):
            at = provider_time(message.get(f"{stage}_at"))
            if at:
                old = evidence[f"{stage}_at"]
                evidence[f"{stage}_at"] = min(old, at) if old else at
    return result


def delivery_evidence(parts, required, receipts):
    """Each slot needs its own exact saved wamid; missing/duplicate IDs prove nothing."""
    seen = set()
    statuses = []
    times = {"delivered": [], "read": []}
    for part in parts:
        wamid = (part or {}).get("wamid")
        evidence = receipts.get(wamid, {}) if wamid and wamid not in seen else {}
        status = evidence.get("status", "unknown")
        seen.add(wamid)
        statuses.append(status)
        for stage in times:
            allowed = status in (("delivered", "read", "played") if stage == "delivered" else ("read", "played"))
            times[stage].append(evidence.get(f"{stage}_at") if allowed else None)
    read = sum(s in ("read", "played") for s in statuses)
    delivered = sum(s in ("delivered", "read", "played") for s in statuses)
    failed = sum(s in ("failed", "error") for s in statuses)
    complete = bool(required and len(parts) == required)
    status = ("read" if complete and read == required else
              "delivered" if complete and delivered == required else
              "failed" if failed else
              "partial" if delivered else "unknown")
    completed_times = {f"{stage}_at": max(values) if complete and all(values) else None
                       for stage, values in times.items()}
    return {"status": status, "required_parts": required, **completed_times,
            "delivered_parts": delivered, "read_parts": read, "failed_parts": failed}
