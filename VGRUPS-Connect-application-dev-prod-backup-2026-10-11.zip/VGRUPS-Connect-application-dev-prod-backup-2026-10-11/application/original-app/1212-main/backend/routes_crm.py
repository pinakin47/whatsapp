from datetime import datetime, timezone
import re
from fastapi import APIRouter, Depends, HTTPException, Request, Query
from pydantic import BaseModel
from typing import Optional

from db import db, new_id, now_iso, log_audit
from auth import get_current_user, require_perm
from routes_automations import run_automations
from lead_access import lead_scope, accessible_lead


async def run_automations_safe(trigger: str, ctx: dict):
    """Fire-and-forget so automations never block the HTTP response."""
    import asyncio as _a
    _a.create_task(run_automations(trigger, ctx))

router = APIRouter(prefix="/api", tags=["crm"])

CONTACT_TYPES = ["lead", "customer", "doctor", "hospital", "pharmacy",
                 "distributor", "cf", "medical_shop", "institution"]


class ContactIn(BaseModel):
    name: str
    mobile: str
    email: Optional[str] = None
    company: Optional[str] = None
    contact_type: str = "lead"
    address: Optional[str] = None
    city: Optional[str] = None
    state: Optional[str] = None
    pincode: Optional[str] = None
    gst: Optional[str] = None
    category: Optional[str] = None
    source: Optional[str] = "manual"
    assigned_to: Optional[str] = None
    tags: list[str] = []
    notes: Optional[str] = None


def _clip(q):
    return {"_id": 0}


# ---------------- Contacts ----------------
@router.get("/contacts")
async def list_contacts(
    user: dict = Depends(require_perm("crm", "view")),
    search: Optional[str] = None,
    contact_type: Optional[str] = None,
    city: Optional[str] = None,
    limit: int = 200,
):
    q: dict = {"deleted": {"$ne": True}}
    if contact_type and contact_type != "all":
        q["contact_type"] = contact_type
    if city:
        q["city"] = city
    if search:
        rx = re.escape(search)
        q["$or"] = [
            {"name": {"$regex": rx, "$options": "i"}},
            {"mobile": {"$regex": rx, "$options": "i"}},
            {"company": {"$regex": rx, "$options": "i"}},
            {"email": {"$regex": rx, "$options": "i"}},
        ]
    items = await db.contacts.find(q, {"_id": 0}).sort("created_at", -1).to_list(limit)
    return {"items": items, "total": await db.contacts.count_documents(q)}


@router.get("/contacts/stats")
async def contact_stats(user: dict = Depends(require_perm("crm", "view"))):
    out = {}
    for t in CONTACT_TYPES:
        out[t] = await db.contacts.count_documents({"contact_type": t, "deleted": {"$ne": True}})
    out["total"] = await db.contacts.count_documents({"deleted": {"$ne": True}})
    return out


@router.post("/contacts")
async def create_contact(body: ContactIn, request: Request, user: dict = Depends(require_perm("crm", "create"))):
    if body.contact_type not in CONTACT_TYPES:
        raise HTTPException(status_code=422, detail="Invalid contact type")
    doc = body.model_dump()
    doc.update({"id": new_id(), "is_demo": False, "deleted": False,
                "created_by": user["id"], "created_at": now_iso(), "updated_at": now_iso()})
    await db.contacts.insert_one(doc)
    await log_audit(user, "create", "crm", doc["id"], detail=body.name)
    await run_automations_safe("new_contact", {"contact_name": body.name, "mobile": body.mobile, "contact_id": doc["id"]})
    doc.pop("_id", None)
    return doc


@router.get("/contacts/{cid}")
async def get_contact(cid: str, user: dict = Depends(require_perm("crm", "view"))):
    doc = await db.contacts.find_one({"id": cid}, {"_id": 0})
    if not doc:
        raise HTTPException(status_code=404, detail="Contact not found")
    doc["orders"] = await db.orders.find({"contact_id": cid}, {"_id": 0}).to_list(50)
    doc["leads"] = await db.leads.find({"contact_id": cid, **lead_scope(user)}, {"_id": 0}).to_list(50)
    return doc


@router.put("/contacts/{cid}")
async def update_contact(cid: str, body: ContactIn, user: dict = Depends(require_perm("crm", "edit"))):
    upd = body.model_dump()
    upd["updated_at"] = now_iso()
    res = await db.contacts.update_one({"id": cid}, {"$set": upd})
    if res.matched_count == 0:
        raise HTTPException(status_code=404, detail="Contact not found")
    await log_audit(user, "update", "crm", cid, detail=body.name)
    return await db.contacts.find_one({"id": cid}, {"_id": 0})


@router.delete("/contacts/{cid}")
async def delete_contact(cid: str, user: dict = Depends(require_perm("crm", "delete"))):
    res = await db.contacts.update_one({"id": cid}, {"$set": {"deleted": True, "updated_at": now_iso()}})
    if res.matched_count == 0:
        raise HTTPException(status_code=404, detail="Contact not found")
    await log_audit(user, "delete", "crm", cid)
    return {"ok": True}


# ---------------- Leads ----------------
LEAD_STATUSES = ["new", "contacted", "qualified", "interested", "quotation",
                 "negotiation", "won", "lost", "follow_up"]
LEAD_SOURCES = ["whatsapp", "website", "google", "meta", "facebook", "instagram",
                "qr", "chrome_extension", "referral", "manual", "campaign", "api"]


class LeadIn(BaseModel):
    title: str
    contact_id: Optional[str] = None
    contact_name: Optional[str] = None
    mobile: Optional[str] = None
    company: Optional[str] = None
    status: str = "new"
    source: str = "manual"
    value: float = 0
    specialty: Optional[str] = None
    assigned_to: Optional[str] = None
    notes: Optional[str] = None
    tags: list[str] = []


class LeadStatusIn(BaseModel):
    status: str


@router.get("/leads")
async def list_leads(user: dict = Depends(require_perm("leads", "view")), search: Optional[str] = None,
                     assigned_to: Optional[str] = None):
    q: dict = lead_scope(user)
    if assigned_to and user["role"] != "mr":
        q["assigned_to"] = assigned_to
    if search:
        rx = re.escape(search)
        q["$or"] = [
            {"title": {"$regex": rx, "$options": "i"}},
            {"contact_name": {"$regex": rx, "$options": "i"}},
            {"company": {"$regex": rx, "$options": "i"}},
        ]
    items = await db.leads.find(q, {"_id": 0}).sort("created_at", -1).to_list(500)
    board = {s: [] for s in LEAD_STATUSES}
    for it in items:
        board.setdefault(it.get("status", "new"), []).append(it)
    return {"board": board, "statuses": LEAD_STATUSES, "total": len(items)}


@router.post("/leads")
async def create_lead(body: LeadIn, user: dict = Depends(require_perm("leads", "create"))):
    if body.status not in LEAD_STATUSES:
        raise HTTPException(status_code=422, detail="Invalid status")
    doc = body.model_dump()
    if body.source == "WhatsApp – MR":
        raise HTTPException(422, "Use authorized capture or verified extraction review for automatic WhatsApp leads")
    if user["role"] == "mr":
        if body.assigned_to and body.assigned_to != user["id"]:
            raise HTTPException(403, "MRs can create only their own leads")
        doc["assigned_to"] = user["id"]
    doc.update({"id": new_id(), "is_demo": False, "deleted": False,
                "created_by": user["id"], "created_at": now_iso(), "updated_at": now_iso(),
                "last_contact": now_iso()})
    await db.leads.insert_one(doc)
    await log_audit(user, "create", "leads", doc["id"], detail=body.title)
    await run_automations_safe("new_lead", {"contact_name": body.contact_name or body.title, "mobile": body.mobile,
                                            "contact_id": body.contact_id, "lead_id": doc["id"]})
    doc.pop("_id", None)
    return doc


@router.patch("/leads/{lid}/status")
async def update_lead_status(lid: str, body: LeadStatusIn, user: dict = Depends(require_perm("leads", "edit"))):
    if body.status not in LEAD_STATUSES:
        raise HTTPException(status_code=422, detail="Invalid status")
    lead = await accessible_lead(db, lid, user)
    res = await db.leads.update_one({"id": lid, **lead_scope(user)}, {"$set": {"status": body.status, "updated_at": now_iso()}})
    if res.matched_count == 0:
        raise HTTPException(status_code=404, detail="Lead not found")
    await log_audit(user, "update_status", "leads", lid, detail=body.status)
    if lead.get("source") == "WhatsApp – MR":
        from lead_capture_core import event
        await event(db, lid, now_iso(), "Lead Status Changed", body.status, user["id"])
    return await db.leads.find_one({"id": lid}, {"_id": 0})


@router.put("/leads/{lid}")
async def update_lead(lid: str, body: LeadIn, user: dict = Depends(require_perm("leads", "edit"))):
    lead = await accessible_lead(db, lid, user)
    if lead.get("source") == "WhatsApp – MR":
        raise HTTPException(409, "Edit this lead in WhatsApp Leads to preserve captured evidence and ownership")
    if body.status not in LEAD_STATUSES or body.source == "WhatsApp – MR":
        raise HTTPException(422, "Invalid status or reserved capture source")
    if user["role"] == "mr" and body.assigned_to != user["id"]:
        raise HTTPException(403, "MRs cannot reassign leads")
    upd = body.model_dump()
    upd["updated_at"] = now_iso()
    res = await db.leads.update_one({"id": lid, **lead_scope(user)}, {"$set": upd})
    if res.matched_count == 0:
        raise HTTPException(status_code=404, detail="Lead not found")
    return await db.leads.find_one({"id": lid}, {"_id": 0})


@router.delete("/leads/{lid}")
async def delete_lead(lid: str, user: dict = Depends(require_perm("leads", "delete"))):
    if user["role"] == "mr":
        raise HTTPException(403, "MRs cannot delete leads")
    lead = await accessible_lead(db, lid, user)
    res = await db.leads.update_one({"id": lid, **lead_scope(user)}, {"$set": {"deleted": True}})
    if res.matched_count == 0:
        raise HTTPException(status_code=404, detail="Lead not found")
    await log_audit(user, "delete", "leads", lid)
    if lead.get("source") == "WhatsApp – MR":
        from lead_capture_core import event
        await event(db, lid, now_iso(), "Lead Deleted", "Evidence retained", user["id"])
    return {"ok": True}


@router.get("/meta/options")
async def meta_options(user: dict = Depends(get_current_user)):
    return {"contact_types": CONTACT_TYPES, "lead_statuses": LEAD_STATUSES, "lead_sources": LEAD_SOURCES}
