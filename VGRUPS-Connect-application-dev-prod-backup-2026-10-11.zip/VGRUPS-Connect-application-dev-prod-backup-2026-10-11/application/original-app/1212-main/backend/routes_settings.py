"""Persistent users and role management with administrator lockout protection."""
import asyncio
from contextlib import asynccontextmanager
from typing import Optional
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, EmailStr, Field, model_validator
from db import db, new_id, now_iso, log_audit
from auth import (require_perm, public_user, hash_password, role_registry,
                  refresh_role_definitions, permissions_for, MODULES, ALL)

router = APIRouter(prefix="/api", tags=["settings"])
ADMIN_ROLES = ("admin", "super_admin")


@asynccontextmanager
async def settings_lock():
    # Release waiting connections rather than exhausting the pool while the
    # lock holder uses collection operations. Shared across all API workers.
    pool = await db.connect()
    for _ in range(100):
        async with pool.acquire() as conn:
            acquired = await conn.fetchval("SELECT pg_try_advisory_lock(hashtext('settings-management'))")
            if acquired:
                try:
                    yield
                finally:
                    await conn.execute("SELECT pg_advisory_unlock(hashtext('settings-management'))")
                return
        await asyncio.sleep(0.05)
    raise HTTPException(409, "Settings are being updated. Please try again.")


class UserEdit(BaseModel):
    name: str = Field(min_length=1, max_length=150)
    email: EmailStr
    role: str
    active: bool = True
    phone: Optional[str] = None
    password: Optional[str] = Field(default=None, min_length=8, max_length=72)


class UserCreate(UserEdit):
    password: str = Field(min_length=8, max_length=72)


class RoleIn(BaseModel):
    key: str = Field(pattern=r"^[a-z][a-z0-9_]{1,59}$")
    label: str = Field(min_length=1, max_length=80)
    permissions: dict[str, list[str]]

    @model_validator(mode="after")
    def valid_permissions(self):
        if any(m not in MODULES or any(a not in ALL for a in actions)
               for m, actions in self.permissions.items()):
            raise ValueError("Choose only supported modules and permission actions.")
        if not self.label.strip():
            raise ValueError("Role name cannot be blank.")
        return self


@router.get("/users")
async def users(actor=Depends(require_perm("settings", "view"))):
    records = await db.users.find({"deleted": {"$ne": True}}, {"_id": 0, "password_hash": 0}).sort("created_at", -1).to_list(1000)
    return {"items": [public_user(r) for r in records]}


def guard_grants(target_permissions, actor):
    allowed = permissions_for(actor["role"])
    if any(not set(actions).issubset(allowed.get(module, [])) for module, actions in target_permissions.items()):
        raise HTTPException(403, "You cannot grant permissions you do not have.")


async def validate_user(body, actor, uid=None):
    if body.role not in role_registry():
        raise HTTPException(422, "Choose an existing role.")
    if not body.name.strip():
        raise HTTPException(422, "Name cannot be blank.")
    guard_grants(permissions_for(body.role), actor)
    if body.role in ADMIN_ROLES and actor["role"] not in ADMIN_ROLES:
        raise HTTPException(403, "Only an administrator can assign administrator roles.")
    existing = await db.users.find_one({"email": str(body.email).lower()})
    if existing and existing["id"] != uid:
        raise HTTPException(409, "Email already exists.")


@router.post("/users")
async def create_user(body: UserCreate, actor=Depends(require_perm("settings", "create"))):
    async with settings_lock():
        await refresh_role_definitions()
        await validate_user(body, actor)
        record = {**body.model_dump(exclude={"password"}), "id": new_id(),
                  "email": str(body.email).lower(), "name": body.name.strip(),
                  "password_hash": hash_password(body.password), "is_demo": False,
                  "created_at": now_iso(), "updated_at": now_iso()}
        await db.users.insert_one(record)
    await log_audit(actor, "create", "settings", record["id"], detail="Team user")
    return public_user(record)


async def guard_user_change(uid, actor, target, role, active):
    if uid == actor["id"] and not active:
        raise HTTPException(409, "You cannot disable or delete your own account.")
    if (target.get("role") in ADMIN_ROLES and target.get("active", True)
            and (role not in ADMIN_ROLES or not active)):
        others = await db.users.count_documents({
            "id": {"$ne": uid}, "role": {"$in": list(ADMIN_ROLES)},
            "active": {"$ne": False}, "deleted": {"$ne": True}})
        if not others:
            raise HTTPException(409, "Keep at least one active administrator.")


@router.put("/users/{uid}")
async def update_user(uid: str, body: UserEdit, actor=Depends(require_perm("settings", "edit"))):
    async with settings_lock():
        await refresh_role_definitions()
        target = await db.users.find_one({"id": uid, "deleted": {"$ne": True}}, {"_id": 0})
        if not target:
            raise HTTPException(404, "User not found.")
        await validate_user(body, actor, uid)
        await guard_user_change(uid, actor, target, body.role, body.active)
        fields = body.model_dump(exclude={"password", "phone"})
        fields.update(email=str(body.email).lower(), name=body.name.strip(), updated_at=now_iso())
        if "phone" in body.model_fields_set:
            fields["phone"] = body.phone
        if body.password:
            fields["password_hash"] = hash_password(body.password)
        await db.users.update_one({"id": uid}, {"$set": fields})
        target.update(fields)
    await log_audit(actor, "edit", "settings", uid, detail="Team user")
    return public_user(target)


@router.delete("/users/{uid}")
async def delete_user(uid: str, actor=Depends(require_perm("settings", "delete"))):
    async with settings_lock():
        target = await db.users.find_one({"id": uid, "deleted": {"$ne": True}})
        if not target:
            raise HTTPException(404, "User not found.")
        await guard_user_change(uid, actor, target, target["role"], False)
        await db.users.update_one({"id": uid}, {"$set": {"active": False, "deleted": True, "updated_at": now_iso()}})
    await log_audit(actor, "delete", "settings", uid, detail="Team user disabled and removed")
    return {"ok": True}


@router.get("/roles")
async def roles(actor=Depends(require_perm("settings", "view"))):
    return {"roles": [{**r, "permissions": permissions_for(key), "protected": key in ADMIN_ROLES}
                      for key, r in role_registry().items()],
            "modules": MODULES, "actions": ALL}


async def save_role(key, body, actor, creating):
    if key in ADMIN_ROLES:
        raise HTTPException(409, "Administrator roles are protected against permission changes or deletion.")
    guard_grants(body.permissions, actor)
    async with settings_lock():
        await refresh_role_definitions()
        exists = key in role_registry()
        if creating and exists:
            raise HTTPException(409, "Role key already exists.")
        if not creating and not exists:
            raise HTTPException(404, "Role not found.")
        if key != body.key:
            raise HTTPException(422, "An existing role key cannot be changed.")
        record = {**body.model_dump(), "label": body.label.strip(), "deleted": False, "updated_at": now_iso()}
        await db.roles.update_one({"key": key}, {"$set": record}, upsert=True)
        await refresh_role_definitions()
    await log_audit(actor, "create" if creating else "edit", "settings", key, detail="Role permissions")
    return {**record, "permissions": permissions_for(key), "protected": False}


@router.post("/roles")
async def create_role(body: RoleIn, actor=Depends(require_perm("settings", "create"))):
    return await save_role(body.key, body, actor, True)


@router.put("/roles/{key}")
async def edit_role(key: str, body: RoleIn, actor=Depends(require_perm("settings", "edit"))):
    return await save_role(key, body, actor, False)


@router.delete("/roles/{key}")
async def delete_role(key: str, actor=Depends(require_perm("settings", "delete"))):
    if key in ADMIN_ROLES:
        raise HTTPException(409, "Administrator roles are protected.")
    async with settings_lock():
        await refresh_role_definitions()
        if key not in role_registry():
            raise HTTPException(404, "Role not found.")
        if await db.users.count_documents({"role": key, "deleted": {"$ne": True}}):
            raise HTTPException(409, "Reassign this role's users before deleting it.")
        await db.roles.update_one({"key": key}, {"$set": {"deleted": True, "updated_at": now_iso()}}, upsert=True)
        await refresh_role_definitions()
    await log_audit(actor, "delete", "settings", key, detail="Role")
    return {"ok": True}