"""Individual MR activity and explicitly approved sales coaching messages."""
import asyncio
import hashlib
import logging
import re
import string
from datetime import datetime, timedelta
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field, field_validator
from auth import require_perm, permissions_for, refresh_role_definitions
from db import db, now_iso, log_audit
from routes_field import _is_manager
from routes_mr_settings import IST, mr_lock
from routes_mr_reporting import opted_out
from mr_activity_query import activity_candidates
import wa_client

router = APIRouter(prefix="/api/mr-ivr", tags=["Individual MR IVR"])
REAL = {"deleted": {"$ne": True}, "is_demo": {"$ne": True}}
DEFAULT_PROFILE = {
    "ivr_enabled": True, "greeting": "", "enabled": False, "opt_in": False,
    "encouragement_time": "11:00", "push_time": "16:00", "days": [0, 1, 2, 3, 4, 5],
    "encouragement_template": "Hi {name}, your daily sales goal is INR {daily_goal}. Keep progressing with your {planned_visits} planned visits. Reply PLAN or CLOSING for your private reporting menu.",
    "push_template": "Hi {name}, sales recorded today: INR {sales}. Pending visits: {pending_visits}. Next planned stop: {next_destination}. Follow up on open enquiries and share your closing report.",
    "field_flow_enabled": False, "midday_enabled": False, "midday_time": "13:00",
    "reminder_minutes": 30, "closing_deadline": "21:00",
}
TOKENS = {"name", "employee_id", "date", "daily_goal", "planned_visits", "completed_visits",
          "pending_visits", "sales", "next_destination"}


class ProfileIn(BaseModel):
    ivr_enabled: bool = True
    greeting: str = Field(default="", max_length=500)
    enabled: bool = False
    opt_in: bool = False
    confirm_enable: bool = False
    field_flow_enabled: bool = False
    midday_enabled: bool = False
    midday_time: str = Field(default="13:00", pattern=r"^(?:[01]\d|2[0-3]):[0-5]\d$")
    reminder_minutes: int = Field(default=30, ge=15, le=180)
    closing_deadline: str = Field(default="21:00", pattern=r"^(?:[01]\d|2[0-3]):[0-5]\d$")
    encouragement_time: str = Field(default="11:00", pattern=r"^(?:[01]\d|2[0-3]):[0-5]\d$")
    push_time: str = Field(default="16:00", pattern=r"^(?:[01]\d|2[0-3]):[0-5]\d$")
    days: list[int] = Field(default=[0, 1, 2, 3, 4, 5], min_length=1, max_length=7)
    encouragement_template: str = Field(default=DEFAULT_PROFILE["encouragement_template"], min_length=1, max_length=3000)
    push_template: str = Field(default=DEFAULT_PROFILE["push_template"], min_length=1, max_length=3000)

    @field_validator("days")
    @classmethod
    def valid_days(cls, days):
        if any(d not in range(7) for d in days) or len(set(days)) != len(days):
            raise ValueError("Select distinct weekdays, Monday=0 through Sunday=6.")
        return sorted(days)

    @field_validator("encouragement_template", "push_template")
    @classmethod
    def valid_template(cls, value):
        if not value.strip():
            raise ValueError("Message cannot be blank.")
        try:
            for _, key, spec, conversion in string.Formatter().parse(value):
                if key is not None and (key not in TOKENS or spec or conversion):
                    raise ValueError("Use only the supported message placeholders.")
        except (ValueError, KeyError):
            raise ValueError("Use only the supported message placeholders.")
        return value.strip()


class MessageIn(BaseModel):
    message: str = Field(min_length=1, max_length=4000)
    confirm_send: bool = False
    request_id: str = Field(min_length=16, max_length=100, pattern=r"^[A-Za-z0-9_-]+$")


def edit_permission(user):
    p = permissions_for(user["role"])
    if not _is_manager(user) or "manage" not in p.get("settings", []) or "send" not in p.get("whatsapp", []):
        raise HTTPException(403, "Administrator or sales manager with settings management and WhatsApp send permissions required.")


async def resolve(mrid, user):
    mr = await db.mr_directory.find_one({"id": mrid, **REAL}, {"_id": 0})
    if not mr:
        raise HTTPException(404, "MR not found.")
    account = await db.users.find_one({**REAL, "email": mr["email"].lower(),
                                     "role": "mr", "active": {"$ne": False}}, {"_id": 0, "id": 1})
    mr["mr_id"] = (account or {}).get("id", f"directory:{mrid}")
    if not _is_manager(user) and mr["mr_id"] != user["id"]:
        raise HTTPException(403, "You can view only your own MR activity.")
    return mr


def day_value(value=None):
    day = value or datetime.now(IST).date().isoformat()
    try:
        if datetime.strptime(day, "%Y-%m-%d").date().isoformat() != day:
            raise ValueError()
    except ValueError:
        raise HTTPException(422, "Date must be YYYY-MM-DD.")
    return day


async def profile_for(mrid):
    saved = await db.mr_ivr_profiles.find_one({"id": mrid}, {"_id": 0})
    return {**DEFAULT_PROFILE, **((saved or {}).get("value") or {})}


async def activity(mr, date):
    visits = await db.field_visits.find({"mr_id": mr["mr_id"], "planned_date": date}, {"_id": 0}).to_list(None)
    report = await db.mr_daily_reports.find_one({"id": f"{date}:{mr['id']}"}, {"_id": 0})
    start = datetime.strptime(date, "%Y-%m-%d").replace(tzinfo=IST)
    def in_day(row):
        try:
            instant = datetime.fromisoformat(row.get("created_at", "").replace("Z", "+00:00"))
            return instant.tzinfo is not None and start <= instant < start + timedelta(days=1)
        except (ValueError, TypeError):
            return False
    order_rows, quotation_rows = await asyncio.gather(
        activity_candidates(db, "orders", mr["mr_id"], start),
        activity_candidates(db, "quotations", mr["mr_id"], start))
    orders = [r for r in order_rows if in_day(r)]
    quotations = [r for r in quotation_rows if in_day(r)]
    plan, closing = (report or {}).get("plan", {}), (report or {}).get("closing", {})
    planned = plan.get("planned_visits", len([v for v in visits if v.get("status") != "skipped"]))
    completed = closing.get("completed_visits", len([v for v in visits if v.get("status") == "visited"]))
    sales = closing.get("sales", sum(float(o.get("total") or 0) for o in orders))
    goal = plan.get("expected_sales")
    return {
        "visits": visits, "report": report, "orders": orders, "quotations": quotations,
        "target": await db.field_targets.find_one({"mr_id": mr["mr_id"], "month": date[:7]}, {"_id": 0}),
        "next_destination": next((v for v in visits if v.get("status") == "planned"), None),
        "summary": {"planned_visits": planned, "completed_visits": completed,
                    "pending_visits": max(0, planned - completed), "sales": sales, "daily_goal": goal,
                    "achievement_pct": round(sales / goal * 100, 2) if goal and goal > 0 else None},
    }


def render_message(template, mr, date, data):
    stop = data["next_destination"] or {}
    destination = " - ".join(filter(None, [stop.get("doctor_name") or stop.get("clinic_name"), stop.get("city") or stop.get("address")]))
    values = {**data["summary"], "name": mr["name"], "employee_id": mr["employee_id"],
              "date": date, "daily_goal": data["summary"]["daily_goal"] if data["summary"]["daily_goal"] is not None else "not set",
              "next_destination": destination or "No pending destination recorded"}
    text = template.format_map(values)
    if len(text) > 4000:
        raise HTTPException(422, "Rendered message exceeds 4000 characters.")
    return text


@router.get("/mrs")
async def list_mrs(user=Depends(require_perm("field_sales", "view"))):
    rows = await db.mr_directory.find(REAL, {"_id": 0}).sort("name", 1).to_list(None)
    day = day_value()
    manager = _is_manager(user)
    items = []
    # Bound SQL parameter counts even for very large directories. Each batch
    # needs three reads, not another directory/account/profile/day per MR.
    for offset in range(0, len(rows), 250):
        batch = rows[offset:offset + 250]
        accounts = await db.users.find({**REAL, "email": {"$in": list({
            row["email"].lower() for row in batch})}, "role": "mr",
            "active": {"$ne": False}}, {"_id": 0, "id": 1, "email": 1}).to_list(None)
        by_email = {account["email"]: account["id"] for account in accounts}
        visible = [{**row, "mr_id": by_email.get(row["email"].lower(), f"directory:{row['id']}")}
                   for row in batch]
        visible = [mr for mr in visible if manager or mr["mr_id"] == user["id"]]
        if not visible:
            continue
        ids = [mr["id"] for mr in visible]
        profiles, field_days = await asyncio.gather(
            db.mr_ivr_profiles.find({"id": {"$in": ids}}, {"_id": 0}).to_list(None),
            db.mr_field_days.find({"id": {"$in": [f"{day}:{mid}" for mid in ids]}},
                                  {"_id": 0}).to_list(None))
        by_profile = {p["id"]: p.get("value") or {} for p in profiles}
        by_day = {d["id"]: d for d in field_days}
        items.extend({**mr, "profile": {**DEFAULT_PROFILE, **by_profile.get(mr["id"], {})},
                      "field_day": by_day.get(f"{day}:{mr['id']}")} for mr in visible)
    return {"items": items}


@router.get("/mrs/{mrid}")
async def detail(mrid: str, date: str | None = None, user=Depends(require_perm("field_sales", "view"))):
    mr, day = await resolve(mrid, user), day_value(date)
    return {"mr": mr, "date": day, **await activity(mr, day), "profile": await profile_for(mrid),
            "history": await db.mr_push_notifications.find({"mr_id": mrid}, {"_id": 0}).sort("created_at", -1).to_list(100),
            "field_day": await db.mr_field_days.find_one({"id": f"{day}:{mrid}"}, {"_id": 0}),
            "leave_requests": await db.mr_leave_requests.find({"mr_directory_id": mrid, "date": day}, {"_id": 0}).to_list(100),
            "manager_requests": await db.mr_manager_requests.find({"mr_id": mrid, "date": day}, {"_id": 0}).to_list(100),
            "field_entries": await db.mr_field_entries.find({"mr_directory_id": mrid, "date": day}, {"_id": 0}).to_list(100)}


@router.put("/mrs/{mrid}/profile")
async def save_profile(mrid: str, body: ProfileIn, user=Depends(require_perm("field_sales", "view"))):
    edit_permission(user)
    mr = await resolve(mrid, user)
    if body.encouragement_time == body.push_time:
        raise HTTPException(422, "Choose different encouragement and follow-up times.")
    if (body.enabled or body.midday_enabled) and (not body.opt_in or not body.confirm_enable or not mr.get("active")):
        raise HTTPException(422, "Active MR, individual opt-in and explicit send confirmation are required.")
    if body.midday_enabled and (not body.field_flow_enabled or not body.ivr_enabled):
        raise HTTPException(422, "Mid-day checks require the individual menu and field activity flow enabled.")
    if body.midday_enabled and body.closing_deadline <= body.midday_time:
        raise HTTPException(422, "Closing deadline must be later than the mid-day check.")
    value = body.model_dump(exclude={"confirm_enable"})
    async with mr_lock(f"profile:{mrid}"):
        await db.mr_ivr_profiles.update_one({"id": mrid}, {"$set": {
            "id": mrid, "value": value, "approved_by": user["id"], "updated_at": now_iso()}}, upsert=True)
    await log_audit(user, "edit", "ivr", mrid, detail="Individual MR IVR and coaching configuration")
    return value


@router.delete("/mrs/{mrid}/profile")
async def reset_profile(mrid: str, user=Depends(require_perm("field_sales", "view"))):
    edit_permission(user)
    await resolve(mrid, user)
    reset = {**DEFAULT_PROFILE, "ivr_enabled": False}
    await db.mr_ivr_profiles.update_one({"id": mrid}, {"$set": {
        "id": mrid, "value": reset, "updated_at": now_iso(), "approved_by": None}}, upsert=True)
    await log_audit(user, "edit", "ivr", mrid, detail="Individual MR IVR reset; scheduled coaching disabled")
    return reset


@router.get("/mrs/{mrid}/preview")
async def preview(mrid: str, kind: str = "encouragement", date: str | None = None, user=Depends(require_perm("field_sales", "view"))):
    if kind not in ("encouragement", "push"):
        raise HTTPException(422, "Choose encouragement or push.")
    mr, day = await resolve(mrid, user), day_value(date)
    profile = await profile_for(mrid)
    return {"message": render_message(profile[f"{kind}_template"], mr, day, await activity(mr, day))}


async def deliver(mr, actor, message, key, kind, date=None):
    send_day = date or day_value()
    existing = await db.mr_push_notifications.find_one({"id": key}, {"_id": 0})
    if existing:
        if existing.get("body") != message:
            raise HTTPException(409, "This request ID was already used for another message.")
        return existing
    # All eligibility checks are before reserving or provider IO.
    current = await db.mr_directory.find_one({"id": mr["id"], **REAL, "active": True})
    live_actor = await db.users.find_one({"id": actor["id"], **REAL, "active": {"$ne": False}})
    if not current or not live_actor:
        raise HTTPException(409, "MR or administrator is no longer active.")
    edit_permission(live_actor)
    if await opted_out(current["phone"]):
        raise HTTPException(409, "This MR has opted out of WhatsApp messages.")
    if kind != "manual":
        profile = await profile_for(mr["id"])
        toggle = "midday_enabled" if kind.startswith("midday") else "enabled"
        if not profile[toggle] or not profile["opt_in"]:
            return None
        if kind.startswith("midday") and (not profile["field_flow_enabled"] or not profile["ivr_enabled"]):
            return None
    from whatsapp_routing import sender_or_none
    session = await sender_or_none(db, purpose="mr")
    if not session:
        raise HTTPException(409, "Connect the QR-linked WhatsApp account before sending.")
    request_id = hashlib.sha256(key.encode()).hexdigest()
    row = {"id": key, "mr_id": mr["id"], "kind": kind, "body": message, "status": "sending",
           "created_at": now_iso(), "user_id": actor["id"], "gateway_request_id": request_id}
    acquired = await db.mr_push_notifications.update_one({"id": key}, {"$setOnInsert": row}, upsert=True)
    if not acquired.upserted_id:
        return await db.mr_push_notifications.find_one({"id": key}, {"_id": 0})
    try:
        await db.whatsapp_send_requests.update_one({"id": request_id}, {"$setOnInsert": {
            "id": request_id, "state": "sending", "provider": "qr",
            "recipient_address": current["phone"], "message_body": message,
            "user_id": actor["id"], "source": "mr_coaching", "created_at": now_iso()}}, upsert=True)
        # Re-read authorization after the reservation; it remains consumed on revocation.
        recipient = await db.mr_directory.find_one({"id": mr["id"], **REAL, "active": True})
        sender = await db.users.find_one({"id": actor["id"], **REAL, "active": {"$ne": False}})
        if not recipient or not sender or recipient["phone"] != current["phone"]:
            raise RuntimeError("Contact or sender authorization changed")
        edit_permission(sender)
        if await opted_out(recipient["phone"]):
            raise RuntimeError("Consent revoked")
        if kind != "manual":
            latest = await db.mr_ivr_profiles.find_one({"id": mr["id"]})
            value = (latest or {}).get("value", {})
            if not latest or latest.get("approved_by") != actor["id"] or not value.get(toggle) or not value.get("opt_in"):
                raise RuntimeError("Schedule authorization changed")
            if kind.startswith("midday"):
                state = await db.mr_field_days.find_one({"id": f"{send_day}:{mr['id']}"})
                if not value.get("field_flow_enabled") or not value.get("ivr_enabled") or \
                        (state or {}).get("status") in ("on_leave", "completed") or \
                        (state or {}).get("closing_status") == "completed" or \
                        (state or {}).get("midday_updated_at"):
                    raise RuntimeError("Mid-day check is no longer needed or authorized")
        response = await wa_client.wa_send(current["phone"], message, request_id=request_id, session_id=session["id"])
        if not response.get("wamid"):
            raise RuntimeError("Unknown acceptance")
        await db.whatsapp_send_requests.update_one({"id": request_id}, {"$set": {
            "state": "accepted", "accepted_at": now_iso(), "gateway_accepted_wamid": response["wamid"]}})
        await db.mr_push_notifications.update_one({"id": key}, {"$set": {
            "status": "sent", "wamid": response["wamid"], "session_id": session["id"], "accepted_at": now_iso()}})
        from routes_campaigns import _upsert_conversation
        conversation = await _upsert_conversation(current["phone"].lstrip("+"), current["name"], session["id"])
        await db.messages.update_one({"wamid": response["wamid"]}, {"$setOnInsert": {
            "id": request_id, "wamid": response["wamid"], "conversation_id": conversation["id"],
            "session_id": session["id"], "direction": "outbound", "type": "text", "body": message,
            "sender": "MR coaching", "status": "sent", "created_at": now_iso(), "is_demo": False}}, upsert=True)
        await db.conversations.update_one({"id": conversation["id"]}, {"$set": {"last_message": message, "last_message_at": now_iso()}})
        if kind.startswith("midday"):
            await db.conversations.update_one({"id": conversation["id"]}, {"$set": {
                "mr_field_invitation": {"id": key, "date": send_day, "kind": kind}}})
    except Exception:
        await db.mr_push_notifications.update_one({"id": key, "status": "sending"}, {"$set": {
            "status": "uncertain", "error": "Acceptance unresolved. No automatic retry."}})
    return await db.mr_push_notifications.find_one({"id": key}, {"_id": 0})


@router.post("/mrs/{mrid}/messages")
async def manual_message(mrid: str, body: MessageIn, user=Depends(require_perm("field_sales", "view"))):
    edit_permission(user)
    if not body.confirm_send or not body.message.strip():
        raise HTTPException(422, "Review the message and explicitly confirm sending.")
    mr = await resolve(mrid, user)
    async with mr_lock(f"coaching:{mrid}"):
        result = await deliver(mr, user, body.message.strip(), f"mr-coach:manual:{mrid}:{user['id']}:{body.request_id}", "manual")
    await log_audit(user, "send", "ivr", mrid, detail="Individual MR coaching message attempt")
    return result


async def coaching_tick(now=None):
    now = (now or datetime.now(IST)).astimezone(IST)
    await refresh_role_definitions()
    for saved in await db.mr_ivr_profiles.find({}).to_list(2000):
        p = saved.get("value", {})
        if not (p.get("enabled") or p.get("midday_enabled")) or not p.get("opt_in") or now.weekday() not in p.get("days", []):
            continue
        actor = await db.users.find_one({"id": saved.get("approved_by"), **REAL, "active": {"$ne": False}})
        if not actor:
            continue
        try:
            edit_permission(actor)
            mr = await resolve(saved["id"], actor)
            if not mr.get("active"):
                continue
            kinds = (["encouragement", "push"] if p.get("enabled") else []) + (["midday", "midday_reminder"] if p.get("midday_enabled") else [])
            for kind in kinds:
                hour, minute = map(int, p["midday_time" if kind.startswith("midday") else f"{kind}_time"].split(":"))
                at = now.replace(hour=hour, minute=minute, second=0, microsecond=0)
                date = now.date().isoformat()
                if kind.startswith("midday"):
                    state = await db.mr_field_days.find_one({"id": f"{date}:{mr['id']}"}) or {}
                    if not p.get("field_flow_enabled") or not p.get("ivr_enabled") or state.get("midday_updated_at") or \
                            state.get("status") in ("on_leave", "completed") or state.get("closing_status") == "completed" or \
                            now.strftime("%H:%M") >= p.get("closing_deadline", "21:00"):
                        continue
                    if kind == "midday_reminder":
                        parent = await db.mr_push_notifications.find_one({"id": f"mr-coach:{date}:{saved['id']}:midday"})
                        if not parent or parent.get("status") != "sent":
                            continue
                        accepted = datetime.fromisoformat(parent["accepted_at"]).astimezone(IST)
                        at = accepted + timedelta(minutes=p.get("reminder_minutes", 30))
                    elif await db.mr_push_notifications.find_one({"id": f"mr-coach:{date}:{saved['id']}:midday_reminder"}):
                        continue
                if not at <= now < at + timedelta(hours=1):
                    continue
                key = f"mr-coach:{now.date()}:{saved['id']}:{kind}"
                if await db.mr_push_notifications.find_one({"id": key}):
                    continue
                if kind.startswith("midday"):
                    options = ("1 — Field Visits Continuing\n2 — Visits Completed\n3 — Returning to Office\n4 — Talk to Manager"
                               if kind == "midday_reminder" else
                               "1 — Field Visits Continuing\n2 — Visits Completed\n3 — Customer Meeting in Progress\n4 — Returning to Office\n5 — Need Manager Assistance")
                    text = f"VGRUPS HEALTHCARE — {'REMINDER' if kind == 'midday_reminder' else 'MID-DAY UPDATE'}\nHello {mr['name']}.\nPlease update your current field status.\n{options}\nIf a visit draft is in progress, reply MIDDAY first."
                else:
                    data = await activity(mr, date)
                    text = render_message(p[f"{kind}_template"], mr, date, data)
                await deliver(mr, actor, text, key, kind, date)
                await asyncio.sleep(5)
                return
        except (HTTPException, ValueError, KeyError):
            continue


async def start_mr_coaching():
    while True:
        try:
            async with mr_lock("coaching-scheduler"):
                await coaching_tick()
        except Exception:
            logging.getLogger("vgrups.mr-coaching").error("MR coaching tick failed; reservations remain consumed.")
        await asyncio.sleep(15)
