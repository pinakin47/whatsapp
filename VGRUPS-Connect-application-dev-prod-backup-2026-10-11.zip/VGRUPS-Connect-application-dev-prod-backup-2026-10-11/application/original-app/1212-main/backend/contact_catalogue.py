"""Explicit, individual catalogue batches with durable per-attachment reservations."""
import asyncio
import logging
from fastapi import HTTPException
from auth import permissions_for, refresh_role_definitions
from db import db, now_iso, new_id
from lead_capture_core import stable
from contact_directory import REAL, recipient, check_consent, international_phone
from mr_catalog_daily import catalogue_snapshot
from campaign_media import signed_url
import wa_client
from whatsapp_routing import sender, sender_or_none, attach_report_senders


def can_send(user):
    p = permissions_for(user["role"])
    return all(action in p.get(module, []) for module, action in (
        ("crm", "view"), ("inbox", "send"), ("catalog", "view"), ("catalog", "send")))


def attempt_id(user_id, key):
    return stable("contact-catalogue", user_id, key)


async def status(database, job):
    parts = await database.contact_catalogue_parts.find({"run_id": job["id"]}).to_list(None)
    job = dict(job)
    await attach_report_senders(database, [job], parts_by_id={job["id"]: parts})
    return {**{k: job.get(k) for k in ("id", "status", "total_parts", "error", "phone")},
            "sender_number": job["sender_number"],
            "accepted_parts": sum(p["status"] == "accepted" for p in parts),
            "removed_parts": sum(p["status"] == "removed" for p in parts),
            "uncertain_parts": sum(p["status"] in ("sending", "uncertain") for p in parts)}


async def enqueue(database, user, cid, key, expected_phone=None, session_id=None):
    if not can_send(user):
        raise HTTPException(403, "Contact view, Inbox send and catalogue view/send permissions are required.")
    identity = attempt_id(user["id"], key)
    old = await database.contact_catalogue_runs.find_one({"id": identity})
    if old:
        if old["contact_ref"] != cid:
            raise HTTPException(409, "This request key belongs to a different recipient.")
        if expected_phone and international_phone(expected_phone) != old["phone"]:
            raise HTTPException(409, "This request key belongs to a different number.")
        if session_id and session_id != old["session_id"]:
            raise HTTPException(409, "This request key belongs to a different WhatsApp sender.")
        return await status(database, old)
    row = await recipient(database, cid, user)
    phone = await check_consent(database, row)
    if expected_phone and international_phone(expected_phone) != phone:
        raise HTTPException(409, "Contact number changed. Reload Contacts before sending.")
    session = await sender(database, session_id=session_id)
    parts = await catalogue_snapshot(database)
    if not parts:
        raise HTTPException(422, "No catalogue images or JPEG/PDF files. Add them in Catalog first.")
    job = {"id": identity, "user_id": user["id"], "contact_ref": cid,
        "phone": phone, "name": row["name"], "session_id": session["id"], "sender_phone": session.get("phone"),
        "contact_id": row["contact_id"], "parts": parts, "total_parts": len(parts),
        "status": "queued", "created_at": now_iso()}
    await database.contact_catalogue_runs.update_one({"id": identity}, {"$setOnInsert": job}, upsert=True)
    return await status(database, await database.contact_catalogue_runs.find_one({"id": identity}))


async def catalogue_tick(database=db):
    await refresh_role_definitions()
    jobs = await database.contact_catalogue_runs.find({"status": {"$in": ["queued", "sending", "blocked_storage"]}}).sort("last_attempt_at", 1).to_list(50)
    for job in jobs:
        session = await sender_or_none(database, session_id=job["session_id"])
        if not session:
            continue
        actor = await database.users.find_one({"id": job["user_id"], **REAL, "active": {"$ne": False}})
        try:
            if not actor or not can_send(actor):
                raise HTTPException(403, "Sending permission is no longer available.")
            row = await recipient(database, job["contact_ref"], actor)
            if await check_consent(database, row) != job["phone"]:
                raise HTTPException(409, "Recipient number changed; remaining attachments cancelled.")
        except HTTPException as exc:
            await database.contact_catalogue_runs.update_one({"id": job["id"]},
                {"$set": {"status": "cancelled", "error": str(exc.detail)}})
            continue
        records = await database.contact_catalogue_parts.find({"run_id": job["id"]}).to_list(None)
        consumed = {r["media_key"] for r in records}
        part = next((p for p in job["parts"] if p["key"] not in consumed), None)
        if not part:
            final = "accepted" if all(r["status"] in ("accepted", "removed") for r in records) else "needs_review"
            await database.contact_catalogue_runs.update_one({"id": job["id"]}, {"$set": {
                "status": final, "error": None if final == "accepted" else "Unresolved attachments are not automatically resent."}})
            continue
        identity = stable("contact-catalogue-part", job["id"], part["key"])
        url = part.get("url")
        if part.get("media_id"):
            file = await database.campaign_media.find_one({"id": part["media_id"], "state": "ready", **REAL})
            if not file:
                await database.contact_catalogue_parts.update_one({"id": identity}, {"$setOnInsert": {
                    "id": identity, "run_id": job["id"], "media_key": part["key"], "status": "removed"}}, upsert=True)
                continue
            try:
                url = await signed_url(part["object_path"])
            except Exception:
                await database.contact_catalogue_runs.update_one({"id": job["id"]}, {"$set": {
                    "status": "blocked_storage", "error": "Storage unavailable. Waiting safely before attempting this attachment.",
                    "last_attempt_at": now_iso()}})
                continue
        claim = await database.contact_catalogue_parts.update_one({"id": identity}, {"$setOnInsert": {
            "id": identity, "run_id": job["id"], "media_key": part["key"],
            "status": "sending", "created_at": now_iso()}}, upsert=True)
        if not claim.upserted_id:
            continue
        caption = f"VGRUPS Healthcare — catalogue\n{part['name']}"
        try:
            # Recheck after storage/claim IO, immediately before any provider call.
            latest_actor = await database.users.find_one({"id": actor["id"], **REAL, "active": {"$ne": False}})
            if not latest_actor or not can_send(latest_actor):
                raise HTTPException(403, "Sending permission was revoked.")
            latest = await recipient(database, job["contact_ref"], latest_actor)
            if await check_consent(database, latest) != job["phone"]:
                raise HTTPException(409, "Recipient number changed.")
            scope = {"session_id": session["id"], **REAL}
            conv = await database.conversations.find_one({"phone": {"$in": [job["phone"], job["phone"].lstrip("+")]}, **scope})
            if not conv:
                candidate = {"id": new_id(), "phone": job["phone"].lstrip("+"),
                    "name": job["name"], "session_id": session["id"], "contact_id": row["contact_id"],
                    "is_demo": False, "deleted": False, "unread": 0, "created_at": now_iso()}
                await database.conversations.update_one({"phone": candidate["phone"], **scope},
                    {"$setOnInsert": candidate}, upsert=True)
                conv = await database.conversations.find_one({"phone": candidate["phone"], **scope})
            await database.whatsapp_send_requests.update_one({"id": identity}, {"$setOnInsert": {
                "id": identity, "state": "sending", "provider": "qr", "recipient_address": job["phone"],
                "message_body": caption, "media_key": part["key"], "gateway_message_id": None,
                "source": "contact_catalogue", "conversation_id": conv["id"], "created_at": now_iso()}}, upsert=True)
            response = await wa_client.wa_send_media(job["phone"], url, part["content_type"], part["filename"], caption,
                session_id=session["id"], request_id=identity, media_key=part["key"])
            if not response.get("wamid"):
                raise RuntimeError("Acceptance unresolved")
            wamid = response["wamid"]
            await database.messages.update_one({"wamid": wamid}, {"$setOnInsert": {
                "id": identity, "wamid": wamid, "conversation_id": conv["id"], "session_id": session["id"],
                "direction": "outbound", "type": "document" if part["content_type"] == "application/pdf" else "image",
                "body": caption, "status": "sent", "is_demo": False, "created_at": now_iso()},
                "$set": {"sender": actor["name"], "capture_skip": True, "media_id": part.get("media_id"),
                         "media_url": part.get("url"), "filename": part["filename"], "content_type": part["content_type"]}}, upsert=True)
            await database.conversations.update_one({"id": conv["id"]}, {"$set": {"last_message": caption, "last_message_at": now_iso()}})
            await database.contact_catalogue_parts.update_one({"id": identity}, {"$set": {"status": "accepted", "wamid": wamid}})
            await database.whatsapp_send_requests.update_one({"id": identity}, {"$set": {"state": "accepted", "provider_id": wamid}})
        except HTTPException as exc:
            await database.contact_catalogue_parts.update_one({"id": identity}, {"$set": {"status": "cancelled"}})
            await database.contact_catalogue_runs.update_one({"id": job["id"]}, {"$set": {"status": "cancelled", "error": str(exc.detail)}})
            return
        except Exception:
            await database.contact_catalogue_parts.update_one({"id": identity}, {"$set": {"status": "uncertain"}})
        await database.contact_catalogue_runs.update_one({"id": job["id"]}, {"$set": {"status": "sending", "error": None, "last_attempt_at": now_iso()}})
        return  # Advance another recipient next tick, rather than monopolizing the worker.


async def start_contact_catalogues():
    while True:
        try:
            await catalogue_tick()
        except Exception:
            logging.getLogger("vgrups.contact-catalogue").error("Individual catalogue cycle failed; reservations retained.")
        await asyncio.sleep(2)
