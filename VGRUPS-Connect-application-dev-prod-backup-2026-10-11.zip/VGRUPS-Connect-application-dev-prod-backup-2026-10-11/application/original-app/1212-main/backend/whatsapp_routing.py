"""Explicit sender assignments. A disconnected assignment never changes provider."""
from fastapi import HTTPException
import re
import wa_client

CONFIG_KEY = "whatsapp_number_routing"
REAL = {"is_demo": {"$ne": True}}


def readable_sender_phone(value):
    """Only an account phone, never a recipient address or a display name."""
    digits = re.sub(r"[\s()+.-]", "", str(value or ""))
    return f"+{digits}" if re.fullmatch(r"[1-9]\d{7,14}", digits) else None


def report_sender(record, phones, evidence=()):
    """Historical attribution must not consult today's routing assignments."""
    pinned = record.get("sender_session_id") or record.get("session_id")
    snapshot = readable_sender_phone(record.get("sender_phone"))
    if snapshot:
        return snapshot
    if pinned:
        return phones.get(pinned) or "Unknown"
    # Evidence is grouped per provider ID. Conflicting copies or missing parts
    # must not make a multipart attempt look like it used a known single sender.
    numbers = []
    for candidates in evidence:
        sessions = {sid for sid in candidates if sid}
        if len(sessions) != 1:
            return "Unknown"
        number = phones.get(next(iter(sessions)))
        if not number:
            return "Unknown"
        numbers.append(number)
    return ", ".join(sorted(set(numbers))) if numbers else "Unknown"


async def report_sender_phones(database):
    """Read saved accounts including archived ones, without contacting a gateway."""
    rows = await database.wa_sessions.find(REAL, {"_id": 0}).to_list(None)
    return {r["id"]: readable_sender_phone(r.get("phone")) for r in rows if r.get("id")}


def report_sender_sql():
    """SQL equivalent of report_sender for filtering before pagination/streaming.

    Uses p's historical evidence, $1's saved parent pin and $5's archived phone
    map. No live gateway or routing assignment participates in attribution.
    """
    return r"""
    (SELECT CASE
        WHEN snapshot ~ '^[1-9][0-9]{7,14}$' THEN '+' || snapshot
        WHEN pinned IS NOT NULL THEN COALESCE($5::jsonb->>pinned, 'Unknown')
        ELSE COALESCE((
            SELECT CASE WHEN bool_and(candidate_count = 1 AND number IS NOT NULL)
                THEN string_agg(DISTINCT number, ', ' ORDER BY number)
                ELSE 'Unknown' END
            FROM (
                SELECT count(DISTINCT NULLIF(sid, '')) AS candidate_count,
                    $5::jsonb->>min(NULLIF(sid, '')) AS number
                FROM jsonb_array_elements(COALESCE(p.sender_evidence, '[]'::jsonb))
                    WITH ORDINALITY e(sessions, part)
                CROSS JOIN LATERAL jsonb_array_elements_text(e.sessions) s(sid)
                GROUP BY e.part
            ) evidence
        ), 'Unknown') END
    FROM (
        SELECT regexp_replace(COALESCE(p.document->>'sender_phone', ''),
                '[\s()+.-]', '', 'g') AS snapshot,
            COALESCE(NULLIF(p.document->>'sender_session_id', ''),
                NULLIF(p.document->>'session_id', ''),
                (SELECT NULLIF(a.document->>'sender_session_id', '') FROM app_documents a
                 WHERE a.collection_name =
                    CASE WHEN p.document ? 'drip_id' THEN 'drips' ELSE 'campaigns' END
                    AND a.document->>'id' = $1)) AS pinned
    ) provenance)
    """


async def report_sender_context(database, messages):
    """Reuse a report's already-scoped message read, never receipt-only rows."""
    conv_ids = list({m["conversation_id"] for m in messages
                     if not m.get("session_id") and m.get("conversation_id")})
    conversations = await database.conversations.find({"id": {"$in": conv_ids}, **REAL},
        {"_id": 0}).to_list(None) if conv_ids else []
    conv_sessions = {c["id"]: c.get("session_id") for c in conversations}
    by_wamid = {}
    for message in messages:
        if message.get("direction") == "inbound":
            continue
        sid = message.get("session_id") or conv_sessions.get(message.get("conversation_id"))
        by_wamid.setdefault(message["wamid"], set()).add(sid)
    phones = await report_sender_phones(database)
    return phones, by_wamid


async def attach_report_senders(database, records, *, parts_by_id=None, context=None):
    """Batch exact message/conversation provenance for authorized report records."""
    if not records:
        return
    parts_by_id = parts_by_id or {}
    def parts(record):
        return parts_by_id.get(record["id"], [record])
    if context is None:
        wamids = list({p["wamid"] for r in records for p in parts(r) if p and p.get("wamid")})
        messages = await database.messages.find({"wamid": {"$in": wamids}, **REAL},
            {"_id": 0}).to_list(None) if wamids else []
        context = await report_sender_context(database, messages)
    phones, by_wamid = context
    for record in records:
        evidence = []
        for part in parts(record):
            if part and (part.get("sender_session_id") or part.get("session_id")):
                evidence.append([part.get("sender_session_id") or part.get("session_id")])
            else:
                evidence.append(by_wamid.get((part or {}).get("wamid"), set()))
        record["sender_number"] = report_sender(record, phones, evidence)


async def accounts(database, include_archived=False):
    try:
        data = await wa_client.wa_list_sessions()
    except Exception:
        data = {}  # Keep saved accounts visible, but withhold connected status.
    stored = await database.wa_sessions.find(REAL, {"_id": 0}).to_list(None)
    by_id = {s["id"]: {**s, "status": "disconnected" if s.get("status") == "connected"
                      else s.get("status", "disconnected")} for s in stored}
    for live in data.get("sessions", []):
        if live.get("id") and not live.get("is_demo"):
            previous = by_id.get(live["id"], {})
            by_id[live["id"]] = {**previous, **live, "phone": live.get("phone") or previous.get("phone")}
    rows = []
    for s in by_id.values():
        archived = s.get("deleted") or s.get("status") in ("deleted", "logged_out")
        if archived and not include_archived:
            continue
        if not s.get("phone") and s.get("status") != "connected":
            if not include_archived or not await database.conversations.find_one({"session_id": s["id"], **REAL}):
                continue
        rows.append({k: s.get(k) for k in ("id", "name", "phone", "status", "created_at", "deleted")})
    return rows


async def configuration(database, rows=None):
    rows = await accounts(database) if rows is None else rows
    saved = await database.app_config.find_one({"key": CONFIG_KEY})
    if not saved and len(rows) == 1:
        # Preserve the existing sole sender before another number is linked.
        value = {"mr_session_id": rows[0]["id"], "general_session_id": rows[0]["id"]}
        await database.app_config.update_one({"key": CONFIG_KEY},
            {"$setOnInsert": {"key": CONFIG_KEY, "value": value}}, upsert=True)
        saved = await database.app_config.find_one({"key": CONFIG_KEY})
    return (saved or {}).get("value") or {"mr_session_id": None, "general_session_id": None}


async def sender(database, session_id=None, purpose="general", require_connected=True):
    rows = await accounts(database)
    config = await configuration(database, rows)
    selected = session_id or config.get(f"{purpose}_session_id")
    if not selected and len(rows) == 1:
        selected = rows[0]["id"]
    if not selected:
        raise HTTPException(409, f"Choose a WhatsApp number for {purpose} messages in WhatsApp Connections.")
    row = next((s for s in rows if s["id"] == selected), None)
    if not row:
        raise HTTPException(409, "Assigned WhatsApp number is unlinked. Select its replacement explicitly.")
    if require_connected and row["status"] != "connected":
        raise HTTPException(409, "Selected WhatsApp number is offline. Reconnect it; another number will not be used.")
    return row


async def sender_or_none(database, session_id=None, purpose="general"):
    try:
        return await sender(database, session_id, purpose)
    except HTTPException:
        return None


async def qr_configured(database, purpose="general"):
    rows = await accounts(database)
    return bool(rows or (await configuration(database, rows)).get(f"{purpose}_session_id"))


async def mr_session_allowed(database, session_id):
    rows = await database.wa_sessions.find({"deleted": {"$ne": True}, **REAL}, {"_id": 0}).to_list(None)
    known = [s for s in rows if s.get("status") not in ("deleted", "logged_out") and
             (s.get("phone") or s.get("status") == "connected")]
    config = await configuration(database, known)
    assigned = config.get("mr_session_id") or (known[0]["id"] if len(known) == 1 else None)
    return bool(assigned and assigned == session_id and any(s["id"] == assigned for s in known))
