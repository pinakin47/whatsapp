"""JPEG/PDF catalogue assets in App Storage, with durable metadata and permissions."""
from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import RedirectResponse
from auth import require_perm
from db import db, now_iso, log_audit
import campaign_media as media
import catalogue_reports as reports

router = APIRouter(prefix="/api/catalog", tags=["Catalogue files"])
REAL = {"deleted": {"$ne": True}}


@router.get("/files")
async def files(actor=Depends(require_perm("catalog", "view"))):
    rows = await db.campaign_media.find({"purpose": "catalog", "state": "ready", **REAL}, {"_id": 0}).sort("created_at", -1).to_list(None)
    return {"items": [{k: r.get(k) for k in ("id", "name", "content_type", "size", "created_at")} for r in rows]}


@router.post("/files/request-upload")
async def request_upload(body: media.UploadIn, actor=Depends(require_perm("catalog", "create"))):
    if body.content_type not in ("image/jpeg", "application/pdf"):
        raise HTTPException(422, "Upload JPEG/JPG (up to 5 MB) or PDF (up to 10 MB).")
    result = await media.request_upload(body, actor)
    await db.campaign_media.update_one({"id": result["media_id"], "owner_id": actor["id"]},
        {"$set": {"purpose": "catalog"}})
    return result


@router.post("/files/{mid}/complete")
async def complete(mid: str, actor=Depends(require_perm("catalog", "create"))):
    if not await db.campaign_media.find_one({"id": mid, "owner_id": actor["id"], "purpose": "catalog", **REAL}):
        raise HTTPException(404, "Catalogue upload not found.")
    result = await media.complete_upload(mid, actor)
    await log_audit(actor, "create", "catalog", mid, detail="Catalogue JPEG/PDF ready for daily MR sharing")
    return result


@router.get("/files/{mid}/download")
async def download(mid: str, actor=Depends(require_perm("catalog", "view"))):
    row = await db.campaign_media.find_one({"id": mid, "purpose": "catalog", "state": {"$in": ["ready", "archived"]}})
    if not row:
        raise HTTPException(404, "Catalogue file not found.")
    return RedirectResponse(await media.signed_url(row["object_path"]), status_code=307)


@router.get("/files/{mid}/download-url")
async def download_url(mid: str, actor=Depends(require_perm("catalog", "view"))):
    row = await db.campaign_media.find_one({"id": mid, "purpose": "catalog", "state": {"$in": ["ready", "archived"]}})
    if not row:
        raise HTTPException(404, "Catalogue file not found.")
    return {"url": await media.signed_url(row["object_path"])}


@router.delete("/files/{mid}")
async def archive(mid: str, actor=Depends(require_perm("catalog", "delete"))):
    result = await db.campaign_media.update_one({"id": mid, "purpose": "catalog", "state": "ready"},
        {"$set": {"deleted": True, "state": "archived", "updated_at": now_iso()}})
    if not result.matched_count:
        raise HTTPException(404, "Catalogue file not found.")
    await log_audit(actor, "delete", "catalog", mid, detail="Removed from future daily catalogue batches; historical files preserved")
    return {"ok": True}


@router.get("/daily-mr")
async def daily_status(actor=Depends(require_perm("catalog", "view")),
                       offset: int = Query(0, ge=0), limit: int = Query(20, ge=1, le=100)):
    cfg = (await db.app_config.find_one({"key": "mr_catalog_daily"}) or {}).get("value", {})
    result = await reports.page(db, db.mr_catalog_runs, db.mr_catalog_parts, {}, offset, limit)
    return {**result, "enabled": cfg.get("enabled", True), "time": cfg.get("time", "09:00"), "timezone": "Asia/Kolkata",
        "activated": bool(await db.app_config.find_one({"key": "automatic_registered_mrs"})),
        "audience": "All active registered MRs, except opted-out or paused MRs"}


@router.get("/daily-mr.csv")
async def daily_status_csv(actor=Depends(require_perm("catalog", "view")),
                           exporter=Depends(require_perm("catalog", "export")),
                           offset: int = Query(0, ge=0), limit: int = Query(20, ge=1, le=100)):
    result = await daily_status(actor, offset, limit)
    return reports.history_csv("daily_mr_catalogue_delivery", result, recipient_header="MR")


@router.get("/daily-mr/{run_id}")
async def daily_detail(run_id: str, actor=Depends(require_perm("catalog", "view"))):
    job = await db.mr_catalog_runs.find_one({"id": run_id})
    if not job:
        raise HTTPException(404, "No saved daily catalogue attempt.")
    return await reports.detail(db, job, db.mr_catalog_parts)


@router.get("/daily-mr/{run_id}/report.csv")
async def daily_detail_csv(run_id: str, actor=Depends(require_perm("catalog", "view")),
                           exporter=Depends(require_perm("catalog", "export"))):
    return reports.detail_csv("daily_mr_catalogue_attempt", await daily_detail(run_id, actor), recipient_header="MR")
