"""Shared lead scope for new UI, legacy Kanban, contact expansions and search."""
from fastapi import HTTPException


def lead_scope(user):
    query = {"deleted": {"$ne": True}, "is_demo": {"$ne": True}}
    if user["role"] == "mr":
        query["assigned_to"] = user["id"]
    elif user["role"] not in ("admin", "super_admin", "sales_manager"):
        query["source"] = {"$ne": "WhatsApp – MR"}
    return query


async def accessible_lead(database, lid, user):
    lead = await database.leads.find_one({"id": lid, **lead_scope(user)}, {"_id": 0})
    if not lead:
        raise HTTPException(404, "Lead not found or not accessible")
    return lead
