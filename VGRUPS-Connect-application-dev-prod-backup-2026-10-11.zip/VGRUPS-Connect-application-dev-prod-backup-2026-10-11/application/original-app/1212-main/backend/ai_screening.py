"""AI resume screening — scores a candidate against a position using the Emergent LLM key (Gemini 3 Flash)."""
import io
import json
import logging
import os
import re

from screening_llm import screening_completion

logger = logging.getLogger("vgrups.ai_screening")

EMERGENT_LLM_KEY = os.environ.get("EMERGENT_LLM_KEY")
MODEL = ("gemini", "gemini-3-flash-preview")

SYSTEM = (
    "You are a senior HR recruiter for VGRUPS Healthcare, a medical products company in India. "
    "You screen candidates for a specific role. Be fair, concise and practical. "
    "Judge fit from the resume text AND the candidate's screening answers against the role's "
    "requirements. Respond ONLY with a single JSON object, no markdown, no commentary."
)


def extract_resume_text(data: bytes, content_type: str, filename: str = "") -> str:
    ct = (content_type or "").lower()
    fn = (filename or "").lower()
    try:
        if "pdf" in ct or fn.endswith(".pdf"):
            from pypdf import PdfReader
            reader = PdfReader(io.BytesIO(data))
            return "\n".join((p.extract_text() or "") for p in reader.pages).strip()
        if "wordprocessingml" in ct or fn.endswith(".docx"):
            import docx
            d = docx.Document(io.BytesIO(data))
            return "\n".join(p.text for p in d.paragraphs).strip()
        if "text" in ct or fn.endswith(".txt"):
            return data.decode("utf-8", errors="ignore").strip()
    except Exception as e:
        logger.warning(f"resume text extraction failed: {e}")
    return ""


def _parse_json(text: str) -> dict:
    t = (text or "").strip()
    t = re.sub(r"^```(?:json)?", "", t).strip()
    t = re.sub(r"```$", "", t).strip()
    m = re.search(r"\{.*\}", t, re.DOTALL)
    if m:
        t = m.group(0)
    return json.loads(t)


async def score_candidate(position: dict, candidate: dict, resume_text: str) -> dict:
    reqs = position.get("requirements") or []
    answers = candidate.get("answers") or []
    answers_txt = "\n".join(f"- {a.get('q')}: {a.get('a')}" for a in answers) or "(none provided)"
    resume_block = (resume_text[:6000] if resume_text else "(no resume text available)")

    prompt = f"""Score this candidate for the role below.

ROLE: {position.get('title')} ({position.get('department')})
ROLE SUMMARY: {position.get('summary')}
REQUIREMENTS:\n{chr(10).join('- ' + r for r in reqs) or '- (general)'}

CANDIDATE SCREENING ANSWERS:\n{answers_txt}

RESUME TEXT:\n{resume_block}

Return JSON with EXACTLY these keys:
{{
  "score": <integer 0-100 overall fit>,
  "recommendation": <one of "strong_fit","possible_fit","weak_fit">,
  "summary": <one sentence verdict>,
  "strengths": [<up to 3 short bullet strings>],
  "concerns": [<up to 3 short bullet strings>]
}}"""

    raw = await screening_completion(EMERGENT_LLM_KEY, MODEL[1], SYSTEM, prompt)
    data = _parse_json(raw)

    score = int(max(0, min(100, int(data.get("score", 0)))))
    rec = data.get("recommendation", "possible_fit")
    if rec not in ("strong_fit", "possible_fit", "weak_fit"):
        rec = "strong_fit" if score >= 75 else "possible_fit" if score >= 50 else "weak_fit"
    return {
        "score": score,
        "recommendation": rec,
        "summary": str(data.get("summary", ""))[:300],
        "strengths": [str(s)[:160] for s in (data.get("strengths") or [])][:3],
        "concerns": [str(s)[:160] for s in (data.get("concerns") or [])][:3],
        "used_resume": bool(resume_text),
    }
