-- Apply in development. Replit's Publish flow manages production schema.
CREATE TABLE IF NOT EXISTS app_documents (
    collection_name text NOT NULL,
    document_id text NOT NULL,
    document jsonb NOT NULL,
    PRIMARY KEY (collection_name, document_id),
    CHECK (jsonb_typeof(document) = 'object')
);
CREATE INDEX IF NOT EXISTS app_documents_data_idx ON app_documents USING gin (document);
CREATE UNIQUE INDEX IF NOT EXISTS app_users_email_unique
    ON app_documents ((document->>'email')) WHERE collection_name = 'users';
CREATE UNIQUE INDEX IF NOT EXISTS app_wa_auth_key_unique
    ON app_documents ((document->>'sessionId'), (document->>'dataId')) WHERE collection_name = 'wa_auth';
CREATE INDEX IF NOT EXISTS app_contacts_mobile_idx
    ON app_documents ((document->>'mobile')) WHERE collection_name = 'contacts';
CREATE INDEX IF NOT EXISTS app_leads_status_idx
    ON app_documents ((document->>'status')) WHERE collection_name = 'leads';
CREATE INDEX IF NOT EXISTS app_conversations_phone_idx
    ON app_documents ((document->>'phone')) WHERE collection_name = 'conversations';
CREATE INDEX IF NOT EXISTS app_messages_wamid_idx
    ON app_documents ((document->>'wamid')) WHERE collection_name = 'messages';
CREATE INDEX IF NOT EXISTS app_audit_created_idx
    ON app_documents ((document->>'created_at')) WHERE collection_name = 'audit_logs';
CREATE INDEX IF NOT EXISTS app_mr_activity_owner_created_idx
    ON app_documents (collection_name, (document->>'created_by'), (document->>'created_at'))
    WHERE collection_name IN ('orders', 'quotations');
-- Contact directory exact-reference / normalized-phone rechecks. These index
-- expressions match postgres_directory; no records or credentials are copied.
-- Keep phone expressions in stored generated columns: migration introspection
-- truncates long index expressions to PostgreSQL's 63-byte identifier limit.
ALTER TABLE app_documents
    ADD COLUMN IF NOT EXISTS directory_mobile_key text GENERATED ALWAYS AS
        (ltrim(regexp_replace(COALESCE(document->>'mobile', ''), '[\s().-]', '', 'g'), '+')) STORED,
    ADD COLUMN IF NOT EXISTS directory_phone_key text GENERATED ALWAYS AS
        (ltrim(regexp_replace(COALESCE(document->>'phone', ''), '[\s().-]', '', 'g'), '+')) STORED,
    ADD COLUMN IF NOT EXISTS directory_mobile_first_key text GENERATED ALWAYS AS
        (ltrim(regexp_replace(COALESCE(NULLIF(document->>'mobile', ''), NULLIF(document->>'phone', ''), ''), '[\s().-]', '', 'g'), '+')) STORED,
    ADD COLUMN IF NOT EXISTS directory_phone_first_key text GENERATED ALWAYS AS
        (ltrim(regexp_replace(COALESCE(NULLIF(document->>'phone', ''), NULLIF(document->>'mobile', ''), ''), '[\s().-]', '', 'g'), '+')) STORED,
    ADD COLUMN IF NOT EXISTS directory_lead_phone_key text GENERATED ALWAYS AS
        (ltrim(regexp_replace(COALESCE(NULLIF(document->>'mobile', ''), NULLIF(document->>'phone', ''), NULLIF(document->>'alternative_phone', ''), ''), '[\s().-]', '', 'g'), '+')) STORED,
    ADD COLUMN IF NOT EXISTS directory_alternate_phone_key text GENERATED ALWAYS AS
        (ltrim(regexp_replace(COALESCE(document->>'alternative_phone', ''), '[\s().-]', '', 'g'), '+')) STORED;
CREATE INDEX IF NOT EXISTS app_directory_source_id_idx
    ON app_documents (collection_name, (document->>'id'))
    WHERE collection_name IN ('contacts', 'mr_directory', 'users', 'leads',
                             'orders', 'quotations', 'candidates', 'conversations');
CREATE INDEX IF NOT EXISTS app_directory_mobile_first_idx
    ON app_documents (collection_name, directory_mobile_first_key)
    WHERE collection_name IN ('contacts', 'orders', 'quotations');
CREATE INDEX IF NOT EXISTS app_directory_phone_first_idx
    ON app_documents (collection_name, directory_phone_first_key)
    WHERE collection_name IN ('mr_directory', 'users', 'candidates');
CREATE INDEX IF NOT EXISTS app_directory_lead_phone_idx
    ON app_documents (directory_lead_phone_key)
    WHERE collection_name = 'leads';
CREATE INDEX IF NOT EXISTS app_directory_alternate_phone_idx
    ON app_documents (directory_alternate_phone_key)
    WHERE collection_name = 'leads';
CREATE INDEX IF NOT EXISTS app_directory_inbox_phone_idx
    ON app_documents (directory_phone_key, (document->>'session_id'))
    WHERE collection_name = 'conversations';
CREATE INDEX IF NOT EXISTS app_directory_optout_mobile_idx
    ON app_documents (directory_mobile_key)
    WHERE collection_name = 'contacts' AND document->'opted_out' = 'true'::jsonb;
CREATE INDEX IF NOT EXISTS app_directory_optout_phone_idx
    ON app_documents (directory_phone_key)
    WHERE collection_name = 'contacts' AND document->'opted_out' = 'true'::jsonb;