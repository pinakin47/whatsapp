from decimal import Decimal
import hashlib
import re
from typing import Literal, Optional

from fastapi import APIRouter, Depends, HTTPException, Query, Response
from pydantic import BaseModel, ConfigDict, EmailStr, Field, field_validator, model_validator
from starlette.concurrency import run_in_threadpool
from auth import require_perm, permissions_for
from db import db
import sales_service as service
from sales_exports import export_pdf, export_xlsx

router = APIRouter(prefix="/api/sales", tags=["sales"])
Status = Literal["Submitted", "Confirmed", "Processing", "Completed", "Cancelled"]


class ItemIn(BaseModel):
    model_config = ConfigDict(extra="forbid")
    product_id: str = Field(min_length=1, max_length=128)
    quantity: int = Field(gt=0, le=1000000, strict=True)
    unit_price: Decimal = Field(ge=0, max_digits=12, decimal_places=2, allow_inf_nan=False)


class CustomerIn(BaseModel):
    model_config = ConfigDict(extra="forbid")
    customer_name: str = Field(min_length=1, max_length=200)
    phone: str = Field(max_length=30)
    email: Optional[EmailStr] = None
    address: str = Field(default="", max_length=2000)
    items: list[ItemIn] = Field(min_length=1, max_length=100)

    @field_validator("customer_name", "address", mode="before")
    @classmethod
    def trim(cls, value):
        return value.strip() if isinstance(value, str) else value

    @field_validator("email", mode="before")
    @classmethod
    def blank_email(cls, value):
        return value.strip() or None if isinstance(value, str) else value

    @field_validator("phone")
    @classmethod
    def indian_phone(cls, value):
        compact = re.sub(r"[\s()-]", "", value)
        if not re.fullmatch(r"(?:(?:\+91|91|0)?[6-9]\d{9})", compact):
            raise ValueError("Enter a valid Indian mobile number (10 digits, optionally +91).")
        return "+91" + compact[-10:]


class SaleIn(CustomerIn):
    request_key: str = Field(min_length=16, max_length=100, pattern=r"^[A-Za-z0-9_-]+$")


class SaleEditIn(BaseModel):
    model_config = ConfigDict(extra="forbid")
    revision: int = Field(ge=1, strict=True)
    status: Optional[Status] = None
    customer_name: Optional[str] = None
    phone: Optional[str] = None
    email: Optional[str] = None
    address: str = ""
    items: Optional[list[ItemIn]] = None

    @model_validator(mode="after")
    def valid_change(self):
        if "status" in self.model_fields_set and self.status is None:
            raise ValueError("Status cannot be blank.")
        if self.customer_name is not None:
            validated = CustomerIn(customer_name=self.customer_name, phone=self.phone,
                                   email=self.email, address=self.address, items=self.items)
            for k in ("customer_name", "phone", "email", "address", "items"):
                setattr(self, k, getattr(validated, k))
        elif any(k in self.model_fields_set for k in ("phone", "email", "address", "items")):
            raise ValueError("Customer edits must include the full customer and product form.")
        elif self.status is None:
            raise ValueError("Provide a status or complete sale edit.")
        return self


def filter_inputs(q: str = Query(default="", max_length=120),
                  date_from: Optional[str] = None, date_to: Optional[str] = None,
                  mr_id: Optional[str] = Query(default=None, max_length=128),
                  customer: str = Query(default="", max_length=200),
                  product_id: Optional[str] = Query(default=None, max_length=128),
                  status: Optional[Status] = None):
    return dict(q=q, date_from=date_from, date_to=date_to, mr_id=mr_id,
                customer=customer, product_id=product_id, status=status)


@router.get("")
async def list_sales(filters: dict = Depends(filter_inputs), page: int = Query(default=1, ge=1),
                     page_size: int = Query(default=20, ge=1, le=100),
                     user: dict = Depends(require_perm("sales", "view"))):
    query = service.filters(user, **filters)
    total = await db.sales.count_documents(query)
    items = await db.sales.find(query, {"_id": 0, "audit": 0}).sort(
        [("created_at", -1), ("id", 1)]).skip((page - 1) * page_size).to_list(page_size)
    perms = permissions_for(user["role"]).get("sales", [])
    return {"items": [service.public(s) for s in items], "total": total, "page": page,
            "page_size": page_size, "is_admin": service.is_admin(user),
            "can_edit": "edit" in perms, "can_delete": "delete" in perms,
            "can_export": "export" in perms, "company": await service.company(db),
            **await service.report(db, query, user)}


@router.get("/products")
async def products(q: str = Query(default="", max_length=100), page: int = Query(default=1, ge=1),
                   user: dict = Depends(require_perm("sales", "view"))):
    query = {**service.REAL, "active": {"$ne": False}}
    if q.strip():
        query["$or"] = [{k: {"$regex": re.escape(q.strip()), "$options": "i"}} for k in ("name", "code")]
    rows = await db.products.find(query, {"_id": 0, "id": 1, "name": 1, "code": 1,
                                         "selling_price": 1}).sort("name", 1).skip((page - 1) * 50).to_list(50)
    return {"items": rows, "total": await db.products.count_documents(query), "page": page, "page_size": 50}


@router.get("/mrs")
async def mrs(q: str = Query(default="", max_length=100),
              user: dict = Depends(require_perm("sales", "view"))):
    query = {"role": "mr", **service.REAL}
    if not service.is_admin(user):
        query["id"] = user["id"]
    if q.strip():
        query["name"] = {"$regex": re.escape(q.strip()), "$options": "i"}
    rows = await db.users.find(query, {"_id": 0, "id": 1, "name": 1, "active": 1}).sort("name", 1).to_list(200)
    return {"items": rows, "total": await db.users.count_documents(query)}


@router.get("/export")
async def export_sales(format: Literal["xlsx", "pdf"], filters: dict = Depends(filter_inputs),
                       user: dict = Depends(require_perm("sales", "export"))):
    query = service.filters(user, **filters)
    if await db.sales.count_documents(query) > 10000:
        raise HTTPException(422, "Select a narrower date range; exports support up to 10,000 sales.")
    rows = await db.sales.find(query, {"_id": 0, "audit": 0}).sort("created_at", -1).to_list(10001)
    if len(rows) > 10000:
        raise HTTPException(422, "Select a narrower date range; exports support up to 10,000 sales.")
    if sum(len(s.get("items", [])) for s in rows) > 25000:
        raise HTTPException(422, "Select a narrower range; exports support up to 25,000 product lines.")
    company = await service.company(db)
    data = await run_in_threadpool(export_xlsx, rows) if format == "xlsx" else await run_in_threadpool(export_pdf, rows, company)
    media = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" if format == "xlsx" else "application/pdf"
    return Response(data, media_type=media, headers={
        "Content-Disposition": f'attachment; filename="vgrups-sales.{format}"', "Cache-Control": "no-store"})


@router.post("")
async def create_sale(body: SaleIn, user: dict = Depends(require_perm("sales", "create"))):
    return await service.create(db, body, user)


@router.get("/save-status")
async def save_status(request_key: str = Query(min_length=16, max_length=100, pattern=r"^[A-Za-z0-9_-]+$"),
                      user: dict = Depends(require_perm("sales", "view"))):
    record_id = hashlib.sha256(f'{user["id"]}:{request_key}'.encode()).hexdigest()
    saved = await db.sales.find_one({"id": record_id, "mr_id": user["id"]}, {"_id": 0})
    return {"found": bool(saved), "sale_id": saved.get("sale_id") if saved else None,
            "id": saved.get("id") if saved else None, "deleted": bool(saved and saved.get("deleted"))}


@router.get("/{sale_id}")
async def sale_detail(sale_id: str, user: dict = Depends(require_perm("sales", "view"))):
    sale = await service.owned(db, sale_id, user)
    return {**service.public(sale), "audit": sale.get("audit", []), "company": await service.company(db)}


@router.patch("/{sale_id}")
async def edit_sale(sale_id: str, body: SaleEditIn,
                    user: dict = Depends(require_perm("sales", "edit"))):
    return await service.change(db, sale_id, body, user)


@router.delete("/{sale_id}")
async def delete_sale(sale_id: str, revision: int = Query(ge=1),
                      user: dict = Depends(require_perm("sales", "delete"))):
    await service.change(db, sale_id, revision, user, remove=True)
    return {"ok": True}
