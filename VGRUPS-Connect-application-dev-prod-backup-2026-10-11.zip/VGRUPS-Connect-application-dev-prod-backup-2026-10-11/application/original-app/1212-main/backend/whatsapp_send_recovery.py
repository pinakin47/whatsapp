"""Conservative recovery: positive, request-bound evidence only; never send."""
from db import new_id, now_iso


async def reconcile_send(existing, user, database, record_sent_message):
    if existing["state"] in ("accepted", "completed"):
        message = existing["response"]
        if existing["state"] == "accepted":
            message = await record_sent_message(message, user, existing["id"])
        return {"state": "accepted", "evidence": "saved_acceptance", "message": message}

    evidence, wamid, accepted_at = None, None, None
    if existing.get("provider") == "qr" and existing.get("conversation_id") and existing.get("message_body"):
        # Written by the private gateway after the original SDK call returned.
        if existing.get("gateway_accepted_wamid"):
            evidence, wamid = "gateway_receipt", existing["gateway_accepted_wamid"]
            accepted_at = existing.get("gateway_accepted_at")
        elif existing.get("gateway_message_id") and existing.get("gateway_session_id"):
            echo = await database.messages.find_one(
                {"wamid": existing["gateway_message_id"]}, {"_id": 0})
            # A locally queued echo is not proof. Require an actual provider ACK,
            # the preassigned message ID, correct session, and exact outbound body.
            if (echo and echo.get("direction") == "outbound"
                    and echo.get("is_demo") is False
                    and echo.get("session_id") == existing["gateway_session_id"]
                    and echo.get("body") == existing["message_body"]
                    and echo.get("provider_status") in (2, 3, 4, 5)):
                evidence, wamid = "linked_phone_ack", echo["wamid"]
                accepted_at = echo.get("created_at")

    if not wamid:
        return {"state": "unresolved", "evidence": None,
                "detail": "No reliable request-linked acceptance evidence yet. The reservation stays protected; no message was resent. Check Inbox or provider records. Matching text or elapsed time is not proof."}

    message = {"id": new_id(), "conversation_id": existing["conversation_id"],
               "wamid": wamid, "direction": "outbound", "type": "text",
               "body": existing["message_body"], "status": "sent", "is_demo": False,
               "sender": user["name"], "created_at": accepted_at or now_iso()}
    changed = await database.whatsapp_send_requests.update_one(
        {"id": existing["id"], "state": "sending"},
        {"$set": {"state": "accepted", "response": message,
                  "accepted_at": accepted_at or now_iso(), "recovery_evidence": evidence}})
    if not changed.matched_count:
        # Another checker or the original request finished concurrently.
        latest = await database.whatsapp_send_requests.find_one({"id": existing["id"]}, {"_id": 0})
        if latest and latest["state"] in ("accepted", "completed"):
            return await reconcile_send(latest, user, database, record_sent_message)
        return {"state": "unresolved", "evidence": None,
                "detail": "The request changed while checking. Check again; no message was resent."}
    # Acceptance remains durable even if Inbox persistence fails here.
    message = await record_sent_message(message, user, existing["id"])
    return {"state": "accepted", "evidence": evidence, "message": message}