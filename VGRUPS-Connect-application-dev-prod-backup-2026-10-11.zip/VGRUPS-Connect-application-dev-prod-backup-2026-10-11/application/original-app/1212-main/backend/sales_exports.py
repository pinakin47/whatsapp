"""Self-contained Excel/PDF downloads; no external service or persistent file."""
import io
from datetime import datetime
from xml.sax.saxutils import escape
from zipfile import ZIP_DEFLATED, ZipFile
from zoneinfo import ZoneInfo

HEADERS = ("Sale ID", "Date", "MR", "Customer", "Phone", "Product", "Quantity", "Unit Price", "Total", "Status")


def export_rows(sales):
    for sale in sales:
        date = datetime.fromisoformat(sale["created_at"]).astimezone(
            ZoneInfo("Asia/Kolkata")).strftime("%d/%m/%Y %H:%M")
        for item in sale["items"]:
            yield (sale["sale_id"], date, sale["mr_name"], sale["customer_name"], sale["phone"],
                   item["product_name"], item["quantity"], item["unit_price"], item["line_total"], sale["status"])


def export_xlsx(sales):
    # Inline string cells prevent spreadsheet formula injection.
    output = io.BytesIO()
    with ZipFile(output, "w", ZIP_DEFLATED) as archive:
        archive.writestr("[Content_Types].xml", '<?xml version="1.0"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>')
        archive.writestr("_rels/.rels", '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>')
        archive.writestr("xl/workbook.xml", '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Sales" sheetId="1" r:id="rId1"/></sheets></workbook>')
        archive.writestr("xl/_rels/workbook.xml.rels", '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>')
        sheet = ['<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>']
        for number, row in enumerate([HEADERS, *export_rows(sales)], 1):
            cells = []
            for index, value in enumerate(row):
                ref = chr(65 + index) + str(number)
                if isinstance(value, (int, float)):
                    cells.append(f'<c r="{ref}"><v>{value}</v></c>')
                else:
                    text = "".join(c for c in str(value or "") if c in "\t\n\r" or ord(c) >= 32)
                    cells.append(f'<c r="{ref}" t="inlineStr"><is><t xml:space="preserve">{escape(text)}</t></is></c>')
            sheet.append(f'<row r="{number}">{"".join(cells)}</row>')
        sheet.append('</sheetData></worksheet>')
        archive.writestr("xl/worksheets/sheet1.xml", "".join(sheet))
    return output.getvalue()


def export_pdf(sales, company):
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4, landscape
    from reportlab.lib.styles import getSampleStyleSheet
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, LongTable, TableStyle
    output = io.BytesIO()
    styles = getSampleStyleSheet()
    document = SimpleDocTemplate(output, pagesize=landscape(A4), rightMargin=20, leftMargin=20)
    content = [Paragraph(escape(company["name"]), styles["Heading1"]),
               Paragraph("Sales report — amounts in INR", styles["Normal"])]
    for key in ("address", "phone", "email"):
        if company.get(key):
            content.append(Paragraph(escape(company[key]), styles["Normal"]))
    content.append(Spacer(1, 12))
    cell_style = styles["BodyText"].clone("cell")
    cell_style.fontSize = 7
    cell_style.leading = 9
    rows = [[Paragraph(escape(h), cell_style) for h in HEADERS]]
    rows += [[Paragraph(escape(str(v)), cell_style) for v in row] for row in export_rows(sales)]
    table = LongTable(rows, repeatRows=1, colWidths=[100, 68, 70, 92, 77, 110, 35, 50, 60, 65])
    table.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#edf3e8")),
                              ("GRID", (0, 0), (-1, -1), .25, colors.lightgrey),
                              ("VALIGN", (0, 0), (-1, -1), "TOP")]))
    content.append(table)
    content.append(Spacer(1, 10))
    content.append(Paragraph(f"Grand total (all selected sales): INR {sum(s['grand_total'] for s in sales):,.2f}", styles["Heading2"]))
    document.build(content)
    return output.getvalue()
