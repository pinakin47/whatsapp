from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field, field_validator
import json
from pathlib import Path
from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo
from urllib.parse import urlparse
from typing import Literal

from db import db, now_iso
from auth import require_perm

router = APIRouter(prefix="/api", tags=["ivr"])

DEFAULT_IVR = json.loads((Path(__file__).resolve().parent.parent / "ivr-default.json").read_text())


class IVROption(BaseModel):
    label: str = Field(min_length=1, max_length=200)
    response: str = Field(default="", max_length=4000)
    handoff: bool = False
    action: str = Field(default="message", pattern=r"^(menu|message|catalogue|category|product_search|pricing|order|order_status|business|support|sales)$")
    category: str = Field(default="", max_length=100)
    options: list["IVROption"] = Field(default_factory=list, max_length=9)


class IVRIn(BaseModel):
    schema_version: Literal[2] = 2
    enabled: bool = False
    greeting: str = Field(min_length=1, max_length=4000)
    footer: str = Field(default="Reply with the number of your choice.", max_length=1000)
    options: list[IVROption] = Field(default_factory=list, min_length=1, max_length=9)
    catalogue_url: str = ""
    sales_contact: str = Field(default="", max_length=200)
    support_contact: str = Field(default="", max_length=200)
    human_handoff: bool = True
    whatsapp_template: str = Field(default="", max_length=200)

    @field_validator("catalogue_url")
    @classmethod
    def catalogue_link(cls, value):
        if value and (urlparse(value).scheme not in ("http", "https") or not urlparse(value).netloc):
            raise ValueError("Use a complete http or https catalogue URL, or leave it blank.")
        return value


def normalized_ivr(value):
    import copy
    result = {**copy.deepcopy(DEFAULT_IVR), **value}
    if value.get("schema_version") != 2:
        result["schema_version"] = 2
        result["options"] = copy.deepcopy(DEFAULT_IVR["options"])
    return result


@router.get("/ivr")
async def get_ivr(user: dict = Depends(require_perm("ivr", "view"))):
    import copy
    doc = await db.app_config.find_one({"key": "ivr"}, {"_id": 0})
    return normalized_ivr(doc["value"]) if doc else copy.deepcopy(DEFAULT_IVR)


@router.put("/ivr")
async def set_ivr(body: IVRIn, user: dict = Depends(require_perm("ivr", "manage"))):
    def check(nodes, depth=1):
        if depth > 4:
            raise HTTPException(422, "Submenus can be nested at most four levels.")
        for node in nodes:
            if not node.label.strip():
                raise HTTPException(422, "Enter a label for each menu option.")
            if node.action == "menu" and not node.options:
                raise HTTPException(422, "A menu needs at least one submenu option.")
            if node.options:
                check(node.options, depth + 1)
    check(body.options)
    value = body.model_dump()
    await db.app_config.update_one({"key": "ivr"},
        {"$set": {"key": "ivr", "value": value, "updated_at": now_iso()}}, upsert=True)
    return value


@router.get("/ivr/analytics")
async def ivr_analytics(period: str = "today", user=Depends(require_perm("reports", "view"))):
    if period not in ("today", "week", "month"):
        raise HTTPException(422, "Choose today, week or month.")
    current = datetime.now(ZoneInfo("Asia/Kolkata"))
    start = current.replace(hour=0, minute=0, second=0, microsecond=0)
    if period == "week":
        start -= timedelta(days=start.weekday())
    if period == "month":
        start = start.replace(day=1)
    start_iso = start.astimezone(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")
    rows = await db.ivr_events.find({"created_at": {"$gte": start_iso}}, {"_id": 0}).sort("created_at", -1).to_list(None)
    keys = ("conversations", "new_conversations", "product_enquiries", "catalogue_requests",
            "pricing_enquiries", "orders", "order_status_requests", "distributor_enquiries",
            "sales_enquiries", "support_requests", "human_handoffs")
    summary = dict.fromkeys(keys, 0)
    real = {"deleted": {"$ne": True}, "is_demo": {"$ne": True}}
    summary["conversations"] = await db.conversations.count_documents({
        **real, "last_message_at": {"$gte": start_iso}})
    summary["new_conversations"] = await db.conversations.count_documents({
        **real, "created_at": {"$gte": start_iso}})
    for row in rows:
        metric = row.get("metric")
        if metric in summary and metric not in ("conversations", "new_conversations"):
            summary[metric] += 1
        if row.get("handoff"):
            summary["human_handoffs"] += 1
    return {"period": period, "summary": summary, "items": rows[:500]}
