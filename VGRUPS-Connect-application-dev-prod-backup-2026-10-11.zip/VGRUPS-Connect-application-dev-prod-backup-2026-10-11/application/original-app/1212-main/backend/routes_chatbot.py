import copy
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from typing import Optional

from db import db, now_iso
from auth import require_perm

router = APIRouter(prefix="/api", tags=["chatbot"])

NODE_TYPES = ["message", "menu", "question", "action"]
ACTION_KINDS = ["create_lead", "add_tag", "handoff"]

DEFAULT_FLOW = {
    "enabled": False,
    "start": "welcome",
    "nodes": [
        {"id": "welcome", "type": "message", "text": "👋 Welcome to VGRUPS Healthcare!", "next": "menu"},
        {"id": "menu", "type": "menu", "text": "How can we help you today?",
         "options": [
             {"label": "Product pricing", "next": "ask_product"},
             {"label": "Download catalog", "next": "catalog"},
             {"label": "Talk to an agent", "next": "to_agent"},
         ]},
        {"id": "ask_product", "type": "question", "text": "Which product are you interested in?", "field": "product", "next": "ask_qty"},
        {"id": "ask_qty", "type": "question", "text": "Great! How many units do you need?", "field": "quantity", "next": "capture"},
        {"id": "capture", "type": "action", "action": {"kind": "create_lead"}, "next": "thanks"},
        {"id": "thanks", "type": "message", "text": "Thank you! 🙏 Our sales team will share pricing shortly.", "next": None},
        {"id": "catalog", "type": "message", "text": "Here is our catalog: https://vgrups.in/catalog 📦", "next": None},
        {"id": "to_agent", "type": "action", "action": {"kind": "handoff"},
         "text": "Connecting you to our team — a representative will reply here shortly. 🙋", "next": None},
    ],
}


class FlowOption(BaseModel):
    label: str
    next: Optional[str] = None


class FlowAction(BaseModel):
    kind: str = "create_lead"
    tag: Optional[str] = None


class FlowNode(BaseModel):
    id: str
    type: str
    text: Optional[str] = None
    next: Optional[str] = None
    field: Optional[str] = None
    options: list[FlowOption] = []
    action: Optional[FlowAction] = None


class FlowIn(BaseModel):
    enabled: bool = False
    start: str
    nodes: list[FlowNode] = []


@router.get("/chatbot/flow")
async def get_flow(user: dict = Depends(require_perm("chatbot", "view"))):
    doc = await db.app_config.find_one({"key": "chatbot_flow"}, {"_id": 0})
    return doc["value"] if doc else copy.deepcopy(DEFAULT_FLOW)


TEMPLATES = [
    {"key": "lead_capture", "name": "Lead Capture Bot",
     "description": "Greets visitors, offers a menu, captures product & quantity, and creates a CRM lead.",
     "start": DEFAULT_FLOW["start"], "nodes": DEFAULT_FLOW["nodes"]},
    {"key": "pricing_bot", "name": "Pricing Bot",
     "description": "Routes buyers by category, asks what they need, and queues a pricing follow-up.",
     "start": "pw", "nodes": [
         {"id": "pw", "type": "message", "text": "👋 Welcome to VGRUPS Healthcare! Let's get you the best price.", "next": "pmenu"},
         {"id": "pmenu", "type": "menu", "text": "What are you looking for?", "options": [
             {"label": "Disposables (gloves, masks)", "next": "pask"},
             {"label": "Supplements & vitamins", "next": "pask"},
             {"label": "Medical devices", "next": "pask"},
             {"label": "Talk to an agent", "next": "pagent"}]},
         {"id": "pask", "type": "question", "text": "Which product and quantity do you need?", "field": "product", "next": "pcap"},
         {"id": "pcap", "type": "action", "action": {"kind": "create_lead"}, "next": "pthanks"},
         {"id": "pthanks", "type": "message", "text": "Thank you! 🙏 Our team will WhatsApp you pricing shortly.", "next": None},
         {"id": "pagent", "type": "action", "action": {"kind": "handoff"}, "text": "Connecting you to our team now. 🙋", "next": None}]},
    {"key": "order_status", "name": "Order Status Bot",
     "description": "Asks for an order number and logs a status request for the team to follow up.",
     "start": "ow", "nodes": [
         {"id": "ow", "type": "message", "text": "📦 Order status — VGRUPS Healthcare", "next": "oask"},
         {"id": "oask", "type": "question", "text": "Please share your order number (e.g. VG20001).", "field": "order_no", "next": "ocap"},
         {"id": "ocap", "type": "action", "action": {"kind": "create_lead"}, "next": "odone"},
         {"id": "odone", "type": "message", "text": "Thanks! We'll update you on order {order_no} shortly. Type 'agent' to talk to us.", "next": None}]},
]


@router.get("/chatbot/templates")
async def list_templates(user: dict = Depends(require_perm("chatbot", "view"))):
    return {"items": copy.deepcopy(TEMPLATES)}


@router.put("/chatbot/flow")
async def set_flow(body: FlowIn, user: dict = Depends(require_perm("chatbot", "manage"))):
    ids = [n.id for n in body.nodes]
    if not body.nodes:
        raise HTTPException(status_code=422, detail="Add at least one node")
    if len(ids) != len(set(ids)):
        raise HTTPException(status_code=422, detail="Node IDs must be unique")
    if body.start not in ids:
        raise HTTPException(status_code=422, detail="Start node does not exist")
    valid = set(ids) | {None}
    for n in body.nodes:
        if n.type not in NODE_TYPES:
            raise HTTPException(status_code=422, detail=f"Invalid node type: {n.type}")
        if n.type == "menu" and not n.options:
            raise HTTPException(status_code=422, detail=f"Menu node '{n.id}' needs at least one option")
        if n.type == "action" and (not n.action or n.action.kind not in ACTION_KINDS):
            raise HTTPException(status_code=422, detail=f"Action node '{n.id}' needs a valid action kind")
        if n.next not in valid:
            raise HTTPException(status_code=422, detail=f"Node '{n.id}' points to a non-existent node")
        for o in (n.options or []):
            if o.next not in valid:
                raise HTTPException(status_code=422, detail=f"Menu option '{o.label}' points to a non-existent node")
    value = body.model_dump()
    await db.app_config.update_one({"key": "chatbot_flow"},
        {"$set": {"key": "chatbot_flow", "value": value, "updated_at": now_iso()}}, upsert=True)
    return value
