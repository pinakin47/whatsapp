"""Independent in-app alerts, truthful outbound states, and authenticated voice responses."""
import asyncio
import hashlib
import hmac
import json
import os
import time
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlparse, urlencode
from xml.sax.saxutils import escape
import httpx
from db import now_iso
from lead_capture_core import settings_for, REAL, event
from routes_mr_reporting import opted_out
from auth import permissions_for, refresh_role_definitions
import wa_client
from integrations import whatsapp_configured, send_whatsapp_text

_voice_cache = (0, False)


async def voice_proxy(action, payload=None):
    script = Path(__file__).resolve().parents[3] / "artifacts/api-server/twilio-voice-proxy.mjs"
    process = await asyncio.create_subprocess_exec("node", str(script), stdin=asyncio.subprocess.PIPE,
                                                  stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.DEVNULL)
    try:
        data, _ = await asyncio.wait_for(process.communicate(json.dumps({"action": action, "payload": payload}).encode()), 30)
        result = json.loads(data)
        if result.get("error"):
            raise RuntimeError("Twilio connection unavailable or acceptance unresolved")
        return result
    except BaseException:
        if process.returncode is None:
            process.kill()
            await process.wait()
        raise


async def voice_ready():
    global _voice_cache
    base = os.environ.get("LEAD_VOICE_CALLBACK_BASE_URL", "")
    if not os.environ.get("LEAD_VOICE_FROM_NUMBER") or not os.environ.get("SESSION_SECRET") or urlparse(base).scheme != "https":
        return False
    if time.monotonic() - _voice_cache[0] > 60:
        try:
            ready = bool((await voice_proxy("status")).get("ready"))
        except Exception:
            ready = False
        _voice_cache = (time.monotonic(), ready)
    return _voice_cache[1]


def voice_token(request_id, expires):
    key = os.environ.get("SESSION_SECRET")
    if not key:
        raise RuntimeError("Voice callback signing is unavailable")
    return hmac.new(key.encode(), f"lead:{request_id}:{expires}".encode(), hashlib.sha256).hexdigest()


def valid_voice_token(request_id, expires, token):
    try:
        return int(expires) >= int(time.time()) and hmac.compare_digest(token, voice_token(request_id, expires))
    except (ValueError, RuntimeError):
        return False


async def deliver_request(database, row):
    if row.get("status") not in ("pending", "blocked_not_connected", "blocked_template_required", "disabled"):
        return
    config = await settings_for(database)
    if not config["enabled"] or not config["authorized_messages_confirmed"]:
        return
    channel = row["channel"]
    toggle = "ask_missing_phone" if channel == "whatsapp" else "voice_enabled"
    if not config[toggle]:
        return
    await refresh_role_definitions()
    approver = await database.users.find_one({"id": config.get("approved_by"), "active": {"$ne": False}, **REAL})
    if not approver or approver["role"] not in ("admin", "super_admin", "sales_manager") or "manage" not in permissions_for(approver["role"]).get("settings", []):
        return
    mr = await database.mr_directory.find_one({"id": row["mr_directory_id"], "active": True, **REAL})
    lead = await database.leads.find_one({"id": row["lead_id"], **REAL})
    if not mr or not lead or lead.get("mobile") or lead.get("status") == "lost" or lead.get("assigned_to") != row["mr_id"] or row.get("resolution") == "completed":
        await database.mr_lead_requests.update_one({"id": row["id"], "status": row["status"]}, {"$set": {"status": "cancelled"}})
        return
    if await opted_out(mr["phone"]):
        await database.mr_lead_requests.update_one({"id": row["id"], "status": row["status"]}, {"$set": {"status": "cancelled", "error": "MR opted out"}})
        return
    session = None
    if channel == "voice":
        if not await voice_ready():
            await database.mr_lead_requests.update_one({"id": row["id"]}, {"$set": {
                "status": "blocked_not_connected", "error": "Awaiting Twilio connection, calling number and HTTPS callback URL",
                "next_attempt_at": time.time() + 300}})
            return
    else:
        from whatsapp_routing import sender_or_none, qr_configured
        session = await sender_or_none(database, purpose="mr")
        if not session and (await qr_configured(database, purpose="mr") or not whatsapp_configured()):
            await database.mr_lead_requests.update_one({"id": row["id"]}, {"$set": {
                "status": "pending", "error": "Assigned MR WhatsApp number is offline or unconfigured; no other number used",
                "next_attempt_at": time.time() + 60}})
            return
        if not session:
            conversations = await database.conversations.find({"phone": {"$in": [mr["phone"], mr["phone"].lstrip("+")]}, **REAL}).to_list(10)
            incoming = await database.messages.find({"conversation_id": {"$in": [c["id"] for c in conversations]}, "direction": "inbound"}).sort("created_at", -1).to_list(1)
            try:
                received = datetime.fromisoformat(incoming[0]["created_at"].replace("Z", "+00:00")) if incoming else None
                if received is not None and received.tzinfo is None:
                    received = received.replace(tzinfo=timezone.utc)
                window_open = received is not None and 0 <= time.time() - received.timestamp() < 86400
            except (KeyError, ValueError, TypeError):
                window_open = False
            if not window_open:
                await database.mr_lead_requests.update_one({"id": row["id"]}, {"$set": {
                    "status": "blocked_template_required", "error": "Cloud API requires an approved template outside the 24-hour window; no send attempted",
                    "next_attempt_at": time.time() + 300}})
                return
    # Provider-independent durable reservation. Never expire an uncertain attempt into a resend.
    claim = await database.mr_lead_requests.update_one({"id": row["id"], "status": row["status"]},
                                                       {"$set": {"status": "sending", "attempted_at": now_iso()}})
    if not claim.modified_count:
        return
    try:
        latest = await settings_for(database)
        target = await database.mr_directory.find_one({"id": row["mr_directory_id"], "active": True, **REAL})
        current_lead = await database.leads.find_one({"id": row["lead_id"], **REAL})
        actor = await database.users.find_one({"id": latest.get("approved_by"), "active": {"$ne": False}, **REAL})
        if not latest["enabled"] or not latest[toggle] or not latest["authorized_messages_confirmed"] or \
                not actor or actor["role"] not in ("admin", "super_admin", "sales_manager") or \
                "manage" not in permissions_for(actor["role"]).get("settings", []) or \
                not target or target["phone"] != mr["phone"] or not current_lead or current_lead.get("mobile") or \
                current_lead.get("assigned_to") != row["mr_id"] or await opted_out(target["phone"]):
            raise RuntimeError("Send authorization changed")
        if channel == "voice":
            expires = int(time.time()) + 3600
            token = voice_token(row["id"], expires)
            callback = os.environ["LEAD_VOICE_CALLBACK_BASE_URL"].rstrip("/") + "/api/lead-capture/voice/" + row["id"]
            callback += "?" + urlencode({"expires": expires, "token": token})
            customer = escape(lead.get("contact_name") or lead.get("doctor_name") or "the customer")
            organization = escape(lead.get("company") or lead.get("title") or "your WhatsApp enquiry")
            identifier = escape(lead.get("display_id", lead["id"]))
            twiml = f'<Response><Gather input="dtmf" numDigits="10" timeout="15" method="POST" action="{escape(callback, {chr(34): "&quot;"})}"><Say>Hello {escape(mr["name"])}. Phone number missing for {customer} at {organization}. Lead {identifier}. Please enter the ten digit Indian mobile number.</Say></Gather><Say>No number received. Please respond on WhatsApp with the lead ID and phone number.</Say></Response>'
            result = await voice_proxy("call", {"To": mr["phone"], "From": os.environ["LEAD_VOICE_FROM_NUMBER"], "Twiml": twiml})
            accepted = result.get("sid")
        elif session:
            # The QR gateway requires the same durable reservation as other sends.
            conversation = await database.conversations.find_one({"phone": mr["phone"].lstrip("+"), "session_id": session["id"], **REAL})
            if not conversation:
                from db import new_id
                conversation = {"id": new_id(), "phone": mr["phone"].lstrip("+"), "name": mr["name"],
                                "session_id": session["id"], "is_demo": False, "created_at": now_iso()}
                await database.conversations.insert_one(conversation)
            await database.whatsapp_send_requests.update_one({"id": row["id"]}, {"$setOnInsert": {
                "id": row["id"], "state": "sending", "provider": "qr", "recipient_address": mr["phone"],
                "message_body": row["body"], "gateway_message_id": None, "source": "lead_capture",
                "conversation_id": conversation["id"], "created_at": now_iso(),
            }}, upsert=True)
            result = await wa_client.wa_send(mr["phone"], row["body"], request_id=row["id"], session_id=session["id"])
            accepted = result.get("wamid")
        else:
            result = await send_whatsapp_text(mr["phone"], row["body"])
            accepted = (result.get("messages") or [{}])[0].get("id")
        if not accepted:
            raise RuntimeError("Acceptance unresolved")
        await database.mr_lead_requests.update_one({"id": row["id"]}, {"$set": {
            "status": "accepted", "provider_id": accepted, "accepted_at": now_iso(), "error": None}})
        if channel == "whatsapp" and session:
            await database.whatsapp_send_requests.update_one({"id": row["id"]}, {"$set": {"state": "accepted", "provider_id": accepted}})
        await event(database, lead["id"], row["id"], "MR Request Accepted", f"{channel}: provider accepted, not a delivery confirmation")
        if channel == "whatsapp":
            # Persist in the MR Inbox, without feeding our own prompt back into extraction.
            from db import new_id
            conversation = await database.conversations.find_one({"phone": mr["phone"].lstrip("+"), "session_id": (session or {}).get("id"), **REAL})
            if not conversation:
                conversation = {"id": new_id(), "phone": mr["phone"].lstrip("+"), "name": mr["name"],
                                "session_id": (session or {}).get("id"), "is_demo": False, "created_at": now_iso()}
                await database.conversations.insert_one(conversation)
            await database.messages.update_one({"wamid": accepted}, {"$setOnInsert": {
                "id": row["id"], "wamid": accepted, "conversation_id": conversation["id"], "direction": "outbound",
                "body": row["body"], "type": "text", "sender": "Lead capture", "capture_skip": True,
                "status": "sent", "is_demo": False, "session_id": (session or {}).get("id"), "created_at": now_iso(),
            }, "$set": {"sender": "Lead capture", "capture_skip": True}}, upsert=True)
            await database.messages.update_one({"wamid": accepted, "status": {"$in": ["sending", None]}},
                {"$set": {"status": "sent"}})
            await database.mr_lead_requests.update_one({"id": row["id"]}, {"$set": {"conversation_id": conversation["id"]}})
    except Exception:
        if channel == "whatsapp" and session:
            await database.whatsapp_send_requests.update_one({"id": row["id"]}, {"$set": {"state": "uncertain"}})
        await database.mr_lead_requests.update_one({"id": row["id"], "status": "sending"}, {"$set": {
            "status": "uncertain", "error": "Acceptance unresolved or authorization changed. No automatic resend; verify provider/Inbox first."}})
        await event(database, lead["id"], row["id"], "MR Request Needs Review", "No automatic resend of an uncertain provider outcome")
