"""Email OTP sign-in: delivered challenges only, bounded attempts, atomic consumption."""
import secrets
import logging
from datetime import datetime, timedelta

from fastapi import HTTPException
from pydantic import EmailStr, TypeAdapter, ValidationError

from auth import (
    PUBLIC_DEFAULT_ADMIN_PASSWORDS, _client_ip, _hash_code,
    create_access_token, is_production, public_user, verify_password,
)
from db import db, log_audit, new_id, now_iso, utcnow
from integrations import integration_status, send_email_otp
from postgres_store import ReturnDocument

SEND_MESSAGE = "If this email is registered, a sign-in code has been sent."
INVALID_CODE = "Invalid or expired sign-in code. Request a new code."
logger = logging.getLogger("vgrups.otp")


def normalize_email(value):
    try:
        return str(TypeAdapter(EmailStr).validate_python(value.strip())).lower()
    except ValidationError:
        raise HTTPException(status_code=422, detail="Enter a valid email address.")


def allowed_user(user):
    if not user or not user.get("active", True):
        return False
    if is_production():
        if user.get("is_demo", False):
            return False
        if any(verify_password(p, user.get("password_hash", "")) for p in PUBLIC_DEFAULT_ADMIN_PASSWORDS):
            return False
    return True


async def reserve_send_budget(email, request):
    now = utcnow()
    await db.otp_rate_limits.delete_many({"expires_at": {"$lt": now.isoformat()}})
    for key, seconds, limit in (
        (f"ip:{_client_ip(request)}", 900, 20),
        (f"email:{email}", 900, 5),
        (f"resend:{email}", 30, 1),
    ):
        bucket = int(now.timestamp()) // seconds
        record = await db.otp_rate_limits.find_one_and_update(
            {"identifier": f"{key}:{bucket}"},
            {"$inc": {"count": 1}, "$setOnInsert": {
                "id": new_id(), "expires_at": (now + timedelta(seconds=seconds * 2)).isoformat(),
            }},
            upsert=True, return_document=ReturnDocument.AFTER,
        )
        if record["count"] > limit:
            raise HTTPException(status_code=429, detail="Too many code requests. Please wait before trying again.")


async def send_login_otp(body, request):
    email = normalize_email(body.identifier)
    if not integration_status()["brevo"]["configured"]:
        raise HTTPException(status_code=503, detail="Email OTP delivery is not configured.")
    await reserve_send_budget(email, request)
    challenge_id = new_id()
    response = {
        "ok": True, "demo_mode": False, "channel": "email",
        "otp_id": challenge_id, "expires_in": 300, "message": SEND_MESSAGE,
    }
    user = await db.users.find_one({"email": email})
    if not allowed_user(user):
        logger.info("Email OTP request skipped: no eligible account (challenge %s)", challenge_id)
        return response
    recent = await db.otp_requests.find_one(
        {"identifier": email, "login_method": "email_otp"}, sort=[("created_at", -1)],
    )
    if recent and (utcnow() - datetime.fromisoformat(recent["created_at"])).total_seconds() < 30:
        raise HTTPException(status_code=429, detail="Please wait 30 seconds before requesting another code.")
    code = f"{secrets.randbelow(1_000_000):06d}"
    await db.otp_requests.insert_one({
        "id": challenge_id, "identifier": email, "user_id": user["id"],
        "purpose": "login", "channel": "email", "login_method": "email_otp",
        "code_hash": _hash_code(code), "expires_at": (utcnow() + timedelta(minutes=5)).isoformat(),
        "verified": False, "delivered": False, "attempts": 0, "created_at": now_iso(),
    })
    try:
        await send_email_otp(email, code)
    except Exception as error:
        # Delivery errors are sanitized by the provider bridge; never log OTPs.
        reason = str(error) if isinstance(error, RuntimeError) else type(error).__name__
        logger.warning("Email OTP provider failure (challenge %s): %s", challenge_id, reason)
        await db.otp_requests.delete_one({"id": challenge_id})
        raise HTTPException(status_code=502, detail="Unable to send the sign-in email. Please try again later.")
    await db.otp_requests.update_many(
        {"identifier": email, "login_method": "email_otp", "verified": False, "id": {"$ne": challenge_id}},
        {"$set": {"verified": True}},
    )
    await db.otp_requests.update_one({"id": challenge_id}, {"$set": {"delivered": True}})
    await log_audit(None, "send_otp", "settings", ip=_client_ip(request), detail="email sign-in code sent")
    return response


async def verify_login_otp(body, request):
    email = normalize_email(body.identifier)
    if not body.otp_id:
        raise HTTPException(status_code=400, detail=INVALID_CODE)
    rec = await db.otp_requests.find_one_and_update(
        {
            "id": body.otp_id, "identifier": email, "purpose": "login",
            "login_method": "email_otp", "verified": False, "delivered": True,
            "expires_at": {"$gt": now_iso()}, "attempts": {"$lt": 5},
        },
        {"$inc": {"attempts": 1}}, return_document=ReturnDocument.AFTER,
    )
    if not rec or not secrets.compare_digest(rec["code_hash"], _hash_code(body.code)):
        raise HTTPException(status_code=400, detail=INVALID_CODE)
    user = await db.users.find_one({"id": rec["user_id"], "email": email})
    consumed = await db.otp_requests.find_one_and_update(
        {"id": rec["id"], "verified": False, "delivered": True, "expires_at": {"$gt": now_iso()}},
        {"$set": {"verified": True}}, return_document=ReturnDocument.AFTER,
    )
    if not consumed or not allowed_user(user):
        raise HTTPException(status_code=400, detail=INVALID_CODE)
    await log_audit(user, "login_otp", "settings", user["id"], ip=_client_ip(request))
    return {
        "ok": True, "verified": True,
        "token": create_access_token(user["id"], email, user["role"]), "user": public_user(user),
    }