"""Provider-independent lead ingestion and immutable evidence. Callers supply the database."""
import hashlib
import re
from difflib import SequenceMatcher
from datetime import datetime
from db import now_iso
from lead_capture_extract import extract_information, mobile, phones, TEXT_FIELDS, IST, PHONE_PATTERN
from auth import permissions_for

REAL = {"deleted": {"$ne": True}, "is_demo": {"$ne": True}}
MANAGERS = ("admin", "super_admin", "sales_manager")
DEFAULT_SETTINGS = {"enabled": False, "authorized_messages_confirmed": False,
                    "ask_missing_phone": False, "voice_enabled": False, "enabled_since": None,
                    "ai_auto_reply": False, "ai_reply_enabled_since": None}


def stable(*parts):
    return hashlib.sha256(":".join(str(p) for p in parts).encode()).hexdigest()


def normalized(value):
    return "".join(c for c in str(value or "").casefold() if c.isalnum())


async def settings_for(database):
    row = await database.app_config.find_one({"key": "mr_lead_capture"}) or {}
    return {**DEFAULT_SETTINGS, **row.get("value", {})}


async def directory_account(database, row):
    account = await database.users.find_one({"email": row["email"].lower(), "role": "mr", "active": {"$ne": False}, **REAL})
    return {**row, "mr_id": (account or {}).get("id", f"directory:{row['id']}")}


async def resolve_message_mr(database, conversation, message):
    from whatsapp_routing import mr_session_allowed
    if not await mr_session_allowed(database, message.get("session_id") or conversation.get("session_id")):
        return None, False
    phone = re.sub(r"\D", "", conversation.get("phone", ""))
    candidates = await database.mr_directory.find({"active": True, **REAL}).to_list(None)
    mrs = [await directory_account(database, row) for row in candidates]
    number_for = lambda mr: re.sub(r"\D", "", mr.get("phone", ""))
    if message.get("direction") == "inbound":
        for mr in mrs:
            if number_for(mr) == phone:
                return mr, True
    if message.get("direction") == "outbound":
        for mr in mrs:
            if message.get("sender_user_id") == mr["mr_id"]:
                return mr, number_for(mr) == phone
    for mr in mrs:
        if conversation.get("assigned_to") in (mr["mr_id"], mr["id"]):
            return mr, number_for(mr) == phone
    for mr in mrs:
        if message.get("account_phone") and re.sub(r"\D", "", message["account_phone"]) == number_for(mr):
            return mr, number_for(mr) == phone
    for mr in mrs:
        if number_for(mr) == phone:
            return mr, True
    return None, False


async def enqueue_message(database, message):
    config = await settings_for(database)
    if not config["enabled"] or not config["authorized_messages_confirmed"]:
        return
    if message.get("type") != "text" or message.get("is_demo") or not message.get("body"):
        return
    if not message.get("session_id") and message.get("authorized_provider") != "meta":
        return
    if message.get("created_at", "") < (config.get("enabled_since") or now_iso()):
        return
    if message.get("capture_skip") or (message.get("direction") == "outbound" and
            (message.get("sender") or "").startswith(("MR AI", "MR IVR", "MR field", "MR reporting", "MR coaching", "Lead capture", "IVR", "Chatbot"))):
        return
    key = stable("message", message.get("wamid") or message["id"])
    await database.mr_lead_queue.update_one({"id": key}, {"$setOnInsert": {
        "id": key, "message_id": message["id"], "conversation_id": message["conversation_id"],
        "status": "pending", "attempts": 0, "created_at": now_iso(),
    }}, upsert=True)


async def safe_enqueue_message(database, message):
    try:
        await enqueue_message(database, message)
    except Exception:
        import logging
        logging.getLogger("vgrups.lead_capture").error("Lead queue write failed; saved WhatsApp evidence will be reconciled. Existing MR menu/send flow remains independent.")


async def event(database, lead_id, key, name, detail="", actor_id="system"):
    await database.mr_lead_events.update_one({"id": stable(lead_id, key, name)}, {"$setOnInsert": {
        "id": stable(lead_id, key, name), "lead_id": lead_id, "event": name, "detail": detail,
        "actor_id": actor_id, "created_at": now_iso(),
    }}, upsert=True)


async def activity(database, lead, message, mr, extracted, key):
    await database.mr_lead_activities.update_one({"id": key}, {"$setOnInsert": {
        "id": key, "lead_id": lead["id"], "display_id": lead.get("display_id", lead["id"]),
        "message_id": message["id"], "conversation_id": message["conversation_id"],
        "body": message["body"], "direction": message["direction"], "sender": message.get("sender", ""),
        "mr_id": mr["mr_id"], "mr_directory_id": mr["id"], "mr_name": mr["name"],
        "extracted": extracted, "created_at": message["created_at"],
    }}, upsert=True)
    await event(database, lead["id"], key, "WhatsApp Message Received", "Original message retained with extraction evidence")
    await event(database, lead["id"], key, "Information Extracted", "Confidence " + str(extracted.get("confidence", 1)))


async def notify_admins(database, lead, key, name):
    # Individual durable alerts; a missing Admin account never prevents Super Admin alerts.
    users = await database.users.find({"role": {"$in": ["admin", "super_admin"]}, "active": {"$ne": False}, **REAL}).to_list(None)
    for user in users:
        if "view" not in permissions_for(user["role"]).get("leads", []):
            continue
        ident = stable(key, user["id"], name)
        body = (f"MR: {lead.get('mr_name', 'Not assigned')}\nCustomer: {lead.get('contact_name') or lead.get('doctor_name') or '-'}\n"
                f"Hospital/customer: {lead.get('company') or lead.get('title')}\nPhone: {lead.get('mobile') or 'Not available'}\n"
                f"Location: {lead.get('location') or 'Not recorded'}\nRequirement: {lead.get('requirement') or '-'}\n"
                f"Source: {lead.get('source')}\nStatus: {lead.get('capture_status') or lead.get('status')}")
        await database.mr_lead_notifications.update_one({"id": ident}, {"$setOnInsert": {
            "id": ident, "user_id": user["id"], "role": user["role"], "lead_id": lead["id"],
            "display_id": lead.get("display_id", lead["id"]), "title": name, "body": body,
            "read": False, "status": "available", "created_at": now_iso(),
        }}, upsert=True)
        await event(database, lead["id"], ident, user["role"].replace("_", " ").title() + " Notified", "In-app notification available", user["id"])


def company_for(data):
    return next((data.get(k) for k in ("hospital_name", "clinic_name", "pharmacy_name", "distributor_name", "institution_name") if data.get(k)), None)


async def match_lead(database, data, conversation, mr):
    phone = data.get("mobile")
    if phone:
        digits = phone[3:]
        pattern = r"^(?:\+?91[\s().-]*)?" + r"[\s().-]*".join(digits) + r"$"
        found = await database.leads.find_one({"mobile": {"$regex": pattern}, **REAL})
        if found:
            return found
    # A forwarded MR report can mention multiple different prospects: never match its chat blindly.
    if not conversation.get("_direct_mr"):
        linked = await database.leads.find({"conversation_id": conversation["id"], **REAL}).to_list(3)
        if len(linked) == 1:
            candidate = linked[0]
            if not company_for(data) or normalized(company_for(data)) == normalized(candidate.get("company")):
                return candidate
    company, person = company_for(data), data.get("contact_name") or data.get("doctor_name")
    if company or person:
        q = {**REAL}
        if company:
            q["company"] = {"$regex": "^" + re.escape(company) + "$", "$options": "i"}
        elif person:
            q["contact_name"] = {"$regex": "^" + re.escape(person) + "$", "$options": "i"}
        candidates = await database.leads.find(q).to_list(100)
        for candidate in candidates:
            cperson = candidate.get("contact_name") or candidate.get("doctor_name")
            if data.get("location") and candidate.get("location") and normalized(data["location"]) != normalized(candidate["location"]):
                continue
            if person and cperson and normalized(person) != normalized(cperson):
                continue
            if company and normalized(company) != normalized(candidate.get("company")):
                continue
            return candidate
        if company and person:
            # Conservative fuzzy identity match requires BOTH organization and person.
            for candidate in await database.leads.find({**REAL, "contact_name": {"$regex": "^" + re.escape(person) + "$", "$options": "i"}}).to_list(100):
                if data.get("location") and candidate.get("location") and normalized(data["location"]) != normalized(candidate["location"]):
                    continue
                if SequenceMatcher(None, normalized(company), normalized(candidate.get("company"))).ratio() >= .92:
                    return candidate
    return None


async def complete_phone(database, lead, number, mr, message=None, key=None):
    if lead.get("assigned_to") != mr["mr_id"]:
        raise ValueError("This lead belongs to another MR")
    number = mobile(number)
    if not number:
        raise ValueError("Enter a valid Indian mobile number")
    other = await match_lead(database, {"mobile": number}, {"id": "", "_direct_mr": True}, mr)
    if other and other["id"] != lead["id"]:
        raise ValueError("Phone matches another lead; administrator review is required before merging")
    key = key or stable(lead["id"], number)
    await database.leads.update_one({"id": lead["id"]}, {"$set": {
        "mobile": number, "capture_status": "Lead Captured", "updated_at": now_iso(), "last_contact_at": now_iso(),
    }})
    await database.mr_lead_requests.update_many({"lead_id": lead["id"], "purpose": "missing_phone"}, {"$set": {"resolution": "completed", "resolved_at": now_iso()}})
    updated = await database.leads.find_one({"id": lead["id"]})
    await event(database, lead["id"], key, "Phone Number Received", number, mr["mr_id"])
    if message:
        await activity(database, updated, message, mr, {"mobile": number, "confidence": 1}, key)
    await notify_admins(database, updated, key, "PHONE NUMBER RECEIVED")
    return updated


async def queue_phone_requests(database, lead, mr, conversation=None):
    config = await settings_for(database)
    if not lead.get("mobile"):
        await database.leads.update_one({"id": lead["id"]}, {"$set": {"capture_status": "Phone Number Required"}})
    for channel in ("whatsapp", "voice"):
        key = stable(lead["id"], mr["mr_id"], "missing_phone", channel, lead.get("phone_request_version", 0))
        enabled = config["ask_missing_phone"] if channel == "whatsapp" else config["voice_enabled"]
        await database.mr_lead_requests.update_one({"id": key}, {"$setOnInsert": {
            "id": key, "lead_id": lead["id"], "display_id": lead.get("display_id", lead["id"]),
            "mr_id": mr["mr_id"], "mr_directory_id": mr["id"], "mr_name": mr["name"], "mr_phone": mr["phone"],
            "channel": channel, "purpose": "missing_phone", "resolution": "pending",
            "status": "pending" if enabled else "disabled", "conversation_id": (conversation or {}).get("id"),
            "body": f"Lead information received.\nLead: {lead.get('display_id', lead['id'])}\nHospital/Customer: {lead.get('company') or lead.get('title')}\nRequirement: {lead.get('requirement') or '-'}\nPhone number is missing. Reply LEAD {lead.get('display_id', lead['id'])} followed by the customer's Indian mobile number. If no MR menu draft is open, you may reply with just the number.",
            "created_at": now_iso(), "attempts": 0,
        }}, upsert=True)
        # Explicitly re-enabling a disabled channel is safe: no provider attempt has occurred.
        if enabled:
            await database.mr_lead_requests.update_one({"id": key, "status": "disabled"}, {"$set": {"status": "pending"}})
        await event(database, lead["id"], key, "MR Requested", f"{channel} request queued" if enabled else f"{channel} request disabled; no notification claimed")


async def ingest(database, job, extractor=extract_information, verified_fields=None):
    message = await database.messages.find_one({"id": job["message_id"]})
    conversation = await database.conversations.find_one({"id": job["conversation_id"], **REAL})
    if not message or not conversation:
        return {"status": "skipped", "error": "Message or authorized conversation unavailable"}
    mr, direct = await resolve_message_mr(database, conversation, message)
    if not mr:
        return {"status": "skipped", "error": "No identifiable active MR"}
    # Never extract the system's own prompts or MR bot replies.
    if message.get("capture_skip") or (message["direction"] == "outbound" and
            (message.get("sender") or "").startswith(("MR AI", "MR IVR", "MR field", "MR reporting", "MR coaching", "Lead capture", "IVR", "Chatbot"))):
        return {"status": "skipped", "mr_name": mr["name"]}
    if message["direction"] == "outbound" and await database.mr_lead_requests.find_one({"body": message.get("body"), "mr_id": mr["mr_id"]}):
        return {"status": "skipped", "mr_name": mr["name"]}
    if not message.get("session_id") and message.get("authorized_provider") != "meta":
        return {"status": "skipped", "error": "Provider authorization cannot be established"}
    text = message["body"].strip()
    base_result = {"mr_id": mr["mr_id"], "mr_directory_id": mr["id"], "mr_name": mr["name"], "body": text}
    conversation = {**conversation, "_direct_mr": direct}
    explicit = re.fullmatch(r"LEAD\s+(\S+)\s+([\d+\s()-]+)", text, re.I)
    bare = mobile(text) if re.fullmatch(r"[\d+\s()-]+", text) else None
    phone_note = None
    if re.search(r"[A-Za-z]", text) and len(phones(text)) == 1 and re.fullmatch(
            r"(?:(?:his|her|their|customer(?:'s)?|doctor(?:'s)?)\s+)?(?:(?:phone|mobile|contact)\s*)?(?:number\s*)?(?:is\s*|[:=-]\s*)?<PHONE>[.!]?",
            PHONE_PATTERN.sub("<PHONE>", text), re.I):
        phone_note = phones(text)[0]
    self_reply = direct and normalized(message.get("account_phone")) == normalized(mr["phone"])
    quoted = await database.mr_lead_requests.find_one({"provider_id": message["reply_to_wamid"], "mr_id": mr["mr_id"], "channel": "whatsapp"}) if message.get("reply_to_wamid") else None
    if direct and (message["direction"] == "inbound" or self_reply) and (explicit or bare or phone_note):
        drafts = conversation.get("mr_field_state") or {}
        legacy = conversation.get("mr_ivr") or {}
        blocked = drafts.get("step", "menu") != "menu" or legacy.get("field", "menu") != "menu"
        if explicit or phone_note or quoted or not blocked:
            query = {"assigned_to": mr["mr_id"], "capture_status": "Phone Number Required", **REAL}
            if explicit:
                query["$or"] = [{"display_id": {"$regex": "^" + re.escape(explicit[1]) + "$", "$options": "i"}}, {"id": explicit[1]}]
            elif quoted:
                query["id"] = quoted["lead_id"]
            pending = await database.leads.find(query).to_list(3)
            if len(pending) == 1:
                try:
                    lead = await complete_phone(database, pending[0], explicit[2] if explicit else (bare or phone_note), mr, message, job["id"])
                    return {**base_result, "status": "completed", "lead_id": lead["id"]}
                except ValueError as error:
                    return {**base_result, "status": "needs_verification", "error": str(error)}
            if pending:
                return {**base_result, "status": "needs_verification", "error": "Several pending leads; reply LEAD <Lead ID> <mobile> to identify one"}
    if len(text) < 12 or sum(c.isalpha() for c in text) < 3 or re.fullmatch(r"(start|field|day visit|closing|pending|plan|status|help|resume|cancel|thanks|thank you|ok)", text, re.I):
        return {**base_result, "status": "skipped"}
    context = ""
    previous = await database.mr_lead_activities.find({"conversation_id": conversation["id"], "mr_id": mr["mr_id"]}).sort("created_at", -1).to_list(5)
    if (not direct or re.match(r"^(his|her|their|he|she|they|same|this|that)\b", text, re.I)) and len({p["lead_id"] for p in previous}) == 1:
        context = "\n".join(p["body"] for p in reversed(previous))[:4000]
    try:
        data = await extractor(text, context)
    except Exception:
        return {**base_result, "status": "ai_extraction_failed", "error": "AI extraction failed; original message is retained and may be retried"}
    if not data.get("is_business"):
        return {**base_result, "status": "skipped", "extracted": data}
    if direct and verified_fields is None:
        customer_phones = [p for p in phones(text + "\n" + context) if p != mobile(mr["phone"])]
        data["mobile"] = customer_phones[0] if customer_phones else None
        data["alternative_phone"] = customer_phones[1] if len(customer_phones) > 1 else None
    # A real customer's WhatsApp address is provider evidence, not AI invention.
    # Direct MR reports must NEVER use the MR's own phone as the customer's phone.
    if not direct and not data.get("mobile"):
        data["mobile"] = mobile(conversation.get("phone"))
        if data["mobile"]:
            data["phone_provenance"] = "Authorized customer WhatsApp address"
    identity = company_for(data) or data.get("contact_name") or data.get("doctor_name")
    if not ((identity and (data.get("mobile") or data.get("requirement"))) or (data.get("mobile") and data.get("requirement"))):
        return {**base_result, "status": "needs_verification", "extracted": data, "error": "Insufficient grounded lead information"}
    existing = None
    if verified_fields is not None and job.get("lead_id") and job.get("status") == "needs_verification":
        existing = await database.leads.find_one({"id": job["lead_id"], **REAL})
        if existing and data.get("mobile"):
            collision = await match_lead(database, {"mobile": data["mobile"]}, {"id": "", "_direct_mr": True}, mr)
            if collision and collision["id"] != existing["id"]:
                return {**base_result, "status": "needs_verification", "error": "Phone belongs to another lead; resolve the duplicate before approval"}
    if not existing:
        existing = await match_lead(database, data, conversation, mr)
    if data.get("confidence", 0) < .55:
        return {**base_result, "status": "needs_verification", "extracted": data, "error": "Low confidence; existing information was not changed"}
    if existing and existing.get("assigned_to") not in (None, mr["mr_id"]):
        # Global deduplication must not grant an MR write access to another MR's record.
        await notify_admins(database, existing, job["id"], "DUPLICATE LEAD REQUIRES OWNERSHIP REVIEW")
        return {**base_result, "status": "ownership_conflict", "extracted": data,
                "lead_id": existing["id"], "error": "Existing lead belongs to another owner; no duplicate or overwrite created"}
    company = company_for(data)
    now = now_iso()
    if not existing:
        year = datetime.now(IST).year
        await database.mr_lead_counters.update_one({"id": str(year)}, {"$inc": {"value": 1}}, upsert=True)
        counter = await database.mr_lead_counters.find_one({"id": str(year)})
        lid = stable("lead", job["id"])
        lead = {
            "id": lid, "display_id": f"WHL-{year}-{counter['value']:04d}", "title": company or identity or data["mobile"],
            "company": company, **{k: data.get(k) for k in TEXT_FIELDS},
            "contact_name": data.get("contact_name") or data.get("doctor_name"),
            "mobile": data.get("mobile"), "alternative_phone": data.get("alternative_phone"),
            "whatsapp_number": "+" + re.sub(r"\D", "", conversation["phone"]) if not direct else None,
            "lead_type": data.get("lead_type", "Other"), "status": "new", "priority": data.get("priority", "normal"),
            "capture_status": "Lead Captured" if data.get("mobile") else "Phone Number Required",
            "verification_status": "Verified extraction" if data["confidence"] >= .85 else "Needs Verification",
            "source": "WhatsApp – MR", "mr_id": mr["mr_id"], "mr_directory_id": mr["id"],
            "mr_name": mr["name"], "employee_id": mr["employee_id"], "assigned_to": mr["mr_id"],
            "conversation_id": conversation["id"], "original_message": text, "ai_extracted": data,
            "confidence": data["confidence"], "next_followup_at": data.get("next_followup_at"),
            "created_by": mr["mr_id"], "created_at": now, "updated_at": now, "last_contact_at": now,
            "date": datetime.now(IST).date().isoformat(), "time": datetime.now(IST).strftime("%H:%M:%S"),
            "is_demo": False, "deleted": False, "value": 0, "admin_remarks": "", "notes": text,
        }
        await database.leads.update_one({"id": lid}, {"$setOnInsert": lead}, upsert=True)
        await event(database, lid, job["id"], "Lead Created", "Automatically captured from an authorized WhatsApp message")
        changed = True
    else:
        lead = existing
        patch = {}
        # Preserve populated/admin-corrected facts. Conflicting facts remain in evidence for review.
        for key in (*TEXT_FIELDS, "mobile", "alternative_phone", "next_followup_at"):
            if data.get(key) and not lead.get(key):
                patch[key] = data[key]
            elif verified_fields is not None and key in verified_fields:
                patch[key] = data.get(key)
        if verified_fields is not None and "priority" in verified_fields:
            patch["priority"] = data["priority"]
        if verified_fields is not None and "lead_type" in verified_fields:
            patch["lead_type"] = data["lead_type"]
        if verified_fields is not None and verified_fields & {"hospital_name", "clinic_name", "pharmacy_name", "distributor_name", "institution_name"}:
            patch["company"] = company
            if lead.get("title") == lead.get("company"):
                patch["title"] = company or identity or lead["title"]
        conflicts = any(data.get(k) and lead.get(k) and normalized(str(data[k])) != normalized(str(lead[k]))
                        for k in (*TEXT_FIELDS, "mobile"))
        if conflicts:
            patch["verification_status"] = "Needs Verification"
        if data.get("priority") in ("high", "urgent") and lead.get("priority") not in ("high", "urgent"):
            patch["priority"] = data["priority"]
        if lead.get("source") != "WhatsApp – MR":
            patch.update(source="WhatsApp – MR", original_source=lead.get("source"),
                         mr_id=mr["mr_id"], mr_directory_id=mr["id"], mr_name=mr["name"],
                         employee_id=mr["employee_id"], conversation_id=conversation["id"],
                         original_message=lead.get("original_message") or text,
                         ai_extracted=data, confidence=data["confidence"],
                         verification_status="Needs Verification" if conflicts or data["confidence"] < .85 else "Verified extraction",
                         capture_status="Lead Captured" if (lead.get("mobile") or data.get("mobile")) else "Phone Number Required")
        if patch.get("mobile"):
            patch["capture_status"] = "Lead Captured"
        changed = bool(patch)
        if not lead.get("assigned_to"):
            patch["assigned_to"] = mr["mr_id"]
        patch.update(updated_at=now, last_contact_at=now)
        await database.leads.update_one({"id": lead["id"]}, {"$set": patch})
        lead = {**lead, **patch}
        if changed:
            await event(database, lead["id"], job["id"], "Lead Updated", "New grounded information appended; populated facts preserved")
    await activity(database, lead, message, mr, data, job["id"])
    if existing and not existing.get("mobile") and lead.get("mobile"):
        lead = await complete_phone(database, lead, lead["mobile"], mr, key=job["id"])
    if changed:
        await notify_admins(database, lead, job["id"], "LEAD – PHONE NUMBER MISSING" if not lead.get("mobile") else "WHATSAPP LEAD CAPTURED")
        if lead.get("priority") in ("high", "urgent"):
            await notify_admins(database, lead, job["id"], "HIGH-PRIORITY LEAD")
    if not lead.get("mobile"):
        await queue_phone_requests(database, lead, mr, conversation if direct else None)
        await event(database, lead["id"], job["id"], "Phone Number Missing")
    needs_review = data["confidence"] < .85 or bool(existing and conflicts and verified_fields is None)
    return {**base_result, "status": "needs_verification" if needs_review else "completed",
            "lead_id": lead["id"], "extracted": data}
