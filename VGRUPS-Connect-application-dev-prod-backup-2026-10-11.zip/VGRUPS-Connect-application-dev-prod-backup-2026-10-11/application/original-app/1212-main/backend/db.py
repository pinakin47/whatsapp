import os
import uuid
from datetime import datetime, timezone
from pathlib import Path

from dotenv import load_dotenv
from postgres_store import PostgresDatabase

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / ".env")

db = PostgresDatabase()


def new_id() -> str:
    return uuid.uuid4().hex


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


async def log_audit(user: dict | None, action: str, module: str, record_id: str | None = None,
                    result: str = "success", ip: str | None = None, detail: str | None = None):
    await db.audit_logs.insert_one({
        "id": new_id(),
        "user_id": (user or {}).get("id"),
        "user_name": (user or {}).get("name"),
        "user_email": (user or {}).get("email"),
        "action": action,
        "module": module,
        "record_id": record_id,
        "result": result,
        "ip": ip,
        "detail": detail,
        "created_at": now_iso(),
    })
