"""Index-backed candidates for an individual MR's IST activity day."""
import json
from datetime import timedelta

from postgres_query import project


def activity_query(collection):
    if collection not in ("orders", "quotations"):
        raise ValueError("Unsupported MR activity collection")
    status = "AND COALESCE(document->>'status', '') NOT IN ('draft', 'cancelled')" if collection == "orders" else ""
    # Literal collections and text expressions match the partial expression
    # index, unlike the generic document API's JSONB comparisons.
    return f"""
        SELECT document FROM app_documents
        WHERE collection_name = '{collection}'
          AND document->>'created_by' = $1
          AND document->>'created_at' >= $2
          AND document->>'created_at' < $3
          AND document->'deleted' IS DISTINCT FROM 'true'::jsonb
          AND document->'is_demo' IS DISTINCT FROM 'true'::jsonb
          {status}
        ORDER BY document_id
    """


async def activity_candidates(database, collection, owner, start):
    # Stored ISO timestamps can have any offset strictly between -24h and
    # +24h. IST midnight is on the previous UTC date, so extreme negative
    # offsets can be two local dates earlier. Include that four-date window,
    # then check exact instants. No history-sized fetch or record-count cap.
    lower = (start.date() - timedelta(days=2)).isoformat()
    upper = (start.date() + timedelta(days=2)).isoformat()
    pool = await database.connect()
    rows = await pool.fetch(activity_query(collection), owner, lower, upper)
    return [project(json.loads(row["document"]), {"_id": 0}) for row in rows]
