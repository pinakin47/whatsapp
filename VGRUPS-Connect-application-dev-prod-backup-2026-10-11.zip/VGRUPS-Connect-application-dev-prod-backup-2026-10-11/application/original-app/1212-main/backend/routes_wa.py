from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from auth import require_perm, get_current_user, permissions_for
from db import log_audit, db
from whatsapp_routing import accounts, configuration, CONFIG_KEY
from typing import Optional
import wa_client

router = APIRouter(prefix="/api/wa", tags=["whatsapp-connect"])


class CreateSessionIn(BaseModel):
    name: str = "WhatsApp"


class RoutingIn(BaseModel):
    mr_session_id: Optional[str] = None
    general_session_id: Optional[str] = None


def may_view_senders(user):
    p = permissions_for(user["role"])
    if not (any("send" in p.get(m, []) for m in ("inbox", "campaigns", "catalog", "whatsapp", "leads"))
            or "view" in p.get("whatsapp", []) or "view" in p.get("inbox", [])):
        raise HTTPException(403, "WhatsApp sender access is required.")


@router.get("/senders")
@router.get("/routing")
async def get_routing(user=Depends(get_current_user)):
    may_view_senders(user)
    rows = await accounts(db)
    return {"items": rows, **await configuration(db, rows)}


@router.get("/accounts")
async def history_accounts(user=Depends(get_current_user)):
    may_view_senders(user)
    return {"items": await accounts(db, include_archived=True), **await configuration(db)}


@router.put("/routing")
async def save_routing(body: RoutingIn, user=Depends(require_perm("whatsapp", "manage"))):
    rows = await accounts(db)
    ids = {s["id"] for s in rows}
    for selected in (body.mr_session_id, body.general_session_id):
        if selected is not None and selected not in ids:
            raise HTTPException(422, "Choose a real linked WhatsApp number.")
    await db.app_config.update_one({"key": CONFIG_KEY},
        {"$set": {"key": CONFIG_KEY, "value": body.model_dump()}}, upsert=True)
    await log_audit(user, "assign_senders", "whatsapp", CONFIG_KEY, detail="MR and general sender assignments")
    return {"items": rows, **body.model_dump()}


@router.get("/sessions")
async def list_sessions(user: dict = Depends(require_perm("whatsapp", "view"))):
    return await wa_client.wa_list_sessions()


@router.get("/sessions/{sid}")
async def get_session(sid: str, user: dict = Depends(require_perm("whatsapp", "view"))):
    return await wa_client.wa_get_session(sid)


@router.post("/sessions")
async def create_session(body: CreateSessionIn, user: dict = Depends(require_perm("whatsapp", "manage"))):
    await configuration(db)
    try:
        res = await wa_client.wa_create_session(body.name)
    except Exception as e:
        raise HTTPException(status_code=503, detail=f"WhatsApp service unavailable: {e}")
    await log_audit(user, "wa_connect_start", "whatsapp", res.get("id"), detail=body.name)
    return res


@router.post("/sessions/{sid}/reconnect")
async def reconnect_session(sid: str, user: dict = Depends(require_perm("whatsapp", "manage"))):
    return await wa_client.wa_reconnect(sid)


@router.post("/sessions/{sid}/logout")
async def logout_session(sid: str, user: dict = Depends(require_perm("whatsapp", "manage"))):
    await log_audit(user, "wa_logout", "whatsapp", sid)
    return await wa_client.wa_logout(sid)


@router.delete("/sessions/{sid}")
async def delete_session(sid: str, user: dict = Depends(require_perm("whatsapp", "manage"))):
    await log_audit(user, "wa_delete", "whatsapp", sid)
    return await wa_client.wa_delete(sid)
