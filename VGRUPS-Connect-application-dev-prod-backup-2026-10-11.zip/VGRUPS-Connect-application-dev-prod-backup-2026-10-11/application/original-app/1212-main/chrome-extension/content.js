/* VGRUPS CRM Connect — content script: detect phone numbers, click to look up + WhatsApp */
(function () {
  const PHONE_RE = /(?:\+?91[\-\s]?)?[6-9]\d{9}/g;
  let bubble = null;

  function digits(s) { return (s || "").replace(/\D/g, ""); }

  function closeBubble() { if (bubble) { bubble.remove(); bubble = null; } }

  function showBubble(x, y, phone) {
    closeBubble();
    bubble = document.createElement("div");
    bubble.className = "vg-bubble";
    bubble.style.left = Math.min(x, window.innerWidth - 300) + "px";
    bubble.style.top = y + 14 + "px";
    bubble.innerHTML = '<div class="vg-bubble-head">VGRUPS CRM</div><div class="vg-bubble-body">Looking up ' + phone + '…</div>';
    document.body.appendChild(bubble);
    chrome.runtime.sendMessage({ type: "LOOKUP", phone }, (res) => {
      if (!bubble) return;
      if (!res || res.error) {
        const msg = res && res.error === "not_logged_in"
          ? 'Open the VGRUPS extension and log in first.'
          : 'Lookup failed. Check the extension settings.';
        bubble.querySelector(".vg-bubble-body").innerHTML = '<div class="vg-muted">' + msg + '</div>';
        return;
      }
      const d = digits(phone).slice(-10);
      let html = "";
      if (res.found && res.contact) {
        const c = res.contact;
        html += '<div class="vg-name">' + (c.name || "Unknown") + '</div>';
        html += '<div class="vg-muted">' + (c.contact_type || "contact") + (c.city ? " · " + c.city : "") + '</div>';
        if (res.leads && res.leads.length) html += '<div class="vg-chip">' + res.leads.length + ' lead(s)</div>';
        if (res.orders && res.orders.length) html += '<div class="vg-chip">' + res.orders.length + ' order(s)</div>';
      } else if (res.found && res.leads && res.leads.length) {
        html += '<div class="vg-name">Known lead</div><div class="vg-chip">' + res.leads.length + ' lead(s)</div>';
      } else {
        html += '<div class="vg-muted">Not in CRM yet.</div>';
      }
      html += '<div class="vg-actions">';
      html += '<a class="vg-btn vg-wa" href="https://wa.me/' + (d.length === 10 ? "91" + d : digits(phone)) + '" target="_blank">WhatsApp</a>';
      if (!res.found) html += '<button class="vg-btn vg-add">Add lead</button>';
      html += '</div>';
      bubble.querySelector(".vg-bubble-body").innerHTML = html;
      const addBtn = bubble.querySelector(".vg-add");
      if (addBtn) addBtn.onclick = () => {
        chrome.runtime.sendMessage({ type: "CAPTURE", payload: { phone: digits(phone), page: location.href } }, (r) => {
          addBtn.textContent = r && r.ok ? "Added ✓" : "Failed";
          addBtn.disabled = true;
        });
      };
    });
  }

  function wrapPhones(root) {
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
      acceptNode(node) {
        if (!node.nodeValue || node.nodeValue.length > 2000) return NodeFilter.FILTER_REJECT;
        const p = node.parentElement;
        if (!p || ["SCRIPT", "STYLE", "TEXTAREA", "INPUT"].includes(p.tagName) || p.closest(".vg-bubble")) return NodeFilter.FILTER_REJECT;
        return PHONE_RE.test(node.nodeValue) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT;
      },
    });
    const nodes = [];
    while (walker.nextNode()) nodes.push(walker.currentNode);
    nodes.slice(0, 200).forEach((node) => {
      const frag = document.createDocumentFragment();
      let last = 0;
      const txt = node.nodeValue;
      txt.replace(PHONE_RE, (m, idx) => {
        frag.appendChild(document.createTextNode(txt.slice(last, idx)));
        const badge = document.createElement("span");
        badge.className = "vg-phone";
        badge.textContent = m;
        badge.onclick = (e) => { e.stopPropagation(); showBubble(e.clientX, e.clientY, m); };
        frag.appendChild(badge);
        last = idx + m.length;
        return m;
      });
      frag.appendChild(document.createTextNode(txt.slice(last)));
      node.parentNode.replaceChild(frag, node);
    });
  }

  document.addEventListener("click", (e) => { if (bubble && !e.target.closest(".vg-bubble") && !e.target.classList.contains("vg-phone")) closeBubble(); });
  try { wrapPhones(document.body); } catch (e) {}
})();
