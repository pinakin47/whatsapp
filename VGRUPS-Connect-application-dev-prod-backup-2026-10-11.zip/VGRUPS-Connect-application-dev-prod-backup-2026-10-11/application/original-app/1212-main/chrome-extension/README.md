# VGRUPS CRM Connect — Chrome Extension

Click any phone number on any webpage to look it up in VGRUPS CRM and start WhatsApp in one click.

## Install (Load unpacked)
1. Download and unzip the extension (from VGRUPS CONNECT → Chrome Extension → Download).
2. Open Chrome → `chrome://extensions`.
3. Turn on **Developer mode** (top-right).
4. Click **Load unpacked** and select this folder.
5. Pin the **VGRUPS CRM Connect** icon, open it, set your Backend URL and log in.

## Use
- On any page, detected phone numbers get a green highlight — click one to see the CRM match + a WhatsApp button, or add it as a new lead.
- Use the popup to look up a number manually.

The Backend URL defaults to your VGRUPS CONNECT app; change it in the popup if your deployed URL differs.
