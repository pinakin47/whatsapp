const DEFAULT_BACKEND = "https://vgrups-connect.preview.emergentagent.com";
const $ = (id) => document.getElementById(id);

async function cfg() {
  const c = await chrome.storage.local.get(["backend", "token", "user"]);
  return { backend: c.backend || DEFAULT_BACKEND, token: c.token || "", user: c.user || null };
}

function show(view) {
  $("login-view").classList.toggle("hide", view !== "login");
  $("app-view").classList.toggle("hide", view !== "app");
}

async function render() {
  const c = await cfg();
  $("backend").value = c.backend;
  if (c.token && c.user) {
    $("who").textContent = `Signed in as ${c.user.name || c.user.email} (${c.user.role || ""})`;
    show("app");
  } else {
    show("login");
  }
}

$("login-btn").onclick = async () => {
  const backend = ($("backend").value || DEFAULT_BACKEND).trim().replace(/\/$/, "");
  const email = $("email").value.trim();
  const password = $("password").value;
  const st = $("login-status");
  st.className = "status"; st.textContent = "Signing in…"; st.classList.remove("hide");
  try {
    const r = await fetch(`${backend}/api/auth/login`, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password }),
    });
    const d = await r.json();
    if (!r.ok || !d.token) { st.className = "status err"; st.textContent = d.detail || "Login failed"; return; }
    await chrome.storage.local.set({ backend, token: d.token, user: d.user });
    render();
  } catch (e) {
    st.className = "status err"; st.textContent = "Network error — check the backend URL.";
  }
};

$("logout-btn").onclick = async () => { await chrome.storage.local.remove(["token", "user"]); render(); };

$("lookup-btn").onclick = async () => {
  const phone = $("lookup-phone").value.trim();
  const box = $("result");
  if (!phone) return;
  box.style.display = "block"; box.textContent = "Searching…";
  chrome.runtime.sendMessage({ type: "LOOKUP", phone }, (res) => {
    if (!res || res.error) { box.textContent = res && res.error === "not_logged_in" ? "Please log in again." : "Lookup failed."; return; }
    const d = phone.replace(/\D/g, "").slice(-10);
    let html = "";
    if (res.found && res.contact) {
      html += `<b>${res.contact.name || "Unknown"}</b><br/><span style="color:#6b7a63">${res.contact.contact_type || ""}${res.contact.city ? " · " + res.contact.city : ""}</span>`;
      if (res.leads?.length) html += `<br/>${res.leads.length} lead(s)`;
      if (res.orders?.length) html += ` · ${res.orders.length} order(s)`;
    } else if (res.found && res.leads?.length) {
      html += `<b>Known lead</b><br/>${res.leads.length} lead(s)`;
    } else {
      html += `<span style="color:#6b7a63">Not in CRM yet.</span>`;
    }
    html += `<a class="wa" href="https://wa.me/${d.length === 10 ? "91" + d : phone.replace(/\D/g, "")}" target="_blank">Open WhatsApp</a>`;
    box.innerHTML = html;
  });
};

render();
