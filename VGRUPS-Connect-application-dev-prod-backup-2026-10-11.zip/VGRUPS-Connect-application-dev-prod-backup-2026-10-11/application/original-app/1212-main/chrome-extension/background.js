// VGRUPS CRM Connect — background service worker (MV3)
const DEFAULTS = { backend: "https://vgrups-connect.preview.emergentagent.com", token: "" };

async function getCfg() {
  const c = await chrome.storage.local.get(["backend", "token"]);
  return { backend: c.backend || DEFAULTS.backend, token: c.token || "" };
}

async function apiLookup(phone) {
  const { backend, token } = await getCfg();
  if (!token) return { error: "not_logged_in" };
  try {
    const r = await fetch(`${backend}/api/ext/lookup/${encodeURIComponent(phone)}`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    if (r.status === 401) return { error: "not_logged_in" };
    if (!r.ok) return { error: "lookup_failed" };
    return await r.json();
  } catch (e) {
    return { error: "network" };
  }
}

async function apiCapture(payload) {
  const { backend, token } = await getCfg();
  if (!token) return { error: "not_logged_in" };
  try {
    const r = await fetch(`${backend}/api/ext/capture`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
      body: JSON.stringify(payload),
    });
    return await r.json();
  } catch (e) {
    return { error: "network" };
  }
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "LOOKUP") { apiLookup(msg.phone).then(sendResponse); return true; }
  if (msg.type === "CAPTURE") { apiCapture(msg.payload).then(sendResponse); return true; }
  if (msg.type === "GET_CFG") { getCfg().then(sendResponse); return true; }
});
