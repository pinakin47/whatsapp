# VGRUPS CONNECT — Product Requirements Document

## Original Problem Statement
Build VGRUPS CONNECT for VGRUPS HEALTHCARE: an all-in-one WhatsApp automation + CRM + sales + marketing + OTP + Chrome Extension enterprise SaaS platform. Full spec spans 10 phases (auth/CRM → WhatsApp → campaigns/automation → chatbot/AI/catalog → orders/payments → ads/Brevo/Sheets → extension/widget/QR → MR & portals → reports/API/audit → security/testing/deploy).

## Decisions (user confirmed)
- Stack: React + FastAPI + MongoDB (native Emergent stack; spec asked Node/Postgres but env standard chosen).
- First build scope: Phases 1–2.
- WhatsApp/Brevo/Razorpay/Meta/Google: NOT configured yet — integration architecture built with honest "Not Connected" states (no faking per requirement #50).
- AI: skipped for now.
- Auth: JWT Bearer (localStorage), bcrypt, RBAC, brute-force lockout.

## Architecture
- Backend modular: db.py, auth.py (JWT+RBAC+OTP), integrations.py (status + Meta/Brevo senders), routes_crm.py, routes_whatsapp.py (+webhook), routes_platform.py (dashboard/users/roles/tasks/products/orders/campaigns/audit/search), seed.py. server.py wires routers + startup seed.
- Frontend: AuthContext + ThemeContext, Layout (sidebar + header + mobile bottom nav + Ctrl+K search), ProtectedRoute, pages per module.
- Design: olive/dark-green healthcare theme (design_guidelines.json), light/dark mode, Plus Jakarta Sans + Inter.

## User Personas / Roles
super_admin, admin, sales_manager, mr, distributor, cf, medical_shop, customer_support, marketing, accounts, view_only. Module-specific permissions (view/create/edit/delete/export/send/approve/assign/manage).

## Implemented (2026-10-02)
- Auth: login/register/me/logout/forgot/reset; JWT; bcrypt; brute-force (5→15min lockout); audit logging.
- RBAC: 11 roles, module permission matrix, require_perm guards, 'crm'/'contacts' synonym resolution.
- OTP: send-otp/verify-otp (WhatsApp/SMS/Email) with hashed storage, 5-min expiry, resend cooldown, demo-mode code when provider absent.
- Dashboard: 11 KPI cards + 6 charts (lead/sales/conversation trend, campaign perf, lead source, MR perf), range filters.
- CRM/Contacts: CRUD + search + type filter + detail sheet (orders/leads).
- Leads: Kanban board (9 stages) with drag-and-drop status update.
- WhatsApp: Unified Inbox (3-pane, folders, send→503 when unconfigured), Template Manager (CRUD, live preview, submit-to-Meta gated), Cloud API webhook (verify + HMAC signature + idempotent inbound/status).
- Integrations health page (WhatsApp/Brevo/Razorpay/AI/SMS/Google/Meta Ads) with test buttons.
- Tasks, Catalog (15 products), Orders (15), Campaigns (5 w/ stats), Settings (team, role matrix, audit log).
- Global search (Ctrl+K). Demo data clearly flagged (is_demo + DEMO badge).
- Verified by testing agent: backend 29/30→ RBAC fixed (now full), frontend core flows pass.

## Backlog (remaining phases)
- P0 (Phase 3): Sales pipelines, Campaigns broadcast send, Drip sequences, Automation builder (drag-drop triggers/actions).
- P1 (Phase 4-5): Chatbot builder, AI assistant (knowledge-grounded), Orders cart/quotation flow, Razorpay payment links.
- P1 (Phase 6-7): Google/Meta lead webhooks + ad attribution, Brevo email, Google Sheets sync, Chrome Extension, website WhatsApp widget, QR/tracking links.
- P2 (Phase 8-10): MR field-sales module, Distributor/C&F/Medical Shop portals, Reports export (CSV/Excel/PDF), API key center, consent/opt-out, security hardening, deployment.

## Known Notes
- Live WhatsApp/payment/email require env credentials (backend/.env): META_*, BREVO_*, RAZORPAY_*.
- CORS currently '*' (Bearer auth, safe); pin origin for prod.

## WhatsApp Web QR Connection (added 2026-10-02)
- Node.js Baileys gateway at /app/whatsapp-service (supervisor program `whatsapp`, 127.0.0.1:3001, autostart+autorestart = 24/7).
- Multi-session QR linking; auth state persisted in MongoDB (wa_auth) so no re-scan after restarts; auto-reconnect on drop; `closing` Set cancels reconnect on logout/delete (resurrection bug fixed).
- Inbound messages written straight to conversations/messages; outbound stored by FastAPI.
- FastAPI proxy /api/wa/* (routes_wa.py + wa_client.py); inbox send + OTP route through connected QR session first, then Cloud API, else 503.
- Frontend: /whatsapp hub with Connections (QR cards, poll 2.5s) + Templates tabs.
- Verified by testing agent iteration_2: backend 9/9, frontend 100%.

## Phase 3 batch (added 2026-10-02)
- **Broadcast Sender**: real campaign engine (routes_campaigns.py) with asyncio tick loop — materializes recipients from audience filters, sends through the linked WhatsApp number with throttle, scheduling (scheduled_at), pause/resume/delete, live progress stats. Opted-out contacts auto-suppressed. Verified 11/11.
- **Auto-Reply Bot**: Node runBot() greets new chats, captures name→product→quantity, auto-creates CRM lead + contact; human handover on "agent"; config via /api/bot/config (WhatsApp hub → Auto-Reply tab).
- **Delivery Ticks**: Node messages.update handler maps Baileys status → sent/delivered/read; Inbox renders Check/CheckCheck ticks.
- **Number Health**: wa_usage.py warm-up ramp (day1:40…day4:300, cap 500) + daily-limit guard enforced in engine; /api/wa/health + health cards in Connections.
- **Opt-out/Consent**: STOP/UNSUBSCRIBE/START handled in Node; consent_records + contacts.opted_out; /api/consent (gated).

## Phase 3 complete (added 2026-10-02)
- **Drip Sequences** (routes_campaigns.py): day-based steps enrolled per audience, engine sends due steps through linked number, auto-stops on reply/purchase/opt-out. /api/drips* + Drips.jsx (Campaigns → Drip tab).
- **Automation Builder** (routes_automations.py): triggers (new_lead/new_contact/new_order/payment_received) → actions (send_whatsapp/add_tag/create_task/create_follow_up). Event hooks in routes_crm (non-blocking via run_automations_safe). Drag-to-reorder flow UI in Automations.jsx (/automation). Action type validated (422).
- **Campaign Report CSV**: GET /api/campaigns/{id}/report.csv (recipient-level delivered/read/replied), export button in broadcasts.
- **Template Broadcasts**: campaign template_name + {name}/{company}/{city} rendered per contact at send; template picker in broadcast dialog.
- Verified testing iteration_4: backend 8/8, frontend 100%.

## Phase 4/5 batch (added 2026-06, this session) — Verified testing iteration_5: backend 14/14, frontend 100%
- **Chatbot Flow Builder** (routes_chatbot.py + whatsapp-service/index.js): visual multi-branch bot. Flow = {enabled, start, nodes[]}; node types message/menu/question/action (create_lead/add_tag/handoff). Delivery via reliable NUMBERED-TEXT replies (user chose this over unreliable Baileys buttons). Node engine runFlow() walks message/action nodes, waits on menu/question; falls back to linear runBot when chatbot_flow disabled. GET/PUT /api/chatbot/flow (validates unique ids, start exists, menu has options, next links resolve). UI /chatbot (ChatbotBuilder.jsx) with node editor + live WhatsApp-style simulator.
- **Orders & Payments** (routes_orders.py + razorpay_client.py): Quotations (pick products, qty, auto subtotal/GST/discount/total) → convert to Order → Razorpay payment link (graceful 503 + 'Not connected' banner when keys empty) → auto WhatsApp send; manual Mark-Paid path. Razorpay webhook (/api/webhooks/razorpay, signature-verified) + /api/payments/config. Atomic QT/VG numbering via counters collection. Fires new_order (on convert) and payment_received (on paid) automation triggers + WhatsApp confirmation. UI: Orders.jsx hub (Quotations|Orders tabs) + Payments.jsx ledger.
- **Automation IF/ELSE** (routes_automations.py): new 'condition' action type {field, op, value, then[], otherwise[]}; recursive executor; ctx enriched with contact_type/tags/city/source/lead_status. condition_fields/ops exposed in GET /api/automations. UI shows IF card with THEN/ELSE sub-action zones.
- Env: RAZORPAY_WEBHOOK_SECRET added (empty). razorpay==2.0.1 in requirements.

## Polish batch (added 2026-06)
- **Catalog Images**: PRODUCT_IMAGES map in seed.py + `seed_product_images()` (server.py startup) now attaches a DISTINCT Unsplash stock photo to every one of the 15 SKUs (set unconditionally). Catalog.jsx renders `<img>` cards with Package-icon + onError fallback; Quotations.jsx line items show thumbnails (quotation-item-image-{id}).
- **Chatbot Templates**: GET /api/chatbot/templates → 3 ready-made flows (Lead Capture, Pricing Bot, Order Status). ChatbotBuilder "Templates" dialog: Enable now (PUT flow) / Load & edit. Responses deep-copied.
- **Recruitment ATS** (routes_recruitment.py): 7 seeded positions (Accounts, Medical Rep, Doctor, Male Nurse, Female Nurse, Social Media, Receptionist) each with info + screening Q&A. Endpoints: /api/recruitment/positions CRUD, /api/recruitment/candidates (+PATCH stage: applied→screening→interview→hired→rejected), PUBLIC /api/careers/positions + /api/careers/apply (no auth, in-memory per-IP throttle + mobile validation; creates candidate + CRM contact type 'candidate'). Pages: Recruitment.jsx (Positions + Candidates tabs), Careers.jsx (public /careers hero + apply). Modules 'recruitment' added to auth.
- **WhatsApp IVR** (routes_ivr.py): GET/PUT /api/ivr; DEFAULT_IVR greeting + 5 numbered options (Sales/Catalogue/Order status/Support/Careers) each with auto-reply + optional human handoff. Node engine (index.js) loadIvr/runIvr: inbound priority chatbot_flow → IVR → linear bot. IVRSetup.jsx designer + live WhatsApp preview. Module 'ivr' added. NOTE: runs over WhatsApp messages, not phone calls.
- Env: RAZORPAY_WEBHOOK_SECRET added (empty). razorpay==2.0.1 in requirements.

## Growth batch (added 2026-06)
- **Per-SKU photos**: all 15 products now have DISTINCT stock images (seed.py PRODUCT_IMAGES, set unconditionally).
- **Recruitment share/QR**: ShareDialog.jsx (qrcode.react) — Positions have an "Apply link" (deep link /careers?position={id}) + page-level "Share Careers / QR" with copy / download-QR / WhatsApp. /jobs -> /careers short redirect. Careers.jsx auto-opens the apply dialog from ?position=.
- **Hire Faster**: candidate WhatsApp dialog in the pipeline with presets (Shortlisted/Interview/Not selected). POST /api/recruitment/candidates/{id}/whatsapp sends via Baileys if connected else returns a wa.me link the UI opens. Apply endpoint returns candidate_id.
- **Ad Lead Capture (Phase 6)**: routes_ads.py — public webhooks POST /api/webhooks/lead (generic/Google/Zapier JSON) + GET/POST /api/webhooks/meta-leads (Meta verify handshake via configurable verify_token + field_data ingestion). Auth: /api/ads/config, /api/ads/leads (per-source counts), /api/ads/test-lead. Captured leads create CRM contact+lead and fire new_lead automation. Ads.jsx dashboard: stats, webhook URLs, masked verify-token, test-lead button, captured-leads table. In-memory per-IP throttle.

## Recruitment + Brevo batch (added 2026-06)
- **Brevo auto-email**: brevo_client.py (BREVO_API_KEY/SENDER in .env, verified sender careers@vgrups.in). Every new AD LEAD with an email gets a welcome email (brand header + top-4 product thumbnails) within seconds via routes_ads._send_welcome_email, with a 7-day welcomed_at dedup guard. Returns "Sent" from the live Brevo API.
- **Recruitment expansion**: 15 positions total (added HR, Purchase, Store/Warehouse, Customer Support, Graphic Designer, Digital Marketing, Sales Executive, Distributor Sales Manager). Each position stores COMMON_QUESTIONS (10) + POSITION_QUESTIONS (role-specific) for the recruitment flow. Public Careers apply form now captures location/qualification/experience/salaries/joining/resume-link + mandatory consent and issues an Application ID (VGRUPS-#### via counters). Candidate pipeline stages expanded (applied→screening→shortlisted→interview→selected→offer→joined→rejected); candidates table shows App ID. HR status WhatsApp messages from the pipeline: Under Review / Shortlisted / Interview Confirmed / App Submitted / Not selected, with interview date/time/mode scheduling saved on the candidate.
- DEFERRED (next phase): fully-conversational in-WhatsApp recruitment questionnaire + real resume document (file) upload over WhatsApp (needs object storage).

## Full E2E sweep + WA pill fix (added 2026-06, this session) — Verified testing iteration_10: frontend 100%, backend product APIs 100%
- **Dashboard WhatsApp status pill unified**: Layout.jsx header pill (data-testid='wa-status-pill') was previously HARDCODED 'Not Connected'. Now wired to GET /api/wa/sessions (polls every 10s) and reads the `connected` boolean from the same Baileys-backed wa_client source used by candidate messaging. Shows 'WhatsApp: Connected' when the QR session is live (verified with session +919177999986), '…' while loading, 'Not Connected' otherwise. Resolves the iteration-9 cosmetic mismatch. Meta Cloud API remains secondary fallback.
- **Full regression sweep (testing_agent iteration_10)**: auth/RBAC, dashboard (11 KPIs + charts), CRM, leads kanban, WhatsApp hub (Baileys primary, connected), campaigns/drips, automation IF/ELSE, chatbot builder + templates, catalog (15 distinct images), orders/quotations/payments (Razorpay graceful Not-Connected), recruitment ATS (15 positions + App IDs + 5 WA presets), public careers (15 positions, consent, VGRUPS-#### id), IVR designer, ads + Brevo welcome email, integrations — all pass, zero regressions.
- Fixed stale backend test: test_wa_sessions.py::test_inbox_send_when_disconnected_returns_503 now skips the 503 assertion when a Baileys QR session is connected (delegates to Baileys → 200). Pytest 8 passed / 1 skipped.

## Security hardening (added 2026-06, this session) — fixes from security_audit
- **SEC-001 (CRITICAL)**: public POST /api/auth/register no longer accepts a client-chosen privileged role — super_admin/admin requests are downgraded to view_only (auth.py). Verified: register with role=super_admin → assigned view_only.
- **SEC-002 (HIGH)**: read endpoints now enforce require_perm instead of bare auth — /contacts, /contacts/{id}, /contacts/stats, /leads (routes_crm.py); /dashboard/stats, /dashboard/charts, /users (settings.view), /roles (settings.view), /tasks, /products, /orders, /search (routes_platform.py). Added scoped GET /api/field/mrs (field_sales.view) so managers populate the MR dropdown without the full staff list. Verified: marketing role gets 403 on /users and /orders; admin 200 across the board.
- **SEC-003 (MEDIUM)**: user search input is re.escape()'d before MongoDB $regex in /contacts, /leads, /products, /search — ReDoS/NoSQL-injection closed. Verified: pathological '(a+)+$' returns 200 in ~0.1s.
- **P3**: removed password-reset token stdout leak (auth.py).
- **Deployment**: added fast GET / returning 200 (health probe) — defers all work; heavy seeding/storage-init stays in the startup event, not the route.
- Still open (low): CORS '*' with Bearer (env-configurable); Node :3001 send/session endpoints rely on 127.0.0.1 bind (add shared-secret later); rotate live BREVO key before go-live.

## Next Tasks
- Webhook security: Meta X-Hub-Signature-256 HMAC (needs App Secret).
- Razorpay live keys + payment link verification (keys pending user).
- Phase 6 remainder: Google Sheets sync, UTM attribution/cost-per-lead analytics.
- Field-sales expansion: targets/incentives, MR route map, offline check-in GPS.
- Portal expansion: distributor stock requests, downloadable invoices/PDF.

## Phase 2+3 + AI Screening (added 2026-06, this session) — Verified testing iteration_12: backend 23/23, frontend 100%
- **AI Resume Screening** (ai_screening.py, Gemini 3 Flash via EMERGENT_LLM_KEY): extracts resume text (pypdf/python-docx), scores candidate vs role → {score 0-100, recommendation, summary, strengths[], concerns[]}. POST /api/recruitment/candidates/{cid}/score (manual, recruitment.edit) + POST .../auto-score (internal, X-WA-Secret) fired fire-and-forget by Node finishApplication(). Recruitment.jsx: AI Fit column + Score button + AI panel in details dialog (strengths/concerns/recommendation).
- **Chrome Extension + Widget** (routes_ext.py + /app/chrome-extension/ + ExtensionWidget.jsx at /extension): MV3 extension (popup login, content.js highlights phone numbers → CRM lookup bubble + WhatsApp + add-lead). GET /api/ext/lookup/{phone}, POST /api/ext/capture, GET /api/ext/download (zips the extension). Website widget: GET /api/widget.js (public, floating WhatsApp button, base URL computed from script src), POST /api/widget/click (public tracking), GET /api/widget/stats. UI: download + snippet generator + click stats by source/UTM.
- **MR Field Sales** (routes_field.py + FieldSales.jsx at /field-sales): field_visits CRUD, daily beat plan, check-in (visited + outcome + order_value), stats cards. Role-scoped — MR sees own, managers see all.
- **Distributor/C&F Portal** (routes_field.py + Portal.jsx at /portal, nav added): own orders + ledger (billed/paid/outstanding). New 'portal' module in auth; distributor/cf/medical_shop get view, admin preview-all.

## Resume-over-WhatsApp (added 2026-06, this session) — Verified testing iteration_11: backend 6/6, frontend 100%
- **Object storage** (storage.py, Emergent-managed via EMERGENT_LLM_KEY + INTEGRATION_PROXY_URL): init at startup (server.py); put/get helpers with force-reinit on 404. Resumes stored at `vgrups-connect/resumes/{candidate_id}/{uuid}.{ext}`.
- **Backend endpoints** (routes_recruitment.py): POST /api/recruitment/resume-upload (INTERNAL — X-WA-Secret header = WA_INTERNAL_SECRET env; Form file+candidate_id+mobile; 15MB cap; persists resume_url/filename/content_type/size on candidate). GET /api/recruitment/candidates/{cid}/resume (auth recruitment.view; streams the file; 404 if none).
- **WhatsApp engine** (whatsapp-service/index.js): runRecruitment() runs BEFORE chatbot/IVR/linear bot. Trigger = 'APPLY <CODE>' deep-link OR keywords (apply/jobs/careers/hiring) → numbered menu of open positions. startApplication() creates/links candidate (shared VGRUPS-#### counter) → asks for resume (PDF/DOC via document message, uploaded to backend) or SKIP → runs the position's COMMON+POSITION questions one-by-one (numbered options for choice type) → finishApplication() saves answers[], maps common fields, sets stage=screening. Resume accepted anytime during Q&A. Env: WA_INTERNAL_SECRET + BACKEND_INTERNAL_URL added to whatsapp.conf.
- **Admin UI** (Recruitment.jsx): per-position WhatsApp-apply button (wa.me APPLY code using linked number from /wa/sessions); candidate row Resume download + details dialog (screening answers + resume). 
- NOTE: the live conversational Q&A over WhatsApp is MANUAL-TEST-REQUIRED (needs a real inbound message to the linked number +919177999986) — all HTTP/storage/UI paths are automated-verified.


## Full test sweep: health, security, links (added 2026-06) — Verified testing iteration_14: backend 27/27, frontend 23/23 routes
- **Health**: GET / returns 200 in <1ms (fast probe for k8s liveness); frontend 200.
- **Auth/RBAC regression**: admin login + /me + wrong-password 401 + missing-token 401; non-admin roles 403 on /users, /roles, /audit-logs; distributor can access /api/portal/summary but not /api/field/visits; MR can list visits; no password_hash/bcrypt leaked in any response.
- **Injection safety**: regex fuzzing ('.*', '(', '[', '$regex') across /api/search, /api/products, /api/contacts, /api/leads — all safe, no 500s.
- **Links/navigation**: all 23 authenticated routes render as super_admin with no 404s or console errors; dashboard stats + live 'WhatsApp: Connected' pill (Baileys session +919177999986) render.
- **Defense-in-depth**: added re.escape() to phone-number regex compiles in routes_ext.py (ext_lookup/ext_capture) per testing-agent review.
- Open low-priority notes: consider /api/health alias (external ingress shadows backend '/'); field _achievement uses planned-month vs check-in month; register role-downgrade returns silent 200.
- Regression suite kept at /app/backend/tests/test_iter14_health_security_links.py (27 tests).