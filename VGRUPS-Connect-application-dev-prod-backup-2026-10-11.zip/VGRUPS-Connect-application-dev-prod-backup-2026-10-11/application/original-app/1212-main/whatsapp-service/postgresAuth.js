const { initAuthCreds, BufferJSON, proto } = require("@whiskeysockets/baileys");
const { authWriteQueue } = require("./auth-write-queue");

// PostgreSQL auth state, preserving Baileys' binary JSON serialization.
async function usePostgresAuthState(coll, sessionId, assertOwned) {
  if (typeof assertOwned !== "function") throw new Error("A session ownership guard is required");
  const queue = authWriteQueue(coll, sessionId);
  const read = async (id) => {
    await queue.wait();
    assertOwned();
    const doc = await coll.findOne({ sessionId, dataId: id });
    return doc ? JSON.parse(doc.value, BufferJSON.reviver) : null;
  };
  const write = (id, value) => {
    assertOwned();
    const snapshot = JSON.stringify(value, BufferJSON.replacer);
    return queue.run(() => {
      assertOwned();
      return coll.updateOne(
    { sessionId, dataId: id },
    { $set: { sessionId, dataId: id, value: snapshot } },
    { upsert: true },
    );
    });
  };
  const removeData = (id) => {
    assertOwned();
    return queue.run(() => { assertOwned(); return coll.deleteOne({ sessionId, dataId: id }); });
  };
  const creds = (await read("creds")) || initAuthCreds();
  return {
    state: {
      creds,
      keys: {
        get: async (type, ids) => {
          const data = {};
          await Promise.all(ids.map(async (id) => {
            let value = await read(`${type}-${id}`);
            if (type === "app-state-sync-key" && value) value = proto.Message.AppStateSyncKeyData.fromObject(value);
            data[id] = value;
          }));
          return data;
        },
        set: async (data) => {
          const tasks = [];
          for (const category in data) {
            for (const id in data[category]) {
              const value = data[category][id];
              const dataId = `${category}-${id}`;
              tasks.push(value ? write(dataId, value) : removeData(dataId));
            }
          }
          await Promise.all(tasks);
        },
      },
    },
    saveCreds: () => write("creds", creds),
    clear: () => {
      assertOwned();
      return queue.run(() => { assertOwned(); return coll.deleteMany({ sessionId }); });
    },
  };
}
module.exports = { usePostgresAuthState };