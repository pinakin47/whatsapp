const { test } = require("node:test");
const assert = require("node:assert/strict");
const { authWriteQueue } = require("./auth-write-queue");

test("credential writes remain ordered across socket replacement and restart reads", async () => {
  const collection = {};
  const first = authWriteQueue(collection, "synthetic");
  const restored = authWriteQueue(collection, "synthetic");
  let release;
  const blocked = new Promise(resolve => { release = resolve; });
  let persisted = null;
  const a = first.run(async () => { await blocked; persisted = "old-snapshot"; });
  const b = restored.run(async () => { persisted = "latest-pairing"; });
  let loaded = false;
  const read = restored.wait().then(() => { loaded = true; return persisted; });
  await Promise.resolve();
  assert.equal(loaded, false);
  release();
  await Promise.all([a, b]);
  assert.equal(await read, "latest-pairing");
});

test("a failed database save does not poison later writes; explicit clear follows pending writes", async () => {
  const q = authWriteQueue({}, "synthetic");
  await assert.rejects(q.run(() => { throw new Error("synthetic outage"); }));
  let stored = null;
  const save = q.run(() => { stored = "durable"; });
  const clear = q.run(() => { stored = null; });
  await Promise.all([save, clear]);
  await q.wait();
  assert.equal(stored, null);
});

test("independent databases and sessions never share credential queues", async () => {
  const coll = {};
  let release;
  const a = authWriteQueue(coll, "one");
  const blocked = a.run(() => new Promise(resolve => { release = resolve; }));
  await Promise.resolve();
  await Promise.resolve();
  await authWriteQueue(coll, "two").run(() => {});
  await authWriteQueue({}, "one").run(() => {});
  release();
  await blocked;
});
