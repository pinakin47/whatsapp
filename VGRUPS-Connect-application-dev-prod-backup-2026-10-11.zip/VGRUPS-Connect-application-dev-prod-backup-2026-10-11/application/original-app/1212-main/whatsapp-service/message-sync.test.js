const test = require("node:test");
const assert = require("node:assert/strict");
const { syncMessage } = require("./message-sync");
const { shouldAutomate } = require("./incoming");

class MemoryCollection {
  constructor() { this.docs = []; }
  async findOne(query) {
    return this.docs.find(doc => Object.entries(query).every(([key, value]) =>
      value?.$in ? value.$in.includes(doc[key]) : value === null ? doc[key] == null : doc[key] === value)) || null;
  }
  async insertOne(doc) { this.docs.push({ ...doc }); }
  async updateOne(query, update, options = {}) {
    let doc = await this.findOne(query);
    if (!doc && options.upsert) {
      doc = { ...query, ...update.$setOnInsert };
      this.docs.push(doc);
      return { matchedCount: 0, upsertedId: doc.id };
    }
    if (!doc) return { matchedCount: 0 };
    Object.assign(doc, update.$set || {});
    for (const [key, value] of Object.entries(update.$inc || {})) doc[key] = (doc[key] || 0) + value;
    return { matchedCount: 1 };
  }
}
function fixture() {
  const conversations = new MemoryCollection(), messages = new MemoryCollection();
  return { conversations, messages,
    sync: msg => syncMessage({ sessionId: "test-session", msg, conversations, messages }) };
}
const message = (id, fromMe = false, timestamp = Math.floor(Date.now() / 1000)) => ({
  key: { id, fromMe, remoteJid: "123456@lid", remoteJidAlt: "15550001111@s.whatsapp.net" },
  message: { conversation: "hi" }, pushName: "Test contact", messageTimestamp: timestamp,
});

test("reconnect ACK enriches a queued echo without duplicating messages", async () => {
  const f = fixture();
  await f.sync({ ...message("queued", true), status: 1 });
  assert.equal(f.messages.docs[0].provider_status, 1);
  await f.sync({ ...message("queued", true), status: 3 });
  assert.equal(f.messages.docs[0].provider_status, 3);
  await f.sync({ ...message("queued", true), status: 2 });
  assert.equal(f.messages.docs[0].provider_status, 3);
  assert.equal(f.messages.docs.length, 1);
  assert.equal(f.conversations.docs[0].unread, 0);
});

test("received WhatsApp message creates a real conversation and unread entry", async () => {
  const f = fixture();
  await f.sync(message("received"));
  assert.equal(f.conversations.docs.length, 1);
  assert.equal(f.conversations.docs[0].is_demo, false);
  assert.equal(f.conversations.docs[0].unread, 1);
  assert.equal(f.messages.docs[0].direction, "inbound");
  assert.equal(f.conversations.docs[0].reply_jid, "123456@lid");
});
test("messages sent from the linked phone appear without increasing unread", async () => {
  const f = fixture();
  await f.sync(message("sent-from-phone", true));
  assert.equal(f.messages.docs[0].direction, "outbound");
  assert.equal(f.messages.docs[0].status, "sent");
  assert.equal(f.conversations.docs[0].unread, 0);
  assert.equal(shouldAutomate(message("own-hi", true)), false);
});
test("both directions share a conversation", async () => {
  const f = fixture();
  await f.sync(message("incoming"));
  await f.sync(message("outgoing", true));
  assert.equal(f.conversations.docs.length, 1);
  assert.equal(f.messages.docs.length, 2);
  assert.equal(f.conversations.docs[0].unread, 1);
});
test("replayed notify/append events do not duplicate messages or unread counts", async () => {
  const f = fixture();
  const msg = message("same-id");
  await f.sync(msg);
  assert.equal(await f.sync(msg), null);
  assert.equal(f.messages.docs.length, 1);
  assert.equal(f.conversations.docs[0].unread, 1);
});
test("app/bot echoes already stored are not inserted again", async () => {
  const f = fixture();
  f.messages.docs.push({ wamid: "already-sent" });
  assert.equal(await f.sync(message("already-sent", true)), null);
  assert.equal(f.conversations.docs.length, 0);
});
test("reconnect messages preserve timestamps without replacing newer previews", async () => {
  const f = fixture();
  await f.sync(message("new"));
  const latest = f.conversations.docs[0].last_message_at;
  await f.sync(message("old", false, Math.floor(Date.now() / 1000) - 3600));
  assert.equal(f.conversations.docs[0].last_message_at, latest);
  assert.equal(shouldAutomate(message("old-hi", false, Math.floor(Date.now() / 1000) - 3600)), false);
  assert.equal(shouldAutomate(message("new-hi")), true);
});
test("protocol messages and missing WhatsApp IDs do not create empty chats", async () => {
  const f = fixture();
  assert.equal(await f.sync(null), null);
  assert.equal(await f.sync({ ...message("protocol"), message: { protocolMessage: {} } }), null);
  assert.equal(await f.sync(message(undefined)), null);
  assert.equal(f.messages.docs.length, 0);
});
test("groups remain excluded", async () => {
  const f = fixture();
  const msg = message("group");
  msg.key.remoteJid = "123@g.us";
  assert.equal(await f.sync(msg), null);
});
test("existing non-demo CRM chats are linked without creating duplicate conversations", async () => {
  const f = fixture();
  f.conversations.docs.push({ id: "existing", phone: "+15550001111", is_demo: false, unread: 0 });
  await f.sync(message("first-live"));
  assert.equal(f.conversations.docs.length, 1);
  assert.equal(f.messages.docs[0].conversation_id, "existing");
  assert.equal(f.conversations.docs[0].session_id, "test-session");
});