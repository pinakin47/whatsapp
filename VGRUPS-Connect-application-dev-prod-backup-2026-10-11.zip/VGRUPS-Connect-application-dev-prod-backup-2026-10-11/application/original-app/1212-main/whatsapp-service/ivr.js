const { isMenuGreeting } = require("./incoming");
const DEFAULT = require("../ivr-default.json");

function normalizeConfig(value) {
  return { ...DEFAULT, ...value, options: value.schema_version === 2 ? value.options : DEFAULT.options, schema_version: 2 };
}
function nodeAt(config, path) {
  let node = config;
  for (const index of path) {
    node = node.options?.[index];
    if (!node) return config;
  }
  return node;
}
function menuText(config, path = []) {
  const node = nodeAt(config, path);
  const head = path.length ? `${node.label}\n${node.response || ""}` : config.greeting;
  return `${head}\n\n${(node.options || []).map((o, i) => `${i + 1}. ${o.label}`).join("\n")}\n\n${config.footer || "Reply with a number."}${path.length ? "\nBACK: Previous menu" : ""}`;
}
function createIvrRunner({ loadConfig, sendText, updateConversation, getConversation, actions, recordEvent }) {
  const queues = new Map();
  async function runConversation(sessionId, conversation, phone, body) {
    const config = normalizeConfig(await loadConfig());
    if (!config.enabled || !config.options?.length) return false;
    const text = String(body || "").trim();
    const save = async values => { await updateConversation(conversation.id, values); Object.assign(conversation, values); };
    const emit = async (option, result = {}) => {
      if (recordEvent) await recordEvent({ session_id: sessionId, conversation_id: conversation.id, phone,
        customer_name: conversation.name, created_at: new Date().toISOString(), option, message: text.slice(0, 4000),
        result: result.result || (result.lead_id ? "lead_created" : result.order_id ? "order_recorded" : result.task_id ? "support_recorded" : "response"),
        conversation_status: conversation.human_takeover ? "human_handoff" : "open",
        ...Object.fromEntries(Object.entries(result).filter(([k]) => ["metric", "new_conversation", "lead_id", "order_id", "task_id", "handoff"].includes(k))) });
    };
    if (isMenuGreeting(text)) {
      const first = !conversation.ivr_started_at;
      await save({ human_takeover: false, ivr: { stage: "menu", path: [] }, ivr_started_at: conversation.ivr_started_at || new Date().toISOString() });
      await sendText(sessionId, phone, conversation.id, menuText(config));
      await emit("Main Menu", { new_conversation: first });
      return true;
    }
    if (conversation.human_takeover) return true;
    let state = conversation.ivr || { stage: "menu", path: [] };
    if (/^back$/i.test(text)) {
      const path = state.stage === "menu" ? (state.path || []).slice(0, -1) : state.path || [];
      await save({ ivr: { stage: "menu", path } });
      await sendText(sessionId, phone, conversation.id, menuText(config, path));
      return true;
    }
    let output, selected;
    const ctx = { sessionId, conversation, phone, config, state };
    if (/^(agent|human|sales person|talk to someone|call me|need help|representative)$/i.test(text)) {
      selected = { label: "Human Assistance", human_request: true, action: state.path?.[0] === 5 ? "support" : "sales" };
      output = await actions.start(selected.action, selected, ctx);
    } else if (state.stage !== "menu") {
      output = await actions.next(text, state, ctx);
    } else {
      const node = nodeAt(config, state.path || []);
      const index = /^[1-9]$/.test(text) ? Number(text) - 1 : -1;
      selected = node.options?.[index];
      if (!selected) {
        await sendText(sessionId, phone, conversation.id, `Please choose a listed option.\n\n${menuText(config, state.path || [])}`);
        return true;
      }
      if (selected.options?.length || selected.action === "menu") {
        const path = [...(state.path || []), index];
        output = { text: menuText(config, path), state: { stage: "menu", path } };
      } else if (!selected.action || selected.action === "message") {
        output = selected.handoff ? await actions.start("sales", selected, ctx) :
          { text: (selected.response || "Please reply AGENT for assistance.") + "\n0: Main Menu", state };
      } else {
        output = await actions.start(selected.action, selected, ctx);
        if (selected.response && ["catalogue", "category", "product_search", "order_status"].includes(selected.action))
          output.text = selected.response + "\n\n" + output.text;
      }
    }
    if (output.state) await save({ ivr: output.state });
    if (output.customer_name) await save({ name: output.customer_name });
    if (output.handoff) await save({ human_takeover: true, assigned_to: output.assigned_to || conversation.assigned_to || null });
    await sendText(sessionId, phone, conversation.id, output.text);
    await emit(selected?.label || state.label || output.state?.product_name || state.product_name || state.stage, output);
    return true;
  }
  return async function runIvr(sessionId, conversation, phone, body) {
    const key = `${sessionId}:${conversation.id}`;
    const work = (queues.get(key) || Promise.resolve()).catch(() => {}).then(async () => {
      const current = getConversation ? await getConversation(conversation.id, sessionId) : conversation;
      if (!current) throw new Error("Conversation is no longer bound to this WhatsApp session.");
      return runConversation(sessionId, current, phone, body);
    });
    queues.set(key, work);
    try { return await work; }
    finally { if (queues.get(key) === work) queues.delete(key); }
  };
}
module.exports = { createIvrRunner, menuText, normalizeConfig };