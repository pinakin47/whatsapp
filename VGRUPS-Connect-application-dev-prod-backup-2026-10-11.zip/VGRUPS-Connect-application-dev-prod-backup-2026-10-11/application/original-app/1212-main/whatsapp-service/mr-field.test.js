const test = require("node:test");
const assert = require("node:assert/strict");
const { createMrIvrRunner } = require("./mr-reporting-flow");
const { inboundContent } = require("./incoming");
function fixture() {
  const tables = {
    app_config: [{ key: "mr_ivr", value: { enabled: true } }],
    mr_directory: [{ id: "mr", name: "Synthetic MR", employee_id: "M1", email: "mr@example.com", phone: "+15550001111", active: true }],
    users: [{ id: "account", email: "mr@example.com", role: "mr", active: true }, { id: "admin", role: "admin", active: true }],
    mr_ivr_profiles: [{ id: "mr", value: { ivr_enabled: true, field_flow_enabled: true, closing_deadline: "21:00" } }],
    conversations: [{ id: "chat", session_id: "qr" }],
  };
  const matches = (row, q) => Object.entries(q).every(([k,v]) => v && typeof v === "object" ?
    Object.entries(v).every(([op,x]) => op === "$ne" ? row[k] !== x : op === "$in" ? x.includes(row[k]) :
      op === "$exists" ? (row[k] !== undefined) === x : op === "$gte" ? row[k] >= x : op === "$lt" ? row[k] < x : false) : row[k] === v);
  const db = { collection(name) {
    const rows = tables[name] ||= [];
    return {
      find(q = {}) { return { async toArray() { return structuredClone(rows.filter(r => matches(r,q))); } }; },
      async findOne(q) { return structuredClone(rows.find(r => matches(r,q)) || null); },
      async updateOne(q, u, opts = {}) {
        let row = rows.find(r => matches(r,q)), added = false;
        if (!row && opts.upsert) { row = { ...q, ...structuredClone(u.$setOnInsert || {}) }; rows.push(row); added = true; }
        if (row) Object.assign(row, structuredClone(u.$set || {}));
        return { matchedCount: row ? 1 : 0, upsertedId: added ? row.id : null };
      },
    };
  } };
  const sent = [], now = () => new Date("2026-10-05T08:00:00+05:30");
  const runner = createMrIvrRunner({ getDatabase: () => db, sendText: async (...args) => sent.push(args[3]), now });
  return { tables, db, runner, sent, async run(...steps) {
    for (const body of steps) await runner("qr", tables.conversations[0], "15550001111", body);
    return sent.at(-1);
  } };
}
async function start(f) { await f.run("FIELD", "1", "2"); }
async function visit(f, result = "1") {
  await f.run("DAY VISIT", "1", "Synthetic Doctor", "Promotion", "Product", "1000", "Call tomorrow", "NO REMARKS", result);
  if (result === "3") await f.run("2026-10-06");
}
test("new menu is alongside unchanged legacy numbers, can return without losing legacy drafts", async () => {
  const f = fixture();
  assert.match(await f.run("PLAN"), /3. View my target.*4. Talk to manager/s);
  assert.match(f.sent.at(-1), /7. Full field activity/);
  await f.run("1", "2");
  const old = structuredClone(f.tables.conversations[0].mr_ivr);
  await f.run("FIELD", "HELP", "PLAN");
  assert.equal(f.tables.conversations[0].mr_ivr.field, old.field);
  assert.deepEqual(f.tables.conversations[0].mr_ivr.data, old.data);
  const g = fixture(); assert.match(await g.run("7"), /FIELD ACTIVITY/);
});
test("typed location is not GPS evidence; actual valid pin is persisted with recorded timestamp", async () => {
  const f = fixture(); await f.run("START", "1");
  assert.match(f.sent.at(-1), /No valid location pin/);
  assert.equal(f.tables.mr_field_days[0].location, undefined);
  await f.runner("qr",f.tables.conversations[0],"15550001111","[location]",{location:{degreesLatitude:12.5,degreesLongitude:77.5},message_id:"pin"});
  assert.equal(f.tables.mr_field_days[0].location.latitude,12.5);
  assert.match(f.sent.at(-1),/not live tracking/);
  assert.equal(inboundContent({key:{remoteJid:"15550001111@s.whatsapp.net"},message:{ephemeralMessage:{message:{locationMessage:{degreesLatitude:12.5,degreesLongitude:77.5}}}}}).location.degreesLongitude,77.5);
});
test("visit details completion and unavailable/reschedule persist without fabricating sales orders", async () => {
  const f = fixture(); await start(f); await visit(f);
  await visit(f,"2"); await visit(f,"3");
  assert.deepEqual(f.tables.field_visits.filter(v=>v.planned_date==="2026-10-05").map(v=>v.status),["visited","unavailable","rescheduled"]);
  assert.equal(f.tables.field_visits.find(v=>v.rescheduled_from)?.planned_date,"2026-10-06");
  assert.equal(f.tables.field_visits[0].reported_order_value,1000);
  assert.equal(f.tables.field_visits[0].visit_type,"Doctor");
  assert.equal(f.tables.orders?.length || 0,0);
  assert.match(await f.run("STATUS"),/Completed recorded visits: 1/);
});
test("midday reminders have their own number mapping and leave real visit drafts resumable", async () => {
  const f = fixture(); await start(f); await f.run("DAY VISIT","1","Synthetic Doctor");
  const before = structuredClone(f.tables.conversations[0].mr_field_state.data);
  f.tables.conversations[0].mr_field_invitation={id:"check",date:"2026-10-05",kind:"midday"};
  assert.match(await f.run("1"),/draft is saved/);
  await f.run("MIDDAY","3");
  assert.equal(f.tables.mr_field_days[0].midday_status,"meeting");
  await f.run("RESUME"); assert.deepEqual(f.tables.conversations[0].mr_field_state.data,before);
  await f.run("FIELD"); f.tables.conversations[0].mr_field_invitation={id:"remind",date:"2026-10-05",kind:"midday_reminder"};
  await f.run("3"); assert.equal(f.tables.mr_field_days[0].midday_status,"returning");
});
test("closing yes/no, preview edit, pending resume and confirmed submit preserve immutable report snapshots", async () => {
  const f=fixture(); await start(f); await visit(f);
  await f.run("CLOSING","1","1","0","0","0","2","2","1","NO REMARKS");
  assert.match(f.sent.at(-1),/DAY CLOSING SUMMARY/);
  assert.equal(f.tables.mr_report_submissions?.length || 0,0);
  await f.run("LATER","FIELD","PENDING");
  assert.match(f.sent.at(-1),/DAY CLOSING SUMMARY/);
  await f.run("2","1","1","0","0","0","1","₹25,000","2","1","Good day","1");
  assert.match(f.sent.at(-1),/COMPLETED/);
  assert.equal(f.tables.mr_daily_reports[0].closing.sales,25000);
  assert.equal(f.tables.mr_daily_reports[0].closing.new_leads,2);
  assert.equal(f.tables.mr_report_submissions.length,1);
  await f.run("CLOSING","1");
  assert.equal(f.tables.mr_report_submissions.length,1);
  assert.equal(f.tables.mr_field_days[0].closing_status,"completed");
});
test("orders and follow-ups are reviewed notes; leave and manager reasons have truthful pending/assignment statuses", async () => {
  const f=fixture(); await start(f);
  await f.run("ORDER","Synthetic customer","250","Product","1");
  await f.run("FOLLOWUP","Synthetic doctor","Call tomorrow","1");
  assert.equal(f.tables.mr_field_entries.length,2); assert.equal(f.tables.orders?.length ||0,0);
  await f.run("MANAGER","5");
  assert.equal(f.tables.mr_manager_requests[0].reason,"Personal Emergency");
  assert.equal(f.tables.conversations[0].assigned_to,"admin");
  await f.run("FIELD","LEAVE","Personal leave");
  assert.equal(f.tables.mr_leave_requests[0].status,"pending");
  assert.equal(f.tables.mr_field_days[0].status,"on_leave");
});
test("customers, wrong sessions, disabled profiles and duplicate WhatsApp messages cannot record activity", async () => {
  const f=fixture();
  assert.equal(await f.runner("qr",f.tables.conversations[0],"15550009999","START"),false);
  await assert.rejects(f.runner("wrong",f.tables.conversations[0],"15550001111","START"),/QR session/);
  await f.runner("qr",f.tables.conversations[0],"15550001111","START",{message_id:"same"});
  const n=f.sent.length;
  await f.runner("qr",f.tables.conversations[0],"15550001111","START",{message_id:"same"});
  assert.equal(f.sent.length,n);
  f.tables.mr_ivr_profiles[0].value.field_flow_enabled=false;
  await f.run("DAY VISIT"); assert.equal(f.tables.field_visits?.length||0,0);
});
test("shared evening invitation does not reinterpret 2 as view today's plan", async () => {
  const f=fixture(); await start(f);
  f.tables.conversations[0].mr_invitation={id:"evening",phase:"closing",date:"2026-10-05"};
  assert.match(await f.run("2"),/PENDING/);
  await f.run("PENDING"); assert.match(f.sent.at(-1),/Step 1 of 8/);
});
test("scheduled midday 1 and reminder 4 never become start day or mark leave", async () => {
  const f=fixture(); await start(f);
  f.tables.conversations[0].mr_field_invitation={id:"check1",date:"2026-10-05",kind:"midday"};
  await f.run("1"); assert.equal(f.tables.mr_field_days[0].midday_status,"field_visits_continuing");
  const g=fixture(); await start(g);
  g.tables.conversations[0].mr_field_invitation={id:"reminder4",date:"2026-10-05",kind:"midday_reminder"};
  await g.run("4"); assert.equal(g.tables.conversations[0].mr_field_state.step,"manager_reason");
  assert.equal(g.tables.mr_leave_requests?.length||0,0);
});
test("closing resumes after midday interruption without losing the previously paused visit draft", async () => {
  const f=fixture(); await start(f);
  await f.run("DAY VISIT","1","Synthetic Doctor","CLOSING","2","MIDDAY","1","RESUME");
  const s=f.tables.conversations[0].mr_field_state;
  assert.equal(s.step,"closing_form"); assert.equal(s.cursor,1);
  assert.equal(s.data.completed_visits,2);
  assert.equal(s.paused.step,"visit_form");
  assert.equal(s.paused.data.name,"Synthetic Doctor");
});
