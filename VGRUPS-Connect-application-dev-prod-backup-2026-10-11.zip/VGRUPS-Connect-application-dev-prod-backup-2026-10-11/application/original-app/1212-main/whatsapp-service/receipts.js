// Keep stage times only when WhatsApp supplied them; an ACK has no exact time.
const ranks = { sent: 1, failed: 2, error: 2, delivered: 3, read: 4, played: 4 };
const fields = ["status", "status_at", "sent_at", "delivered_at", "read_at", "failed_at", "provider_status"];
function providerTime(value) {
  if (value == null || typeof value === "boolean") return null;
  const seconds = Number(value);
  const date = typeof value === "string" && !Number.isFinite(seconds)
    ? (/(Z|[+-]\d{2}:\d{2})$/.test(value) ? new Date(value) : new Date(NaN))
    : new Date(seconds > 0 ? seconds * 1000 : NaN);
  return Number.isFinite(date.getTime()) ? date.toISOString() : null;
}
const stageOf = status => ({ played: "read", error: "failed" })[status] || status;
function mergeReceipt(message, status, timestamp) {
  const next = Object.fromEntries(fields.map(key => [key, message[key] ?? null]));
  const at = providerTime(timestamp);
  const key = `${stageOf(status)}_at`;
  if (at) {
    const old = providerTime(next[key]);
    next[key] = old && old < at ? old : at;
  }
  if (ranks[status] > (ranks[next.status] || 0)) {
    next.status = status;
    next.status_at = next[key];
  } else if (stageOf(status) === stageOf(next.status)) next.status_at = next[key];
  const ack = { sent: 2, delivered: 3, read: 4, played: 5 }[status];
  if (ack) next.provider_status = Math.max(Number(next.provider_status) || 0, ack);
  return next;
}
async function applyReceipt(messages, wamid, status, timestamp) {
  if (!wamid || !ranks[status]) return;
  for (;;) {
    const message = await messages.findOne({ wamid });
    if (!message) return;
    const next = mergeReceipt(message, status, timestamp);
    if (fields.every(key => (message[key] ?? null) === next[key])) return;
    const selector = { wamid, ...Object.fromEntries(fields.map(key => [key, message[key] ?? null])) };
    const result = await messages.updateOne(selector, { $set: next });
    if (result.matchedCount) return;
  }
}
async function reconcileReceipts(messages, wamid) {
  const evidence = await messages.database.collection("whatsapp_receipts").findOne({ wamid });
  if (!evidence) return;
  for (const stage of ["sent", "failed", "delivered", "read"]) {
    if (evidence[`${stage}_at`]) await applyReceipt(messages, wamid, stage, evidence[`${stage}_at`]);
  }
  if (ranks[evidence.status]) await applyReceipt(messages, wamid, evidence.status, null);
}
async function saveReceipt(messages, wamid, status, timestamp) {
  if (!wamid || !ranks[status]) return;
  const evidence = messages.database.collection("whatsapp_receipts");
  await evidence.updateOne({ wamid }, { $setOnInsert: { wamid } }, { upsert: true });
  await applyReceipt(evidence, wamid, status, timestamp);
  await reconcileReceipts(messages, wamid);
}
async function ingestUserReceipts(messages, updates) {
  for (const { key, receipt } of updates) {
    if (!key?.fromMe || !key.id || !receipt) continue;
    if (receipt.receiptTimestamp != null)
      await saveReceipt(messages, key.id, "delivered", receipt.receiptTimestamp);
    if (receipt.readTimestamp != null)
      await saveReceipt(messages, key.id, "read", receipt.readTimestamp);
    if (receipt.playedTimestamp != null)
      await saveReceipt(messages, key.id, "read", receipt.playedTimestamp);
  }
}
async function ingestStatusUpdates(messages, updates) {
  const map = { 2: "sent", 3: "delivered", 4: "read", 5: "read" };
  for (const { key, update } of updates) {
    if (!key?.fromMe || !key.id || !map[update?.status]) continue;
    // Baileys puts the receipt node's `t` into this field on live status updates.
    // History/echo messageTimestamp is the send time and must NOT use this path.
    await saveReceipt(messages, key.id, map[update.status], update.messageTimestamp);
  }
}
module.exports = { providerTime, mergeReceipt, saveReceipt, reconcileReceipts, ingestUserReceipts, ingestStatusUpdates };
