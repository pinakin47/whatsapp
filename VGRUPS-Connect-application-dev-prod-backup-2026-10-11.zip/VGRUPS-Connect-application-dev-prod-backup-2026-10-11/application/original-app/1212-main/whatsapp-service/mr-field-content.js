const TYPES = ["Doctor", "Hospital", "Clinic", "Pharmacy / Medical Shop", "Distributor / Stockist", "Diagnostic Centre", "Institution", "Other Customer"];
const REASONS = ["Customer Issue", "Order Issue", "Field/Travel Issue", "Reporting Issue", "Personal Emergency", "Other"];
const STATUSES = ["Field Visits Continuing", "Visits Completed", "Customer Meeting in Progress", "Returning to Office", "Need Manager Assistance"];
const STATUS_KEYS = ["field_visits_continuing", "visits_completed", "meeting", "returning", "manager_needed"];
const numbered = values => values.map((v, i) => `${i + 1} — ${v}`).join("\n");
const MENU = "VGRUPS HEALTHCARE — FIELD ACTIVITY\n1 — START DAY VISIT\n2 — VIEW TODAY'S PLAN\n3 — TALK TO MANAGER\n4 — MARK LEAVE\nDAY VISIT: Record visit | STATUS: Progress | CLOSING: Close day\nORDER: Report order note | FOLLOWUP: Record follow-up | PENDING: Resume closing\nPLAN: Original planning menu | HELP: Commands";
const HELP = "START / START DAY VISIT — Start day\nFIELD — Field activity menu\nDAY VISIT — Record or resume a visit\nSTATUS — Today's recorded progress\nMIDDAY — Answer field status check\nORDER — Report order note (not an actual sales order)\nFOLLOWUP — Record follow-up\nCLOSING — Day closing\nPENDING — Resume pending closing\nMANAGER — Manager assistance\nLEAVE — Leave request\nHELP — Get assistance\nBACK — Previous question\nLATER — Save current draft\nRESUME — Resume paused draft\nCANCEL — Discard current draft; saved records remain\nPLAN — Original planning menu";
const VISIT_FIELDS = [
  ["name", "Please enter the doctor/customer's name.", "text"],
  ["purpose", "Visit purpose?", "text"],
  ["products", "Products discussed? Reply SKIP if none.", "optional"],
  ["order_value", "Order value reported for this visit in INR? Enter 0 if none. This records a note, not a sales order.", "money"],
  ["followup", "Follow-up required? Describe it or reply SKIP.", "optional"],
  ["remarks", "Visit remarks? Reply NO REMARKS if none.", "optional"],
];
const CLOSE_FIELDS = [
  ["completed_visits", "How many total field visits did you complete today?", "int", 1],
  ["doctor_visits", "How many doctors did you meet?", "int", 2],
  ["hospital_visits", "How many hospitals/clinics did you visit?", "int", 3],
  ["pharmacy_visits", "How many pharmacies/medical shops?", "int", 4],
  ["distributor_visits", "How many distributors/stockists?", "int", 5],
  ["orders_yes", "Any orders today? 1 — YES 2 — NO", "yes", 6],
  ["sales", "Today's total reported order value in INR? Example: INR 25,000", "money", 6],
  ["new_leads", "How many new customers/leads were generated?", "int", 7],
  ["followup_count", "How many customer/doctor follow-ups are required? Enter 0 if none.", "int", 7],
  ["remarks", "Important remarks? Reply NO REMARKS if none.", "optional", 8],
];
const ENTRY_FIELDS = {
  order: [["customer", "Order customer name?", "text"], ["value", "Reported order value in INR?", "money"], ["products", "Products / quantities? Reply SKIP if none.", "optional"]],
  followup: [["customer", "Customer/doctor name?", "text"], ["details", "Follow-up requirement?", "text"]],
};
function parseValue(text, type) {
  if (type === "yes") return /^(1|yes)$/i.test(text) ? true : /^(2|no)$/i.test(text) ? false : null;
  if (type === "money" || type === "int") {
    const clean = text.replace(/^(?:₹|INR|Rs\.?)\s*/i, "").replace(/,/g, "");
    if (!(type === "int" ? /^\d+$/ : /^\d+(?:\.\d{1,2})?$/).test(clean)) return null;
    const n = Number(clean);
    return Number.isFinite(n) && n <= (type === "int" ? 10000 : 1000000000) ? n : null;
  }
  if (!text || text.length > 2000) return null;
  return type === "optional" && /^(skip|no remarks|none)$/i.test(text) ? "" : text;
}
function closingSummary(mr, date, d) {
  return `VGRUPS HEALTHCARE — DAY CLOSING SUMMARY\n${mr.name} | ${date}\n` +
    `Total visits: ${d.completed_visits}\nDoctors: ${d.doctor_visits}\nHospitals/clinics: ${d.hospital_visits}\n` +
    `Pharmacies: ${d.pharmacy_visits}\nDistributors: ${d.distributor_visits}\nOrder value: INR ${d.sales || 0}\n` +
    `New leads: ${d.new_leads}\nFollow-ups: ${d.followup_count}\nRemarks: ${d.remarks || "No remarks"}\n` +
    "1 — SUBMIT REPORT\n2 — EDIT REPORT\n3 — TALK TO MANAGER";
}
module.exports = { TYPES, REASONS, STATUSES, STATUS_KEYS, numbered, MENU, HELP, VISIT_FIELDS, CLOSE_FIELDS, ENTRY_FIELDS, parseValue, closingSummary };
