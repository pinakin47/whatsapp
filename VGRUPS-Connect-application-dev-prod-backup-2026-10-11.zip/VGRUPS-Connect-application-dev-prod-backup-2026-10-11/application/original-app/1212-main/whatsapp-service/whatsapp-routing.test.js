const test = require("node:test");
const assert = require("node:assert/strict");
const { mrSessionAllowed, explicitOrSoleSession } = require("./whatsapp-routing");

test("two connected numbers never result in an arbitrary sender", () => {
  const sessions = { mr: { status: "connected" }, sales: { status: "connected" } };
  assert.equal(explicitOrSoleSession(sessions), null);
  assert.equal(explicitOrSoleSession(sessions, "sales"), "sales");
  sessions.sales.status = "disconnected";
  assert.equal(explicitOrSoleSession(sessions), "mr");
  assert.equal(explicitOrSoleSession(sessions, "sales"), "sales");
});

test("MR inbound processing is restricted to assigned number", async () => {
  const db = { collection: () => ({ findOne: async () => ({ value: { mr_session_id: "mr" } }) }) };
  assert.equal(await mrSessionAllowed(db, "mr"), true);
  assert.equal(await mrSessionAllowed(db, "sales"), false);
});

test("one linked account is automatic, multiple unassigned accounts are not", async () => {
  const rows = [{ id: "mr", phone: "15551111111" }];
  const db = { collection: () => ({ findOne: async () => null, find: () => ({ toArray: async () => rows }) }) };
  assert.equal(await mrSessionAllowed(db, "mr"), true);
  rows.push({ id: "sales", phone: "15552222222" });
  assert.equal(await mrSessionAllowed(db, "mr"), false);
});
