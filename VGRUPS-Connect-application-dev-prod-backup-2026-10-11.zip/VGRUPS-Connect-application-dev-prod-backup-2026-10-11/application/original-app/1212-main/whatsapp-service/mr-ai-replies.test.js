const test = require("node:test");
const assert = require("node:assert/strict");
const { aiCandidate, queueMrAiReply } = require("./mr-ai-replies");

function fixture() {
  const tables = {
    app_config: [{ key: "mr_lead_capture", value: { enabled: true, authorized_messages_confirmed: true,
      ai_auto_reply: true, ai_reply_enabled_since: "2026-10-01" } },
      { key: "whatsapp_number_routing", value: { mr_session_id: "session" } }],
    mr_directory: [{ id: "dir", phone: "+919000000001", email: "mr@example.test", active: true }],
    users: [{ id: "mr", email: "mr@example.test", role: "mr", active: true }],
    mr_ivr_profiles: [], mr_ai_replies: [],
  };
  const match = (row, q) => Object.entries(q).every(([k, v]) =>
    v && typeof v === "object" && "$ne" in v ? row[k] !== v.$ne : row[k] === v);
  const db = { collection(name) {
    return {
      findOne: async q => tables[name].find(r => match(r, q)) || null,
      updateOne: async (q, u) => { if (!tables[name].some(r => match(r, q))) tables[name].push(u.$setOnInsert); },
    };
  } };
  const conv = { id: "conv", phone: "919000000001", session_id: "session" };
  const msg = { id: "msg", wamid: "provider-msg", conversation_id: "conv", session_id: "session",
    direction: "inbound", type: "text", body: "How do I complete my daily report?", created_at: "2026-10-06" };
  return { tables, db, conv, msg };
}

test("MR lead and reporting questions queue once without blocking on OpenAI", async () => {
  const f = fixture();
  assert.equal(await queueMrAiReply(f.db, f.conv, f.msg), true);
  assert.equal(await queueMrAiReply(f.db, f.conv, f.msg), true);
  assert.equal(f.tables.mr_ai_replies.length, 1);
  assert.equal(f.tables.mr_ai_replies[0].mr_id, "mr");
});

test("customers, outbound messages, another session and pre-activation history are excluded", async () => {
  for (const change of [
    { conv: { phone: "919000000099" } }, { msg: { direction: "outbound" } },
    { msg: { session_id: "other" } }, { msg: { created_at: "2026-09-30" } },
    { msg: { is_demo: true } }, { msg: { capture_skip: true } },
  ]) {
    const f = fixture();
    assert.equal(await queueMrAiReply(f.db, { ...f.conv, ...change.conv }, { ...f.msg, ...change.msg }), false);
    assert.equal(f.tables.mr_ai_replies.length, 0);
  }
});

test("menus, numeric answers and normal reporting drafts retain existing handling", () => {
  for (const body of ["PLAN", "CLOSING", "FIELD", "1", "1000", "BACK", "DONE", "CANCEL", "hello", "HELP", "MANAGER"])
    assert.equal(aiCandidate({}, body), false, body);
  const drafting = { mr_ivr: { field: "visits", data: {} } };
  assert.equal(aiCandidate(drafting, "Sample Clinic | Pune | Follow-up"), false);
  assert.equal(aiCandidate(drafting, "How should I format a visit?"), true);
  assert.equal(aiCandidate(drafting, "Can I finish this report later?"), true);
  assert.equal(aiCandidate(drafting, "Whyte Clinic - Pune"), false);
  assert.equal(aiCandidate(drafting, "LEAD WHL-1 9000000100", true), true);
});

test("disabled AI, human takeover, opt-out and individually disabled MR are quiet", async () => {
  for (const mode of ["off", "human", "optout", "profile"]) {
    const f = fixture();
    if (mode === "off") f.tables.app_config[0].value.ai_auto_reply = false;
    if (mode === "human") f.conv.human_takeover = true;
    if (mode === "optout") f.conv.opted_out = true;
    if (mode === "profile") f.tables.mr_ivr_profiles.push({ id: "dir", value: { ivr_enabled: false } });
    assert.equal(await queueMrAiReply(f.db, f.conv, f.msg), false);
  }
});

test("a queue failure preserves the existing MR menu fallback", async () => {
  const f = fixture();
  f.db.collection = () => ({ findOne: async () => { throw new Error("Synthetic database failure"); } });
  assert.equal(await queueMrAiReply(f.db, f.conv, f.msg), false);
});
