const test = require("node:test");
const assert = require("node:assert/strict");
const { enqueueLeadMessage, isPendingLeadReply } = require("./lead-capture");
class DB {
  constructor() {
    this.rows = {
      app_config: [{ key: "mr_lead_capture", value: { enabled: true, authorized_messages_confirmed: true, enabled_since: "2026-01-01" } },
                   { key: "whatsapp_number_routing", value: { mr_session_id: "session" } }],
      mr_directory: [{ id: "dir", email: "mr@example.test", phone: "+919000000001", active: true }],
      users: [{ id: "mr", email: "mr@example.test", role: "mr", active: true }],
      leads: [{ id: "lead", assigned_to: "mr", capture_status: "Phone Number Required" }],
      mr_lead_requests: [], mr_lead_queue: [],
    };
  }
  collection(name) {
    const rows = this.rows[name];
    const match = (row, q) => Object.entries(q).every(([k, v]) => v && typeof v === "object" && "$ne" in v ? row[k] !== v.$ne : row[k] === v);
    return {
      findOne: async q => rows.find(r => match(r, q)) || null,
      find: q => ({ toArray: async () => rows.filter(r => match(r, q)) }),
      updateOne: async (q, update) => { if (!rows.some(r => match(r, q))) rows.push(update.$setOnInsert); },
    };
  }
}
const conv = { id: "conv", phone: "919000000001" };
test("lead evidence enqueue is idempotent and ignores pre-consent history", async () => {
  const db = new DB();
  const msg = { id: "message", wamid: "wamid", conversation_id: "conv", session_id: "session", type: "text", body: "Hospital needs gloves", created_at: "2026-10-06" };
  await enqueueLeadMessage(db, msg);
  await enqueueLeadMessage(db, msg);
  await enqueueLeadMessage(db, { ...msg, id: "old", wamid: "old", created_at: "2025-01-01" });
  assert.equal(db.rows.mr_lead_queue.length, 1);
});
test("natural and explicit phone responses are consumed only for an active MR's pending lead", async () => {
  const db = new DB();
  assert.equal(await isPendingLeadReply(db, conv, "His number is 9876543210."), true);
  assert.equal(await isPendingLeadReply(db, conv, "LEAD WHL-2026-0001 9876543210"), true);
  assert.equal(await isPendingLeadReply(db, { ...conv, phone: "919999999999" }, "9876543210"), false);
});
test("numeric closing drafts are not interpreted as customer numbers", async () => {
  const db = new DB(), drafting = { ...conv, mr_field_state: { step: "closing_sales" } };
  assert.equal(await isPendingLeadReply(db, drafting, "9876543210"), false);
  assert.equal(await isPendingLeadReply(db, drafting, "His number is 9876543210."), true);
});
test("a quoted phone request is identifiable even during an existing draft", async () => {
  const db = new DB();
  db.rows.mr_lead_requests.push({ provider_id: "prompt", mr_id: "mr", channel: "whatsapp" });
  assert.equal(await isPendingLeadReply(db, { ...conv, mr_field_state: { step: "closing_sales" } }, "9876543210", "prompt"), true);
});
test("disabling capture does not consume any legacy MR responses", async () => {
  const db = new DB(); db.rows.app_config[0].value.enabled = false;
  assert.equal(await isPendingLeadReply(db, conv, "9876543210"), false);
});
