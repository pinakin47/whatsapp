const test = require("node:test");
const assert = require("node:assert/strict");
const { ingestStatusUpdates, ingestUserReceipts, saveReceipt, providerTime } = require("./receipts");
const { fixtureDatabase } = require("./receipt-fixture");

function fixture() {
  const row = { wamid: "exact", status: "sent", created_at: "2020-01-01T00:00:00Z" };
  let conflict = false;
  const messages = {
    database: fixtureDatabase(),
    async findOne({ wamid }) { return wamid === row.wamid ? { ...row } : null; },
    async updateOne(selector, update) {
      if (conflict) {
        conflict = false;
        Object.assign(row, { status: "read", read_at: "2026-10-05T08:00:08.000Z",
          status_at: "2026-10-05T08:00:08.000Z" });
        return { matchedCount: 0 };
      }
      const matches = Object.entries(selector).every(([k, v]) => (row[k] ?? null) === v);
      if (matches) Object.assign(row, update.$set);
      return { matchedCount: Number(matches) };
    },
  };
  return { row, messages, conflict() { conflict = true; } };
}
const key = { id: "exact", fromMe: true };
const event = (status, messageTimestamp) => ({ key, update: { status, messageTimestamp } });

test("direct-chat live ACK times survive delayed sent/delivered and duplicate read events", async () => {
  const f = fixture();
  await ingestStatusUpdates(f.messages, [
    event(4, 1791187208), event(3, 1791187203), event(2, 1791187201),
    event(4, 1791187212), event(3, 1791187205),
  ]);
  assert.equal(f.row.status, "read");
  assert.equal(f.row.read_at, "2026-10-05T08:00:08.000Z");
  assert.equal(f.row.delivered_at, "2026-10-05T08:00:03.000Z");
  assert.equal(f.row.status_at, f.row.read_at);
});
test("user receipts can supply independent delivered/read timestamps including Long-like values", async () => {
  const f = fixture();
  await ingestUserReceipts(f.messages, [{ key, receipt: {
    receiptTimestamp: { toString: () => "1791187203" }, readTimestamp: 1791187208,
  } }]);
  assert.equal(f.row.delivered_at, "2026-10-05T08:00:03.000Z");
  assert.equal(f.row.read_at, "2026-10-05T08:00:08.000Z");
  assert.equal(f.row.status, "read");
});
test("missing timestamps and read-only receipts do not manufacture delivered times", async () => {
  for (const value of [null, undefined, false, 0, -1, "bad", Infinity, "2026-10-05T08:00:00"]) {
    assert.equal(providerTime(value), null);
    const f = fixture();
    await ingestStatusUpdates(f.messages, [event(4, value)]);
    assert.equal(f.row.status, "read");
    assert.equal(f.row.read_at, null);
    assert.equal(f.row.delivered_at, null);
  }
});
test("a concurrent stronger receipt wins and ignored inbound/unknown IDs change nothing", async () => {
  const f = fixture();
  f.conflict();
  await saveReceipt(f.messages, "exact", "delivered", 1791187203);
  assert.equal(f.row.status, "read");
  assert.equal(f.row.status_at, f.row.read_at);
  const before = { ...f.row };
  await ingestStatusUpdates(f.messages, [{ key: { ...key, fromMe: false }, update: { status: 4, messageTimestamp: 1791187212 } }]);
  await saveReceipt(f.messages, "unrelated", "read", 1791187212);
  assert.deepEqual(f.row, before);
});
