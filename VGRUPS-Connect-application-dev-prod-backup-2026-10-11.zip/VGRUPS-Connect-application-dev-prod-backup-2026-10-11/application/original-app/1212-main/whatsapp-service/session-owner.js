// One gateway owns the entire wa_auth credential store in a database.
// Never use an environment-specific lock key: shared credentials need one lock.
const LOCK_KEY = "vgrups:wa_auth:gateway-owner";

function gatewayMode(env = process.env) {
  const mode = env.WA_GATEWAY_MODE || (env.REPLIT_DEPLOYMENT === "1" ? "enabled" : "disabled");
  if (!["enabled", "disabled"].includes(mode)) throw new Error("Invalid WA_GATEWAY_MODE");
  return mode;
}

async function acquireGatewayOwner(pool, onLost, { heartbeatMs = 3000 } = {}) {
  const client = await pool.connect();
  let active = false;
  let released = false;
  let connectionLost = false;
  let timer;
  let checking = false;
  const lose = () => {
    connectionLost = true;
    if (!active) return;
    active = false;
    clearInterval(timer);
    onLost();
  };
  client.on("error", lose);
  client.on("end", lose);
  try {
    const result = await client.query({
      text: "SELECT pg_try_advisory_lock(hashtextextended($1, 0)) AS acquired",
      values: [LOCK_KEY], query_timeout: 5000,
    });
    if (connectionLost) throw new Error("WhatsApp ownership connection closed during acquisition");
    if (!result.rows[0]?.acquired) {
      client.release(true);
      return null;
    }
    active = true;
    timer = setInterval(async () => {
      if (checking || !active) return;
      checking = true;
      try {
        await client.query({ text: "SELECT 1", query_timeout: 5000 });
      } catch {
        lose();
      } finally {
        checking = false;
      }
    }, heartbeatMs);
    timer.unref?.();
    return {
      assertOwned() {
        if (!active) throw new Error("WhatsApp session ownership is unavailable");
      },
      // Destroy the dedicated connection; do not return a session lock to a pool.
      release() {
        if (released) return;
        released = true;
        active = false;
        clearInterval(timer);
        client.release(true);
      },
    };
  } catch (error) {
    client.release(true);
    throw error;
  }
}

function singleFlight() {
  const pending = new Map();
  return (id, start) => {
    if (pending.has(id)) return pending.get(id);
    const promise = Promise.resolve().then(start).finally(() => pending.delete(id));
    pending.set(id, promise);
    return promise;
  };
}

function retryAfterDisconnect(code, reasons) {
  return code !== reasons.connectionReplaced && code !== reasons.loggedOut;
}

module.exports = { gatewayMode, acquireGatewayOwner, singleFlight, retryAfterDisconnect };
