// Keep credential snapshots ordered across socket replacements. Never store auth in a browser.
const queues = new WeakMap();
function authWriteQueue(collection, sessionId) {
  let sessions = queues.get(collection);
  if (!sessions) { sessions = new Map(); queues.set(collection, sessions); }
  if (!sessions.has(sessionId)) sessions.set(sessionId, Promise.resolve());
  return {
    wait: () => sessions.get(sessionId).catch(() => {}),
    run(operation) {
      const result = sessions.get(sessionId).catch(() => {}).then(operation);
      sessions.set(sessionId, result);
      // Mark rejection handled without hiding it from the caller or the next read.
      result.catch(() => {});
      return result;
    },
  };
}
module.exports = { authWriteQueue };
