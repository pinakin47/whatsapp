const { replyAddress } = require("./incoming");

// Only the already-selected QR provider may handle this reservation.
// No expired claim, retry, failure or missing receipt permits a second send.
async function sendReservedText({ requestId, to, text, sessionId, sock, requests, generateMessageId, onReserved }) {
  const address = replyAddress({ reply_jid: to }, to);
  if (!requestId) return sock.sendMessage(address, { text });
  if (!/^[a-f0-9]{64}$/.test(requestId)) throw new Error("Invalid send reservation");
  const selector = { id: requestId, state: "sending", provider: "qr",
    recipient_address: to, message_body: text };
  const messageId = generateMessageId(sock.user?.id);
  const claim = await requests.updateOne({ ...selector, gateway_message_id: null }, {
    $set: { gateway_message_id: messageId, gateway_session_id: sessionId },
  });
  if (claim.matchedCount !== 1) {
    throw new Error("Send reservation already submitted or unavailable. No second message was sent.");
  }
  // Persist AI metadata before any socket echo can enter capture again.
  if (onReserved) await onReserved(messageId);
  const result = await sock.sendMessage(address, { text }, { messageId });
  if (result?.key?.id) {
    await requests.updateOne({ id: requestId, gateway_message_id: messageId }, { $set: {
      gateway_accepted_wamid: result.key.id, gateway_accepted_at: new Date().toISOString(),
    } });
  }
  return result;
}

module.exports = { sendReservedText };

async function sendReservedMedia({ requestId, mediaKey, to, caption, sessionId, content, sock, requests, generateMessageId, onReserved }) {
  if (!requestId) return sock.sendMessage(replyAddress({ reply_jid: to }, to), content);
  if (!/^[a-f0-9]{64}$/.test(requestId) || !mediaKey) throw new Error("Invalid media reservation");
  const messageId = generateMessageId(sock.user?.id);
  const claim = await requests.updateOne({ id: requestId, state: "sending", provider: "qr",
    recipient_address: to, message_body: caption, media_key: mediaKey, gateway_message_id: null }, {
    $set: { gateway_message_id: messageId, gateway_session_id: sessionId },
  });
  if (claim.matchedCount !== 1) throw new Error("Media reservation already submitted; no second attachment was sent.");
  if (onReserved) await onReserved(messageId);
  const result = await sock.sendMessage(replyAddress({ reply_jid: to }, to), content, { messageId });
  if (result?.key?.id) await requests.updateOne({ id: requestId }, { $set: {
    gateway_accepted_wamid: result.key.id, gateway_accepted_at: new Date().toISOString(),
  } });
  return result;
}

module.exports.sendReservedMedia = sendReservedMedia;