// Lightweight ingestion only: AI and lead mutations run in the existing Python API.
const { createHash } = require("crypto");
const key = value => createHash("sha256").update(value).digest("hex");
const real = { deleted: { $ne: true }, is_demo: { $ne: true } };
const { mrSessionAllowed } = require("./whatsapp-routing");

async function enqueueLeadMessage(db, message) {
  try {
  if (!await mrSessionAllowed(db, message.session_id)) return;
  const row = await db.collection("app_config").findOne({ key: "mr_lead_capture" });
  const cfg = row?.value;
  if (!cfg?.enabled || !cfg.authorized_messages_confirmed || message.type !== "text" ||
      message.is_demo || message.capture_skip || !message.body ||
      !cfg.enabled_since || message.created_at < cfg.enabled_since) return;
  const id = key(`message:${message.wamid || message.id}`);
  await db.collection("mr_lead_queue").updateOne({ id }, { $setOnInsert: {
    id, message_id: message.id, conversation_id: message.conversation_id,
    status: "pending", attempts: 0, created_at: new Date().toISOString(),
  } }, { upsert: true });
  } catch {
    console.warn("Lead queue write failed; saved messages will be reconciled. Existing MR flows remain independent.");
  }
}

async function isPendingLeadReply(db, conversation, body, replyTo) {
  const cfg = (await db.collection("app_config").findOne({ key: "mr_lead_capture" }))?.value;
  if (!cfg?.enabled || !cfg.authorized_messages_confirmed) return false;
  const digits = body.replace(/[\s()+.-]/g, "");
  const explicit = /^LEAD\s+\S+\s+[\d+\s()-]+$/i.test(body.trim());
  const bare = /^(?:91)?[6-9]\d{9}$/.test(digits);
  const note = /[a-z]/i.test(body) && /^(?:(?:his|her|their|customer(?:'s)?|doctor(?:'s)?)\s+)?(?:(?:phone|mobile|contact)\s*)?(?:number\s*)?(?:is\s*|[:=-]\s*)?(?:\+?91[\s-]*)?[6-9](?:[\s-]*\d){9}[.!]?$/i.test(body.trim());
  if (!explicit && !bare && !note) return false;
  const draftOpen = (conversation.mr_field_state?.step || "menu") !== "menu" ||
      (conversation.mr_ivr?.field || "menu") !== "menu";
  const number = conversation.phone.replace(/\D/g, "");
  const dirs = await db.collection("mr_directory").find({ active: true, ...real }).toArray();
  const mr = dirs.find(r => r.phone.replace(/\D/g, "") === number);
  if (!mr) return false;
  const account = await db.collection("users").findOne({ email: mr.email.toLowerCase(), role: "mr", active: { $ne: false }, ...real });
  const mrId = account?.id || `directory:${mr.id}`;
  const quoted = replyTo && await db.collection("mr_lead_requests").findOne({ provider_id: replyTo, mr_id: mrId, channel: "whatsapp" });
  if (!explicit && !note && !quoted && draftOpen) return false;
  const pending = await db.collection("leads").findOne({ assigned_to: mrId, capture_status: "Phone Number Required", ...real });
  return Boolean(pending);
}

module.exports = { enqueueLeadMessage, isPendingLeadReply };
