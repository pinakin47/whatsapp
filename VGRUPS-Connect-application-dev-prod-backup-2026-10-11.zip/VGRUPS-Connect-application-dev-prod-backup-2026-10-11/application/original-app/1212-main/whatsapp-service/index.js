const express = require("express");
const pino = require("pino");
const QRCode = require("qrcode");
const { randomUUID } = require("crypto");
const { PostgresStore } = require("./postgresStore");
const { gatewayMode, acquireGatewayOwner, singleFlight, retryAfterDisconnect } = require("./session-owner");
const makeWASocket = require("@whiskeysockets/baileys").default;
const {
  DisconnectReason,
  fetchLatestBaileysVersion,
  makeCacheableSignalKeyStore,
  downloadMediaMessage,
  generateMessageIDV2,
} = require("@whiskeysockets/baileys");
const { usePostgresAuthState } = require("./postgresAuth");
const { replyAddress, isMenuGreeting, shouldAutomate } = require("./incoming");
const { syncMessage } = require("./message-sync");
const { ingestStatusUpdates, ingestUserReceipts } = require("./receipts");
const { sendReservedText, sendReservedMedia } = require("./send-reservation");
const { createIvrRunner } = require("./ivr");
const { createIvrActions } = require("./ivr-actions");
const { createMrIvrRunner } = require("./mr-reporting-flow");
const { queueMrAiReply } = require("./mr-ai-replies");
const { mrSessionAllowed, explicitOrSoleSession } = require("./whatsapp-routing");
const { inboundContent } = require("./incoming");
const DEFAULT_IVR = require("../ivr-default.json");

const PORT = process.env.WA_PORT || 3001;
const BACKEND_URL = process.env.BACKEND_INTERNAL_URL || "http://127.0.0.1:8001";
const WA_SECRET = process.env.WA_INTERNAL_SECRET || "";

const logger = pino({ level: "warn" });
const app = express();
app.use(express.json());

let db, authColl, sessColl, convColl, msgColl, contactsColl, leadsColl, configColl, consentColl, recipColl, positionsColl, candidatesColl, countersColl;
const sessions = {};
const closing = new Set();
const startOnce = singleFlight();
const reconnectTimers = new Map();
let owner = null;
let ownershipStatus = "starting";
const assertOwned = () => {
  if (!owner) throw new Error("WhatsApp gateway does not own this credential store");
  owner.assertOwned();
};

// Standby gateways must not read credentials, pair, send, logout, or delete.
app.use((req, res, next) => {
  if (ownershipStatus === "active" || req.path === "/health") return next();
  if (req.method === "GET" && req.path === "/sessions") {
    return res.json({ sessions: [], connected: false, gateway_status: ownershipStatus });
  }
  return res.status(409).json({ error: "WhatsApp gateway is not the session owner", gateway_status: ownershipStatus });
});

const uid = () => randomUUID().replace(/-/g, "");
const nowIso = () => new Date().toISOString();
const jidOf = (num) => num.replace(/\D/g, "") + "@s.whatsapp.net";
const numOf = (jid) => (jid || "").split("@")[0].split(":")[0];

const DEFAULT_BOT = {
  enabled: false,
  welcome: "👋 Welcome to VGRUPS Healthcare! We're glad you reached out.",
  askName: "To help you better, may I know your name?",
  askProduct: "Which product are you interested in? (e.g. VD3K2, Nitrile Gloves, N95 Masks)",
  askQuantity: "Great! How many units do you need?",
  handoff: "Thank you! 🙏 Our sales team will contact you shortly with pricing and availability.",
};
let botCache = null, botCacheAt = 0;
async function loadBotConfig() {
  if (botCache && Date.now() - botCacheAt < 15000) return botCache;
  const doc = await configColl.findOne({ key: "bot" });
  botCache = (doc && doc.value) || DEFAULT_BOT;
  botCacheAt = Date.now();
  return botCache;
}

let flowCache = null, flowCacheAt = 0;
async function loadFlow() {
  if (flowCache && Date.now() - flowCacheAt < 15000) return flowCache;
  const doc = await configColl.findOne({ key: "chatbot_flow" });
  flowCache = (doc && doc.value) || { enabled: false, nodes: [] };
  flowCacheAt = Date.now();
  return flowCache;
}

let ivrCache = null, ivrCacheAt = 0;
async function loadIvr() {
  if (ivrCache && Date.now() - ivrCacheAt < 15000) return ivrCache;
  const doc = await configColl.findOne({ key: "ivr" });
  ivrCache = (doc && doc.value) || DEFAULT_IVR;
  ivrCacheAt = Date.now();
  return ivrCache;
}

const runCustomerIvr = createIvrRunner({
  loadConfig: loadIvr,
  sendText: (...args) => sendText(...args),
  updateConversation: (id, values) => convColl.updateOne({ id }, { $set: values }),
  getConversation: (id, sessionId) => convColl.findOne({ id, session_id: sessionId }),
  actions: createIvrActions({ getDatabase: () => db }),
  recordEvent: event => db.collection("ivr_events").insertOne({ id: uid(), ...event }),
});
const runMrIvr = createMrIvrRunner({ getDatabase: () => db, sendText: (...args) => sendText(...args) });
const runIvr = async (...args) =>
  (await mrSessionAllowed(db, args[0]) && await runMrIvr(...args)) || await runCustomerIvr(...args);

function renderVars(text, data) {
  return (text || "").replace(/\{([^}]+)\}/g, (m, k) => {
    const v = data[k.trim()];
    return v != null && v !== "" ? String(v) : m;
  });
}

function menuText(node, data) {
  const opts = (node.options || []).map((o, i) => `${i + 1}. ${o.label}`).join("\n");
  const head = renderVars(node.text, data);
  return `${head}\n\n${opts}\n\n_Reply with a number (e.g. 1)_`;
}

async function flowCreateLead(phone, data) {
  let contact = await contactsColl.findOne({ mobile: "+" + phone }) || await contactsColl.findOne({ mobile: phone });
  let contactId;
  const nm = data.name || data.Name || "WhatsApp Lead";
  if (contact) { contactId = contact.id; }
  else {
    contactId = uid();
    await contactsColl.insertOne({
      id: contactId, name: nm, mobile: "+" + phone, email: null, company: null,
      contact_type: "lead", address: null, city: null, state: null, pincode: null, gst: null,
      category: null, source: "whatsapp", assigned_to: null, tags: ["chatbot"], notes: "",
      opted_out: false, is_demo: false, deleted: false, created_at: nowIso(), updated_at: nowIso(),
    });
  }
  const notes = Object.entries(data).map(([k, v]) => `${k}: ${v}`).join(" | ");
  await leadsColl.insertOne({
    id: uid(), title: `WhatsApp enquiry - ${nm}`, contact_id: contactId, contact_name: nm,
    mobile: "+" + phone, company: null, status: "new", source: "whatsapp", value: 0, specialty: null,
    assigned_to: null, tags: ["chatbot"], notes, is_demo: false, deleted: false,
    created_at: nowIso(), updated_at: nowIso(), last_contact: nowIso(),
  });
  return contactId;
}

// Flow engine: returns true if the flow handled the message (so linear bot is skipped)
async function runFlow(sessionId, conv, phone, body) {
  const flow = await loadFlow();
  if (!flow.enabled || !Array.isArray(flow.nodes) || flow.nodes.length === 0) return false;
  if (conv.human_takeover) return true;

  const lower = body.trim().toLowerCase();
  if (["agent", "human", "representative", "support", "talk to agent"].includes(lower)) {
    await convColl.updateOne({ id: conv.id }, { $set: { human_takeover: true } });
    await sendText(sessionId, phone, conv.id, "Connecting you to our team. A representative will reply here shortly. 🙋");
    return true;
  }

  const map = {};
  flow.nodes.forEach((n) => { map[n.id] = n; });
  const data = conv.flow_data || {};
  const waiting = conv.flow_node;
  let nextId;

  if (!waiting && !conv.flow_started) {
    nextId = flow.start;
  } else if (waiting) {
    const node = map[waiting];
    if (!node) { nextId = flow.start; }
    else if (node.type === "menu") {
      const choice = parseInt(body.trim(), 10);
      const opt = node.options && node.options[choice - 1];
      if (!opt) { await sendText(sessionId, phone, conv.id, menuText(node, data)); return true; }
      nextId = opt.next;
    } else if (node.type === "question") {
      data[node.field || node.id] = body.trim();
      nextId = node.next;
    } else {
      nextId = node.next;
    }
  } else {
    nextId = flow.start;
  }

  // Walk forward, executing message/action nodes until a waiting node or the end.
  let current = nextId;
  let guard = 0;
  let newWaiting = null;
  while (current && guard < 30) {
    guard++;
    const node = map[current];
    if (!node) break;
    if (node.type === "message") {
      await sendText(sessionId, phone, conv.id, renderVars(node.text, data));
      current = node.next;
    } else if (node.type === "action") {
      const kind = (node.action && node.action.kind) || "";
      if (kind === "create_lead") {
        await flowCreateLead(phone, data);
      } else if (kind === "add_tag") {
        const tag = (node.action && node.action.tag) || "chatbot";
        await contactsColl.updateMany({ mobile: { $in: ["+" + phone, phone] } }, { $addToSet: { tags: tag } });
      } else if (kind === "handoff") {
        await convColl.updateOne({ id: conv.id }, { $set: { human_takeover: true } });
        if (node.text) await sendText(sessionId, phone, conv.id, renderVars(node.text, data));
        current = null;
        break;
      }
      current = node.next;
    } else if (node.type === "menu") {
      await sendText(sessionId, phone, conv.id, menuText(node, data));
      newWaiting = node.id;
      break;
    } else if (node.type === "question") {
      await sendText(sessionId, phone, conv.id, renderVars(node.text, data));
      newWaiting = node.id;
      break;
    } else {
      current = node.next;
    }
  }

  await convColl.updateOne({ id: conv.id },
    { $set: { flow_node: newWaiting, flow_data: data, flow_started: true } });
  return true;
}

async function persistMeta(id) {
  const s = sessions[id];
  if (!s) return;
  await sessColl.updateOne(
    { id },
    { $set: { id, name: s.name, status: s.status, phone: s.phone, updated_at: nowIso() },
      $setOnInsert: { created_at: nowIso() } },
    { upsert: true }
  );
}

async function sendText(sessionId, toPhone, convId, text, sender = "VGRUPS Bot") {
  const s = sessions[sessionId];
  if (!s || s.status !== "connected") throw new Error("WhatsApp session is not connected");
  const conversation = await convColl.findOne({ id: convId });
  const r = await s.sock.sendMessage(replyAddress(conversation, toPhone), { text });
  const message = {
    id: uid(), conversation_id: convId, wamid: r?.key?.id || null, direction: "outbound",
    type: "text", body: text, status: "sent", is_demo: false, sender, session_id: sessionId,
    created_at: nowIso(),
  };
  if (message.wamid) {
    await msgColl.updateOne({ wamid: message.wamid }, { $setOnInsert: message }, { upsert: true });
    await msgColl.updateOne({ wamid: message.wamid }, { $set: { sender } });
  } else await msgColl.insertOne(message);
  await convColl.updateOne({ id: convId }, { $set: { last_message: text, last_message_at: nowIso() } });
  return r?.key?.id || null;
}

async function runBot(sessionId, conv, phone, body) {
  const cfg = await loadBotConfig();
  if (!cfg.enabled || conv.human_takeover) return;
  const lower = body.trim().toLowerCase();

  // Human handover
  if (["agent", "human", "representative", "support", "talk to agent"].includes(lower)) {
    await convColl.updateOne({ id: conv.id }, { $set: { human_takeover: true } });
    await sendText(sessionId, phone, conv.id, "Connecting you to our team. A representative will reply here shortly. 🙋");
    return;
  }

  let step = conv.bot_step;
  const data = conv.bot_data || {};

  if (!step) {
    await sendText(sessionId, phone, conv.id, `${cfg.welcome}\n\n${cfg.askName}`);
    await convColl.updateOne({ id: conv.id }, { $set: { bot_step: "await_name", bot_data: {} } });
    return;
  }
  if (step === "await_name") {
    data.name = body.trim();
    await sendText(sessionId, phone, conv.id, `Nice to meet you, ${data.name}! ${cfg.askProduct}`);
    await convColl.updateOne({ id: conv.id }, { $set: { bot_step: "await_product", bot_data: data, name: data.name } });
    return;
  }
  if (step === "await_product") {
    data.product = body.trim();
    await sendText(sessionId, phone, conv.id, cfg.askQuantity);
    await convColl.updateOne({ id: conv.id }, { $set: { bot_step: "await_quantity", bot_data: data } });
    return;
  }
  if (step === "await_quantity") {
    data.quantity = body.trim();
    // Create / link contact + lead
    let contact = await contactsColl.findOne({ mobile: "+" + phone }) || await contactsColl.findOne({ mobile: phone });
    let contactId;
    if (contact) {
      contactId = contact.id;
    } else {
      contactId = uid();
      await contactsColl.insertOne({
        id: contactId, name: data.name, mobile: "+" + phone, email: null, company: null,
        contact_type: "lead", address: null, city: null, state: null, pincode: null, gst: null,
        category: null, source: "whatsapp", assigned_to: null, tags: ["chatbot"], notes: "",
        opted_out: false, is_demo: false, deleted: false, created_at: nowIso(), updated_at: nowIso(),
      });
    }
    await leadsColl.insertOne({
      id: uid(), title: `WhatsApp enquiry - ${data.name}`, contact_id: contactId, contact_name: data.name,
      mobile: "+" + phone, company: null, status: "new", source: "whatsapp", value: 0, specialty: null,
      assigned_to: null, tags: ["chatbot"], notes: `Product: ${data.product} | Qty: ${data.quantity}`,
      is_demo: false, deleted: false, created_at: nowIso(), updated_at: nowIso(), last_contact: nowIso(),
    });
    await convColl.updateOne({ id: conv.id }, { $set: { bot_step: "done", bot_data: data, contact_id: contactId, contact_type: "lead" } });
    await sendText(sessionId, phone, conv.id, cfg.handoff);
    logger.warn(`bot captured lead for ${data.name} (${phone})`);
    return;
  }
}

// ---------------- Recruitment (resume + Q&A over WhatsApp) ----------------
const RECRUIT_KEYWORDS = ["apply", "job", "jobs", "career", "careers", "vacancy", "vacancies", "hiring"];
const RESUME_OK = ["application/pdf", "application/msword",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document"];

function isRecruitTrigger(body) {
  const t = (body || "").trim().toLowerCase();
  if (t.startsWith("apply")) return true;
  return RECRUIT_KEYWORDS.includes(t);
}

function getDocMessage(msg) {
  return msg.message?.documentMessage
    || msg.message?.documentWithCaptionMessage?.message?.documentMessage
    || null;
}

async function openPositions() {
  return positionsColl.find({ status: "open" }).sort({ created_at: 1 }).toArray();
}

async function nextAppId() {
  const c = await countersColl.findOneAndUpdate(
    { _id: "applications" }, { $inc: { seq: 1 } }, { upsert: true, returnDocument: "after" });
  return `VGRUPS-${1000 + ((c && c.seq) || 0)}`;
}

function questionText(q, idx, total) {
  let head = `*Question ${idx + 1} of ${total}*\n${q.q}`;
  if (q.type === "choice" && Array.isArray(q.options) && q.options.length) {
    head += "\n\n" + q.options.map((o, i) => `${i + 1}. ${o}`).join("\n") + "\n\n_Reply with the option number._";
  }
  return head;
}

async function uploadResume(sessionId, phone, msg, candidateId) {
  try {
    const docMsg = getDocMessage(msg);
    if (!docMsg) return false;
    const filename = docMsg.fileName || `resume_${phone}.pdf`;
    const mimetype = docMsg.mimetype || "application/octet-stream";
    const buffer = await downloadMediaMessage(msg, "buffer", {}, {
      logger, reuploadRequest: sessions[sessionId].sock.updateMediaMessage,
    });
    const form = new FormData();
    form.append("file", new Blob([buffer], { type: mimetype }), filename);
    form.append("candidate_id", candidateId);
    form.append("mobile", "+" + phone);
    const resp = await fetch(`${BACKEND_URL}/api/recruitment/resume-upload`, {
      method: "POST", headers: { "X-WA-Secret": WA_SECRET }, body: form,
    });
    if (!resp.ok) { logger.error(`resume upload HTTP ${resp.status}`); return false; }
    return true;
  } catch (e) {
    logger.error("resume upload error: " + e.message);
    return false;
  }
}

async function startApplication(sessionId, conv, phone, pos) {
  const mobile = "+" + phone;
  let cand = await candidatesColl.findOne({ mobile, position_id: pos.id });
  let candId, appId;
  if (cand) { candId = cand.id; appId = cand.application_id; }
  else {
    appId = await nextAppId();
    candId = uid();
    await candidatesColl.insertOne({
      id: candId, application_id: appId, name: conv.name || phone, mobile, email: null,
      position_id: pos.id, position_title: pos.title, department: pos.department || null,
      stage: "applied", location: null, qualification: null, experience: null,
      current_company: null, current_salary: null, expected_salary: null, joining: null,
      resume_url: null, resume_path: null, resume_filename: null, notes: null, answers: [],
      source: "whatsapp", interview_date: null, interview_time: null, interview_mode: null,
      is_demo: false, created_at: nowIso(), updated_at: nowIso(),
    });
    const ec = await contactsColl.findOne({ mobile });
    if (!ec) {
      await contactsColl.insertOne({
        id: uid(), name: conv.name || phone, mobile, email: null, company: null,
        contact_type: "candidate", address: null, city: null, state: null, pincode: null, gst: null,
        category: pos.title, source: "whatsapp", assigned_to: null,
        tags: ["candidate", pos.department || "General"],
        notes: `Applied for ${pos.title} (${appId}) via WhatsApp`, opted_out: false,
        is_demo: false, deleted: false, created_at: nowIso(), updated_at: nowIso(),
      });
    } else {
      await contactsColl.updateOne({ id: ec.id }, {
        $addToSet: { tags: { $each: ["candidate", pos.department || "General"] } },
        $set: { category: pos.title, updated_at: nowIso() },
      });
    }
  }
  const questions = Array.isArray(pos.questions) ? pos.questions : [];
  const recruit = {
    active: true, step: "await_resume", position_id: pos.id, position_code: pos.code || null,
    position_title: pos.title, candidate_id: candId, application_id: appId,
    q_index: 0, answers: [], questions,
  };
  await convColl.updateOne({ id: conv.id }, { $set: { recruit, contact_id: candId, contact_type: "candidate" } });
  const sal = (pos.salary_min && pos.salary_max)
    ? `\n💰 Salary: ₹${pos.salary_min.toLocaleString("en-IN")} – ₹${pos.salary_max.toLocaleString("en-IN")}` : "";
  await sendText(sessionId, phone, conv.id,
    `✅ *Applying for: ${pos.title}*\n🆔 Application ID: *${appId}*${sal}\n\n${pos.summary || ""}\n\n📎 Please send your *resume* (PDF/DOC) as a document now, or type *SKIP* to continue to a few quick questions.`,
    "VGRUPS Careers");
}

async function askQuestion(sessionId, convId, phone, recruit) {
  await sendText(sessionId, phone, convId,
    questionText(recruit.questions[recruit.q_index], recruit.q_index, recruit.questions.length), "VGRUPS Careers");
}

async function startQa(sessionId, conv, phone, recruit) {
  recruit.step = "qa";
  recruit.q_index = 0;
  await convColl.updateOne({ id: conv.id }, { $set: { recruit } });
  if (!recruit.questions.length) { await finishApplication(sessionId, conv, phone, recruit); return; }
  await sendText(sessionId, phone, conv.id, `Great — just ${recruit.questions.length} quick questions. 📝`, "VGRUPS Careers");
  await askQuestion(sessionId, conv.id, phone, recruit);
}

async function finishApplication(sessionId, conv, phone, recruit) {
  const notes = recruit.answers.map((a) => `${a.q}: ${a.a}`).join(" | ");
  const upd = { answers: recruit.answers, notes, stage: "screening", updated_at: nowIso() };
  for (const a of recruit.answers) {
    const ql = a.q.toLowerCase();
    if (ql.includes("full name")) upd.name = a.a;
    else if (ql.includes("email")) upd.email = a.a;
    else if (ql.includes("city")) upd.location = a.a;
    else if (ql.includes("qualification")) upd.qualification = a.a;
    else if (ql.includes("total experience")) upd.experience = a.a;
    else if (ql.includes("previous company")) upd.current_company = a.a;
    else if (ql.includes("current monthly")) upd.current_salary = a.a;
    else if (ql.includes("expected monthly")) upd.expected_salary = a.a;
    else if (ql.includes("joining")) upd.joining = a.a;
  }
  await candidatesColl.updateOne({ id: recruit.candidate_id }, { $set: upd });
  if (upd.name) await contactsColl.updateOne({ mobile: "+" + phone }, { $set: { name: upd.name, updated_at: nowIso() } });
  recruit.active = false;
  recruit.step = "done";
  await convColl.updateOne({ id: conv.id }, { $set: { recruit } });
  await sendText(sessionId, phone, conv.id,
    `🎉 Thank you! Your application for *${recruit.position_title}* is complete.\n🆔 Application ID: *${recruit.application_id}*\n\nOur HR team will review your details and reach out here. Reply *agent* anytime to talk to a person. 🌿`,
    "VGRUPS Careers");
  // Fire-and-forget AI screening on the backend
  fetch(`${BACKEND_URL}/api/recruitment/candidates/${recruit.candidate_id}/auto-score`, {
    method: "POST", headers: { "X-WA-Secret": WA_SECRET },
  }).catch((e) => logger.error("auto-score trigger failed: " + e.message));
}

// Returns true if the recruitment flow handled the message.
async function runRecruitment(sessionId, conv, phone, body, msg) {
  if (conv.human_takeover) return false;
  const r = conv.recruit;
  const docMsg = getDocMessage(msg);
  const t = (body || "").trim();
  const lower = t.toLowerCase();

  if (!r || !r.active) {
    if (!isRecruitTrigger(body)) return false;
    const positions = await openPositions();
    if (!positions.length) {
      await sendText(sessionId, phone, conv.id, "We don't have any open positions right now. Please check back soon! 🌿", "VGRUPS Careers");
      return true;
    }
    const m = lower.match(/^apply\s+([a-z\-]+)/);
    const code = m ? m[1].toUpperCase() : null;
    const pos = code ? positions.find((p) => (p.code || "").toUpperCase() === code) : null;
    if (pos) { await startApplication(sessionId, conv, phone, pos); return true; }
    const menu = positions.map((p, i) => `${i + 1}. ${p.title}`).join("\n");
    await sendText(sessionId, phone, conv.id,
      `🌿 *VGRUPS Healthcare — Careers*\nWe're hiring! Reply with the number of the role you'd like to apply for:\n\n${menu}`,
      "VGRUPS Careers");
    await convColl.updateOne({ id: conv.id }, { $set: { recruit: { active: true, step: "menu" } } });
    return true;
  }

  if (r.step === "menu") {
    const positions = await openPositions();
    const idx = parseInt(t, 10);
    const pos = (idx >= 1 && idx <= positions.length) ? positions[idx - 1] : null;
    if (!pos) {
      const menu = positions.map((p, i) => `${i + 1}. ${p.title}`).join("\n");
      await sendText(sessionId, phone, conv.id, `Please reply with a valid number:\n\n${menu}`, "VGRUPS Careers");
      return true;
    }
    await startApplication(sessionId, conv, phone, pos);
    return true;
  }

  if (r.step === "await_resume") {
    if (docMsg) {
      if (!RESUME_OK.includes(docMsg.mimetype)) {
        await sendText(sessionId, phone, conv.id, "⚠️ Please send a *PDF or Word* document, or type *SKIP* to continue.", "VGRUPS Careers");
        return true;
      }
      const ok = await uploadResume(sessionId, phone, msg, r.candidate_id);
      await sendText(sessionId, phone, conv.id, ok ? "✅ Resume received, thank you!" : "⚠️ We couldn't save that file, but let's continue — you can resend it later.", "VGRUPS Careers");
      await startQa(sessionId, conv, phone, r);
      return true;
    }
    if (lower === "skip") {
      await sendText(sessionId, phone, conv.id, "No problem — you can share your resume later. 📝", "VGRUPS Careers");
      await startQa(sessionId, conv, phone, r);
      return true;
    }
    await sendText(sessionId, phone, conv.id, "📎 Please attach your *resume* (PDF/DOC) as a document, or type *SKIP* to continue.", "VGRUPS Careers");
    return true;
  }

  if (r.step === "qa") {
    if (docMsg) {
      if (RESUME_OK.includes(docMsg.mimetype)) {
        const ok = await uploadResume(sessionId, phone, msg, r.candidate_id);
        await sendText(sessionId, phone, conv.id, ok ? "✅ Resume received, thank you! Let's continue." : "⚠️ Couldn't save that file. Let's continue.", "VGRUPS Careers");
      }
      await askQuestion(sessionId, conv.id, phone, r);
      return true;
    }
    const q = r.questions[r.q_index];
    let ans = t;
    if (q.type === "choice" && Array.isArray(q.options) && q.options.length) {
      const ci = parseInt(t, 10);
      if (!(ci >= 1 && ci <= q.options.length)) {
        await sendText(sessionId, phone, conv.id, "Please reply with the option number.\n\n" + questionText(q, r.q_index, r.questions.length), "VGRUPS Careers");
        return true;
      }
      ans = q.options[ci - 1];
    } else if (!ans) {
      await askQuestion(sessionId, conv.id, phone, r);
      return true;
    }
    r.answers.push({ q: q.q, a: ans });
    r.q_index += 1;
    if (r.q_index >= r.questions.length) {
      await finishApplication(sessionId, conv, phone, r);
      return true;
    }
    await convColl.updateOne({ id: conv.id }, { $set: { recruit: r } });
    await askQuestion(sessionId, conv.id, phone, r);
    return true;
  }

  return false;
}

async function handleInbound(sessionId, msg) {
  try {
    const { enqueueLeadMessage, isPendingLeadReply } = require("./lead-capture");
    const synced = await syncMessage({ sessionId, msg, conversations: convColl, messages: msgColl,
                                      accountPhone: sessions[sessionId]?.phone,
                                      onPersist: message => enqueueLeadMessage(db, message) });
    if (!synced || !shouldAutomate(msg)) return;
    const { phone, body } = synced;
    const mrMeta = { message_id: msg.key?.id, location: inboundContent(msg)?.location };
    let conv = synced.conv;
    const mrAccount = await mrSessionAllowed(db, sessionId);
    // Preserve every existing MR menu. Only an explicitly identifiable pending-lead
    // response is consumed; numeric closing/visit drafts still reach their own handler.
    if (mrAccount && await isPendingLeadReply(db, conv, body, synced.persisted?.reply_to_wamid)) {
      await queueMrAiReply(db, conv, synced.persisted, true);
      return;
    }

    const lower = body.trim().toLowerCase();

    // Opt-out / opt-in handling
    if (["stop", "unsubscribe", "opt out", "optout"].includes(lower)) {
      await contactsColl.updateMany({ mobile: { $in: ["+" + phone, phone] } }, { $set: { opted_out: true, updated_at: nowIso() } });
      await convColl.updateOne({ id: conv.id }, { $set: { opted_out: true } });
      await consentColl.insertOne({ id: uid(), phone, status: "opted_out", source: "whatsapp_reply", purpose: "marketing", created_at: nowIso() });
      await sendText(sessionId, phone, conv.id, "You've been unsubscribed from marketing messages. Reply START to opt back in.", "System");
      return;
    }
    if (["start", "subscribe", "opt in", "optin"].includes(lower)) {
      await contactsColl.updateMany({ mobile: { $in: ["+" + phone, phone] } }, { $set: { opted_out: false, updated_at: nowIso() } });
      await convColl.updateOne({ id: conv.id }, { $set: { opted_out: false } });
      await consentColl.insertOne({ id: uid(), phone, status: "opted_in", source: "whatsapp_reply", purpose: "marketing", created_at: nowIso() });
      if (mrAccount && lower === "start" && await runMrIvr(sessionId, conv, phone, body, mrMeta)) return;
      await sendText(sessionId, phone, conv.id, "You're subscribed again. Welcome back! 🌿", "System");
      if (lower === "start") {
        conv.opted_out = false;
        await runIvr(sessionId, conv, phone, "start");
      }
      return;
    }

    // Campaign reply attribution (stop drip)
    const candidates = await recipColl.find({ phone, status: { $in: ["sent", "delivered", "read"] }, replied: { $ne: true } }).toArray();
    let recip = null;
    for (const candidate of candidates) {
      const campaign = await db.collection("campaigns").findOne({ id: candidate.campaign_id });
      const sameSender = campaign?.sender_session_id
        ? campaign.sender_session_id === sessionId
        : await msgColl.findOne({ campaign_id: candidate.campaign_id, session_id: sessionId, direction: "outbound" });
      if (sameSender) { recip = candidate; break; }
    }
    if (recip) {
      await recipColl.updateOne({ id: recip.id }, { $set: { replied: true } });
      await db.collection("campaigns").updateOne({ id: recip.campaign_id }, { $inc: { "stats.replies": 1 } });
    }

    // refetch conv (bot fields may have changed)
    conv = await convColl.findOne({ id: conv.id });
    if (mrAccount && await queueMrAiReply(db, conv, synced.persisted)) return;
    if (mrAccount && await runMrIvr(sessionId, conv, phone, body, mrMeta)) return;
    if (isMenuGreeting(body) && await runCustomerIvr(sessionId, conv, phone, body)) return;
    const recruited = await runRecruitment(sessionId, conv, phone, body, msg);
    if (recruited) return;
    if (await runCustomerIvr(sessionId, conv, phone, body)) return;
    if (!await runFlow(sessionId, conv, phone, body)) await runBot(sessionId, conv, phone, body);
  } catch (e) {
    logger.error("inbound error: " + e.message);
  }
}

async function handleStatusUpdate(updates) {
  for (const u of updates) {
    try {
      await ingestStatusUpdates(msgColl, [u]);
    } catch (e) { logger.warn("Receipt persistence failed"); }
  }
}

function startSession(sessionId, name) {
  return startOnce(sessionId, () => openSession(sessionId, name));
}

function restoreSession(sessionId, name) {
  startSession(sessionId, name).catch(() => {
    logger.error("WhatsApp restore failed; retrying saved session without clearing credentials");
    if (closing.has(sessionId) || sessions[sessionId]?.status === "connection_conflict") return;
    clearTimeout(reconnectTimers.get(sessionId));
    reconnectTimers.set(sessionId, setTimeout(() => {
      reconnectTimers.delete(sessionId);
      if (!closing.has(sessionId)) restoreSession(sessionId, name);
    }, 5000));
  });
}

async function openSession(sessionId, name) {
  assertOwned();
  if (closing.has(sessionId)) return null;
  clearTimeout(reconnectTimers.get(sessionId));
  reconnectTimers.delete(sessionId);
  const previous = sessions[sessionId];
  if (previous?.sock) {
    previous.sock.ev.removeAllListeners();
    previous.sock.end(new Error("Local session restart"));
  }
  const { state, saveCreds, clear } = await usePostgresAuthState(authColl, sessionId, assertOwned);
  const { version } = await fetchLatestBaileysVersion();
  assertOwned();
  if (closing.has(sessionId)) return null;

  const sock = makeWASocket({
    version,
    logger,
    printQRInTerminal: false,
    browser: ["VGRUPS CONNECT", "Chrome", "1.0.0"],
    auth: { creds: state.creds, keys: makeCacheableSignalKeyStore(state.keys, logger) },
    markOnlineOnConnect: false,
  });

  sessions[sessionId] = sessions[sessionId] || {};
  Object.assign(sessions[sessionId], { sock, name, status: "connecting", qr: null });

  sock.ev.on("creds.update", () => {
    if (sessions[sessionId]?.sock !== sock || closing.has(sessionId)) return;
    saveCreds().catch(() => logger.error("WhatsApp credential persistence failed"));
  });

  sock.ev.on("connection.update", async (u) => {
    const { connection, lastDisconnect, qr } = u;
    const s = sessions[sessionId];
    if (!s || s.sock !== sock) return;
    if (qr) {
      s.qr = await QRCode.toDataURL(qr);
      s.status = "qr";
      await persistMeta(sessionId);
    }
    if (connection === "open") {
      const accountPhone = numOf(sock.user?.id);
      const original = await sessColl.findOne({ id: sessionId });
      if (original?.phone && numOf(original.phone) !== accountPhone) {
        // Reusing a history anchor for a different phone would mix two accounts.
        // Keep the original records; the new phone must use Link WhatsApp Number.
        closing.add(sessionId);
        try { await sock.logout(); } catch {}
        await clear();
        delete sessions[sessionId];
        await sessColl.updateOne({ id: sessionId }, { $set: {
          status: "logged_out", pairing_error: "Scan the original number here. Use Link WhatsApp Number for a different phone.",
          updated_at: nowIso(),
        } });
        setTimeout(() => closing.delete(sessionId), 8000);
        return;
      }
      // A connected badge must not precede durable pairing storage.
      try {
        await saveCreds();
      } catch {
        logger.error("WhatsApp pairing could not be saved; connected status withheld");
        sock.end(new Error("Credential persistence unavailable"));
        return;
      }
      if (sessions[sessionId]?.sock !== sock || closing.has(sessionId)) return;
      s.status = "connected";
      s.qr = null;
      s.phone = accountPhone;
      await persistMeta(sessionId);
      logger.warn(`session ${sessionId} connected as ${s.phone}`);
    }
    if (connection === "close") {
      const code = lastDisconnect?.error?.output?.statusCode;
      if (closing.has(sessionId)) {
        s.status = "logged_out";
        s.qr = null;
        delete sessions[sessionId];
        logger.warn(`session ${sessionId} closed (deleted/logged out, no reconnect)`);
      } else if (code === DisconnectReason.loggedOut) {
        s.status = "logged_out";
        s.qr = null;
        await clear();
        await persistMeta(sessionId);
        delete sessions[sessionId];
        logger.warn(`session ${sessionId} logged out`);
      } else if (!retryAfterDisconnect(code, DisconnectReason)) {
        // An older deployment or another linked client may not use our lock.
        // Do not fight it, and do not delete credentials on a replacement.
        s.status = "connection_conflict";
        s.qr = null;
        await persistMeta(sessionId);
        logger.warn("WhatsApp connection replaced; automatic reconnect stopped");
      } else {
        s.status = "reconnecting";
        await persistMeta(sessionId);
        clearTimeout(reconnectTimers.get(sessionId));
        reconnectTimers.set(sessionId, setTimeout(() => {
          reconnectTimers.delete(sessionId);
          if (closing.has(sessionId) || sessions[sessionId]?.sock !== sock) return;
          restoreSession(sessionId, name);
        }, 2500));
      }
    }
  });

  let messageQueue = Promise.resolve();
  sock.ev.on("messages.upsert", ({ messages, type }) => {
    if (!["notify", "append"].includes(type)) return;
    messageQueue = messageQueue.then(async () => {
      for (const m of messages) await handleInbound(sessionId, m);
    }).catch(() => logger.error("WhatsApp message synchronization failed"));
  });

  sock.ev.on("messages.update", handleStatusUpdate);
  sock.ev.on("message-receipt.update", (updates) => {
    ingestUserReceipts(msgColl, updates).catch(() => logger.warn("Receipt persistence failed"));
  });

  return sessions[sessionId];
}

// ---------------- HTTP API ----------------
app.get("/health", (req, res) => res.json({ ok: true, sessions: Object.keys(sessions).length, gateway_status: ownershipStatus }));

app.get("/sessions", async (req, res) => {
  const stored = await sessColl.find({ deleted: { $ne: true } }).toArray();
  const out = stored.map((s) => {
    const live = sessions[s.id];
    return {
      id: s.id, name: s.name,
      status: live ? live.status : s.status === "connected" ? "reconnecting" : s.status,
      phone: live ? live.phone : s.phone,
      qr: live ? live.qr : null,
      created_at: s.created_at || null,
    };
  });
  for (const id of Object.keys(sessions)) {
    if (!out.find((o) => o.id === id)) {
      const s = sessions[id];
      out.push({ id, name: s.name, status: s.status, phone: s.phone, qr: s.qr, created_at: null });
    }
  }
  res.json({ sessions: out, connected: out.some((o) => o.status === "connected") });
});

app.get("/sessions/:id", (req, res) => {
  const s = sessions[req.params.id];
  if (!s) return res.status(404).json({ error: "not found" });
  res.json({ id: req.params.id, name: s.name, status: s.status, phone: s.phone, qr: s.qr });
});

app.post("/sessions", async (req, res) => {
  const name = (req.body && req.body.name) || "WhatsApp";
  const id = uid();
  await startSession(id, name);
  await persistMeta(id);
  res.json({ id, name, status: "connecting" });
});

app.post("/sessions/:id/reconnect", async (req, res) => {
  const id = req.params.id;
  closing.delete(id);
  const meta = await sessColl.findOne({ id });
  if (!meta || meta.deleted) return res.status(404).json({ error: "not found" });
  await startSession(id, meta.name);
  res.json({ ok: true });
});

app.post("/sessions/:id/send", async (req, res) => {
  const s = sessions[req.params.id];
  const { to, text } = req.body || {};
  if (!s || s.status !== "connected") return res.status(409).json({ error: "session not connected" });
  if (!to || !text) return res.status(422).json({ error: "to and text required" });
  try {
    const result = await s.sock.sendMessage(jidOf(to), { text });
    res.json({ ok: true, wamid: result?.key?.id || null });
  } catch (e) {
    res.status(502).json({ error: e.message });
  }
});

app.post("/send-media", async (req, res) => {
  const { to, url, content_type, filename, caption, session_id, request_id, media_key } = req.body || {};
  const id = explicitOrSoleSession(sessions, session_id);
  if (!id || sessions[id]?.status !== "connected") return res.status(409).json({ error: "requested WhatsApp session is not connected" });
  const allowed = ["image/png", "image/jpeg", "image/webp", "application/pdf"];
  try {
    const target = new URL(url);
    const hosts = request_id ? ["storage.googleapis.com", "images.unsplash.com"] : ["storage.googleapis.com"];
    if (!to || target.protocol !== "https:" || !hosts.includes(target.hostname) || target.username || target.password || !allowed.includes(content_type)) {
      return res.status(422).json({ error: "Invalid campaign attachment" });
    }
    const content = content_type === "application/pdf"
      ? { document: { url }, mimetype: content_type, fileName: filename || "attachment.pdf", caption: caption || "" }
      : { image: { url }, caption: caption || "" };
    const result = await sendReservedMedia({ requestId: request_id, mediaKey: media_key, to, caption: caption || "",
      sessionId: id, content, sock: sessions[id].sock, requests: db.collection("whatsapp_send_requests"),
      generateMessageId: generateMessageIDV2, onReserved: async messageId => {
        const reservation = await db.collection("whatsapp_send_requests").findOne({ id: request_id });
        if (reservation?.source !== "mr_catalog") return;
        await msgColl.updateOne({ wamid: messageId }, { $setOnInsert: {
          id: uid(), wamid: messageId, conversation_id: reservation.conversation_id, session_id: id,
          direction: "outbound", type: content_type === "application/pdf" ? "document" : "image",
          body: caption || "", status: "sending", sender: "MR daily catalogue", capture_skip: true,
          is_demo: false, created_at: nowIso(),
        } }, { upsert: true });
      } });
    return res.json({ ok: true, wamid: result?.key?.id || null, session_id: id });
  } catch (error) {
    return res.status(502).json({ error: "Campaign attachment send was not confirmed." });
  }
});

app.post("/send", async (req, res) => {
  const { to, text, request_id, session_id } = req.body || {};
  const id = explicitOrSoleSession(sessions, session_id);
  if (!id || sessions[id]?.status !== "connected") return res.status(409).json({ error: "requested WhatsApp session is not connected" });
  if (!to || !text) return res.status(422).json({ error: "to and text required" });
  try {
    const result = await sendReservedText({
      requestId: request_id, to, text, sessionId: id, sock: sessions[id].sock,
      requests: db.collection("whatsapp_send_requests"), generateMessageId: generateMessageIDV2,
      onReserved: async messageId => {
        const reservation = await db.collection("whatsapp_send_requests").findOne({ id: request_id });
        if (!["mr_ai", "lead_capture"].includes(reservation?.source)) return;
        await msgColl.updateOne({ wamid: messageId }, { $setOnInsert: {
          id: uid(), wamid: messageId, conversation_id: reservation.conversation_id, direction: "outbound",
          type: "text", body: text, status: "sending", session_id: id, is_demo: false,
          sender: reservation.source === "mr_ai" ? "MR AI assistant" : "Lead capture",
          capture_skip: true, created_at: nowIso(),
        } }, { upsert: true });
      },
    });
    res.json({ ok: true, wamid: result?.key?.id || null, session_id: id, phone: sessions[id].phone });
  } catch (e) {
    res.status(502).json({ error: e.message });
  }
});

app.post("/sessions/:id/logout", async (req, res) => {
  const id = req.params.id;
  closing.add(id);
  const s = sessions[id];
  try { if (s && s.sock) await s.sock.logout(); } catch (e) {}
  const { clear } = await usePostgresAuthState(authColl, id, assertOwned);
  await clear();
  delete sessions[id];
  await sessColl.updateOne({ id }, { $set: { status: "logged_out", updated_at: nowIso() } });
  setTimeout(() => closing.delete(id), 8000);
  res.json({ ok: true });
});

app.delete("/sessions/:id", async (req, res) => {
  const id = req.params.id;
  closing.add(id);
  const s = sessions[id];
  try { if (s && s.sock) s.sock.end(); } catch (e) {}
  const { clear } = await usePostgresAuthState(authColl, id, assertOwned);
  await clear();
  delete sessions[id];
  // Keep account metadata as an anchor for its saved history. Only pairing
  // credentials are removed; CRM, leads, contacts, sales and messages stay intact.
  await sessColl.updateOne({ id }, { $set: { status: "deleted", deleted: true, updated_at: nowIso() } });
  setTimeout(() => closing.delete(id), 8000);
  res.json({ ok: true });
});

async function main() {
  if (gatewayMode() === "disabled") {
    ownershipStatus = "disabled";
    app.listen(PORT, "127.0.0.1", () => logger.warn("WhatsApp gateway disabled; credentials left untouched"));
    return;
  }
  db = new PostgresStore();
  await db.connect();
  owner = await acquireGatewayOwner(db.pool, () => {
    ownershipStatus = "ownership_lost";
    for (const timer of reconnectTimers.values()) clearTimeout(timer);
    for (const s of Object.values(sessions)) {
      s.sock?.ev.removeAllListeners();
      try { s.sock?.end(new Error("Gateway ownership lost")); } catch {}
    }
    logger.error("WhatsApp database ownership lost; stopping gateway without logout");
    process.exit(1);
  });
  if (!owner) {
    ownershipStatus = "owned_elsewhere";
    await db.close();
    app.listen(PORT, "127.0.0.1", () => logger.warn("WhatsApp gateway standby; another gateway owns this credential store"));
    // A rolling release briefly overlaps the old owner. The production
    // supervisor retries without touching credentials until ownership is free.
    setTimeout(() => process.exit(1), 10000).unref?.();
    return;
  }
  ownershipStatus = "active";
  authColl = db.collection("wa_auth");
  sessColl = db.collection("wa_sessions");
  convColl = db.collection("conversations");
  msgColl = db.collection("messages");
  contactsColl = db.collection("contacts");
  leadsColl = db.collection("leads");
  configColl = db.collection("app_config");
  consentColl = db.collection("consent_records");
  recipColl = db.collection("campaign_recipients");
  positionsColl = db.collection("positions");
  candidatesColl = db.collection("candidates");
  countersColl = db.collection("counters");

  const stored = await sessColl.find({ status: { $nin: ["logged_out", "connection_conflict"] },
    deleted: { $ne: true }, is_demo: { $ne: true } }).toArray();
  for (const s of stored) {
    sessions[s.id] = { name: s.name, phone: s.phone, status: "reconnecting", qr: null };
    restoreSession(s.id, s.name);
  }

  app.listen(PORT, "127.0.0.1", () => logger.warn(`VGRUPS WhatsApp service on :${PORT} (restored ${stored.length})`));
}

main().catch((e) => { logger.error(e); process.exit(1); });
