const test = require("node:test");
const assert = require("node:assert/strict");
const { inboundContent, replyAddress } = require("./incoming");
const { createIvrRunner } = require("./ivr");
const defaultConfig = require("../ivr-default.json");

const message = (content, key = {}) => ({
  key: { remoteJid: "123456@lid", remoteJidAlt: "15550001111@s.whatsapp.net", ...key },
  message: content,
});

test("LID inbound retains the real reply address and uses the phone alternative", () => {
  const parsed = inboundContent(message({ conversation: "hi" }));
  assert.equal(parsed.jid, "123456@lid");
  assert.equal(parsed.phone, "15550001111");
  assert.equal(replyAddress({ reply_jid: parsed.jid }, parsed.phone), parsed.jid);
});
test("ordinary phone addressing still works", () => {
  assert.equal(replyAddress({}, "+15550001111"), "15550001111@s.whatsapp.net");
});
test("wrapped messages and media captions preserve hi", () => {
  assert.equal(inboundContent(message({ ephemeralMessage: { message: { extendedTextMessage: { text: "hi" } } } })).body, "hi");
  assert.equal(inboundContent(message({ imageMessage: { caption: "hi" } })).body, "hi");
});
test("outgoing, groups, broadcasts and newsletters do not trigger IVR", () => {
  for (const key of [{ fromMe: true }, { remoteJid: "1@g.us" }, { remoteJid: "status@broadcast" }, { remoteJid: "1@newsletter" }]) {
    assert.equal(inboundContent(message({ conversation: "hi" }, key)), null);
  }
});

function fixture(config = defaultConfig, conversation = { id: "test-conversation" }) {
  const sent = [], updated = [];
  const run = createIvrRunner({
    loadConfig: async () => config,
    sendText: async (...args) => sent.push(args[3]),
    updateConversation: async (...args) => updated.push(args),
  });
  return { sent, updated, run: (text) => run("test-session", conversation, "15550001111", text) };
}

for (const greeting of ["hi", " HI! ", "hello", "hey", "menu", "0"]) {
  test(`${greeting} opens the complete default menu`, async () => {
    const f = fixture();
    assert.equal(await f.run(greeting), true);
    assert.match(f.sent[0], /Welcome to VGRUPS Healthcare/);
    assert.match(f.sent[0], /1\. Products & Catalogue/);
    assert.match(f.sent[0], /7\. Talk to Sales Team/);
    assert.doesNotMatch(f.sent[0], /Careers|Settings|Campaigns|Integrations/);
  });
}
test("hi restarts IVR after human handoff", async () => {
  const f = fixture(defaultConfig, { id: "test-conversation", human_takeover: true });
  await f.run("hi");
  assert.equal(f.sent.length, 1);
  assert.equal(f.updated[0][0], "test-conversation");
  assert.equal(f.updated[0][1].human_takeover, false);
  assert.equal(f.updated[0][1].ivr.stage, "menu");
});
test("ordinary text does not interrupt human handoff", async () => {
  const f = fixture(defaultConfig, { id: "test-conversation", human_takeover: true });
  assert.equal(await f.run("my order is delayed"), true);
  assert.equal(f.sent.length, 0);
});
test("menu choice sends response and return-to-menu instruction", async () => {
  const f = fixture();
  await f.run("1");
  assert.match(f.sent[0], /What would you like to see/);
  assert.match(f.sent[0], /Product Catalogue/);
  assert.match(f.sent[0], /Reply 0/);
});
test("customer support shows only its submenu", async () => {
  const f = fixture();
  await f.run("6");
  assert.equal(f.sent.length, 1);
  assert.match(f.sent[0], /Payment Issue/);
  assert.equal(f.updated[0][1].ivr.path[0], 5);
});
test("invalid choices show menu instead of accepting partial numbers", async () => {
  const f = fixture();
  await f.run("1abc");
  assert.match(f.sent[0], /1\. Products & Catalogue/);
});
test("explicitly disabled configuration remains disabled", async () => {
  const f = fixture({ ...defaultConfig, enabled: false });
  assert.equal(await f.run("hi"), false);
  assert.equal(f.sent.length, 0);
});
test("delivery errors are not silently marked as handled", async () => {
  const run = createIvrRunner({
    loadConfig: async () => defaultConfig,
    sendText: async () => { throw new Error("Disconnected"); },
    updateConversation: async () => {},
  });
  await assert.rejects(run("test", { id: "test" }, "15550001111", "hi"), /Disconnected/);
});