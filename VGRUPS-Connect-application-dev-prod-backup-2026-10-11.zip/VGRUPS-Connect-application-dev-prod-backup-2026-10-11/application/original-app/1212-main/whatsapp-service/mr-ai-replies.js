const { identifyMr } = require("./mr-reporting-data");
const { isMenuGreeting } = require("./incoming");
const { createHash } = require("crypto");
const { mrSessionAllowed } = require("./whatsapp-routing");

const commands = /^(?:\d+(?:\.\d+)?|plan|morning|closing|close|day closing|report|field|day visit|pending|status|help|resume|later|cancel|back|done|confirm|menu|start|stop|unsubscribe|subscribe|opt ?out|opt ?in|manager|agent|human)$/i;
const question = /^(?:(?:what|how|why|which|when|where|can you|can i|could you|could i|should i|please explain|explain)\b|कसे|काय|क्यों|कैसे|क्या|समजाव)/i;

function aiCandidate(conversation, body, phoneReply = false) {
  const text = String(body || "").trim();
  if (!text || conversation.human_takeover || conversation.opted_out) return false;
  if (phoneReply) return true;
  if (commands.test(text) || isMenuGreeting(text)) return false;
  const drafting = (conversation.mr_ivr?.field || "menu") !== "menu" ||
    (conversation.mr_field_state?.step || "menu") !== "menu";
  return !drafting || question.test(text);
}

async function queueMrAiReply(db, conversation, message, phoneReply = false) {
  try {
    if (!message || !await mrSessionAllowed(db, message.session_id)) return false;
    if (!message || message.direction !== "inbound" || message.type !== "text" || message.is_demo ||
        message.capture_skip || !message.session_id || conversation.session_id !== message.session_id ||
        !aiCandidate(conversation, message.body, phoneReply)) return false;
    const cfg = (await db.collection("app_config").findOne({ key: "mr_lead_capture" }))?.value;
    if (!cfg?.enabled || !cfg.authorized_messages_confirmed || !cfg.ai_auto_reply ||
        !cfg.ai_reply_enabled_since || message.created_at < cfg.ai_reply_enabled_since) return false;
    const mr = await identifyMr(db, conversation.phone);
    if (!mr) return false;
    const profile = await db.collection("mr_ivr_profiles").findOne({ id: mr.id });
    if (profile?.value?.ivr_enabled === false) return false;
    const id = createHash("sha256").update(`mr-ai:${message.wamid || message.id}`).digest("hex");
    await db.collection("mr_ai_replies").updateOne({ id }, { $setOnInsert: {
      id, message_id: message.id, conversation_id: conversation.id, session_id: message.session_id,
      mr_id: mr.mr_id, mr_directory_id: mr.id, mr_name: mr.name, phone_reply: phoneReply,
      status: "pending", created_at: new Date().toISOString(),
    } }, { upsert: true });
    return true;
  } catch {
    console.warn("MR AI queue unavailable; existing menus remain available.");
    return false;
  }
}

module.exports = { aiCandidate, queueMrAiReply };
