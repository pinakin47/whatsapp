const { test } = require("node:test");
const assert = require("node:assert/strict");
const { EventEmitter } = require("node:events");
const { gatewayMode, acquireGatewayOwner, singleFlight, retryAfterDisconnect } = require("./session-owner");

function databaseFixture() {
  const locks = new Map();
  const clients = [];
  return {
    locks, clients,
    async connect() {
      const client = new EventEmitter();
      client.fail = false;
      client.queries = [];
      client.query = async ({ text, values }) => {
        client.queries.push(text);
        if (client.fail) throw new Error("Synthetic database outage");
        if (text.includes("pg_try_advisory_lock")) {
          if (locks.has(values[0])) return { rows: [{ acquired: false }] };
          locks.set(values[0], client);
          return { rows: [{ acquired: true }] };
        }
        return { rows: [{}] };
      };
      client.release = (destroy) => {
        assert.equal(destroy, true, "Never put a locked connection back in the pool");
        client.released = true;
        for (const [key, value] of locks) if (value === client) locks.delete(key);
        client.emit("end");
      };
      clients.push(client);
      return client;
    },
  };
}

test("development is disabled by default; only published runtime defaults to enabled", () => {
  assert.equal(gatewayMode({}), "disabled");
  assert.equal(gatewayMode({ REPLIT_DEPLOYMENT: "1" }), "enabled");
  assert.equal(gatewayMode({ REPLIT_DEPLOYMENT: "1", WA_GATEWAY_MODE: "disabled" }), "disabled");
  assert.equal(gatewayMode({ WA_GATEWAY_MODE: "enabled" }), "enabled");
  assert.throws(() => gatewayMode({ WA_GATEWAY_MODE: "typo" }), /Invalid/);
});

test("simultaneous gateways share one lock; loser cannot restore and release allows takeover", async () => {
  const pool = databaseFixture();
  let losses = 0;
  const owners = await Promise.all([
    acquireGatewayOwner(pool, () => losses++),
    acquireGatewayOwner(pool, () => losses++),
  ]);
  assert.equal(owners.filter(Boolean).length, 1);
  assert.equal(pool.locks.size, 1);
  assert.equal(pool.clients.filter(c => c.released).length, 1);
  owners.find(Boolean).assertOwned();
  owners.find(Boolean).release();
  assert.equal(losses, 0, "Intentional shutdown is not ownership loss");
  assert.throws(() => owners.find(Boolean).assertOwned(), /unavailable/);
  const next = await acquireGatewayOwner(pool, () => losses++);
  assert.ok(next);
  next.release();
});

test("lost database connection invalidates ownership exactly once", async () => {
  const pool = databaseFixture();
  let losses = 0;
  const owner = await acquireGatewayOwner(pool, () => losses++);
  pool.clients[0].emit("error", new Error("Synthetic disconnect"));
  pool.clients[0].emit("end");
  assert.equal(losses, 1);
  assert.throws(() => owner.assertOwned(), /unavailable/);
  owner.release();
});

test("heartbeat failures stop ownership rather than continuing to use credentials", async () => {
  const pool = databaseFixture();
  let notify;
  const lost = new Promise(resolve => { notify = resolve; });
  const owner = await acquireGatewayOwner(pool, notify, { heartbeatMs: 5 });
  pool.clients[0].fail = true;
  const timeout = setTimeout(() => notify("timeout"), 500);
  assert.notEqual(await lost, "timeout");
  clearTimeout(timeout);
  assert.throws(() => owner.assertOwned(), /unavailable/);
  owner.release();
});

test("failed acquisition destroys its dedicated database connection", async () => {
  const pool = databaseFixture();
  const connect = pool.connect.bind(pool);
  pool.connect = async () => { const client = await connect(); client.fail = true; return client; };
  await assert.rejects(acquireGatewayOwner(pool, () => {}), /Synthetic/);
  assert.equal(pool.clients[0].released, true);
});

test("duplicate restore/reconnect requests coalesce, failures permit a later retry", async () => {
  const run = singleFlight();
  let starts = 0, finish;
  const start = () => { starts++; return new Promise(resolve => { finish = resolve; }); };
  const one = run("synthetic-session", start);
  const two = run("synthetic-session", start);
  assert.equal(one, two);
  await Promise.resolve();
  assert.equal(starts, 1);
  finish("socket");
  assert.equal(await two, "socket");
  await assert.rejects(run("synthetic-session", () => { throw new Error("failed"); }), /failed/);
  assert.equal(await run("synthetic-session", () => "new socket"), "new socket");
});

test("replacement and logout never retry; temporary disconnects still do", () => {
  const reasons = { connectionReplaced: 440, loggedOut: 401 };
  assert.equal(retryAfterDisconnect(440, reasons), false);
  assert.equal(retryAfterDisconnect(401, reasons), false);
  assert.equal(retryAfterDisconnect(408, reasons), true);
  assert.equal(retryAfterDisconnect(undefined, reasons), true);
});
