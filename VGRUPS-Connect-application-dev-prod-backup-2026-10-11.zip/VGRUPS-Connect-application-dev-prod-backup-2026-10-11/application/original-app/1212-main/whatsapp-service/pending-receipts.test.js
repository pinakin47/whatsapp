const test = require("node:test");
const assert = require("node:assert/strict");
const { fixtureDatabase } = require("./receipt-fixture");
const { ingestStatusUpdates, ingestUserReceipts, saveReceipt } = require("./receipts");
const { syncMessage } = require("./message-sync");
const { sendReservedText } = require("./send-reservation");

const key = { id: "exact", fromMe: true, remoteJid: "15550001111@s.whatsapp.net" };
const persist = messages => messages.updateOne({ wamid: "exact" }, { $setOnInsert: {
  wamid: "exact", status: "sent", direction: "outbound", body: "fixture",
  created_at: "2020-01-01T00:00:00Z",
} }, { upsert: true });

test("QR ACK before echo survives persistence without creating an incomplete Inbox message", async () => {
  const database = fixtureDatabase(), messages = database.collection("messages");
  await ingestStatusUpdates(messages, [{ key, update: { status: 4, messageTimestamp: 1791187208 } }]);
  await ingestUserReceipts(messages, [{ key, receipt: { receiptTimestamp: 1791187203 } }]);
  assert.equal(messages.docs.length, 0);
  assert.equal(database.collection("whatsapp_receipts").docs.length, 1);
  await syncMessage({ sessionId: "fixture", messages, conversations: database.collection("conversations"),
    msg: { key, message: { conversation: "fixture" }, status: 2, messageTimestamp: 1791187201 } });
  const row = messages.docs[0];
  assert.equal(row.body, "fixture");
  assert.equal(row.status, "read");
  assert.equal(row.provider_status, 4);
  assert.equal(row.read_at, "2026-10-05T08:00:08.000Z");
  assert.equal(row.delivered_at, "2026-10-05T08:00:03.000Z");
  assert.equal(row.sent_at, null); // Echo timestamp is not live receipt evidence.
});

test("concurrent first receipts and worker persistence retain strongest state and independent times", async () => {
  const database = fixtureDatabase(), messages = database.collection("messages");
  await Promise.all([
    saveReceipt(messages, "exact", "read", 1791187208),
    saveReceipt(messages, "exact", "delivered", 1791187203),
    saveReceipt(messages, "exact", "read", 1791187212),
    saveReceipt(messages, "exact", "failed", 1791187210),
    persist(messages), persist(messages),
  ]);
  assert.equal(messages.docs.length, 1);
  assert.equal(database.collection("whatsapp_receipts").docs.length, 1);
  assert.equal(messages.docs[0].status, "read");
  assert.equal(messages.docs[0].read_at, "2026-10-05T08:00:08.000Z");
  assert.equal(messages.docs[0].delivered_at, "2026-10-05T08:00:03.000Z");
  await persist(messages);
  assert.equal(messages.docs[0].status_at, messages.docs[0].read_at);
});

test("timestamp-less evidence survives insertOne and exact IDs never contaminate another message", async () => {
  const database = fixtureDatabase(), messages = database.collection("messages");
  await saveReceipt(messages, "exact", "read", null);
  await saveReceipt(messages, "exact-other", "delivered", 1791187203);
  await messages.insertOne({ wamid: "exact", status: "sent", body: "fixture" });
  assert.equal(messages.docs.length, 1);
  assert.equal(messages.docs[0].status, "read");
  for (const key of ["read_at", "delivered_at", "status_at"]) assert.equal(messages.docs[0][key], null);
  assert.equal(database.collection("whatsapp_receipts").docs.length, 2);
});

test("an ACK during the reserved SDK call is retained without permitting another send", async () => {
  const database = fixtureDatabase(), messages = database.collection("messages");
  const requests = database.collection("whatsapp_send_requests");
  const requestId = "a".repeat(64), to = "15550001111", text = "fixture";
  await requests.insertOne({ id: requestId, state: "sending", provider: "qr",
    recipient_address: to, message_body: text });
  let sends = 0;
  const args = { requestId, to, text, sessionId: "fixture", requests,
    generateMessageId: () => "exact",
    sock: { user: { id: "fixture" }, async sendMessage() {
      sends++;
      await ingestStatusUpdates(messages, [{ key, update: { status: 4 } }]);
      assert.equal(messages.docs.length, 0);
      return { key: { id: "exact" } };
    } } };
  const result = await sendReservedText(args);
  assert.equal(result.key.id, "exact");
  assert.equal(requests.docs[0].gateway_accepted_wamid, "exact");
  await persist(messages);
  assert.equal(messages.docs[0].status, "read");
  assert.equal(messages.docs[0].read_at, null);
  await assert.rejects(sendReservedText(args), /already submitted/);
  assert.equal(sends, 1);
});
