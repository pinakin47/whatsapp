const { identifyMr, loadBaseline, submit, summary, istDay, newSubmission } = require("./mr-reporting-data");
const { isMenuGreeting } = require("./incoming");
const { handleFieldFlow } = require("./mr-field-flow");
const PURPOSES = ["Product Promotion", "Order Collection", "New Customer", "Follow-up", "Payment Follow-up", "Quotation", "Other"];
const PURPOSE_TEXT = PURPOSES.map((p, i) => `${i + 1}. ${p}`).join("\n");
const PLAN_FIELDS = [
  ["planned_visits", "How many doctor/customer visits are you planning today?", "int"],
  ["visits", "Enter doctor/customer - location, one per message. Send DONE when finished.", "visits"],
  ["purpose", "Choose the visit purpose.", "purpose"],
  ["expected_sales", "What is your expected sales value today in INR?", "money"],
  ["quotes_yes", "Any quotations planned today? 1. Yes 2. No", "yes"],
  ["quote_count", "How many quotations?", "int"],
  ["quote_customer", "Quotation customer?", "text"],
  ["quote_product", "Quotation product?", "text"],
  ["quote_value", "Quotation value in INR?", "money"],
  ["followups_yes", "Pending follow-ups today? 1. Yes 2. No", "yes"],
  ["followups", "Enter customer/doctor - follow-up requirement. Send DONE when finished.", "list"],
  ["special_plan", "Any special activity or target today? Reply SKIP if none.", "optional"],
];
const CLOSE_FIELDS = [
  ["completed_visits", "How many planned visits did you actually complete?", "int"],
  ["doctor_visits", "How many doctors did you meet?", "int"],
  ["customer_visits", "How many hospitals/clinics/customers did you visit?", "int"],
  ["calls", "How many doctor/customer calls did you complete?", "int"],
  ["order_confirm", "Confirm orders already entered: 1. Yes 2. Edit", "yes"],
  ["orders", "How many orders did you receive today?", "int"],
  ["sales", "Today's total sales/order value in INR?", "money"],
  ["quotations", "How many quotations did you create/send today?", "int"],
  ["quotation_details", "Important quotation/customer details? Reply SKIP if none.", "optional"],
  ["new_customers_yes", "Any new doctors/customers today? 1. Yes 2. No", "yes"],
  ["new_customers", "Enter new customer/doctor - location. Send DONE when finished.", "list"],
  ["daily_achievement", "Most important result of today's field work?", "optional"],
  ["problems_yes", "Any problems today? 1. Yes 2. No", "yes"],
  ["problems", "Describe the problem.", "text"],
  ["pending_yes", "Pending follow-ups for tomorrow? 1. Yes 2. No", "yes"],
  ["pending_followups", "Enter customer - follow-up requirement. Send DONE when finished.", "list"],
  ["tomorrow_visits", "How many visits are planned for tomorrow?", "int"],
  ["tomorrow_plan", "Enter tomorrow's doctor/customer - location, one per message. Send DONE when finished.", "visits"],
  ["tomorrow_purpose", "Choose tomorrow's visit purpose.", "purpose"],
  ["tomorrow_order", "Expected order quantity for this visit? Enter 0 if none.", "int"],
  ["tomorrow_sales", "Expected sales in INR for this visit? Enter 0 if none.", "money"],
  ["remarks", "Any remarks for your manager? Reply SKIP if none.", "optional"],
];
const fields = phase => phase === "plan" ? PLAN_FIELDS : CLOSE_FIELDS;
const listKey = state => state.phase === "plan" ? "visits" : "tomorrow_plan";
const yn = text => /^(1|yes)$/i.test(text) ? true : /^(2|no)$/i.test(text) ? false : null;
const parseVisit = text => {
  const parts = text.split(/\s[-–—]\s/);
  return parts.length >= 2 && parts[0].trim() && parts.slice(1).join(" - ").trim() ?
    { name: parts[0].trim(), location: parts.slice(1).join(" - ").trim() } : null;
};
function prompt(state) {
  const spec = fields(state.phase).find(f => f[0] === state.field);
  let message = spec[1];
  if (spec[2] === "purpose") {
    const visit = state.data[listKey(state)]?.[state.cursor || 0];
    message += `\nVisit ${(state.cursor || 0) + 1}: ${visit?.name || ""}\n${PURPOSE_TEXT}`;
  }
  if (["tomorrow_order", "tomorrow_sales"].includes(state.field)) {
    message += `\nVisit ${(state.cursor || 0) + 1}: ${state.data.tomorrow_plan?.[state.cursor || 0]?.name}`;
  }
  if (state.field === "quote_customer") message += ` (${(state.cursor || 0) + 1}/${state.data.quote_count})`;
  if (state.field === "order_confirm") message += `\n${state.baseline.orders.length} orders, INR ${
    state.baseline.orders.reduce((n, o) => n + Number(o.total || 0), 0)}`;
  if (state.phase === "closing" && state.field === "completed_visits") {
    message = `You planned ${state.baseline.report?.plan?.planned_visits ?? state.baseline.visits.length} visits.\n${message}`;
  }
  const value = state.data[state.field];
  if (["int", "money", "optional"].includes(spec[2]) && value !== undefined)
    message += `\nExisting value: ${value}. Reply SAME to keep it, or enter a new value.`;
  return message + "\nBACK: Previous question | CANCEL: Discard draft";
}
function summaryText(state) {
  const d = state.data;
  const totals = summary(state.phase === "plan" ? d : state.baseline.report?.plan || {
    planned_visits: state.baseline.visits.filter(v => v.status !== "skipped").length,
  },
    state.phase === "closing" ? d : {});
  const lines = state.phase === "plan" ? [
    `Planned visits: ${d.planned_visits}`, `Quotations: ${(d.quotations || []).length}`,
    `Expected sales: INR ${d.expected_sales}`, `Follow-ups: ${(d.followups || []).length}`,
    `Special plan: ${d.special_plan || "None"}`,
  ] : Object.entries(totals).map(([k, v]) => `${k.replaceAll("_", " ")}: ${v ?? "Not set"}`);
  const visits = state.phase === "plan" ? d.visits || [] : d.tomorrow_plan || [];
  lines.push(...visits.map(v => `${v.name} - ${v.location}: ${v.purpose || "Other"}`));
  if (state.phase === "closing") lines.push(
    `Daily achievement: ${d.daily_achievement || "None"}`, `Problems: ${d.problems || "None"}`,
    `Tomorrow follow-ups: ${(d.pending_followups || []).join("; ") || "None"}`,
    `New customers: ${(d.new_customers || []).join("; ") || "None"}`, `Remarks: ${d.remarks || "None"}`);
  return `${state.phase === "plan" ? "TODAY'S PLAN" : "DAY CLOSING SUMMARY"}\nMR: ${state.mr.name} (${state.mr.employee_id})\n` +
    lines.join("\n") + "\n\n1. Confirm & Submit\n2. Edit\n3. Cancel";
}
function move(state, field) {
  const previous = state.field;
  const next = field || fields(state.phase)[fields(state.phase).findIndex(f => f[0] === state.field) + 1]?.[0];
  const cursor = ["purpose", "quote_value", "tomorrow_sales"].includes(previous) ?
    Math.max(0, (state.cursor || 0) - 1) : state.cursor || 0;
  state.history = [...(state.history || []), { field: previous, cursor }].slice(-100);
  state.field = next || "confirm";
  if (["visits", "tomorrow_plan"].includes(state.field)) state.list_started = null;
  return state.field === "confirm" ? summaryText(state) : prompt(state);
}
const menuText = (mr, mode) => `VGRUPS HEALTHCARE — ${mr.name} (${mr.employee_id})\n` +
  (mr.greeting ? mr.greeting + "\n" : "") +
  (mode === "closing" ? "1. Start day closing\n2. Complete later\n3. Talk to manager\nPLAN: Morning menu" :
    "1. Start today's plan\n2. Yesterday's pending follow-ups\n3. View my target\n4. Talk to manager\n5. My activity and next planned stop\n6. Sales encouragement\nCLOSING: Day closing menu") +
  (mr.field_flow_enabled ? "\n7. Full field activity flow (FIELD)" : "");

function createMrIvrRunner({ getDatabase, sendText, now = () => new Date() }) {
  const queues = new Map();
  async function process(sessionId, conversation, phone, body, meta = {}) {
    const db = getDatabase();
    const config = await db.collection("app_config").findOne({ key: "mr_ivr" });
    const mr = await identifyMr(db, phone);
    if (!mr) return false; // Customers cannot select the private MR workflow.
    const profile = await db.collection("mr_ivr_profiles").findOne({ id: mr.id });
    if (!config?.value?.enabled && profile?.value?.ivr_enabled !== true) return false;
    if (profile?.value?.ivr_enabled === false) return true;
    mr.greeting = profile?.value?.greeting || "";
    mr.field_flow_enabled = profile?.value?.field_flow_enabled === true;
    const live = await db.collection("conversations").findOne({ id: conversation.id, session_id: sessionId });
    if (!live) throw new Error("MR conversation does not belong to this QR session");
    const day = istDay(now());
    let state = live.mr_ivr?.date === day && live.mr_ivr?.mr?.id === mr.id ? live.mr_ivr : null;
    const text = String(body || "").trim();
    if (await handleFieldFlow({ db, mr, live, day, profile: profile?.value || {}, sessionId, phone, text, meta, sendText, now })) return true;
    const speak = async message => {
      await db.collection("conversations").updateOne({ id: live.id, session_id: sessionId },
        { $set: { mr_ivr: state } });
      await sendText(sessionId, phone, live.id, message, "MR reporting IVR");
      return true;
    };
    const baseline = await loadBaseline(db, mr, day);
    if (state?.data) state.baseline = baseline; // App activity may change while a draft is paused.
    const command = /^(plan|morning)$/i.test(text) ? "plan" : /^(closing|close|day closing|report)$/i.test(text) ? "closing" : null;
    if (live.human_takeover && !command && !/^(resume|start)$/i.test(text))
      return true; // A manager conversation must not be interrupted by automated menus.
    if (live.human_takeover && (command || /^resume$/i.test(text)))
      await db.collection("conversations").updateOne({ id: live.id }, { $set: { human_takeover: false } });
    if (command && state?.phase === command && !["menu", "confirm", "edit"].includes(state.field))
      return speak("Resuming your saved draft.\n" + prompt(state));
    if (/^(resume|later)$/i.test(text) && state && !["menu", "confirm", "edit"].includes(state.field))
      return speak(text.toLowerCase() === "later" ? "Draft saved. Reply RESUME when ready." : prompt(state));
    const invitation = live.mr_invitation;
    if (!command && invitation?.date === day && invitation.id !== state?.invitation_seen) {
      if (state && !["menu", "confirm", "edit"].includes(state.field) && state.phase !== invitation.phase) {
        state.invitation_seen = invitation.id;
        return speak("A new day-closing invitation arrived. Your current draft is saved. Reply RESUME to continue it, or CLOSING to start the closing menu.");
      }
      if (!state || state.field === "menu")
        state = { date: day, mr, phase: invitation.phase, field: "menu", invitation_seen: invitation.id };
    }
    if (command || !state || (text !== "0" && isMenuGreeting(text)) || /^menu$/i.test(text)) {
      const clock = new Intl.DateTimeFormat("en-GB", { timeZone: "Asia/Kolkata", hour: "2-digit", minute: "2-digit", hourCycle: "h23" }).format(now());
      state = { date: day, mr, phase: command || (clock >= (config?.value?.closing_time || "20:00") ? "closing" : "plan"), field: "menu" };
      return speak(menuText(mr, state.phase));
    }
    if (/^(cancel|3)$/i.test(text) && (text.toLowerCase() === "cancel" || state.field === "confirm")) {
      state = { date: day, mr, phase: state.phase, field: "menu" };
      return speak("Draft cancelled. Submitted reports are unchanged.\n" + menuText(mr, state.phase));
    }
    if (/^help$/i.test(text)) return speak("Reply with the answer requested, BACK to go back, CANCEL to discard the draft, PLAN or CLOSING to change menus.");
    const manager = async () => {
      const managerAccount = await db.collection("users").findOne({
        role: { $in: ["admin", "super_admin", "sales_manager"] },
        active: { $ne: false }, deleted: { $ne: true }, is_demo: { $ne: true },
      });
      const taskId = `mr-help:${day}:${mr.id}`;
      await db.collection("tasks").updateOne({ id: taskId }, { $setOnInsert: {
        id: taskId, title: `MR manager assistance: ${mr.name}`, description: `Employee ${mr.employee_id}; WhatsApp assistance requested.`,
        status: "pending", priority: "high", assigned_to: managerAccount?.id || null, created_by: mr.mr_id,
        created_at: now().toISOString(), source: "mr_ivr", conversation_id: live.id,
      } }, { upsert: true });
      await db.collection("conversations").updateOne({ id: live.id }, { $set: {
        human_takeover: true, assigned_to: managerAccount?.id || null,
      } });
      return speak("Your manager assistance request has been recorded. Reply PLAN or CLOSING to resume self-service.");
    };
    if (/^(manager|agent|human)$/i.test(text)) return manager();
    if (state.field === "menu") {
      if (state.phase === "plan" && ["5", "6"].includes(text)) {
        const plan = baseline.report?.plan || { planned_visits: baseline.visits.filter(v => v.status !== "skipped").length };
        const closing = baseline.report?.closing || {
          completed_visits: baseline.visits.filter(v => v.status === "visited").length,
          sales: baseline.orders.reduce((n, o) => n + Number(o.total || 0), 0),
        };
        const totals = summary(plan, closing);
        const stop = baseline.visits.find(v => v.status === "planned");
        const destination = stop ? [stop.doctor_name || stop.clinic_name, stop.city || stop.address].filter(Boolean).join(" - ") : "No pending destination recorded";
        if (text === "5") return speak(`Today's recorded activity: ${totals.completed_visits}/${totals.planned_visits} visits; sales INR ${totals.sales}.\nNext planned stop (not live location): ${destination}\n${menuText(mr, "plan")}`);
        const template = profile?.value?.encouragement_template ||
          "Hi {name}, keep progressing with your {planned_visits} planned visits. Your daily sales goal is INR {daily_goal}. Reply CLOSING to share your results.";
        const values = { ...totals, name: mr.name, employee_id: mr.employee_id, date: day,
          daily_goal: totals.daily_goal ?? "not set", next_destination: destination };
        return speak(template.replace(/\{([a-z_]+)\}/g, (_, key) => String(values[key] ?? "not set")) + "\n" + menuText(mr, "plan"));
      }
      if ((state.phase === "plan" && text === "4") || (state.phase === "closing" && text === "3")) return manager();
      if (state.phase === "closing" && text === "2") return speak("You can complete this later. Reply CLOSING when ready.");
      if (state.phase === "plan" && text === "2")
        return speak("Yesterday's pending follow-ups:\n" + (baseline.previous?.closing?.pending_followups || []).join("\n") +
          (baseline.previous?.closing?.pending_followups?.length ? "" : "None recorded.") + "\n" + menuText(mr, "plan"));
      if (state.phase === "plan" && text === "3") return speak(baseline.target ?
        `Assigned MONTHLY target (${day.slice(0, 7)}): ${baseline.target.visit_target} visits; INR ${baseline.target.order_target}\n${menuText(mr, "plan")}` :
        "No assigned monthly target is recorded.\n" + menuText(mr, "plan"));
      if (text !== "1") return speak(menuText(mr, state.phase));
      const existing = state.phase === "plan" ? baseline.report?.plan : baseline.report?.closing;
      const knownVisits = baseline.visits.filter(v => v.status !== "skipped").map(v => ({
        name: v.doctor_name || v.clinic_name, location: v.city || v.address || "Not recorded", purpose: v.notes || "Other",
      }));
      state = { ...state, baseline, data: existing ? JSON.parse(JSON.stringify(existing)) : (
        state.phase === "plan" ? { planned_visits: knownVisits.length, visits: knownVisits } : {
          completed_visits: baseline.visits.filter(v => v.status === "visited").length,
          quotations: baseline.quotations.length,
          quotation_details: baseline.quotations.map(q => `${q.quote_no}: INR ${q.total}`).join("; "),
        }), field: state.phase === "plan" ? "planned_visits" : "completed_visits", history: [], submission_id: newSubmission(), cursor: 0 };
      await db.collection("conversations").updateOne({ id: live.id }, { $set: { human_takeover: false } });
      return speak(prompt(state));
    }
    if (/^back$/i.test(text) && state.history?.length) {
      const prev = state.history.pop(); state.field = prev.field; state.cursor = prev.cursor;
      state.list_started = null;
      return speak(state.field === "confirm" ? summaryText(state) : prompt(state));
    }
    if (state.field === "confirm") {
      if (text === "2") {
        state.field = "edit";
        return speak("Choose a question to edit:\n" + fields(state.phase).map((f, i) => `${i + 1}. ${f[1]}`).join("\n"));
      }
      if (text !== "1") return speak(summaryText(state));
      const d = state.data;
      if (state.phase === "plan" && (d.visits || []).length !== d.planned_visits)
        return speak("Visit list length must match planned visits. Choose 2 to edit.\n" + summaryText(state));
      if (state.phase === "closing" && (d.doctor_visits + d.customer_visits !== d.completed_visits ||
          (d.tomorrow_plan || []).length !== d.tomorrow_visits))
        return speak("Doctor + hospital/customer counts must equal completed visits; tomorrow's list must match tomorrow's count. Choose 2 to edit.");
      await submit(db, mr, day, state.phase, d, state.submission_id);
      const phase = state.phase; state = { date: day, mr, phase, field: "menu" };
      return speak(phase === "plan" ? "Today's plan has been submitted successfully.\n" + menuText(mr, phase) :
        "Day closing submitted successfully. Your report is saved in Field Sales. Management notifications are queued; delivery status is shown in the application.\n" + menuText(mr, phase));
    }
    if (state.field === "edit") {
      const f = fields(state.phase)[Number(text) - 1];
      if (!f) return speak("Please choose a listed question number.");
      if ((f[2] === "purpose" || ["tomorrow_order", "tomorrow_sales"].includes(f[0])) &&
          !state.data[listKey(state)]?.length)
        return speak("No visits are listed. Edit the planned visit count and visit list first.");
      if (["quote_customer", "quote_product", "quote_value"].includes(f[0]) && !state.data.quote_count)
        return speak("No quotations are planned. Edit the quotation question and count first.");
      if (f[0] === "order_confirm" && !state.baseline.orders.length)
        return speak("No confirmed application orders are recorded today. Choose the order count or sales question to edit.");
      state.field = f[0]; state.cursor = 0; state.list_started = null;
      return speak(prompt(state)); // Keep other answers; walk remaining questions using SAME.
    }
    const spec = fields(state.phase).find(f => f[0] === state.field);
    const [key, , type] = spec;
    const d = state.data;
    const value = /^same$/i.test(text) ? d[key] : text;
    let answer, message;
    if (["int", "money"].includes(type)) {
      const raw = String(value ?? "").replace(/,/g, "").replace(/^₹/, "");
      if (!/^\d+(\.\d{1,2})?$/.test(raw) || !Number.isFinite(Number(raw)) ||
          Number(raw) > (type === "int" ? 10000 : 1e12) ||
          (type === "int" && !Number.isInteger(Number(raw)))) return speak("Enter a valid non-negative " + (type === "int" ? "whole number." : "amount with at most 2 decimal places."));
      answer = Number(raw); d[key] = answer;
      if (key === "planned_visits") {
        if (answer > 100) return speak("At most 100 planned detailed visits per day.");
        if (!answer) d.visits = [];
        message = move(state, answer ? "visits" : "expected_sales");
      }
      else if (key === "quote_count") {
        if (answer > 100) return speak("At most 100 quotation details per plan.");
        d.quotations = []; state.cursor = 0; message = move(state, answer ? "quote_customer" : "followups_yes");
      } else if (key === "quote_value") {
        d.quotations = d.quotations || []; d.quotations[state.cursor] = { customer: d.quote_customer, product: d.quote_product, value: answer };
        state.cursor++; message = move(state, state.cursor < d.quote_count ? "quote_customer" : "followups_yes");
      } else if (key === "tomorrow_visits") {
        if (answer > 100) return speak("At most 100 planned detailed visits for tomorrow.");
        if (!answer) d.tomorrow_plan = [];
        message = move(state, answer ? "tomorrow_plan" : "remarks");
      } else if (key === "tomorrow_order") {
        d.tomorrow_plan[state.cursor].expected_order = answer; message = move(state, "tomorrow_sales");
      } else if (key === "tomorrow_sales") {
        d.tomorrow_plan[state.cursor].expected_sales = answer; state.cursor++;
        message = move(state, state.cursor < d.tomorrow_plan.length ? "tomorrow_purpose" : "remarks");
      } else if (key === "calls") message = move(state, state.baseline.orders.length ? "order_confirm" : "orders");
      else message = move(state);
    } else if (type === "yes") {
      answer = yn(text);
      if (answer === null) return speak("Reply 1 for Yes or 2 for No.");
      d[key] = answer;
      if (key === "quotes_yes") { if (!answer) d.quotations = []; message = move(state, answer ? "quote_count" : "followups_yes"); }
      if (key === "followups_yes") { d.followups = []; message = move(state, answer ? "followups" : "special_plan"); }
      if (key === "new_customers_yes") { d.new_customers = []; message = move(state, answer ? "new_customers" : "daily_achievement"); }
      if (key === "problems_yes") { if (!answer) d.problems = "No problem"; message = move(state, answer ? "problems" : "pending_yes"); }
      if (key === "pending_yes") { d.pending_followups = []; message = move(state, answer ? "pending_followups" : "tomorrow_visits"); }
      if (key === "order_confirm") {
        if (answer) { d.orders = state.baseline.orders.length; d.sales = state.baseline.orders.reduce((n, o) => n + Number(o.total || 0), 0); }
        message = move(state, answer ? "quotations" : "orders");
      }
    } else if (type === "list" || type === "visits") {
      if (/^same$/i.test(text) && type === "visits" && d[key]?.length) {
        state.cursor = 0; message = move(state, key === "visits" ? "purpose" : "tomorrow_purpose");
      } else if (/^done$/i.test(text)) {
        const expected = key === "visits" ? d.planned_visits : key === "tomorrow_plan" ? d.tomorrow_visits : null;
        if (expected !== null && (d[key] || []).length !== expected) return speak(`Please enter exactly ${expected} visits, then DONE. CANCEL discards this draft.`);
        if (expected === null && !d[key]?.length) return speak("Enter at least one item before DONE.");
        state.cursor = 0; message = move(state, key === "visits" ? "purpose" : key === "tomorrow_plan" ? "tomorrow_purpose" : null);
      } else {
        answer = type === "visits" ? parseVisit(text) : text;
        if (!answer || text.length > 1000) return speak("Enter a valid " + (type === "visits" ? "name - location." : "name and requirement (at most 1000 characters)."));
        if (!state.list_started || state.list_started !== key) { d[key] = []; state.list_started = key; }
        if (d[key].length >= 100) return speak("At most 100 detailed entries. Send DONE.");
        d[key].push(answer); message = `Saved entry ${d[key].length}. Send the next entry, or DONE.`;
      }
    } else if (type === "purpose") {
      answer = PURPOSES[Number(text) - 1];
      if (!answer) return speak(PURPOSE_TEXT + "\nChoose 1–7.");
      d[listKey(state)][state.cursor].purpose = answer;
      if (state.phase === "closing") message = move(state, "tomorrow_order");
      else { state.cursor++; message = move(state, state.cursor < d.visits.length ? "purpose" : "expected_sales"); }
    } else {
      if (!value || String(value).length > 2000) return speak("Enter an answer of at most 2000 characters.");
      d[key] = /^skip$/i.test(String(value)) && type === "optional" ? "" : String(value);
      message = move(state);
    }
    return speak(message);
  }
  return async (...args) => {
    const key = `${args[0]}:${args[1].id}`;
    const job = (queues.get(key) || Promise.resolve()).catch(() => {}).then(() => process(...args));
    queues.set(key, job);
    try { return await job; } finally { if (queues.get(key) === job) queues.delete(key); }
  };
}
module.exports = { createMrIvrRunner, PLAN_FIELDS, CLOSE_FIELDS, summaryText };