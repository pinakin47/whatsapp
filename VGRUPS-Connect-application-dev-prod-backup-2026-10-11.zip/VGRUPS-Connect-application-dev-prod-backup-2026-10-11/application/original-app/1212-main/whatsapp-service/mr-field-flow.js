const { randomUUID } = require("crypto");
const { loadBaseline, submit } = require("./mr-reporting-data");
const { TYPES, REASONS, STATUSES, STATUS_KEYS, numbered, MENU, HELP, VISIT_FIELDS, CLOSE_FIELDS, ENTRY_FIELDS, parseValue, closingSummary } = require("./mr-field-content");

async function handleFieldFlow({ db, mr, live, day, profile, sessionId, phone, text, meta = {}, sendText, now }) {
  if (!profile.field_flow_enabled) return false;
  let s = live.mr_field_state?.date === day && live.mr_field_state?.mr_id === mr.id ? live.mr_field_state : null;
  const legacyMenu = !live.mr_ivr || live.mr_ivr.field === "menu" ||
    (live.mr_invitation?.date === day && live.mr_invitation.id !== live.mr_ivr?.invitation_seen);
  const enterSeven = text === "7" && legacyMenu && !s?.active;
  const explicit = /^(field|start|start day visit|start day closing|day visit|status|midday|order|followup|pending|leave|mark leave|help|manager)$/i.test(text) ||
    enterSeven;
  const invite = live.mr_field_invitation;
  const unseenInvite = invite?.date === day && invite.id !== s?.invitation_seen;
  if (!s?.active && !explicit && !(unseenInvite && /^[1-5]$/.test(text))) return false;
  if (meta.message_id && s?.last_message_id === meta.message_id) return true;
  if (live.human_takeover && !/^(field|start|resume|plan|closing|pending|help|status)$/i.test(text)) return true;
  if (live.human_takeover && /^(field|start|resume|closing|pending)$/i.test(text))
    await db.collection("conversations").updateOne({ id: live.id }, { $set: { human_takeover: false } });
  s ||= { date: day, mr_id: mr.id, active: true, step: "menu" };
  if (explicit && !/^midday$/i.test(text) && invite?.id) s.invitation_seen = invite.id;
  const days = db.collection("mr_field_days");
  const dayId = target => `${target}:${mr.id}`;
  let daily = await days.findOne({ id: dayId(day) }) || {};
  const updateDay = async (patch, target = day) => {
    await days.updateOne({ id: dayId(target) }, { $set: {
      id: dayId(target), date: target, mr_directory_id: mr.id, mr_id: mr.mr_id,
      mr_name: mr.name, employee_id: mr.employee_id, ...patch, updated_at: now().toISOString(),
    } }, { upsert: true });
    if (target === day) daily = { ...daily, ...patch };
  };
  const ack = async message => {
    s.active = true;
    if (meta.message_id) s.last_message_id = meta.message_id;
    await db.collection("conversations").updateOne({ id: live.id, session_id: sessionId }, { $set: { mr_field_state: s } });
    await sendText(sessionId, phone, live.id, `Thank you for your message, ${mr.name}.\n\n${message}`, "MR field activity IVR");
    return true;
  };
  const pause = () => {
    if (["visit_type", "visit_form", "visit_result", "reschedule_date", "entry_form", "entry_confirm", "closing_form", "closing_confirm"].includes(s.step)) {
      s.paused = { step: s.step, data: s.data, cursor: s.cursor, kind: s.kind, record_id: s.record_id, started_at: s.started_at, visit_type: s.visit_type,
        report_date: s.report_date, submission_id: s.submission_id, previous: s.paused };
    }
  };
  const question = () => {
    const fields = s.step === "visit_form" ? VISIT_FIELDS : s.step === "entry_form" ? ENTRY_FIELDS[s.kind] : CLOSE_FIELDS;
    const f = fields[s.cursor];
    return (s.step === "closing_form" ? `DAY CLOSING — Step ${f[3]} of 8\n` : "") + f[1];
  };
  const resume = async () => {
    if (s.paused) { const saved = s.paused; Object.assign(s, saved); s.paused = saved.previous; delete s.previous; }
    if (["visit_form", "entry_form", "closing_form"].includes(s.step)) return ack("Resuming your saved draft.\n" + question());
    if (s.step === "visit_result") return ack("Visit draft saved.\n1 — Visit Completed\n2 — Doctor/Customer Not Available\n3 — Reschedule Visit\n4 — Add Another Visit");
    if (s.step === "reschedule_date") return ack("Enter the new planned visit date in YYYY-MM-DD format.");
    if (s.step === "visit_type") return ack("Select the visit type:\n" + numbered(TYPES));
    if (s.step === "closing_confirm") return ack(closingSummary(mr, s.report_date || day, s.data));
    return ack(MENU);
  };
  const manager = async () => {
    pause(); s.step = "manager_reason"; s.request_id = randomUUID();
    return ack("Please select the reason for manager assistance:\n" + numbered(REASONS));
  };
  const startClosing = async (target = day, stored = null) => {
    const old = await days.findOne({ id: dayId(target) });
    const baseline = await loadBaseline(db, mr, target);
    if (old?.closing_status === "completed" || baseline.report?.closing_submitted_at) {
      s.step = "menu";
      return ack(`Day closing for ${target} is already completed. Saved reports remain unchanged.\n${MENU}`);
    }
    pause();
    s.step = "closing_form"; s.report_date = target; s.cursor = stored?.cursor || old?.closing_draft?.cursor || 0;
    s.data = stored?.data || old?.closing_draft?.data || {};
    s.submission_id = stored?.submission_id || old?.closing_draft?.submission_id || randomUUID();
    if (s.cursor >= CLOSE_FIELDS.length) { s.step = "closing_confirm"; return ack(closingSummary(mr, target, s.data)); }
    await updateDay({ closing_status: "pending", closing_draft: { cursor: s.cursor, data: s.data, submission_id: s.submission_id } }, target);
    return ack(`DAY CLOSING HAS BEEN STARTED for ${target}.\n` + question());
  };
  const closingInvite = live.mr_invitation;
  if (closingInvite?.date === day && closingInvite.phase === "closing" && closingInvite.id !== s.shared_invitation_seen) {
    s.shared_invitation_seen = closingInvite.id;
    if (/^[1-3]$/.test(text)) {
      if (s.step !== "menu") return ack("A closing invitation arrived. Your current draft is saved. Reply CLOSING to begin closing, or RESUME to continue your draft.");
      if (text === "1") return startClosing();
      if (text === "3") return manager();
      await updateDay({ closing_status: "pending", closing_draft: daily.closing_draft || {
        cursor: 0, data: {}, submission_id: randomUUID() } });
      return ack("Day closing saved as PENDING. Reply PENDING or CLOSING to complete it before " + (profile.closing_deadline || "21:00") + " IST.");
    }
  }
  if (/^plan$/i.test(text)) {
    pause(); s.active = false;
    await db.collection("conversations").updateOne({ id: live.id }, { $set: { mr_field_state: s, human_takeover: false } });
    return false; // Original planning state and menu are intentionally untouched.
  }
  if (/^(field|help)$/i.test(text) || enterSeven) {
    pause(); s.step = "menu";
    return ack(text.toLowerCase() === "help" ? HELP : MENU);
  }
  if (/^cancel$/i.test(text)) {
    if (s.step.startsWith("closing")) {
      await updateDay({ closing_status: "not_submitted", closing_draft: null }, s.report_date || day);
    }
    s = { date: day, mr_id: mr.id, active: true, step: "menu", invitation_seen: s.invitation_seen };
    return ack("Current draft discarded. Saved reports, visits and requests are unchanged.\n" + MENU);
  }
  if (/^(later|complete later)$/i.test(text)) {
    if (s.step === "menu") {
      if (daily.closing_status === "completed") return ack("Today's closing is already completed. Reply STATUS to review it.");
      if (/^complete later$/i.test(text)) await updateDay({ closing_status: "pending",
        closing_draft: daily.closing_draft || { cursor: 0, data: {}, submission_id: randomUUID() } });
      else return ack("Reply CLOSING to begin a closing report, or DAY VISIT to record a visit.");
    }
    return ack("Your draft is saved as PENDING. Reply RESUME, DAY VISIT or PENDING to continue. Closing deadline: " + (profile.closing_deadline || "21:00") + " IST.");
  }
  if (/^resume$/i.test(text)) {
    await db.collection("conversations").updateOne({ id: live.id }, { $set: { human_takeover: false } });
    return resume();
  }
  if (/^status$/i.test(text)) {
    const base = await loadBaseline(db, mr, day);
    const counts = base.visits.filter(v => v.status === "visited");
    return ack(`VGRUPS HEALTHCARE — TODAY'S STATUS\nDate: ${day}\nDay status: ${daily.status || "Not started"}\n` +
      `Completed recorded visits: ${counts.length}\nDoctors: ${counts.filter(v => v.visit_type === "Doctor").length}\n` +
      `Hospitals/clinics: ${counts.filter(v => ["Hospital", "Clinic"].includes(v.visit_type)).length}\n` +
      `Actual owned orders: INR ${base.orders.reduce((n, o) => n + Number(o.total || 0), 0)}\n` +
      `Reported closing order value: ${base.report?.closing ? "INR " + base.report.closing.sales : "Not submitted"}\n` +
      `New leads reported: ${base.report?.closing?.new_leads ?? "Not submitted"}\n` +
      `Closing: ${base.report?.closing_submitted_at ? "COMPLETED" : daily.closing_status || "Not started"}\n` +
      "DAY VISIT — Add visit | CLOSING — Close day | MANAGER — Assistance");
  }
  if (/^(manager|talk to manager)$/i.test(text)) return manager();
  if (/^pending$/i.test(text)) {
    const rows = await days.find({ mr_directory_id: mr.id, closing_status: "pending" }).toArray();
    const pending = rows.sort((a, b) => b.date.localeCompare(a.date))[0];
    return pending ? startClosing(pending.date, pending.closing_draft) : ack("No pending field-activity closing report is recorded.\n" + MENU);
  }
  if (/^(closing|start day closing)$/i.test(text)) return startClosing();
  if (/^(start|start day visit)$/i.test(text) || (s.step === "menu" && text === "1" && !unseenInvite)) {
    if (daily.status === "on_leave") return ack("A leave request is recorded for today. Contact your manager before starting field work.");
    if (daily.closing_status === "completed") return ack("Today's closing is completed. Reply STATUS to review it.");
    await db.collection("conversations").updateOne({ id: live.id }, { $set: { human_takeover: false } });
    await updateDay({ status: "started", started_at: daily.started_at || now().toISOString() });
    s.step = "location";
    return ack("Day Visit has been started successfully.\nBefore your first visit, share a WhatsApp location pin.\n1 — Location Shared\n2 — Unable to Share Location\n3 — Talk to Manager");
  }
  if (/^(leave|mark leave)$/i.test(text) || (s.step === "menu" && text === "4" && !unseenInvite)) {
    pause(); s.step = "leave_reason"; return ack("Please enter the reason for today's leave request. It requires manager review.");
  }
  if (/^day visit$/i.test(text)) {
    if (s.paused && ["visit_type", "visit_form", "visit_result", "reschedule_date"].includes(s.paused.step)) return resume();
    if (["visit_type", "visit_form", "visit_result", "reschedule_date"].includes(s.step)) return resume();
    if (!daily.started_at) return ack("Please reply START DAY VISIT before recording your first visit.");
    if (daily.status === "on_leave" || daily.closing_status === "completed") return ack("Field visits are closed for today. Reply STATUS or MANAGER.");
    s.step = "visit_type"; s.record_id = randomUUID(); s.started_at = now().toISOString(); s.data = {};
    return ack("Your field visit has been initiated. Select the visit type:\n" + numbered(TYPES));
  }
  if (/^(order|followup)$/i.test(text)) {
    pause(); s.kind = text.toLowerCase(); s.step = "entry_form"; s.data = {}; s.cursor = 0; s.record_id = randomUUID();
    return ack(question());
  }
  if (/^midday$/i.test(text) || (unseenInvite && /^[1-5]$/.test(text))) {
    if (unseenInvite && !["menu", "midday"].includes(s.step) && text.toLowerCase() !== "midday") {
      s.invitation_seen = invite.id;
      return ack("A mid-day check arrived. Your current draft is saved. Reply MIDDAY to answer it, or RESUME to continue the draft.");
    }
    pause(); s.step = "midday"; s.reminder = invite?.kind === "midday_reminder"; s.invitation_seen = invite?.id;
    if (/^midday$/i.test(text)) return ack("Please update your current status:\n" +
      numbered(s.reminder ? [STATUSES[0], STATUSES[1], STATUSES[3], "Talk to Manager"] : STATUSES));
  }
  if (s.step === "midday") {
    const choices = s.reminder ? [0, 1, 3, 4] : [0, 1, 2, 3, 4];
    const index = /^\d+$/.test(text) ? choices[Number(text) - 1] :
      choices.find(i => STATUSES[i].toLowerCase() === text.toLowerCase());
    if (index === undefined) return ack("Please select a valid status.\n" + numbered(choices.map(i => STATUSES[i])));
    await updateDay({ midday_status: STATUS_KEYS[index], status: STATUS_KEYS[index], midday_updated_at: now().toISOString() });
    if (index === 4) return manager();
    s.step = "menu";
    return ack(`Your status has been recorded as ${STATUSES[index].toUpperCase()}.\nPlease record your visits, order notes and follow-ups.\nCLOSING — Start day closing | DAY VISIT — Add another visit`);
  }
  if (s.step === "location") {
    const lat = meta.location?.degreesLatitude, lon = meta.location?.degreesLongitude;
    if (typeof lat === "number" && typeof lon === "number" && Number.isFinite(lat) && Number.isFinite(lon) && Math.abs(lat) <= 90 && Math.abs(lon) <= 180) {
      await updateDay({ location_status: "shared", location: { latitude: lat, longitude: lon, recorded_at: now().toISOString() } });
      s.step = "menu"; return ack("Your shared location pin has been recorded. This is a check-in, not live tracking.\nHave a productive day.\nDAY VISIT — Start customer/doctor visit");
    }
    if (/^(2|unable to share location)$/i.test(text)) {
      await updateDay({ location_status: "unable_to_share" }); s.step = "menu";
      return ack("Unable to share location recorded. This reply recorded no new coordinates; earlier check-ins remain unchanged.\nDAY VISIT — Start visit | MANAGER — Assistance");
    }
    if (/^(3|talk to manager)$/i.test(text)) return manager();
    return ack("No valid location pin has been received yet. Use WhatsApp Attach → Location, or reply 2 if unable to share. Typing 1 does not record coordinates.");
  }
  if (s.step === "leave_reason") {
    if (!text || text.length > 2000) return ack("Enter a leave reason of 1–2000 characters, or CANCEL.");
    const id = `mr-leave:${day}:${mr.id}`;
    await db.collection("mr_leave_requests").updateOne({ id }, { $setOnInsert: {
      id, mr_directory_id: mr.id, mr_id: mr.mr_id, date: day, reason: text, status: "pending",
      requested_at: now().toISOString(), conversation_id: live.id,
    } }, { upsert: true });
    await updateDay({ status: "on_leave", leave_status: "pending" }); s.step = "menu";
    return ack("Your leave request is recorded as PENDING manager review. It is not an approved leave.");
  }
  if (s.step === "manager_reason") {
    const reason = REASONS[Number(text) - 1] || REASONS.find(v => v.toLowerCase() === text.toLowerCase());
    if (!reason) return ack("Please select one of the six reasons:\n" + numbered(REASONS));
    const real = { active: { $ne: false }, deleted: { $ne: true }, is_demo: { $ne: true } };
    const selected = mr.manager_id && await db.collection("users").findOne({ id: mr.manager_id, ...real, role: { $in: ["admin", "super_admin", "sales_manager"] } });
    const managerAccount = selected || await db.collection("users").findOne({ ...real, role: { $in: ["admin", "super_admin", "sales_manager"] } });
    const id = `mr-field-manager:${mr.id}:${s.request_id}`;
    await db.collection("mr_manager_requests").updateOne({ id }, { $setOnInsert: {
      id, mr_id: mr.id, directory_id: mr.id, mr_name: mr.name, date: day, reason,
      assigned_to: managerAccount?.id || null, status: managerAccount ? "assigned" : "unassigned",
      source: "mr_field_ivr", requested_at: now().toISOString(), conversation_id: live.id,
    } }, { upsert: true });
    s.step = "menu";
    await db.collection("conversations").updateOne({ id: live.id }, { $set: { human_takeover: true, assigned_to: managerAccount?.id || null } });
    return ack(managerAccount ? "Your request has been recorded and assigned to a manager in the Inbox. For urgent issues, contact your manager directly. FIELD or RESUME returns to self-service." :
      "Your request was recorded, but no active manager is available for assignment. Contact your manager directly. FIELD returns to self-service.");
  }
  if (s.step === "menu") {
    if (/^(2|view today's plan)$/i.test(text)) {
      const base = await loadBaseline(db, mr, day);
      const plans = base.report?.plan?.visits || base.visits.filter(v => v.status === "planned")
        .map(v => ({ name: v.doctor_name || v.clinic_name, location: v.city || v.address || "Not recorded" }));
      return ack("TODAY'S RECORDED PLAN\n" + (plans.map(v => `${v.name} — ${v.location}`).join("\n") || "No planned destinations recorded. Reply PLAN to prepare a plan.") +
        "\nThese are planned destinations, not live location.\n" + MENU);
    }
    if (/^(3|talk to manager)$/i.test(text)) return manager();
    return ack("Sorry, we could not understand your response. Select an available option.\n" + HELP);
  }
  if (s.step === "visit_type") {
    const type = TYPES[Number(text) - 1] || TYPES.find(v =>
      [v.toLowerCase(), v.toLowerCase().split(" /")[0]].includes(text.toLowerCase().replace(/\s+visit$/, "")));
    if (!type) return ack("Please select a visit type from 1 to 8.\n" + numbered(TYPES));
    s.visit_type = type; s.step = "visit_form"; s.cursor = 0;
    return ack(`${type} Visit selected.\n` + question());
  }
  if (["visit_form", "entry_form", "closing_form"].includes(s.step)) {
    const fields = s.step === "visit_form" ? VISIT_FIELDS : s.step === "entry_form" ? ENTRY_FIELDS[s.kind] : CLOSE_FIELDS;
    if (/^back$/i.test(text) && s.cursor > 0) {
      s.cursor--;
      if (s.step === "closing_form" && fields[s.cursor][0] === "sales" && !s.data.orders_yes) s.cursor--;
      return ack(question());
    }
    const [key, , type] = fields[s.cursor];
    const value = parseValue(text, type);
    if (value === null) return ack("Invalid answer. Enter a valid non-negative number or the requested text (maximum 2000 characters).\n" + question());
    s.data[key] = value; s.cursor++;
    if (s.step === "closing_form") {
      if (key === "orders_yes" && !value) { s.data.sales = 0; s.cursor++; }
      if (key === "sales" && s.data.orders_yes && value === 0) { s.cursor--; return ack("Orders were marked YES. Enter a positive value, or reply BACK to change the order status."); }
      await updateDay({ closing_status: "pending", closing_draft: { cursor: s.cursor, data: s.data, submission_id: s.submission_id } }, s.report_date || day);
    }
    if (s.cursor < fields.length) return ack(`Recorded ${key.replaceAll("_", " ")}: ${value === "" ? "None" : value}.\n` + question());
    if (s.step === "visit_form") { s.step = "visit_result"; return ack("Visit details received.\n1 — Visit Completed\n2 — Doctor/Customer Not Available\n3 — Reschedule Visit\n4 — Add Another Visit"); }
    if (s.step === "entry_form") { s.step = "entry_confirm"; return ack("Please review this reported " + s.kind + " note:\n" + Object.entries(s.data).map(([k, v]) => `${k}: ${v || "None"}`).join("\n") + "\n1 — Save note\n2 — Edit\n3 — Manager"); }
    s.step = "closing_confirm"; return ack(closingSummary(mr, s.report_date || day, s.data));
  }
  if (s.step === "reschedule_date") {
    const stamp = Date.parse(text + "T12:00:00Z");
    if (!/^\d{4}-\d{2}-\d{2}$/.test(text) || !Number.isFinite(stamp) ||
        new Date(stamp).toISOString().slice(0, 10) !== text || text < day)
      return ack("Enter a valid visit date on or after today in YYYY-MM-DD format, or CANCEL.");
    s.data.rescheduled_date = text; s.step = "visit_result"; text = "3";
  }
  if (s.step === "visit_result") {
    text = ({ "visit completed": "1", "doctor not available": "2", "customer not available": "2",
      "not available": "2", "reschedule visit": "3", "add another visit": "4" })[text.toLowerCase()] || text;
    if (!/^[1-4]$/.test(text)) return ack("Select 1 completed, 2 unavailable, 3 reschedule or 4 add another visit.");
    if (text === "3" && !s.data.rescheduled_date) {
      s.step = "reschedule_date";
      return ack("Please enter the new planned visit date in YYYY-MM-DD format. No reschedule is recorded until you provide a valid date.");
    }
    if (text === "4") {
      s.paused = { step: "visit_result", data: s.data, cursor: s.cursor, record_id: s.record_id, started_at: s.started_at, visit_type: s.visit_type, previous: s.paused };
      s.step = "visit_type"; s.data = {}; s.record_id = randomUUID(); s.started_at = now().toISOString();
      return ack("Previous visit draft is saved; it was not marked complete. RESUME restores it.\nSelect your next visit type:\n" + numbered(TYPES));
    }
    const status = { 1: "visited", 2: "unavailable", 3: "rescheduled" }[text];
    await db.collection("field_visits").updateOne({ id: s.record_id }, { $setOnInsert: {
      id: s.record_id, mr_id: mr.mr_id, mr_directory_id: mr.id, planned_date: day,
      doctor_name: s.data.name, visit_type: s.visit_type, purpose: s.data.purpose,
      products_discussed: s.data.products, reported_order_value: s.data.order_value,
      followup: s.data.followup, remarks: s.data.remarks, status, check_in_at: s.started_at,
      ...(s.data.rescheduled_date ? { rescheduled_date: s.data.rescheduled_date } : {}),
      check_out_at: now().toISOString(), source: "mr_field_ivr", created_at: s.started_at,
      ...(daily.location ? { day_check_in_location: daily.location } : {}),
    } }, { upsert: true });
    if (s.data.rescheduled_date) await db.collection("field_visits").updateOne({ id: `reschedule:${s.record_id}` }, { $setOnInsert: {
      id: `reschedule:${s.record_id}`, mr_id: mr.mr_id, mr_directory_id: mr.id,
      planned_date: s.data.rescheduled_date, doctor_name: s.data.name, visit_type: s.visit_type,
      purpose: s.data.purpose, notes: s.data.followup || s.data.purpose,
      status: "planned", rescheduled_from: s.record_id, source: "mr_field_ivr", created_at: now().toISOString(),
    } }, { upsert: true });
    s.step = "menu"; return ack(`Visit recorded as ${status.toUpperCase()}${s.data.rescheduled_date ? " for " + s.data.rescheduled_date : ""}. No sales order was created.\nDAY VISIT — Next visit | STATUS — Progress | CLOSING — Close day`);
  }
  if (s.step === "entry_confirm") {
    if (text === "2") { s.step = "entry_form"; s.cursor = 0; return ack(question()); }
    if (text === "3") return manager();
    if (text !== "1") return ack("Select 1 save, 2 edit or 3 manager.");
    await db.collection("mr_field_entries").updateOne({ id: s.record_id }, { $setOnInsert: {
      id: s.record_id, mr_directory_id: mr.id, mr_id: mr.mr_id, date: day,
      kind: s.kind, data: s.data, created_at: now().toISOString(), source: "mr_field_ivr",
    } }, { upsert: true });
    s.step = "menu"; return ack("Your reported note has been saved. Order notes do not create sales orders or contact/lead records.\n" + MENU);
  }
  if (s.step === "closing_confirm") {
    text = ({ "submit report": "1", "edit report": "2" })[text.toLowerCase()] || text;
    if (text === "2") { s.cursor = 0; s.step = "closing_form"; return ack("Editing your report.\n" + question()); }
    if (text === "3") return manager();
    if (text !== "1") return ack("Please verify the summary and reply 1 submit, 2 edit or 3 manager.");
    const d = s.data;
    if (d.doctor_visits + d.hospital_visits + d.pharmacy_visits + d.distributor_visits > d.completed_visits) {
      s.cursor = 0; s.step = "closing_form"; return ack("Visit type counts exceed total visits. Please correct the report.\n" + question());
    }
    const target = s.report_date || day, baseline = await loadBaseline(db, mr, target);
    const closing = { ...d, customer_visits: d.hospital_visits + d.pharmacy_visits + d.distributor_visits,
      daily_achievement: d.remarks, orders: d.orders_yes ? Math.max(1, baseline.orders.length) : 0,
      calls: 0, quotations: baseline.quotations.length, new_customers: [], pending_followups: [],
      tomorrow_plan: [], tomorrow_visits: 0, field_flow: true };
    await submit(db, mr, target, "closing", closing, baseline, s.submission_id, now().toISOString());
    await updateDay({ status: "completed", closing_status: "completed", closing_summary: d, closing_draft: null,
      closing_submitted_at: now().toISOString() }, target);
    s.step = "menu"; delete s.report_date;
    return ack(`VGRUPS HEALTHCARE — DAY CLOSING COMPLETED\nReport for ${target} successfully submitted and queued for the configured administrator reports. This is not a delivery confirmation.\nHave a good evening.`);
  }
  return ack("Please select an available option.\n" + HELP);
}
module.exports = { handleFieldFlow };
