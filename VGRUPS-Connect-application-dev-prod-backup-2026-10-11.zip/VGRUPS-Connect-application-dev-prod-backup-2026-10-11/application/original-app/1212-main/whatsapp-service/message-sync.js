const { randomUUID } = require("crypto");
const { inboundContent, messageTime } = require("./incoming");

// Persist live and reconnect messages from either direction before running bots.
async function syncMessage({ sessionId, msg, conversations, messages, accountPhone, onPersist }) {
  const incoming = inboundContent(msg, { includeOwn: true });
  const wamid = msg?.key?.id;
  if (!incoming || !wamid) return null;
  const known = await messages.findOne({ wamid });
  if (known) {
    if (onPersist) await onPersist(known);
    const ack = Number(msg.status);
    if (incoming.direction === "outbound" && [2, 3, 4, 5].includes(ack)
        && Number(known.provider_status || 0) < ack) {
      // Reconnect history can carry a real ACK for an earlier local-only echo.
      // Enrich it without adding a message or changing unread/preview counts.
      await messages.updateOne({ wamid, direction: "outbound", session_id: sessionId,
        provider_status: known.provider_status ?? null }, { $set: { provider_status: ack } });
    }
    return null;
  }
  const { jid, phone, name, body, direction } = incoming;
  const created_at = new Date(messageTime(msg)).toISOString();
  let conv = await conversations.findOne({ session_id: sessionId, reply_jid: jid }) ||
    await conversations.findOne({ session_id: sessionId, phone }) ||
    await conversations.findOne({ session_id: null, is_demo: false, phone: { $in: [phone, "+" + phone] } });
  if (!conv) {
    conv = {
      id: randomUUID().replace(/-/g, ""), phone, name, contact_id: null, contact_type: "lead",
      assigned_to: null, unread: 0, starred: false, archived: false, status: "open",
      last_message: body, last_message_at: created_at, is_demo: false,
      session_id: sessionId, reply_jid: jid, created_at,
    };
    await conversations.insertOne(conv);
  }
  const result = await messages.updateOne({ wamid }, { $setOnInsert: {
    id: randomUUID().replace(/-/g, ""), conversation_id: conv.id, wamid, direction,
    type: "text", body, status: direction === "inbound" ? "received" : "sent",
    is_demo: false, sender: direction === "inbound" ? name : "WhatsApp",
    provider_status: direction === "outbound" ? Number(msg.status) || null : null,
    session_id: sessionId, account_phone: accountPhone || null,
    reply_to_wamid: msg.message?.extendedTextMessage?.contextInfo?.stanzaId || null, created_at,
  } }, { upsert: true });
  if (result.matchedCount) return null;
  const fields = { session_id: sessionId, reply_jid: jid };
  if (!conv.last_message_at || created_at >= conv.last_message_at) {
    fields.last_message = body;
    fields.last_message_at = created_at;
  }
  await conversations.updateOne({ id: conv.id }, {
    $set: fields, ...(direction === "inbound" ? { $inc: { unread: 1 } } : {}),
  });
  const persisted = await messages.findOne({ wamid });
  if (onPersist) await onPersist(persisted);
  return { ...incoming, conv, persisted };
}

module.exports = { syncMessage };