// PostgreSQL JSONB persistence shared with the FastAPI backend.
const { Pool } = require("pg");
const { randomUUID } = require("crypto");

class Query {
  constructor(collection) { this.params = [collection]; }
  param(value, cast = "") {
    this.params.push(value);
    return `$${this.params.length}${cast}`;
  }
  field(key) { return `(document #> ${this.param(key.split("."), "::text[]")})`; }
  equal(field, value) {
    if (value === null) return `(${field} IS NULL OR ${field} = 'null'::jsonb)`;
    const right = this.param(JSON.stringify(value), "::jsonb");
    return `COALESCE((${field} = ${right} OR (jsonb_typeof(${field}) = 'array' AND ${field} @> jsonb_build_array(${right}))), FALSE)`;
  }
  filter(selector = {}) {
    const clauses = Object.entries(selector).map(([key, value]) => {
      if (key === "$or" || key === "$and") {
        if (!value.length) return key === "$or" ? "FALSE" : "TRUE";
        return `(${value.map((item) => this.filter(item)).join(key === "$or" ? " OR " : " AND ")})`;
      }
      if (key.startsWith("$")) throw new Error(`Unsupported selector: ${key}`);
      const field = this.field(key);
      if (!value || typeof value !== "object" || Array.isArray(value) || !Object.keys(value).some((item) => item.startsWith("$"))) {
        return this.equal(field, value);
      }
      return "(" + Object.entries(value).map(([op, expected]) => {
        if (op === "$eq" || op === "$ne") {
          const eq = this.equal(field, expected);
          return op === "$eq" ? eq : `NOT (${eq})`;
        }
        if (op === "$in" || op === "$nin") {
          const eq = expected.length ? `(${expected.map((item) => this.equal(field, item)).join(" OR ")})` : "FALSE";
          return op === "$in" ? eq : `NOT (${eq})`;
        }
        throw new Error(`Unsupported query operator: ${op}`);
      }).join(" AND ") + ")";
    });
    return clauses.length ? clauses.join(" AND ") : "TRUE";
  }
  where(selector) { return `collection_name=$1 AND (${this.filter(selector)})`; }
}

const clone = (value) => value === undefined ? null : JSON.parse(JSON.stringify(value));
const getPath = (doc, path) => path.split(".").reduce((value, key) => value?.[key], doc);
function setPath(doc, path, value) {
  const parts = path.split(".");
  let target = doc;
  for (const part of parts.slice(0, -1)) {
    if (!target[part] || typeof target[part] !== "object" || Array.isArray(target[part])) target[part] = {};
    target = target[part];
  }
  target[parts.at(-1)] = clone(value);
}
function applyUpdate(doc, update, inserting = false) {
  const result = clone(doc);
  for (const [op, fields] of Object.entries(update)) {
    if (op === "$setOnInsert" && !inserting) continue;
    if (op === "$set" || op === "$setOnInsert") {
      for (const [key, value] of Object.entries(fields)) setPath(result, key, value);
    } else if (op === "$inc") {
      for (const [key, value] of Object.entries(fields)) {
        const current = getPath(result, key) ?? 0;
        if (typeof current !== "number") throw new Error(`Cannot increment nonnumeric field ${key}`);
        setPath(result, key, current + value);
      }
    } else if (op === "$addToSet") {
      for (const [key, value] of Object.entries(fields)) {
        const current = getPath(result, key) ?? [];
        if (!Array.isArray(current)) throw new Error(`Cannot add to non-array field ${key}`);
        const additions = value && typeof value === "object" && "$each" in value ? value.$each : [value];
        for (const item of additions) {
          if (!current.some((existing) => JSON.stringify(existing) === JSON.stringify(item))) current.push(clone(item));
        }
        setPath(result, key, current);
      }
    } else throw new Error(`Unsupported update operator: ${op}`);
  }
  return result;
}

class Cursor {
  constructor(collection, selector) { this.collection = collection; this.selector = selector; this.order = {}; }
  sort(order) { this.order = order; return this; }
  async toArray() {
    const query = new Query(this.collection.name);
    let sql = `SELECT document FROM app_documents WHERE ${query.where(this.selector)}`;
    const sort = Object.entries(this.order).map(([key, direction]) =>
      `${query.field(key)} ${direction < 0 ? "DESC NULLS LAST" : "ASC NULLS FIRST"}`);
    sql += sort.length ? ` ORDER BY ${sort.join(", ")}` : " ORDER BY document_id";
    const result = await this.collection.database.pool.query(sql, query.params);
    return result.rows.map((row) => row.document);
  }
}

class Collection {
  constructor(database, name) { this.database = database; this.name = name; }
  find(selector = {}) { return new Cursor(this, selector); }
  async findOne(selector) {
    const query = new Query(this.name);
    const result = await this.database.pool.query(
      `SELECT document FROM app_documents WHERE ${query.where(selector)} LIMIT 1`, query.params);
    return result.rows[0]?.document ?? null;
  }
  async transaction(fn) {
    const conn = await this.database.pool.connect();
    try {
      await conn.query("BEGIN");
      // Same lock as the Python store: protects cross-runtime upserts.
      await conn.query("SELECT pg_advisory_xact_lock(hashtextextended($1, 0))", [this.name]);
      const result = await fn(conn);
      await conn.query("COMMIT");
      return result;
    } catch (error) {
      await conn.query("ROLLBACK");
      throw error;
    } finally { conn.release(); }
  }
  async insert(conn, document) {
    const doc = clone(document);
    const id = String(doc._id || doc.id || randomUUID().replace(/-/g, ""));
    doc._id = id;
    await conn.query("INSERT INTO app_documents(collection_name,document_id,document) VALUES($1,$2,$3::jsonb)",
      [this.name, id, JSON.stringify(doc)]);
    return doc;
  }
  async insertOne(document) {
    const result = await this.transaction(async (conn) => ({ insertedId: (await this.insert(conn, document))._id }));
    await this.reconcileMessage(document);
    return result;
  }
  async reconcileMessage(document) {
    if (this.name === "messages" && document?.wamid) {
      await require("./receipts").reconcileReceipts(this, document.wamid);
    }
  }
  async update(selector, update, options = {}) {
    return this.transaction(async (conn) => {
      const query = new Query(this.name);
      const result = await conn.query(
        `SELECT document_id, document FROM app_documents WHERE ${query.where(selector)}${options.many ? "" : " LIMIT 1"} FOR UPDATE`, query.params);
      if (!result.rows.length) {
        if (!options.upsert) return { matchedCount: 0, modifiedCount: 0, before: null, after: null };
        const base = Object.fromEntries(Object.entries(selector).filter(([key, value]) =>
          !key.startsWith("$") && (value === null || typeof value !== "object")));
        const doc = await this.insert(conn, applyUpdate(base, update, true));
        return { matchedCount: 0, modifiedCount: 0, upsertedId: doc._id, before: null, after: doc };
      }
      let modifiedCount = 0;
      let after = null;
      for (const row of result.rows) {
        const doc = applyUpdate(row.document, update);
        const changed = JSON.stringify(doc) !== JSON.stringify(row.document);
        if (changed) {
          await conn.query("UPDATE app_documents SET document=$3::jsonb WHERE collection_name=$1 AND document_id=$2",
            [this.name, row.document_id, JSON.stringify(doc)]);
          modifiedCount++;
        }
        after = doc;
      }
      return { matchedCount: result.rows.length, modifiedCount, before: result.rows[0].document, after };
    });
  }
  async updateOne(selector, update, options) {
    const { before, after, ...result } = await this.update(selector, update, options);
    if (options?.upsert) await this.reconcileMessage(after);
    return result;
  }
  async findOneAndUpdate(selector, update, options = {}) {
    const result = await this.update(selector, update, options);
    if (options.upsert) {
      await this.reconcileMessage(result.after);
      if (result.after && this.name === "messages")
        result.after = await this.findOne({ _id: result.after._id });
    }
    return options.returnDocument === "after" ? result.after : result.before;
  }
  updateMany(selector, update, options = {}) {
    return this.updateOne(selector, update, { ...options, many: true });
  }
  async remove(selector, many) {
    return this.transaction(async (conn) => {
      const query = new Query(this.name);
      const result = await conn.query(
        `DELETE FROM app_documents WHERE collection_name=$1 AND document_id IN (SELECT document_id FROM app_documents WHERE ${query.where(selector)}${many ? "" : " LIMIT 1"})`,
        query.params);
      return { deletedCount: result.rowCount };
    });
  }
  deleteOne(selector) { return this.remove(selector, false); }
  deleteMany(selector) { return this.remove(selector, true); }
}

class PostgresStore {
  constructor() {
    if (!process.env.DATABASE_URL) throw new Error("DATABASE_URL is required");
    this.pool = new Pool({ connectionString: process.env.DATABASE_URL });
  }
  async connect() { await this.pool.query("SELECT count(*) FROM app_documents WHERE FALSE"); }
  collection(name) { return new Collection(this, name); }
  close() { return this.pool.end(); }
}
module.exports = { PostgresStore };