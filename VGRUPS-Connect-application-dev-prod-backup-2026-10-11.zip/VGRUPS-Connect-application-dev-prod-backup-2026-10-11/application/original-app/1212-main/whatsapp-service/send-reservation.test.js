const test = require("node:test");
const assert = require("node:assert/strict");
const { sendReservedText, sendReservedMedia } = require("./send-reservation");

function fixture() {
  const requestId = "a".repeat(64);
  const record = { id: requestId, state: "sending", provider: "qr",
    recipient_address: "123456@lid", message_body: "Synthetic product" };
  const calls = [];
  const requests = {
    async updateOne(selector, update) {
      if (!Object.entries(selector).every(([k, v]) => v === null ? record[k] == null : record[k] === v)) return { matchedCount: 0 };
      Object.assign(record, update.$set);
      return { matchedCount: 1 };
    },
  };
  const sock = { user: { id: "test-sender" }, async sendMessage(...args) {
    calls.push(args);
    return { key: { id: args[2].messageId } };
  } };
  const args = { requestId, to: record.recipient_address, text: record.message_body,
    sessionId: "test-session", sock, requests, generateMessageId: () => "test-provider-id" };
  return { record, calls, sock, requests, args };
}

test("catalogue attachments persist correlation and bot metadata before IO; never resend", async () => {
  const f = fixture();
  f.record.media_key = "catalogue-image";
  let marked = false;
  const args = { ...f.args, mediaKey: f.record.media_key, caption: f.record.message_body,
    content: { image: { url: "https://storage.googleapis.com/fixture/catalog.jpg" }, caption: f.record.message_body },
    onReserved: async () => { marked = true; } };
  f.sock.sendMessage = async (...call) => {
    assert.equal(marked, true);
    assert.equal(f.record.gateway_message_id, "test-provider-id");
    f.calls.push(call);
    return { key: { id: "test-provider-id" } };
  };
  await sendReservedMedia(args);
  assert.equal(f.calls[0][1].image.url, args.content.image.url);
  assert.equal(f.record.gateway_accepted_wamid, "test-provider-id");
  await assert.rejects(sendReservedMedia(args), /no second attachment/);
  assert.equal(f.calls.length, 1);
});

test("wrong catalogue part and timed-out PDF cannot produce another SDK send", async () => {
  const f = fixture();
  f.record.media_key = "catalogue-pdf";
  const args = { ...f.args, mediaKey: "wrong", caption: f.record.message_body,
    content: { document: { url: "https://storage.googleapis.com/fixture/catalog.pdf" }, mimetype: "application/pdf" } };
  await assert.rejects(sendReservedMedia(args), /no second attachment/);
  assert.equal(f.calls.length, 0);
  args.mediaKey = f.record.media_key;
  f.sock.sendMessage = async () => { f.calls.push("attempt"); throw new Error("Synthetic timeout"); };
  await assert.rejects(sendReservedMedia(args), /Synthetic timeout/);
  await assert.rejects(sendReservedMedia(args), /no second attachment/);
  assert.equal(f.calls.length, 1);
});

test("persist correlation before the SDK call and save its receipt", async () => {
  const f = fixture();
  f.sock.sendMessage = async (...args) => {
    assert.equal(f.record.gateway_message_id, "test-provider-id");
    f.calls.push(args);
    return { key: { id: "test-provider-id" } };
  };
  await sendReservedText(f.args);
  assert.equal(f.calls[0][0], "123456@lid");
  assert.deepEqual(f.calls[0][2], { messageId: "test-provider-id" });
  assert.equal(f.record.gateway_accepted_wamid, "test-provider-id");
  await assert.rejects(sendReservedText(f.args), /No second message/);
  assert.equal(f.calls.length, 1);
});

test("AI metadata is persisted before the socket can echo the outgoing message", async () => {
  const f = fixture();
  let marked = false;
  f.args.onReserved = async id => { assert.equal(id, "test-provider-id"); marked = true; };
  f.sock.sendMessage = async () => {
    assert.equal(marked, true);
    return { key: { id: "test-provider-id" } };
  };
  await sendReservedText(f.args);
});

test("metadata persistence failure does not send or unlock the reservation", async () => {
  const f = fixture();
  f.args.onReserved = async () => { throw new Error("Synthetic metadata failure"); };
  await assert.rejects(sendReservedText(f.args), /metadata failure/);
  assert.equal(f.calls.length, 0);
  await assert.rejects(sendReservedText(f.args), /No second message/);
});

test("timeouts, missing acceptance and receipt persistence failures never unlock sends", async () => {
  for (const variant of ["timeout", "missing", "storage"]) {
    const f = fixture();
    f.sock.sendMessage = async () => {
      f.calls.push("call");
      if (variant === "timeout") throw new Error("Synthetic timeout");
      return variant === "missing" ? {} : { key: { id: "test-provider-id" } };
    };
    const update = f.requests.updateOne;
    f.requests.updateOne = async (selector, value) => {
      if (variant === "storage" && value.$set.gateway_accepted_wamid) throw new Error("Synthetic storage failure");
      return update(selector, value);
    };
    if (variant === "missing") await sendReservedText(f.args);
    else await assert.rejects(sendReservedText(f.args), /Synthetic/);
    await assert.rejects(sendReservedText(f.args), /No second message/);
    assert.equal(f.calls.length, 1);
    assert.equal(f.record.state, "sending");
  }
});

test("wrong provider, recipient, body or unknown key never calls a socket", async () => {
  for (const change of [{ provider: "cloud" }, { recipient_address: "other" }, { message_body: "other" }, { id: "b".repeat(64) }]) {
    const f = fixture();
    Object.assign(f.record, change);
    await assert.rejects(sendReservedText(f.args), /No second message/);
    assert.equal(f.calls.length, 0);
  }
});

test("concurrent requests claim a gateway message ID only once", async () => {
  const f = fixture();
  let release;
  f.sock.sendMessage = async () => {
    f.calls.push("call");
    await new Promise(resolve => { release = resolve; });
    return { key: { id: "test-provider-id" } };
  };
  const first = sendReservedText(f.args);
  await new Promise(resolve => setImmediate(resolve));
  await assert.rejects(sendReservedText(f.args), /No second message/);
  release();
  await first;
  assert.equal(f.calls.length, 1);
});