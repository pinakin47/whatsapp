// Run the real entry point with isolated synthetic DB and WhatsApp dependencies.
const { test } = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const vm = require("node:vm");
const path = require("node:path");
const { EventEmitter } = require("node:events");
const ownership = require("./session-owner");

async function fixture(mode, owns = true) {
  const routes = new Map(), middleware = [], sockets = [], timers = [];
  const writes = [], authReads = [];
  let databaseStarts = 0, listens = 0, authClears = 0;
  const app = {
    use(fn) { middleware.push(fn); },
    listen(port, host, fn) { assert.equal(host, "127.0.0.1"); listens++; fn(); },
  };
  for (const method of ["get", "post", "delete"]) {
    app[method] = (route, handler) => routes.set(`${method} ${route}`, handler);
  }
  const express = () => app;
  express.json = () => (_req, _res, next) => next();
  const collection = name => ({
    find: () => ({ toArray: async () => name === "wa_sessions" ? [{ id: "fixture", name: "Fixture" }] : [] }),
    findOne: async () => ({ id: "fixture", name: "Fixture" }),
    updateOne: async (...args) => { writes.push({ name, args }); },
    deleteOne: async () => { writes.push({ name, deleted: true }); },
  });
  const baileys = {
    default() {
      const sock = { ev: new EventEmitter(), end() {}, user: { id: "synthetic@s.whatsapp.net" } };
      sockets.push(sock);
      return sock;
    },
    DisconnectReason: { loggedOut: 401, connectionReplaced: 440 },
    fetchLatestBaileysVersion: async () => ({ version: [0, 0, 0] }),
    makeCacheableSignalKeyStore: keys => keys,
  };
  const modules = {
    express, pino: () => ({ warn() {}, error() {} }), qrcode: { toDataURL: async () => "synthetic-qr" },
    crypto: require("node:crypto"), "@whiskeysockets/baileys": baileys,
    "./postgresStore": { PostgresStore: class {
      async connect() { databaseStarts++; }
      collection(name) { return collection(name); }
      async close() {}
    } },
    "./session-owner": {
      ...ownership,
      gatewayMode: () => ownership.gatewayMode({ WA_GATEWAY_MODE: mode }),
      acquireGatewayOwner: async () => owns ? { assertOwned() {} } : null,
    },
    "./postgresAuth": { usePostgresAuthState: async (_coll, id, guard) => {
      guard();
      authReads.push(id);
      return { state: { creds: {}, keys: {} }, saveCreds: async () => {}, clear: async () => { authClears++; } };
    } },
    "./incoming": {},
    "./message-sync": {}, "./receipts": {}, "./send-reservation": {},
    "./ivr": { createIvrRunner: () => () => {} },
    "./ivr-actions": { createIvrActions: () => ({}) },
    "./mr-reporting-flow": { createMrIvrRunner: () => () => {} },
    "./mr-ai-replies": { queueMrAiReply: async () => {} },
    "./whatsapp-routing": require("./whatsapp-routing"),
    "../ivr-default.json": {},
  };
  const source = fs.readFileSync(path.join(__dirname, "index.js"), "utf8");
  vm.runInNewContext(source, {
    require: name => {
      if (!(name in modules)) throw new Error(`Unmocked dependency ${name}`);
      return modules[name];
    },
    process: { env: { WA_GATEWAY_MODE: mode }, exit: () => { throw new Error("Unexpected exit"); } },
    setTimeout: fn => { timers.push(fn); return fn; },
    clearTimeout: fn => { const i = timers.indexOf(fn); if (i >= 0) timers.splice(i, 1); },
  });
  await new Promise(resolve => setImmediate(resolve));
  const response = () => ({
    statusCode: 200,
    status(code) { this.statusCode = code; return this; },
    json(value) { this.body = value; return this; },
  });
  async function request(method, route, params = {}) {
    const req = { method: method.toUpperCase(), path: route, params };
    const res = response();
    let allowed = true;
    for (const fn of middleware) {
      let next = false;
      fn(req, res, () => { next = true; });
      if (!next) { allowed = false; break; }
    }
    if (allowed) await routes.get(`${method} ${route}`)(req, res);
    return res;
  }
  return { request, sockets, timers, writes, authReads,
    stats: () => ({ databaseStarts, listens, authClears }) };
}

test("disabled development never reads auth or opens a socket; destructive endpoints are blocked", async () => {
  const f = await fixture("disabled");
  assert.equal(f.stats().databaseStarts, 0);
  assert.equal(f.stats().listens, 1);
  assert.equal(f.authReads.length, 0);
  assert.equal(f.sockets.length, 0);
  assert.equal((await f.request("get", "/health")).body.gateway_status, "disabled");
  assert.equal((await f.request("get", "/sessions")).body.connected, false);
  for (const [method, route] of [["post", "/sessions"], ["post", "/sessions/:id/logout"], ["delete", "/sessions/:id"], ["post", "/sessions/:id/reconnect"]]) {
    assert.equal((await f.request(method, route, { id: "fixture" })).statusCode, 409);
  }
  assert.equal(f.writes.length, 0);
  assert.equal(f.stats().authClears, 0);
});

test("a losing gateway does not restore credentials or mutate the session store", async () => {
  const f = await fixture("enabled", false);
  assert.equal((await f.request("get", "/health")).body.gateway_status, "owned_elsewhere");
  assert.equal(f.sockets.length, 0);
  assert.equal(f.authReads.length, 0);
  assert.equal((await f.request("post", "/sessions/:id/logout", { id: "fixture" })).statusCode, 409);
  assert.equal(f.writes.length, 0);
});

test("replacement retains credentials, records conflict, and does not schedule a retry", async () => {
  const f = await fixture("enabled");
  assert.equal(f.sockets.length, 1);
  const handler = f.sockets[0].ev.listeners("connection.update")[0];
  await handler({ connection: "close", lastDisconnect: { error: { output: { statusCode: 440 } } } });
  assert.equal(f.timers.length, 0);
  assert.equal(f.stats().authClears, 0);
  assert.ok(f.writes.some(write => write.args[1].$set.status === "connection_conflict"));
});

test("manual reconnect cancels an old retry and ignores obsolete socket events", async () => {
  const f = await fixture("enabled");
  const oldHandler = f.sockets[0].ev.listeners("connection.update")[0];
  await oldHandler({ connection: "close", lastDisconnect: { error: { output: { statusCode: 408 } } } });
  assert.equal(f.timers.length, 1);
  const req = () => f.request("post", "/sessions/:id/reconnect", { id: "fixture" });
  await Promise.all([req(), req()]);
  assert.equal(f.sockets.length, 2, "Concurrent requests open only one new socket");
  assert.equal(f.timers.length, 0);
  const writes = f.writes.length;
  await oldHandler({ connection: "close", lastDisconnect: { error: { output: { statusCode: 401 } } } });
  assert.equal(f.stats().authClears, 0);
  assert.equal(f.writes.length, writes);
});

test("real auth adapter requires ownership for credential reads, saves, key changes, and clearing", async () => {
  const module = { exports: {} };
  vm.runInNewContext(fs.readFileSync(path.join(__dirname, "postgresAuth.js"), "utf8"), {
    module,
    require: name => name === "./auth-write-queue" ? require("./auth-write-queue") : ({
      initAuthCreds: () => ({ synthetic: true }),
      BufferJSON: {}, proto: {},
    }),
  });
  const { usePostgresAuthState } = module.exports;
  let accesses = 0;
  const coll = {};
  for (const key of ["findOne", "updateOne", "deleteOne", "deleteMany"]) {
    coll[key] = async () => { accesses++; return null; };
  }
  await assert.rejects(usePostgresAuthState(coll, "fixture"), /ownership guard/);
  assert.equal(accesses, 0);
  let owned = true;
  const guard = () => { if (!owned) throw new Error("lost"); };
  const auth = await usePostgresAuthState(coll, "fixture", guard);
  assert.equal(accesses, 1);
  owned = false;
  await assert.rejects(auth.state.keys.get("session", ["fixture"]), /lost/);
  await assert.rejects(auth.state.keys.set({ session: { fixture: {} } }), /lost/);
  await assert.rejects(auth.state.keys.set({ session: { fixture: null } }), /lost/);
  assert.throws(auth.saveCreds, /lost/);
  assert.throws(auth.clear, /lost/);
  assert.equal(accesses, 1, "Lost ownership must not reach storage");
});
