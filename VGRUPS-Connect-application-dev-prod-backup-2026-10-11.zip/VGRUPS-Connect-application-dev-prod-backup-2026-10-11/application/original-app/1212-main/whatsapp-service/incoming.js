// Keep WhatsApp's real peer address: a LID is not a telephone number.
function inboundContent(msg, { includeOwn = false } = {}) {
  if (!msg?.message || (msg.key?.fromMe && !includeOwn)) return null;
  const jid = msg.key?.remoteJid || "";
  if (!/^[\d:]+@(s\.whatsapp\.net|lid)$/.test(jid)) return null;
  let content = msg.message;
  for (let i = 0; i < 5; i++) {
    const wrapped = content.ephemeralMessage?.message ||
      content.viewOnceMessage?.message || content.viewOnceMessageV2?.message ||
      content.documentWithCaptionMessage?.message;
    if (!wrapped) break;
    content = wrapped;
  }
  const alternate = msg.key.remoteJidAlt;
  const phoneJid = alternate?.endsWith("@s.whatsapp.net") ? alternate : jid;
  const phone = phoneJid.split("@")[0].split(":")[0];
  const body = content.conversation || content.extendedTextMessage?.text ||
    content.imageMessage?.caption || content.videoMessage?.caption ||
    (content.imageMessage ? "[image]" : "") || (content.videoMessage ? "[video]" : "") ||
    (content.audioMessage ? "[audio]" : "") || (content.documentMessage ? "[document]" : "") ||
    (content.stickerMessage ? "[sticker]" : "") || (content.locationMessage ? "[location]" : "");
  if (!body) return null; // Protocol/key updates are not customer messages.
  return { jid, phone, body, name: msg.key.fromMe ? phone : msg.pushName || phone,
    direction: msg.key.fromMe ? "outbound" : "inbound",
    ...(content.locationMessage ? { location: content.locationMessage } : {}) };
}

function replyAddress(conversation, phone) {
  const peer = conversation?.reply_jid;
  return peer && /^[\d:]+@(s\.whatsapp\.net|lid)$/.test(peer)
    ? peer : phone.replace(/\D/g, "") + "@s.whatsapp.net";
}

const isMenuGreeting = (text) => /^(h+i+|h+a+i+|h+e+l+o+|h+e+y+|good\s*(morning|afternoon|evening)|n+a+m+a+s+t+h?e+|start|help|menu|main\s+menu|0)(?:\s+(there|sir|madam|everyone|team))?[!.,\s]*$/i.test(text.trim());
function messageTime(msg, now = Date.now()) {
  const timestamp = msg.messageTimestamp;
  const seconds = Number(timestamp?.toNumber ? timestamp.toNumber() :
    timestamp && typeof timestamp === "object" && "low" in timestamp
      ? (timestamp.low >>> 0) + (timestamp.high || 0) * 4294967296 : timestamp);
  return Number.isFinite(seconds) && seconds > 0 && seconds * 1000 <= now + 60000
    ? seconds * 1000 : now;
}

function shouldAutomate(msg, now = Date.now()) {
  return !msg.key?.fromMe && now - messageTime(msg, now) < 300000;
}

module.exports = { inboundContent, replyAddress, isMenuGreeting, messageTime, shouldAutomate };