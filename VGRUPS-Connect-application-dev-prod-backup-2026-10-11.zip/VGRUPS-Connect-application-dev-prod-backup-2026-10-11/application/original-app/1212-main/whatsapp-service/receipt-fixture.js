// Exercise the actual store's post-commit hooks, without constructing a pool.
const { PostgresStore } = require("./postgresStore");
const copy = value => value == null ? value : JSON.parse(JSON.stringify(value));
function fixtureDatabase() {
  const collections = new Map();
  const database = {
    collection(name) {
      if (collections.has(name)) return collections.get(name);
      const collection = PostgresStore.prototype.collection.call(database, name);
      collection.docs = [];
      collection.findOne = async query => copy(collection.docs.find(doc =>
        Object.entries(query).every(([key, value]) => (doc[key] ?? null) === value)) || null);
      collection.update = async (query, update, options = {}) => {
        await Promise.resolve(); // Allow competing snapshots before the atomic write.
        let doc = collection.docs.find(row =>
          Object.entries(query).every(([key, value]) => (row[key] ?? null) === value));
        const before = copy(doc) || null;
        if (!doc && options.upsert) {
          doc = { ...query, ...copy(update.$setOnInsert) };
          collection.docs.push(doc);
        }
        if (doc) Object.assign(doc, copy(update.$set));
        return { matchedCount: Number(Boolean(before)), modifiedCount: Number(Boolean(doc)),
          ...(!before && doc ? { upsertedId: "fixture" } : {}), before, after: copy(doc) || null };
      };
      collection.transaction = fn => fn(null);
      collection.insert = async (_, doc) => {
        const stored = { ...copy(doc), _id: doc.id || "fixture" };
        collection.docs.push(stored);
        return stored;
      };
      collections.set(name, collection);
      return collection;
    },
  };
  return database;
}
module.exports = { fixtureDatabase };
