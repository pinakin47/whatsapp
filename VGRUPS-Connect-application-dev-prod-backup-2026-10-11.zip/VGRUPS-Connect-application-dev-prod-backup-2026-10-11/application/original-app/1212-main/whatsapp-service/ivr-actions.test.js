const test = require("node:test");
const assert = require("node:assert/strict");
const { createIvrRunner } = require("./ivr");
const { createIvrActions } = require("./ivr-actions");
const defaults = require("../ivr-default.json");

function matches(row, query) {
  return Object.entries(query).every(([key, v]) => typeof v === "object" && v !== null
    ? Object.entries(v).every(([op, value]) => op === "$ne" ? row[key] !== value : op === "$in" ? value.includes(row[key]) : false)
    : row[key] === v);
}
function fixture(patch = {}) {
  const tables = {
    products: [{ id: "p1", name: "Oral Film", code: "OF", category: "oral", description: "Stored product description", selling_price: 100, gst: 5, unit: "box" },
      { id: "demo", name: "Dummy product", is_demo: true, category: "oral" }],
    users: [{ id: "agent", role: "sales_manager", active: true }],
    orders: [{ id: "mine", order_no: "VG1", mobile: "+15550001111", status: "dispatched", expected_delivery: "2026-10-08" },
      { id: "theirs", order_no: "VG2", mobile: "+15550002222", status: "private-status" }],
  };
  const database = { collection(name) {
    const rows = tables[name] ||= [];
    return {
      find(query = {}) { return { sort() { return this; }, async toArray() { return rows.filter(r => matches(r, query)); } }; },
      async findOne(q) { return rows.find(r => matches(r, q)) || null; },
      async insertOne(r) { rows.push(structuredClone(r)); },
      async updateOne(q, u, o = {}) {
        let row = rows.find(r => matches(r, q));
        if (!row && o.upsert) { row = { ...q, ...structuredClone(u.$setOnInsert || {}) }; rows.push(row); }
        if (row) Object.assign(row, structuredClone(u.$set || {}));
        return { matchedCount: row ? 1 : 0 };
      },
      async findOneAndUpdate(q) {
        let row = rows.find(r => matches(r, q));
        if (!row) { row = { ...q, seq: 0 }; rows.push(row); }
        row.seq++; return row;
      },
    };
  } };
  const config = { ...structuredClone(defaults), ...patch }, sent = [], events = [];
  const conversation = { id: "conversation", name: "Synthetic customer", reply_jid: "15550001111@s.whatsapp.net" };
  const runner = createIvrRunner({ loadConfig: async () => config, sendText: async (...args) => sent.push(args[3]),
    updateConversation: async () => {}, actions: createIvrActions({ getDatabase: () => database }), recordEvent: async e => events.push(e) });
  return { tables, conversation, config, sent, events, async run(...steps) { for (const text of steps) await runner("mock-session", conversation, "15550001111", text); return sent.at(-1); } };
}

test("common greetings, case, extra spaces and repeated letters open only seven public branches", async () => {
  for (const greeting of ["Hii", "hiii", "helo", "HHHellooo", "hey", "good  morning", "Good afternoon", "good evening", "Namaste", "Hai", "Hi there", "Hello sir", "Hello madam", "Start", "Help"]) {
    const f = fixture();
    assert.match(await f.run(greeting), /7\. Talk to Sales Team/);
    assert.doesNotMatch(f.sent.at(-1), /Recruitment|Settings|Campaigns/);
  }
});
test("nested category and product context persists, excluding dummy products and private prices", async () => {
  const f = fixture();
  assert.match(await f.run("hi", "1", "4"), /1\. Oral Film/);
  assert.doesNotMatch(f.sent.at(-1), /Dummy product/);
  assert.match(await f.run("1"), /Stored product description/);
  assert.doesNotMatch(f.sent.at(-1), /100|₹/);
  assert.match(await f.run("back"), /Product Catalogue/);
  assert.match(await f.run("back"), /7\. Talk to Sales Team/);
});
test("catalogue uses the configured real link rather than an invented URL", async () => {
  const f = fixture({ catalogue_url: "https://example.com/actual-catalogue" });
  assert.match(await f.run("hi", "1", "1"), /https:\/\/example.com\/actual-catalogue/);
  assert.equal(f.events.at(-1).metric, "catalogue_requests");
});
test("pricing creates one existing CRM lead and hands off to a real user", async () => {
  const f = fixture();
  await f.run("hi", "2", "1", "Synthetic customer", "Synthetic pharmacy", "Oral Film", "5", "City", "+15550001111", "Quotation please");
  assert.equal(f.tables.leads.length, 1);
  assert.equal(f.tables.leads[0].product_interest, "Oral Film");
  assert.equal(f.tables.leads[0].assigned_to, "agent");
  assert.equal(f.conversation.human_takeover, true);
  assert.equal(f.events.at(-1).lead_id, f.tables.leads[0].id);
});
test("orders use existing products, prices and order counters, as drafts awaiting confirmation", async () => {
  const f = fixture();
  await f.run("hi", "3", "1", "Synthetic customer", "Synthetic pharmacy", "OF", "2", "City", "+15550001111", "Order request");
  const order = f.tables.orders.find(o => o.conversation_id === "conversation");
  assert.equal(order.status, "draft");
  assert.equal(order.total, 210);
  assert.equal(order.items[0].product_id, "p1");
  assert.match(f.sent.at(-1), /not a payment or dispatch confirmation/);
});
test("order ownership blocks guessed numbers and returns only the sender's actual status", async () => {
  const f = fixture();
  assert.doesNotMatch(await f.run("hi", "4", "VG2"), /private-status/);
  assert.match(f.sent.at(-1), /your WhatsApp number/);
  assert.match(await f.run("VG1"), /dispatched/);
  assert.match(f.sent.at(-1), /2026-10-08/);
});
test("unknown LID identities cannot look up another phone's order", async () => {
  const f = fixture();
  f.conversation.reply_jid = "15550001111@lid";
  assert.doesNotMatch(await f.run("hi", "4", "VG1"), /dispatched/);
});
test("support stores a real task, not a fabricated payment or delivery status", async () => {
  const f = fixture();
  await f.run("hi", "6", "3", "Synthetic customer", "VG1", "Payment issue");
  assert.equal(f.tables.tasks.length, 1);
  assert.match(f.tables.tasks[0].notes, /VG1.*\nPayment issue/);
  assert.equal(f.events.at(-1).metric, "support_requests");
});
test("business enquiry goes to leads and configurable handoff can be disabled", async () => {
  const f = fixture({ human_handoff: false });
  await f.run("hi", "5", "1", "Synthetic customer", "Company", "OF", "10", "City", "+15550001111", "Distributor enquiry");
  assert.equal(f.tables.leads[0].enquiry_type, "business");
  assert.equal(f.conversation.human_takeover, false);
  assert.equal(f.events.at(-1).handoff, false);
});
test("human keywords offer quick assistance and create a lead after the requirement", async () => {
  const f = fixture();
  assert.match(await f.run("hi", "agent"), /Please share your requirement/);
  await f.run("Please call me");
  assert.equal(f.tables.leads.length, 1);
  assert.equal(f.conversation.human_takeover, true);
});
test("invalid quantities and another phone do not create orders or leads", async () => {
  const f = fixture();
  assert.match(await f.run("hi", "7", "Name", "Company", "OF", "five"), /whole-number/);
  await f.run("2", "City", "+15550002222");
  assert.match(f.sent.at(-1), /messaging from/);
  assert.equal(f.tables.leads?.length || 0, 0);
  assert.match(await f.run("0"), /7\. Talk to Sales Team/);
});
test("form submission is idempotent when the same persisted state is processed again", async () => {
  const f = fixture({ human_handoff: false });
  await f.run("hi", "agent");
  const pending = structuredClone(f.conversation.ivr);
  await f.run("One enquiry");
  f.conversation.ivr = pending;
  await f.run("One enquiry");
  assert.equal(f.tables.leads.length, 1);
});
test("closely arriving replies are processed in order in the same conversation", async () => {
  const f = fixture();
  await f.run("hi");
  await Promise.all([f.run("1"), f.run("4")]);
  assert.match(f.sent.at(-1), /Available Products/);
});