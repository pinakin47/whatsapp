const real = { deleted: { $ne: true }, is_demo: { $ne: true } };

async function mrSessionAllowed(db, sessionId) {
  const config = (await db.collection("app_config").findOne({ key: "whatsapp_number_routing" }))?.value;
  if (config?.mr_session_id) return config.mr_session_id === sessionId;
  const rows = await db.collection("wa_sessions").find({
    ...real, status: { $nin: ["logged_out", "deleted"] },
  }).toArray();
  const known = rows.filter(s => s.phone || s.status === "connected");
  return known.length === 1 && known[0].id === sessionId;
}

function explicitOrSoleSession(sessions, selected) {
  if (selected) return selected;
  const connected = Object.keys(sessions).filter(id => sessions[id].status === "connected");
  return connected.length === 1 ? connected[0] : null;
}

module.exports = { mrSessionAllowed, explicitOrSoleSession };
