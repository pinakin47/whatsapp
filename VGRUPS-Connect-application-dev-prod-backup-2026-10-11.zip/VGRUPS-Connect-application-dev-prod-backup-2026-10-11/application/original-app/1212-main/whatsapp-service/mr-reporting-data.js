const { randomUUID, createHash } = require("crypto");

const digits = value => String(value || "").replace(/\D/g, "");
function istDay(now = new Date()) {
  return new Date(now.getTime() + 330 * 60000).toISOString().slice(0, 10);
}
const tomorrow = day => new Date(Date.parse(day + "T12:00:00Z") + 86400000).toISOString().slice(0, 10);
const real = { deleted: { $ne: true }, is_demo: { $ne: true } };

async function identifyMr(db, phone) {
  const mr = await db.collection("mr_directory").findOne({
    ...real, active: true, phone: "+" + digits(phone),
  });
  if (!mr) return null;
  const account = await db.collection("users").findOne({
    ...real, active: { $ne: false }, role: "mr", email: mr.email.toLowerCase(),
  });
  return { ...mr, mr_id: account?.id || `directory:${mr.id}` };
}

async function loadBaseline(db, mr, date) {
  const visits = await db.collection("field_visits").find({ mr_id: mr.mr_id, planned_date: date }).toArray();
  const start = Date.parse(date + "T00:00:00+05:30");
  // Query a coarse UTC day range, then compare instants across ISO offset formats.
  const range = { $gte: new Date(start).toISOString().slice(0, 10),
    $lt: new Date(start + 2 * 86400000).toISOString().slice(0, 10) };
  const allOrders = await db.collection("orders").find({ ...real, created_by: mr.mr_id, created_at: range }).toArray();
  const dailyOrders = allOrders.filter(o => Date.parse(o.created_at) >= start &&
    Date.parse(o.created_at) < start + 86400000 && !["cancelled", "draft"].includes(o.status));
  const report = await db.collection("mr_daily_reports").findOne({ id: `${date}:${mr.id}` });
  const yesterday = new Date(Date.parse(date + "T12:00:00Z") - 86400000).toISOString().slice(0, 10);
  const previous = await db.collection("mr_daily_reports").findOne({ id: `${yesterday}:${mr.id}` });
  const target = await db.collection("field_targets").findOne({ mr_id: mr.mr_id, month: date.slice(0, 7) });
  const quotations = (await db.collection("quotations").find({
    ...real, created_by: mr.mr_id, created_at: range,
  }).toArray()).filter(q => Date.parse(q.created_at) >= start && Date.parse(q.created_at) < start + 86400000);
  return { visits, orders: dailyOrders, quotations, report, previous, target };
}

function summary(plan = {}, closing = {}) {
  const goal = typeof plan.expected_sales === "number" ? plan.expected_sales : null;
  return {
    planned_visits: plan.planned_visits ?? 0, completed_visits: closing.completed_visits ?? 0,
    pending_visits: Math.max(0, (plan.planned_visits ?? 0) - (closing.completed_visits ?? 0)),
    doctor_visits: closing.doctor_visits ?? 0, customer_visits: closing.customer_visits ?? 0,
    calls: closing.calls ?? 0, orders: closing.orders ?? 0, sales: closing.sales ?? 0,
    quotations: closing.quotations ?? 0, daily_goal: goal,
    achievement_pct: goal > 0 ? Math.round((closing.sales || 0) / goal * 10000) / 100 : null,
    tomorrow_visits: closing.tomorrow_visits ?? 0,
  };
}

async function saveVisits(db, mr, date, visits, source, baseline = []) {
  for (let i = 0; i < visits.length; i++) {
    const v = visits[i];
    const existing = baseline.find(b => b.doctor_name === v.name && (b.city || "") === (v.location || ""));
    if (existing) {
      if (existing.source === "mr_ivr" && existing.status === "planned")
        await db.collection("field_visits").updateOne({ id: existing.id, status: "planned" },
          { $set: { notes: `Purpose: ${v.purpose || "Other"}` } });
      continue; // Never overwrite a manual check-in or count it twice.
    }
    const fingerprint = createHash("sha256").update(`${v.name}|${v.location}`).digest("hex").slice(0, 20);
    const id = `mr-ivr:${source}:${date}:${mr.id}:${fingerprint}`;
    await db.collection("field_visits").updateOne({ id }, { $set: {
      doctor_name: v.name, city: v.location, notes: `Purpose: ${v.purpose || "Other"}`,
      expected_order: v.expected_order ?? null, expected_sales: v.expected_sales ?? null,
      updated_at: new Date().toISOString(),
    }, $setOnInsert: {
      id, mr_id: mr.mr_id, mr_name: mr.name, planned_date: date, status: "planned",
      check_in_at: null, outcome: null, order_value: 0, source: "mr_ivr",
      created_at: new Date().toISOString(),
    } }, { upsert: true });
  }
  for (const previous of baseline) {
    if (previous.source === "mr_ivr" && previous.status === "planned" &&
        !visits.some(v => v.name === previous.doctor_name && (v.location || "") === (previous.city || "")))
      await db.collection("field_visits").updateOne({ id: previous.id, status: "planned" },
        { $set: { status: "skipped", notes: "Replaced by a confirmed IVR visit plan.", updated_at: new Date().toISOString() } });
  }
}

async function submit(db, mr, date, phase, data, submissionId) {
  const reports = db.collection("mr_daily_reports");
  const id = `${date}:${mr.id}`;
  const baseline = await loadBaseline(db, mr, date);
  const old = baseline.report || {};
  const now = new Date().toISOString();
  const plan = phase === "plan" ? data : old.plan || {
    planned_visits: baseline.visits.filter(v => v.status !== "skipped").length,
    expected_sales: null, visits: baseline.visits.map(v => ({
      name: v.doctor_name || v.clinic_name, location: v.city || v.address || "", purpose: v.notes || "Other",
    })), source: "existing_field_visits",
  };
  const closing = phase === "closing" ? data : old.closing || {};
  if (phase === "closing") {
    closing.order_details = baseline.orders.map(o => ({
      id: o.id, order_no: o.order_no, total: o.total, status: o.status, items: o.items || [],
    }));
    closing.app_quotation_details = baseline.quotations.map(q => ({
      id: q.id, quote_no: q.quote_no, total: q.total, items: q.items || [],
    }));
  }
  if (phase === "plan") await saveVisits(db, mr, date, data.visits || [], "plan", baseline.visits);
  if (phase === "closing") {
    const nextVisits = await db.collection("field_visits").find({
      mr_id: mr.mr_id, planned_date: tomorrow(date),
    }).toArray();
    await saveVisits(db, mr, tomorrow(date), data.tomorrow_plan || [], "tomorrow", nextVisits);
  }
  const patch = {
    id, date, mr_id: mr.mr_id, mr_directory_id: mr.id, mr_name: mr.name,
    employee_id: mr.employee_id, [phase]: phase === "plan" ? plan : closing,
    [`${phase}_submitted_at`]: now, [`${phase}_submission_id`]: submissionId, updated_at: now,
  };
  await reports.updateOne({ id }, { $set: patch }, { upsert: true });
  let report = await reports.findOne({ id });
  // Preserve independent plan/closing writes from another QR conversation.
  if (!report.plan && phase === "closing") {
    await reports.updateOne({ id, plan: { $exists: false } }, { $set: { plan } });
    report = await reports.findOne({ id });
  }
  report.summary = summary(report.plan, report.closing);
  const version = { id };
  for (const key of ["plan_submission_id", "closing_submission_id"])
    version[key] = report[key] === undefined ? { $exists: false } : report[key];
  await reports.updateOne(version, { $set: { summary: report.summary } });
  if (phase === "closing") {
    await db.collection("mr_report_submissions").updateOne({ id: submissionId }, {
      $setOnInsert: { id: submissionId, report, submitted_at: now, notified_complete: false },
    }, { upsert: true });
  }
  return report;
}
module.exports = { identifyMr, loadBaseline, submit, summary, istDay, tomorrow, newSubmission: randomUUID };