const test = require("node:test");
const assert = require("node:assert/strict");
const { createMrIvrRunner } = require("./mr-reporting-flow");
const { submit, identifyMr, loadBaseline, istDay } = require("./mr-reporting-data");

function matches(row, query) {
  return Object.entries(query).every(([key, value]) => {
    if (value && typeof value === "object") return Object.entries(value).every(([op, v]) =>
      op === "$ne" ? row[key] !== v : op === "$in" ? v.includes(row[key]) :
      op === "$exists" ? (row[key] !== undefined) === v :
      op === "$gte" ? row[key] >= v : op === "$lt" ? row[key] < v : false);
    return row[key] === value;
  });
}
function fixture() {
  const tables = {
    app_config: [{ key: "mr_ivr", value: { enabled: true, closing_time: "20:00" } }],
    mr_directory: [{ id: "mr1", name: "Synthetic MR", employee_id: "MR001", email: "mr@example.com", phone: "+15550001111", active: true }],
    users: [{ id: "account", name: "Synthetic MR", email: "mr@example.com", role: "mr", active: true },
      { id: "manager", role: "admin", active: true }],
    conversations: [{ id: "conversation", session_id: "qr1" }],
  };
  const db = { collection(name) {
    const rows = tables[name] ||= [];
    return {
      find(q = {}) { return { async toArray() { return structuredClone(rows.filter(r => matches(r, q))); } }; },
      async findOne(q) { return structuredClone(rows.find(r => matches(r, q)) || null); },
      async updateOne(q, u, opts = {}) {
        let row = rows.find(r => matches(r, q)), added = false;
        if (!row && opts.upsert) { row = { ...q, ...structuredClone(u.$setOnInsert || {}) }; rows.push(row); added = true; }
        if (row) Object.assign(row, structuredClone(u.$set || {}));
        return { matchedCount: row ? 1 : 0, upsertedId: added ? row.id : null };
      },
    };
  } };
  const sent = [];
  const runner = createMrIvrRunner({ getDatabase: () => db, sendText: async (...args) => sent.push(args[3]),
    now: () => new Date("2026-10-05T08:00:00+05:30") });
  return { tables, db, sent, runner, async run(...steps) {
    for (const body of steps) await runner("qr1", tables.conversations[0], "15550001111", body);
    return sent.at(-1);
  } };
}
async function plan(f) {
  await f.run("PLAN", "1", "2", "Doctor One - Hyderabad", "Hospital Two - Hyderabad", "DONE",
    "1", "4", "50000", "1", "1", "Hospital Two", "Stored product", "1000",
    "1", "Doctor One - Samples follow-up", "DONE", "SKIP");
}
test("full morning confirmation writes only plans and real field visit rows", async () => {
  const f = fixture(); await plan(f);
  assert.match(f.sent.at(-1), /Confirm & Submit/);
  assert.equal(f.tables.mr_daily_reports?.length || 0, 0);
  await f.run("1");
  const report = f.tables.mr_daily_reports[0];
  assert.equal(report.plan.planned_visits, 2);
  assert.equal(report.plan.quotations[0].value, 1000);
  assert.equal(report.plan.visits[1].purpose, "Follow-up");
  assert.equal(f.tables.field_visits.length, 2);
  assert.equal(f.tables.users.length, 2);
  assert.equal(f.tables.mr_report_submissions?.length || 0, 0);
});
test("closing collects all answers, tomorrow details and accurate achievement without inventing orders", async () => {
  const f = fixture(); await plan(f); await f.run("1");
  await f.run("CLOSING", "1", "1", "1", "0", "12", "4", "45000", "3", "Customer quotation",
    "1", "New Doctor - Hyderabad", "DONE", "Large enquiry received", "1", "Delivery delayed",
    "1", "Hospital - follow up", "DONE", "1", "Doctor Three - Hyderabad", "DONE",
    "2", "5", "10000", "SKIP");
  assert.match(f.sent.at(-1), /achievement pct: 90/);
  await f.run("1");
  const r = f.tables.mr_daily_reports[0];
  assert.equal(r.summary.pending_visits, 1);
  assert.equal(r.summary.achievement_pct, 90);
  assert.equal(r.closing.problems, "Delivery delayed");
  assert.equal(r.closing.tomorrow_plan[0].expected_order, 5);
  assert.equal(f.tables.field_visits.filter(v => v.planned_date === "2026-10-06").length, 1);
  assert.equal(f.tables.mr_report_submissions.length, 1);
  assert.equal(f.tables.orders.length, 0);
});
test("customers, inactive MRs and another QR session cannot access private reporting", async () => {
  const f = fixture();
  assert.equal(await f.runner("qr1", f.tables.conversations[0], "15550009999", "1"), false);
  f.tables.mr_directory[0].active = false;
  assert.equal(await f.runner("qr1", f.tables.conversations[0], "15550001111", "PLAN"), false);
  f.tables.mr_directory[0].active = true;
  await assert.rejects(f.runner("wrong-session", f.tables.conversations[0], "15550001111", "PLAN"), /QR session/);
  f.tables.app_config[0].value.enabled = false;
  assert.equal(await f.run("PLAN"), undefined);
});
test("invalid numbers, cancellation, pause/resume and zero-visit plans persist safely", async () => {
  const f = fixture(); await f.run("PLAN", "1");
  assert.match(await f.run("-1"), /non-negative/);
  assert.match(await f.run("2.5"), /whole number/);
  await f.run("0", "later");
  assert.match(await f.run("resume"), /expected sales/);
  await f.run("0", "2", "2", "SKIP", "1");
  assert.equal(f.tables.mr_daily_reports[0].plan.visits.length, 0);
  assert.equal(f.tables.mr_daily_reports[0].summary.daily_goal, 0);
  assert.equal(f.tables.mr_daily_reports[0].summary.achievement_pct, null);
  await f.run("PLAN", "1", "0", "0", "2", "2", "SKIP", "2", "3");
  assert.match(f.sent.at(-1), /No visits are listed/);
  await f.run("PLAN", "1", "CANCEL");
  assert.equal(f.tables.mr_daily_reports.length, 1);
});
test("existing visits and owned confirmed orders are reused, including offset timestamps", async () => {
  const f = fixture();
  f.tables.field_visits = [{ id: "manual", mr_id: "account", doctor_name: "Doctor One",
    city: "Hyderabad", planned_date: "2026-10-05", status: "visited", outcome: "Keep this" }];
  f.tables.orders = [
    { id: "own", created_by: "account", created_at: "2026-10-05T01:00:00.000Z", total: 45000, status: "confirmed" },
    { id: "private", created_by: "other", created_at: "2026-10-05T01:00:00.000Z", total: 99999, status: "confirmed" },
    { id: "draft", created_by: "account", created_at: "2026-10-05T01:00:00.000Z", total: 100000, status: "draft" },
  ];
  const mr = await identifyMr(f.db, "15550001111");
  assert.equal((await loadBaseline(f.db, mr, "2026-10-05")).orders.length, 1);
  await f.run("PLAN", "1", "SAME", "SAME", "1", "50000", "2", "2", "SKIP", "1");
  assert.equal(f.tables.field_visits.length, 1);
  assert.equal(f.tables.field_visits[0].outcome, "Keep this");
  await f.run("CLOSING", "1", "SAME", "1", "0", "12");
  assert.match(f.sent.at(-1), /1 orders, INR 45000/);
  await f.run("1", "0", "SKIP", "2", "SKIP", "2", "2", "0", "SKIP", "1");
  assert.equal(f.tables.mr_daily_reports[0].closing.orders, 1);
  assert.equal(f.tables.mr_daily_reports[0].closing.sales, 45000);
  assert.equal(f.tables.mr_daily_reports[0].closing.order_details[0].id, "own");
});
test("duplicate submissions don't duplicate visits or notification snapshots", async () => {
  const f = fixture(), mr = await identifyMr(f.db, "15550001111");
  const p = { planned_visits: 1, expected_sales: 100, visits: [{ name: "Doctor", location: "City", purpose: "Follow-up" }] };
  await submit(f.db, mr, "2026-10-05", "plan", p, "p1");
  await submit(f.db, mr, "2026-10-05", "plan", p, "p1");
  const c = { completed_visits: 1, doctor_visits: 1, customer_visits: 0, sales: 90, tomorrow_plan: [] };
  await submit(f.db, mr, "2026-10-05", "closing", c, "c1");
  await submit(f.db, mr, "2026-10-05", "closing", c, "c1");
  assert.equal(f.tables.field_visits.length, 1);
  assert.equal(f.tables.mr_report_submissions.length, 1);
  await Promise.all([
    submit(f.db, mr, "2026-10-05", "plan", { ...p, expected_sales: 200 }, "p2"),
    submit(f.db, mr, "2026-10-05", "closing", { ...c, sales: 180 }, "c2"),
  ]);
  assert.equal(f.tables.mr_daily_reports[0].plan.expected_sales, 200);
  assert.equal(f.tables.mr_daily_reports[0].closing.sales, 180);
});
test("manager requests are assigned, idempotent and self-service resumes", async () => {
  const f = fixture();
  await f.run("PLAN", "4", "manager");
  assert.equal(f.tables.tasks.length, 1);
  assert.equal(f.tables.tasks[0].assigned_to, "manager");
  assert.equal(f.tables.conversations[0].human_takeover, true);
  const previousCount = f.sent.length;
  await f.run("Please discuss samples with me");
  assert.equal(f.sent.length, previousCount);
  await f.run("PLAN", "1");
  assert.equal(f.tables.conversations[0].human_takeover, false);
});
test("closing invitation routes a direct 1 correctly without interpreting it as morning data", async () => {
  const f = fixture(); await f.run("PLAN");
  f.tables.conversations[0].mr_invitation = { id: "evening", date: "2026-10-05", phase: "closing" };
  await f.run("1");
  assert.equal(f.tables.conversations[0].mr_ivr.phase, "closing");
  assert.match(f.sent.at(-1), /actually complete/);
  assert.equal(istDay(new Date("2026-10-04T19:00:00Z")), "2026-10-05");
});
test("visit edits never rename an already checked-in doctor", async () => {
  const f = fixture(), mr = await identifyMr(f.db, "15550001111");
  const p = { planned_visits: 1, visits: [{ name: "First", location: "City", purpose: "Promotion" }] };
  await submit(f.db, mr, "2026-10-05", "plan", p, "p1");
  f.tables.field_visits[0].status = "visited";
  await submit(f.db, mr, "2026-10-05", "plan", { planned_visits: 1,
    visits: [{ name: "Second", location: "City", purpose: "Follow-up" }] }, "p2");
  assert.equal(f.tables.field_visits.find(v => v.status === "visited").doctor_name, "First");
});

test("individual MR greeting, activity and encouragement are private and configurable", async () => {
  const f = fixture();
  f.tables.mr_ivr_profiles = [{id: "mr1", value: {ivr_enabled: true, greeting: "Welcome to your individual IVR", encouragement_template: "Keep progressing, {name}. Sales INR {sales}."}}];
  f.tables.app_config[0].value.enabled = false;
  assert.match(await f.run("PLAN"), /individual IVR/);
  assert.match(await f.run("5"), /not live location/);
  assert.match(await f.run("6"), /Keep progressing, Synthetic MR/);
  f.tables.mr_ivr_profiles[0].value.ivr_enabled = false;
  const before = f.sent.length;
  await f.run("PLAN");
  assert.equal(f.sent.length, before);
});