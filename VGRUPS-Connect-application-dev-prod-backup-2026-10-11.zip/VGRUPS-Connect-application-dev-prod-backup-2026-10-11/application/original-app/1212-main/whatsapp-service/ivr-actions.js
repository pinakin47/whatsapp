const { randomUUID } = require("crypto");
const id = () => randomUUID().replace(/-/g, "");
const now = () => new Date().toISOString();
const digits = value => String(value || "").replace(/\D/g, "");
const metricFor = { pricing: "pricing_enquiries", business: "distributor_enquiries", sales: "sales_enquiries", support: "support_requests", order: "orders" };
const QUESTIONS = [
  ["name", "Please enter your name."], ["company", "Your company, hospital or pharmacy?"],
  ["product", "Which product do you need? Please enter its name or code."],
  ["quantity", "What quantity do you need? Enter a whole number."],
  ["location", "Your city / location?"], ["mobile", "Your WhatsApp mobile number, including country code?"],
  ["requirement", "Please describe your requirement."]
];

function createIvrActions({ getDatabase }) {
  const database = () => getDatabase();
  const products = () => database().collection("products");
  const real = { deleted: { $ne: true }, is_demo: { $ne: true }, active: { $ne: false } };
  async function form(action, option, ctx, data = {}) {
    const questions = option.human_request ? [
      ["requirement", "Please share your requirement. Our team will assist you."]
    ] : action === "support" ? [
      QUESTIONS[0], ["order_number", "Related order number? Reply NONE if not applicable."],
      ["requirement", "Please describe the issue so our support team can help."]
    ] : QUESTIONS;
    if (option.human_request) data = { name: ctx.conversation.name || "WhatsApp customer", ...data };
    const state = { stage: "form", request_id: id(), action, label: option.label, data, questions, field: 0, path: ctx.state.path || [] };
    while (state.field < questions.length && data[questions[state.field][0]]) state.field++;
    return { text: `${option.response || option.label || "Enquiry"}\n\n${questions[state.field][1]}\n\n0: Main Menu`, state };
  }
  async function productList(ctx, category = "", offset = 0, metric = "product_enquiries", search = "") {
    // Filter the real catalogue, never manufacture sample products.
    const rows = await products().find(real).sort({ name: 1 }).toArray();
    const selected = rows.filter(p => {
      const value = `${p.category || ""} ${p.name || ""} ${p.description || ""}`.toLowerCase();
      const aliases = category === "medical" ? ["medical", "surgical"] : [category.toLowerCase()];
      return (!category || aliases.some(a => value.includes(a))) &&
        (!search || `${p.name || ""} ${p.code || ""}`.toLowerCase().includes(search.toLowerCase()));
    });
    const page = selected.slice(offset, offset + 8);
    if (!page.length) return { text: "No matching products are currently available. Reply AGENT for help, or 0 for the main menu.", state: { stage: "menu", path: ctx.state.path || [] }, metric };
    return { text: `Available Products\n\n${page.map((p, i) => `${i + 1}. ${p.name}`).join("\n")}${selected.length > offset + 8 ? "\n9. More products" : ""}\n\nReply with a product number. 0: Main Menu`,
      state: { stage: "products", ids: page.map(p => p.id), category, search, offset, has_more: selected.length > offset + 8, path: ctx.state.path || [] }, metric };
  }
  async function detail(productId, ctx) {
    const p = await products().findOne({ id: productId, ...real });
    if (!p) return { text: "That product is no longer available. Reply 0 for the main menu.", state: { stage: "menu", path: ctx.state.path || [] } };
    const link = p.product_url || p.catalogue_url || p.url;
    return { text: [p.name, (p.description || "").slice(0, 700), p.pack_size ? `Pack: ${p.pack_size}` : p.unit ? `Unit: ${p.unit}` : "", link || "",
      "\n1. Product Information\n2. Pricing Enquiry\n3. Talk to Sales\n0. Main Menu"].filter(Boolean).join("\n"),
      state: { stage: "product", product_id: p.id, product_name: p.name, path: ctx.state.path || [] } };
  }
  async function contact(ctx, data) {
    let row = await database().collection("contacts").findOne({ mobile: { $in: [ctx.phone, "+" + ctx.phone] }, deleted: { $ne: true }, is_demo: { $ne: true } });
    if (!row) {
      row = { id: id(), name: data.name, mobile: "+" + ctx.phone, company: data.company || null,
        city: data.location || null, contact_type: "lead", opted_out: false, tags: ["WhatsApp IVR"],
        is_demo: false, created_at: now(), updated_at: now() };
      await database().collection("contacts").insertOne(row);
    }
    return row;
  }
  async function assignee(action) {
    const roles = action === "support" ? ["customer_support", "admin", "super_admin"] : ["sales_manager", "mr", "admin", "super_admin"];
    const user = await database().collection("users").findOne({ role: { $in: roles }, active: { $ne: false }, deleted: { $ne: true }, is_demo: { $ne: true } });
    return user?.id || null;
  }
  async function number(name, prefix, base) {
    const counter = await database().collection("counters").findOneAndUpdate({ _id: name }, { $inc: { seq: 1 } }, { upsert: true, returnDocument: "after" });
    return prefix + (base + counter.seq);
  }
  async function submit(ctx, state) {
    const data = state.data;
    const person = await contact(ctx, data);
    const assigned = await assignee(state.action);
    const handoff = Boolean(ctx.config.human_handoff);
    const fields = { created_at: now(), updated_at: now(), created_by: "whatsapp_ivr", is_demo: false,
      conversation_id: ctx.conversation.id, contact_id: person.id, contact_name: data.name, mobile: "+" + ctx.phone, assigned_to: assigned };
    const result = { metric: metricFor[state.action], customer_name: data.name, handoff, conversation_status: handoff ? "human_handoff" : "open",
      state: { stage: "menu", path: [] } };
    if (state.action === "support") {
      const taskId = state.request_id || id();
      await database().collection("tasks").updateOne({ id: taskId }, { $setOnInsert: { ...fields, id: taskId, title: `${state.label}: ${data.name}`,
        task_type: "customer_support", status: "pending", priority: "medium", due_date: now().slice(0, 10),
        notes: `Order: ${data.order_number || "NONE"}\n${data.requirement}` } }, { upsert: true });
      result.task_id = taskId;
      result.text = `Your support request has been recorded. Our team will assist you.${ctx.config.support_contact ? "\nSupport: " + ctx.config.support_contact : ""}\n0: Main Menu`;
    } else if (state.action === "order") {
      const candidates = await products().find({ ...real }).toArray();
      const p = candidates.find(p => [p.name, p.code].some(v => String(v || "").toLowerCase() === data.product.toLowerCase()));
      if (!p || p.selling_price == null || !Number.isFinite(Number(p.selling_price)) || Number(p.selling_price) < 0) {
        return { text: "Please enter an exact available product name/code so we can record your order. Reply AGENT for a custom order or 0 for the main menu.",
          state: { ...state, field: state.questions.findIndex(q => q[0] === "product") } };
      }
      const qty = Number(data.quantity), price = Number(p.selling_price), amount = price * qty;
      const gst = amount * Number(p.gst || 0) / 100;
      const orderId = state.request_id || id();
      const existingOrder = await database().collection("orders").findOne({ id: orderId });
      const orderNo = existingOrder?.order_no || await number("orders", "VG", 20000);
      await database().collection("orders").updateOne({ id: orderId }, { $setOnInsert: { ...fields, id: orderId, order_no: orderNo,
        items: [{ product_id: p.id, name: p.name, code: p.code, qty, price, amount, gst: Number(p.gst || 0) }],
        items_count: 1, subtotal: amount, gst_amount: gst, discount: 0, total: amount + gst,
        status: "draft", payment_status: "pending", notes: `WhatsApp order request; requires team confirmation.\n${data.requirement}` } }, { upsert: true });
      result.order_id = orderId;
      result.text = `Order request ${orderNo} has been recorded for ${p.name} × ${qty}. Our team will confirm pricing and availability. This is not a payment or dispatch confirmation.\n0: Main Menu`;
    } else {
      const leadId = state.request_id || id();
      const existingLead = await database().collection("leads").findOne({ id: leadId });
      await database().collection("leads").updateOne({ id: leadId }, { $setOnInsert: { ...fields, id: leadId, lead_no: existingLead?.lead_no || await number("leads", "LD", 10000),
        name: data.name, company: data.company, city: data.location, product_interest: data.product,
        quantity: data.quantity ? Number(data.quantity) : null, enquiry_type: state.action,
        status: "new", source: "whatsapp_ivr", stage: "new",
        notes: `${state.label}\n${data.requirement}` } }, { upsert: true });
      result.lead_id = leadId;
      result.text = `Thank you. Your enquiry has been received. Our sales team will contact you shortly.${ctx.config.sales_contact ? "\nSales: " + ctx.config.sales_contact : ""}\n0: Main Menu`;
    }
    result.assigned_to = assigned;
    return result;
  }
  return {
    async start(action, option, ctx) {
      if (action === "catalogue") {
        let link = ctx.config.catalogue_url;
        if (!link) {
          const configured = await database().collection("app_config").findOne({ key: "chatbot_flow" });
          const node = configured?.value?.nodes?.find(n => n.id === "catalog");
          link = node?.text?.match(/https?:\/\/[^\s]+/)?.[0];
        }
        if (link) return { text: `VGRUPS Healthcare Product Catalogue\n${link}\n\n1. Product Information\n2. Pricing\n3. Talk to Sales\n0. Main Menu`,
          state: { stage: "catalogue", path: ctx.state.path || [] }, metric: "catalogue_requests" };
        return productList(ctx, "", 0, "catalogue_requests");
      }
      if (action === "category") return productList(ctx, option.category || "");
      if (action === "product_search") return { text: "Enter a product name or code. Reply 0 for the main menu.", state: { stage: "search", path: ctx.state.path || [] } };
      if (action === "order_status") return { text: "Please enter your Order Number. Reply 0 for the main menu.", state: { stage: "order_status", path: ctx.state.path || [] } };
      return form(action, option, ctx);
    },
    async next(text, state, ctx) {
      if (state.stage === "products") {
        if (text === "9" && state.has_more) return productList(ctx, state.category, state.offset + 8, undefined, state.search);
        if (!/^[1-8]$/.test(text) || !state.ids[Number(text) - 1]) return { text: "Please select a listed product number, or reply 0 for the main menu.", state };
        return detail(state.ids[Number(text) - 1], ctx);
      }
      if (state.stage === "search") return productList(ctx, "", 0, "product_enquiries", text);
      if (state.stage === "product" || state.stage === "catalogue") {
        if (text === "1") return state.product_id ? detail(state.product_id, ctx) : productList(ctx);
        if (text === "2" || text === "3") return form(text === "2" ? "pricing" : "sales",
          { label: text === "2" ? "Pricing Enquiry" : "Talk to Sales" }, ctx, state.product_name ? { product: state.product_name } : {});
        return { text: "Reply 1 for information, 2 for pricing, 3 for sales, or 0 for the main menu.", state };
      }
      if (state.stage === "order_status") {
        const order = await database().collection("orders").findOne({ order_no: text.trim().toUpperCase(), deleted: { $ne: true }, is_demo: { $ne: true } });
        // A guessed order number is never sufficient to reveal another customer's data.
        const jid = String(ctx.conversation.reply_jid || "");
        const verifiedNumber = !jid.endsWith("@lid") || digits(ctx.phone) !== digits(jid.split("@")[0]);
        if (!order || !verifiedNumber || digits(order.mobile) !== digits(ctx.phone))
          return { text: "We could not find that order for your WhatsApp number. Please check the number and try again, or reply AGENT for assistance.", state, metric: "order_status_requests", result: "not_found_or_not_owned" };
        return { text: `Order: ${order.order_no}\nStatus: ${order.status}${order.expected_delivery ? "\nExpected delivery: " + order.expected_delivery : ""}\n1. Talk to Sales\n0. Main Menu`,
          state: { stage: "status_result", path: state.path }, metric: "order_status_requests", order_id: order.id };
      }
      if (state.stage === "status_result") return text === "1" ? form("sales", { label: "Order Assistance" }, ctx) :
        { text: "Reply 1 to talk to sales, or 0 for the main menu.", state };
      if (state.stage === "form") {
        const [field] = state.questions[state.field];
        if (!text.trim() || text.length > 2000) return { text: "Enter a non-empty response, up to 2000 characters.", state };
        if (field === "quantity" && (!/^[1-9]\d{0,5}$/.test(text.trim())))
          return { text: "Please enter a positive whole-number quantity, up to 999999.", state };
        if (field === "mobile" && digits(text) !== digits(ctx.phone))
          return { text: "Please enter the number you are messaging from, with country code, for secure order and enquiry records.", state };
        const next = { ...state, data: { ...state.data, [field]: text.trim() }, field: state.field + 1 };
        while (next.field < next.questions.length && next.data[next.questions[next.field][0]]) next.field++;
        if (next.field < next.questions.length) return { text: next.questions[next.field][1] + "\n0: Main Menu", state: next };
        return submit(ctx, next);
      }
      throw new Error("Unsupported IVR conversation state.");
    }
  };
}
module.exports = { createIvrActions };