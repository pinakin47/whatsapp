# Dependency security verification

## Inventory and package managers

The inventory uses a filesystem walk, not Git's tracked-file list. Dependency
caches, VCS directories and generated build output are pruned before traversal.
`pnpm security:versions` repeats this walk and checks every discovered dependency
file for all eleven vulnerable package/version pairs in the requested findings.

| Manifest | Manager / lockfile | Remediation |
| --- | --- | --- |
| `package.json` | pnpm / root `pnpm-lock.yaml` | `pnpm audit --fix` |
| `artifacts/api-server/package.json` | pnpm / root lock | `pnpm audit --fix` |
| `artifacts/mockup-sandbox/package.json` | pnpm / root lock | `pnpm audit --fix` |
| `artifacts/vgrups-connect/package.json` | pnpm / root lock | Auto-fix; direct Axios upgrade |
| `lib/api-client-react/package.json` | pnpm / root lock | `pnpm audit --fix` |
| `lib/api-spec/package.json` | pnpm / root lock | `pnpm audit --fix` |
| `lib/api-zod/package.json` | pnpm / root lock | `pnpm audit --fix` |
| `lib/db/package.json` | pnpm / root lock | `pnpm audit --fix` |
| `scripts/package.json` | pnpm / root lock | `pnpm audit --fix` |
| `original-app/1212-main/whatsapp-service/package.json` | pnpm / root lock | `pnpm audit --fix` |
| `original-app/1212-main/frontend/package.json` | Yarn Classic / new local `yarn.lock` | No auto-fix; direct bump and resolutions |
| `pyproject.toml` | uv / `uv.lock` | pip-audit attempt; manifest updates and `uv sync` |
| `original-app/1212-main/backend/requirements.txt` | pip | `pip-audit -r requirements.txt --fix`; explicit corrections |
| `lib/bounded-braces/package.json` (new) | pnpm / root lock | Audit after installation |

Each pnpm auto-fix was invoked from its own manifest directory. Shared workspace
overrides are intentional; pnpm regenerates its single shared lockfile.

## Fixes and compatibility decisions

- Axios: 1.20.0 in both frontends.
- Transitive minimums: brace-expansion 5.0.12, fast-uri 3.1.8,
  source-map-js 1.2.2, proxy-addr 2.0.8, postcss-selector-parser 7.1.6.
  The imported frontend's legacy minimatch 3/5 consumers instead resolve to
  patched brace-expansion 2.1.7, preserving the callable CommonJS API they require.
  The parent-scoped Yarn resolution precedes the generic 5.x resolution.
  The bounded adapter uses a distinct npm alias for patched brace-expansion 5.x
  so Yarn's hoisting cannot substitute the legacy callable dependency.
- FastAPI 0.143.0 supports patched Starlette 1.3.1. Both Python manifests now
  agree; upgrading Starlette alone would violate the old FastAPI constraint.
- Removed unused python-jose and ecdsa from the imported requirements. The app
  already uses PyJWT with an explicit HS256 allowlist; there is no ecdsa signing
  path or python-jose import to migrate. ecdsa has no upstream timing-attack fix.
- Removed Emergent's wrapper and its hard-pinned LiteLLM wheel rather than
  overriding its incompatible dependencies. Resume screening still uses the same
  Gemini model, system message, Emergent proxy, credentials and app-ID header.
  The replacement makes one request via existing httpx, supports native Gemini
  keys, and explicitly fails on missing configuration or provider errors.
- `braces` 3.0.3 has no patched upstream release. Its callers here are build-time
  micromatch and chokidar, not public API routes. They now use our original,
  bounded adapter backed by patched `brace-expansion`, with bounded pattern
  length, brace count, range cardinality, output length, rewrites and expansion
  count. This does not vendor the vulnerable recursive AST implementation.
  The adapter returns expanded glob alternatives; it does not expose unused
  braces AST methods. Both frontend builds and mockup discovery exercise it.
- Yarn installation required updating its existing shell-quote resolution to
  1.12.0 after the package firewall blocked 1.9.0, and its svgo resolution to
  2.8.4. No firewall policy or minimum-release-age protection was disabled.

## Checks

Run:

```sh
pnpm security:versions
pnpm audit
uv lock --check
uv export --frozen --format requirements-txt --no-hashes --no-emit-project \
  --output-file /tmp/python-locked-requirements.txt >/dev/null
uv run pip-audit -r /tmp/python-locked-requirements.txt --no-deps --disable-pip
uv run pip-audit -r original-app/1212-main/backend/requirements.txt --no-deps --disable-pip
pnpm --filter @workspace/bounded-braces test
cd original-app/1212-main/frontend
yarn install --frozen-lockfile --ignore-scripts --non-interactive
yarn test:dependency-compatibility
cd ../../..
pnpm typecheck
PYTHONPATH=original-app/1212-main/backend uv run pytest \
  original-app/1212-main/backend/tests/test_screening_llm.py \
  original-app/1212-main/backend/tests/test_auth_seed_security.py \
  original-app/1212-main/backend/tests/test_email_otp_login.py \
  -k 'not unconfigured_otp_is_demo_only_in_development'
```

Auditing an export of the frozen Python lock matters: an untargeted pip-audit can
discover the separate system interpreter's pip, which uv does not manage. This
pip-audit release does not recognize uv.lock through its `--locked` option.

The imported frontend's Yarn lock uses the `braces` dependency slot for the local
`@workspace/bounded-braces` package. Scanners that identify packages only by that
slot incorrectly report upstream braces advisories against our adapter's 1.0.0
version. Its `resolved` value is a local file, not an upstream braces release.
Do not misrepresent this as a patched upstream braces version or suppress it
globally. The version guard and adapter tests independently verify the replacement.

The additional imported CRA development-tool findings for node-forge and
sprintf-js are outside the requested package/version list. They are not claimed
to have been fixed. Existing React hook lint warnings in the imported frontend
make `CI=true yarn build` fail, but its ordinary production build remains usable;
those unrelated UI warnings are not changed by this dependency task.

Two old `test_auth_seed_security` OTP cases expect a legacy demo response and mock
only the auth module, not its current email-OTP helper. They fail against the
current login flow independently of dependency versions, and must not be rerun
against a real database. The current email-OTP suite uses in-memory fixtures.
