# MR WhatsApp lead capture

## Contextual MR automatic replies

In **Leads → WhatsApp Leads → Setup**, an administrator can enable **Automatically reply to MR messages with OpenAI** after enabling authorized lead capture and confirming activation. Replies use the personal OpenAI account only; provider failures never switch billing. The feature remains off until this explicit action.

Eligible free-form messages from recognized active MRs are queued without blocking the existing WhatsApp menus. Replies use recent messages in the originating conversation and only that MR's lead evidence, submitted report records, visits and target. They guide lead follow-up and reporting; they do not submit or edit reports. Numeric answers and normal draft entries retain their existing handlers.

Human takeover, opt-out, a newer inbound message, a newer staff answer or revoked send authorization cancels an unsent response. Replies use the exact originating QR session, not another number or provider. Old responses expire. Interrupted or uncertain sends are not automatically retried.

Accepted replies appear in Inbox with an **MR AI assistant** label. Setup shows recent reply activity and failure/uncertainty states. Provider acceptance is not delivery/read confirmation. AI replies and missing-phone prompts are marked before socket echoes so they cannot feed back into lead extraction.

Verification used isolated backend/gateway fixtures, synthetic browser-intercepted activation controls and a synthetic request through the personal OpenAI account. No real WhatsApp messages or telephone calls were sent.

Open **Leads → WhatsApp Leads**. The existing Leads board and MR menus remain available.

## Activation

1. An administrator opens **Setup**, confirms that the app is authorized to process the integrated messages, and explicitly confirms activation.
2. AI extraction uses your OpenAI account when `OPENAI_API_KEY` is saved securely, with the `gpt-5-mini` model and OpenAI billing. Without that key, the previously configured Replit AI integration remains available and uses credits. A failed personal-key request never silently switches to managed billing.
3. Missing-phone WhatsApp requests and telephone voice calls have separate switches and require confirmation when enabled.
4. Capture and both sending switches are initially off. No real messages or calls were sent during verification.

Only messages actually received or sent through the authorized QR/Meta integration are eligible. An active MR must be identifiable through the employee directory, actual sender, assigned conversation or linked account. The app cannot access private WhatsApp conversations outside its integration.

## Capture and review

- Business messages retain their original text and extraction evidence.
- Numbers normalize to Indian `+91` format. An MR's registered number is not assumed to be the customer's number.
- Phone, organization/contact identity, conversation and conservative similarity matching prevent duplicates. Conflicting information does not automatically replace populated facts.
- Low-confidence results and ownership conflicts appear in **Review Queue**. Administrators verify corrections explicitly. Correcting an existing review candidate updates that record rather than creating another lead.
- Message and audit histories have separate paging controls, including records beyond the first thousand.
- Admin and Super Admin receive separate linked in-app notifications. These are not claims of external WhatsApp/SMS delivery.

## Missing phone numbers

Both WhatsApp and voice request records are created, with truthful disabled, queued, blocked, accepted or uncertain states.

An MR can reply:

`LEAD WHL-2026-0001 9876543210`

A single unambiguous pending lead also accepts `His number is 9876543210.` Quoting a phone request identifies its lead when several are pending. Bare numbers are not consumed while an MR reporting draft is expecting numeric answers.

The phone can also be supplied through a subsequent complete business message or an authorized lead edit. Completion resolves the request and alerts both administrator roles independently.

Accepted or uncertain provider attempts are not automatically resent. An offline channel does not prevent available work on another channel. Meta text messages outside the 24-hour service window remain blocked until an approved-template workflow is available; no send is falsely recorded.

## Telephone IVR setup still required

Connect Twilio, choose an authorized calling number, and configure `LEAD_VOICE_FROM_NUMBER` and `LEAD_VOICE_CALLBACK_BASE_URL` through the workspace environment tooling. The callback base must be HTTPS and reach the same backend/environment holding the request records.

The prepared voice flow names the customer, organization and lead ID, collects a ten-digit number by keypad, and verifies the signed callback and provider call ID. Do not enable live calls until the connection, number and callback are verified. A WhatsApp text IVR is not a telephone call.

## Access and administration

MRs can view and edit only leads assigned to them; they cannot delete, reassign, edit admin remarks or change audit evidence. Administrators with the relevant permissions can assign, verify, soft-delete and export. Original evidence remains after deletion.

Presets include missing/completed phone, new, follow-up, hot, hospital, doctor, clinic, pharmacy, distributor, converted and lost leads. Filters and administrator CSV export use the same access rules. Analytics and activity/request views are included.
