# WhatsApp session ownership

Development and publishing previously ran the same gateway startup script and
restored every non-logged-out entry in `wa_sessions`. Neither socket startup nor
credential access was exclusive. Reconnect requests could also open a second
socket in the same process. A WhatsApp `connectionReplaced` close was treated as a
temporary network failure, creating repeated reconnects.

Production metadata confirmed an active Autoscale deployment. Recent filtered
production logs contained gateway startups but did not establish simultaneous
restoration of the same session. Shared database credentials were not inspected.
The configuration permits competition if the two environments share a database;
it is not evidence that they currently do.

## Runtime policy

- `WA_GATEWAY_MODE` accepts only `enabled` or `disabled`.
- Without an override, development is disabled and published runtimes
  (`REPLIT_DEPLOYMENT=1`) are enabled.
- Disabled gateways keep their loopback health endpoint available but never
  connect to the database, restore credentials, generate pairing QR codes, or
  send messages. Mutation endpoints return 409. Session listing returns an empty
  list with `gateway_status: disabled`, not a stale production connection.
- Enabled gateways acquire a PostgreSQL session advisory lock on a dedicated
  connection **before** reading any session or authentication records. The key
  is identical across environments because credentials, not runtime names,
  determine exclusivity. No schema migration is needed.
- A losing gateway stays in `owned_elsewhere` standby without credential access.
  Restart it after the owner has stopped if an intentional takeover is needed.
- Database connection loss or a failed heartbeat stops the owner without logout.
  The dedicated connection is never returned to a pool while holding its lock.
- Concurrent starts for one session coalesce. Manual reconnect cancels the old
  timer, detaches the old socket, and rejects obsolete socket events.
- A replacement conflict stops automatic retries and preserves credentials.
  A conflicted session is not automatically restored on subsequent restarts.
  Use explicit reconnect only after identifying and stopping the competitor.

## Pairing and rollout

No credentials are migrated, deleted, or renamed by this change. Production
pairing is preserved. Development no longer restores the production-linked
number by default; its WhatsApp sending and pairing are intentionally unavailable.

For development pairing, explicitly enable a gateway only with an isolated
development credential database and use a different test WhatsApp number.
Do not enable development against the legacy live gateway's database: the old
build has no ownership lock and can still compete with a new owner.

Only workspace code and its development workflow were changed. No live
configuration, production data, or deployment was changed. An approved future
rollout must stop any legacy gateway that lacks the lock before starting the
new enabled owner. Ask the user for approval before that production change.
Autoscale can create multiple owners or scale down a persistent connection;
the lock prevents simultaneous restoration but does not guarantee continuous
uptime. Evaluate Reserved VM separately with user approval.

Verification uses synthetic ownership clients and a mocked entry-point fixture,
not live credentials, QR scanning, or WhatsApp messages.
