// Credentials are injected by the connector proxy, never passed through stdin.
import { ReplitConnectors } from "@replit/connectors-sdk";

let input = "";
for await (const chunk of process.stdin) input += chunk;
try {
  const { action, payload } = JSON.parse(input);
  if (!["send-otp", "send-email", "senders"].includes(action)) throw new Error("Invalid action");
  const connectors = new ReplitConnectors();
  const response = await connectors.proxy(
    "brevo",
    action === "senders" ? "/senders" : "/smtp/email",
    action === "senders"
      ? { method: "GET" }
      : {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        },
  );
  if (!response.ok) {
    process.stdout.write(JSON.stringify({
      error: `Brevo request failed (HTTP ${response.status}). Check the connected account and verified sender.`,
    }));
    process.exitCode = 1;
  } else {
    process.stdout.write(JSON.stringify(await response.json()));
  }
} catch {
  process.stdout.write(JSON.stringify({ error: "Brevo connector request failed." }));
  process.exitCode = 1;
}