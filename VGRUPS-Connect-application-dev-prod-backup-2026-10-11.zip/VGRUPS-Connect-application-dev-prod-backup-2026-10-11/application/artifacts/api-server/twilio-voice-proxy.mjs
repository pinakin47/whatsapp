// Twilio credentials remain inside the Replit connector; stdin contains no credentials.
import { ReplitConnectors } from "@replit/connectors-sdk";
let input = "";
for await (const chunk of process.stdin) input += chunk;
try {
  const { action, payload } = JSON.parse(input);
  if (!["status", "call"].includes(action)) throw new Error("Invalid action");
  const sdk = new ReplitConnectors();
  const accountResponse = await sdk.proxy("twilio", "/2010-04-01/Accounts.json", { method: "GET" });
  if (!accountResponse.ok) throw new Error("Unavailable");
  const account = (await accountResponse.json()).accounts?.find(a => a.status === "active");
  if (!account) throw new Error("Unavailable");
  if (action === "status") {
    process.stdout.write(JSON.stringify({ ready: true }));
  } else {
    const response = await sdk.proxy("twilio", `/2010-04-01/Accounts/${account.sid}/Calls.json`, {
      method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams(payload).toString(),
    });
    if (!response.ok) throw new Error("Call acceptance unresolved");
    const result = await response.json();
    process.stdout.write(JSON.stringify({ sid: result.sid, status: result.status }));
  }
} catch {
  process.stdout.write(JSON.stringify({ error: "Twilio connection unavailable or acceptance unresolved." }));
  process.exitCode = 1;
}
