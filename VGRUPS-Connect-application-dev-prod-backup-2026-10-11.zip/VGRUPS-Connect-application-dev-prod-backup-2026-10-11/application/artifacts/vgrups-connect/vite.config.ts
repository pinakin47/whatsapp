import path from 'path';
import react from '@vitejs/plugin-react';
import { defineConfig } from 'vite';
import runtimeErrorOverlay from '@replit/vite-plugin-runtime-error-modal';

const port = Number(process.env.PORT);
if (!process.env.PORT || Number.isNaN(port) || port <= 0) {
  throw new Error('PORT environment variable is required');
}
const basePath = process.env.BASE_PATH || '/';

export default defineConfig({
  base: basePath,
  plugins: [
    react({ include: /\.(js|jsx|ts|tsx)$/ }),
    runtimeErrorOverlay(),
  ],
  // Original CRA source has JSX inside .js files
  esbuild: { loader: 'jsx', include: /src\/.*\.jsx?$/, exclude: [] },
  optimizeDeps: {
    esbuildOptions: { loader: { '.js': 'jsx' } },
  },
  define: {
    'process.env.REACT_APP_BACKEND_URL': JSON.stringify(''),
  },
  css: { postcss: path.resolve(import.meta.dirname) },
  resolve: {
    alias: { '@': path.resolve(import.meta.dirname, 'src') },
    dedupe: ['react', 'react-dom'],
  },
  root: path.resolve(import.meta.dirname),
  build: { outDir: path.resolve(import.meta.dirname, 'dist/public'), emptyOutDir: true },
  server: { port, strictPort: true, host: '0.0.0.0', allowedHosts: true },
  preview: { port, host: '0.0.0.0', allowedHosts: true },
});
