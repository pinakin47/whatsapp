import { test as base, expect } from "@playwright/test";

export const SENDERS = ["+15550000001", "+15550000002", "Unknown"];
export const ITEM_ID = "synthetic-history";
export const ITEM_NAME = "Synthetic history";
export const CSV = "name,mobile,sender_number,delivery\nSynthetic recipient,+15550000099,Unknown,read\n";
export const REPORT_ERROR = "Synthetic report outage";

const item = {
  id: ITEM_ID, name: ITEM_NAME, status: "completed", message: "Synthetic fixture only",
  message_gap_seconds: 5, sender_number: SENDERS[0],
  stats: { total: 125, sent: 125 }, steps: [{ day: 0, message: "Fixture only" }],
};

export const CARD_CAMPAIGN = {
  ...item, id: "synthetic-card-campaign", name: "Synthetic card campaign",
};
export const CARD_CSV = "name,mobile,sender_number,delivery\nSynthetic card recipient,+15550000098,+15550000002,sent\n";

export function filters(url) {
  return Object.fromEntries(new URL(url).searchParams);
}

export function rowName(params) {
  return `Fixture ${params.sender || "all"} / ${params.delivery || "all"} / ${params.search || "all"} / page ${params.page || 1}`;
}

function report(params) {
  const pageSize = Number(params.page_size || 50);
  return {
    campaign: item, summary: { total: 125, sent: 125 }, sender_numbers: SENDERS,
    pagination: { page: Number(params.page || 1), page_size: pageSize, total: 125, pages: Math.ceil(125 / pageSize) },
    recipients: [{
      id: "synthetic-recipient", name: rowName(params), mobile: "+15550000099",
      sender_number: params.sender === "Unknown" ? null : params.sender || SENDERS[0],
      status: "sent", delivery: params.delivery || "read", replied: false,
      sent_at: "2026-10-01T08:00:00Z",
    }],
  };
}

base.use({ launchOptions: process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH
  ? { executablePath: process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH } : {},
  serviceWorkers: "block",
});

// No real authentication, API, delivery provider, or database is used.
// Unexpected APIs (including reads) fail closed rather than silently returning {}.
export const test = base.extend({
  reportApi: async ({ context, page }, use) => {
    const baseURL = process.env.BASE_URL || (process.env.REPLIT_DEV_DOMAIN
      ? `https://${process.env.REPLIT_DEV_DOMAIN}` : null);
    if (!baseURL) throw new Error("Set BASE_URL to the running frontend preview URL.");
    const origin = new URL(baseURL).origin;
    const requests = [];
    const unexpected = [];
    const pageErrors = [];
    const held = [];
    const reportFailures = [];
    const exportFailures = [];
    let campaignPermissions = ["view", "export"];
    let includeCardCampaign = false;
    let holdWhen = () => false;
    let omitSenders = false;
    page.on("pageerror", error => pageErrors.push(error.message));
    await context.addInitScript(() => localStorage.setItem("vg_token", "synthetic-report-token"));
    // Also prevent a future realtime client from reaching a live gateway.
    await context.routeWebSocket(/.*/, socket => socket.close());
    await context.route("**/*", async route => {
      const request = route.request();
      const url = new URL(request.url());
      const isApi = /\/api(?:\/|$)/.test(url.pathname);
      if (!isApi) {
        if (["xhr", "fetch"].includes(request.resourceType())) {
          unexpected.push(`${request.method()} ${url.pathname}`);
          return route.abort();
        }
        if (url.origin !== origin) return route.abort();
        return route.continue();
      }
      requests.push({ path: url.pathname, method: request.method(), params: filters(url) });
      if (request.method() !== "GET") {
        unexpected.push(`${request.method()} ${url.pathname}`);
        return route.abort();
      }
      const json = body => route.fulfill({ contentType: "application/json", body: JSON.stringify(body) });
      const fail = failure => failure === "network"
        ? route.abort("failed")
        : route.fulfill({ status: 503, contentType: "application/json", body: JSON.stringify({ detail: REPORT_ERROR }) });
      if (url.pathname === "/api/auth/me") return json({
        id: "synthetic-reader", name: "Synthetic Reader", role: "admin",
        permissions: { campaigns: campaignPermissions },
      });
      if (["/api/campaigns", "/api/drips"].includes(url.pathname)) {
        return json({ items: url.pathname === "/api/campaigns" && includeCardCampaign ? [item, CARD_CAMPAIGN] : [item] });
      }
      if (url.pathname === "/api/lead-capture/notifications") return json({ items: [], unread: 0 });
      if (["/api/campaign-groups", "/api/whatsapp/templates", "/api/wa/senders", "/api/wa/sessions"].includes(url.pathname)) {
        return json({ items: [] });
      }
      if (new RegExp(`^/api/(campaigns|drips)/${ITEM_ID}/report\\.csv$`).test(url.pathname)) {
        if (exportFailures.length) return fail(exportFailures.shift());
        return route.fulfill({ contentType: "text/csv", body: CSV });
      }
      if (includeCardCampaign && url.pathname === `/api/campaigns/${CARD_CAMPAIGN.id}/report.csv`) {
        if (exportFailures.length) return fail(exportFailures.shift());
        return route.fulfill({ contentType: "text/csv", body: CARD_CSV });
      }
      if (new RegExp(`^/api/(campaigns|drips)/${ITEM_ID}/report$`).test(url.pathname)) {
        if (reportFailures.length) return fail(reportFailures.shift());
        const params = filters(url);
        const body = report(params);
        if (omitSenders) body.sender_numbers = [];
        if (holdWhen(params)) {
          // The browser may abort this route when filters change. Keeping the
          // response lets tests explicitly attempt late completion nonetheless.
          held.push({
            params,
            release: async () => {
              try { await json(body); }
              catch (error) {
                if (!request.failure()) throw error;
              }
            },
          });
          return;
        }
        return json(body);
      }
      unexpected.push(`${request.method()} ${url.pathname}`);
      return route.abort();
    });
    const openReport = async (type, { waitForReport = true } = {}) => {
      if (type === "drips") await page.getByTestId("camp-tab-drips").click();
      await page.getByTestId(`${type === "drips" ? "drip" : "campaign"}-report-${ITEM_ID}`).click();
      if (waitForReport) await expect(page.getByTestId("report-dialog").locator("tbody")).toContainText(rowName({}));
    };
    try {
      await use({
        requests, held,
        setCampaignPermissions: actions => { campaignPermissions = [...actions]; },
        includeCardCampaign: () => { includeCardCampaign = true; },
        openReport,
        hold: predicate => { holdWhen = predicate; },
        // Queue failures only for the explicitly synthetic report endpoints.
        // Once consumed, the next request automatically receives a good fixture.
        failReports: (...failures) => reportFailures.push(...failures),
        failExports: (...failures) => exportFailures.push(...failures),
        omitSenders: () => { omitSenders = true; },
        reports: type => requests.filter(r => r.path === `/api/${type}/${ITEM_ID}/report`),
        exports: (type, id = ITEM_ID) => requests.filter(r => r.path === `/api/${type}/${id}/report.csv`),
        open: async (type, { waitForReport = true } = {}) => {
          await page.goto(`${baseURL.replace(/\/$/, "")}/campaigns`);
          await openReport(type, { waitForReport });
        },
      });
    } finally {
      // These assertions also fail the test if an app change adds a live write
      // or an API dependency for which no synthetic fixture was supplied.
      expect(unexpected, "All API calls must be explicitly intercepted").toEqual([]);
      expect(pageErrors, "No uncaught frontend errors").toEqual([]);
    }
  },
});

export { expect };
