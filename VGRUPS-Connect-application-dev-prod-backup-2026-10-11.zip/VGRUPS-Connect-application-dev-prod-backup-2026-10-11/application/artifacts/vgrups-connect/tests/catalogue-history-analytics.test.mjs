// Isolated hook/element harness: no browser, backend, credentials or messages.
import { test } from "node:test";
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import { runInNewContext } from "node:vm";
import { transformWithEsbuild } from "vite";
import { trackEvent } from "../src/lib/analytics.js";

const source = await readFile(new URL("../src/components/CatalogueHistory.jsx", import.meta.url), "utf8");
const { code } = await transformWithEsbuild(
  source.replace(/^import .*;\n/gm, "").replace("export default function", "function"),
  "CatalogueHistory.jsx", { loader: "jsx", jsx: "transform", jsxFactory: "createElement", jsxFragment: "Fragment" },
);
const row = {
  id: "private-attempt-id", name: "Private recipient", phone: "private-phone",
  error: "private-provider-error", parts: [{ id: "private-part", wamid: "private-message" }],
};

function harness(daily, allowed = true, tracker = "working") {
  const slots = [], events = [], errors = [];
  let cursor = 0, effects = [], dirty = true, tree;
  let failRead = false, failDownload = false, downloads = 0;
  const emit = (name, data) => {
    if (tracker === "missing") globalThis.window = {};
    else globalThis.window = { umami: { track: (name, data) => {
      if (tracker === "throw") throw new Error("Broken tracker");
      if (tracker === "reject") return Promise.reject(new Error("Broken tracker"));
      // VM objects have different prototypes; compare their serialized payloads.
      events.push([name, JSON.parse(JSON.stringify(data))]);
    } } };
    try { trackEvent(name, data); } finally { delete globalThis.window; }
  };
  const Component = runInNewContext(`${code}\nCatalogueHistory;`, {
    URLSearchParams, encodeURIComponent,
    Fragment: "fragment",
    createElement: (type, props, ...children) => ({ type, props: props || {}, children: children.flat(Infinity) }),
    Button: "button", CatalogueReceiptEvidence: "evidence",
    useAuth: () => ({ user: { id: "private-user" }, can: () => allowed }),
    useState: (initial) => {
      const i = cursor++;
      if (!(i in slots)) slots[i] = initial;
      return [slots[i], value => {
        const next = typeof value === "function" ? value(slots[i]) : value;
        if (next !== slots[i]) { slots[i] = next; dirty = true; }
      }];
    },
    useRef: (initial) => {
      const i = cursor++;
      return slots[i] ||= { current: initial };
    },
    useEffect: (fn, deps) => {
      const i = cursor++;
      const old = slots[i];
      if (!old || deps.some((dep, j) => dep !== old.deps[j])) {
        old?.cleanup?.();
        slots[i] = { deps };
        effects.push(() => { slots[i].cleanup = fn(); });
      }
    },
    api: { get: async path => {
      if (failRead) throw new Error("private-read-error");
      return { data: path.includes("?")
        ? { items: [row], total: 60, has_more: true } : row };
    } },
    apiError: e => e.message,
    toast: { error: e => errors.push(e) },
    downloadReportCsv: async () => {
      if (failDownload) throw new Error("private-download-error");
      downloads++;
    },
    trackEvent: emit,
  });
  const settle = async () => {
    for (let i = 0; i < 6; i++) {
      if (dirty) {
        dirty = false; cursor = 0; effects = [];
        tree = Component({ daily, contactRef: "private-contact" });
        effects.forEach(fn => fn());
      }
      await new Promise(resolve => setImmediate(resolve));
    }
  };
  const findIn = (label, node) => {
    if (!node || typeof node !== "object") return undefined;
    if (node.type === "button" && node.children.join("") === label) return node;
    return node.children.map(child => findIn(label, child)).find(Boolean);
  };
  const find = label => findIn(label, tree);
  const click = async label => {
    const button = find(label);
    assert.ok(button, `Missing button: ${label}`);
    assert.ok(!button.props.disabled, `Disabled button: ${label}`);
    await button.props.onClick();
    await settle();
  };
  return {
    settle, click, find, events, errors,
    failReads: value => { failRead = value; },
    failDownloads: value => { failDownload = value; },
    get downloads() { return downloads; },
  };
}

for (const daily of [false, true]) {
  test(`${daily ? "daily" : "individual"} success events contain only fixed enum dimensions`, async () => {
    const h = harness(daily);
    const history_type = daily ? "daily" : "individual";
    await h.settle();
    assert.equal(h.events.length, 0);
    await h.click("View saved attempt");
    await h.click("Refresh saved receipts");
    await h.click("Export saved attempt CSV");
    await h.click("Close details");
    await h.click("View saved attempt");
    await h.click("Older attempts");
    await h.click("Refresh history");
    await h.click("Previous attempts");
    await h.click("Export this page CSV");
    assert.deepEqual(h.events, [
      ["catalogue_history_detail_opened", { history_type }],
      ["catalogue_history_csv_exported", { history_type, export_scope: "detail" }],
      ["catalogue_history_detail_opened", { history_type }],
      ["catalogue_history_older_page_opened", { history_type }],
      ["catalogue_history_csv_exported", { history_type, export_scope: "page" }],
    ]);
    assert.equal(h.downloads, 2);
  });
}

test("failed reads and downloads do not report success; successful recovery does", async () => {
  const h = harness(false);
  await h.settle();
  h.failReads(true);
  await h.click("View saved attempt");
  assert.equal(h.events.length, 0);
  h.failReads(false);
  await h.click("Reload details");
  assert.equal(h.events.length, 1);
  h.failDownloads(true);
  await h.click("Export saved attempt CSV");
  assert.equal(h.events.length, 1);
  assert.equal(h.errors.length, 1);
  h.failReads(true);
  await h.click("Older attempts");
  assert.equal(h.events.length, 1);
  h.failReads(false);
  await h.click("Reload history");
  assert.equal(h.events.length, 2);
});

for (const tracker of ["missing", "throw", "reject"]) {
  test(`${tracker} analytics cannot prevent history or downloads`, async () => {
    const h = harness(true, true, tracker);
    await h.settle();
    await h.click("Older attempts");
    await h.click("View saved attempt");
    assert.ok(h.find("Export saved attempt CSV"));
    await h.click("Export saved attempt CSV");
    await h.click("Export this page CSV");
    assert.equal(h.downloads, 2);
    assert.equal(h.errors.length, 0);
  });
}

test("users without export permission retain history access but no export events or controls", async () => {
  const h = harness(false, false);
  await h.settle();
  await h.click("View saved attempt");
  assert.equal(h.find("Export saved attempt CSV"), undefined);
  assert.equal(h.find("Export this page CSV"), undefined);
  assert.equal(h.downloads, 0);
  assert.equal(h.events.length, 1);
});
