// Run against a frontend workflow; the backend need not be running:
// BASE_URL=https://<preview-host> PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH=$(which chromium) \
//   pnpm --filter @workspace/vgrups-connect test:report-filters
import { readFile } from "node:fs/promises";
import { test, expect, SENDERS, ITEM_ID, ITEM_NAME, CSV, CARD_CAMPAIGN, CARD_CSV, REPORT_ERROR, rowName } from "./fixtures/report-api.mjs";

const sender = page => page.getByLabel("Filter report sender number");
const delivery = page => page.getByLabel("Filter report delivery");
const search = page => page.getByLabel("Search report recipients");
const perPage = page => page.getByLabel("Recipients per page");
const rows = page => page.getByTestId("report-dialog").locator("tbody");
const exportButton = page => page.getByTestId("report-export");

async function expectRow(page, params) {
  await expect(rows(page)).toContainText(rowName(params));
}

async function expectFilters(page, selected) {
  await expect(sender(page)).toHaveValue(selected.sender);
  await expect(delivery(page)).toHaveValue(selected.delivery);
  await expect(search(page)).toHaveValue(selected.search);
}

async function expectNoExportControls(page) {
  await expect(exportButton(page)).toHaveCount(0);
  await expect(page.getByTestId(`campaign-export-${ITEM_ID}`)).toHaveCount(0);
  await expect(page.getByRole("button", { name: /Export.*CSV/i })).toHaveCount(0);
}

async function filterViewOnlyReport(page, reportApi, type) {
  await expectRow(page, {});
  await expectNoExportControls(page);
  await sender(page).selectOption("Unknown");
  await expectRow(page, { sender: "Unknown" });
  await delivery(page).selectOption("read");
  await expectRow(page, { sender: "Unknown", delivery: "read" });
  await search(page).fill("  View only & +fixture  ");
  await page.clock.runFor(350);
  const selected = { sender: "Unknown", delivery: "read", search: "View only & +fixture" };
  await expectRow(page, selected);
  await expectFilters(page, { ...selected, search: "  View only & +fixture  " });
  await perPage(page).selectOption("25");
  await expect(page.getByTestId("report-pagination")).toContainText("Page 1 of 5");
  await page.getByRole("button", { name: "Next", exact: true }).click();
  await expectRow(page, { ...selected, page: 2 });
  expect(reportApi.reports(type).at(-1).params).toEqual({
    ...selected, page: "2", page_size: "25",
  });
  await expectNoExportControls(page);
  await page.getByTestId("report-dialog").getByRole("button", { name: "Close", exact: true }).click();
  await expect(page.getByTestId("report-dialog")).toHaveCount(0);
  // Check the card outside the modal as well, not just the report toolbar.
  await expectNoExportControls(page);
  await reportApi.openReport(type);
  await expectRow(page, {});
  await expectNoExportControls(page);
  expect(reportApi.requests.filter(r => r.path.endsWith(".csv"))).toEqual([]);
}

test.describe("campaign card CSV caller", () => {
  for (const failFirst of [false, true]) {
    test(failFirst
      ? "failed card CSV creates no download and retries the selected campaign without dialog filters"
      : "card CSV exports the selected campaign without another report's filters or pagination",
    async ({ page, reportApi }) => {
      reportApi.includeCardCampaign();
      const downloads = [];
      page.on("download", download => downloads.push(download));
      await reportApi.open("campaigns");
      // Leave a different campaign's dialog with every query setting populated.
      await sender(page).selectOption(SENDERS[1]);
      await delivery(page).selectOption("read");
      await search(page).fill("  Card export & +fixture  ");
      const selected = { sender: SENDERS[1], delivery: "read", search: "Card export & +fixture" };
      await expectRow(page, selected);
      await perPage(page).selectOption("25");
      await expect(page.getByTestId("report-pagination")).toContainText("Page 1 of 5");
      await page.getByRole("button", { name: "Next", exact: true }).click();
      await expectRow(page, { ...selected, page: 2 });
      expect(reportApi.reports("campaigns").at(-1).params).toEqual({
        ...selected, page: "2", page_size: "25",
      });
      await page.getByTestId("report-dialog").getByRole("button", { name: "Close", exact: true }).click();
      await expect(page.getByTestId("report-dialog")).toHaveCount(0);
      await expect(exportButton(page)).toHaveCount(0);
      const cardExport = page.getByTestId(`campaign-export-${CARD_CAMPAIGN.id}`);
      await expect(cardExport).toBeVisible();
      await expect(cardExport).toBeEnabled();
      const expectedRequest = {
        path: `/api/campaigns/${CARD_CAMPAIGN.id}/report.csv`, method: "GET", params: {},
      };

      if (failFirst) {
        reportApi.failExports("http");
        await cardExport.click();
        await expect(page.locator("[data-sonner-toast][data-type='error']")).toContainText("Request failed with status code 503");
        await expect(cardExport).toBeEnabled();
        expect(reportApi.requests.filter(r => r.path.endsWith(".csv"))).toEqual([expectedRequest]);
        expect(downloads).toHaveLength(0);
        // Retry through the same card, without reopening a report or reloading.
      }

      const downloadPromise = page.waitForEvent("download");
      await cardExport.click();
      const download = await downloadPromise;
      expect(await download.failure()).toBeNull();
      expect(download.suggestedFilename()).toBe(`${CARD_CAMPAIGN.name.replace(/\s/g, "_")}_report.csv`);
      expect(await readFile(await download.path(), "utf8")).toBe(CARD_CSV);
      await expect(cardExport).toBeEnabled();
      await expect(page.getByTestId("report-dialog")).toHaveCount(0);
      expect(downloads).toHaveLength(1);
      // Exact equality excludes sender/search/delivery AND page/page_size.
      expect(reportApi.requests.filter(r => r.path.endsWith(".csv"))).toEqual(
        Array.from({ length: failFirst ? 2 : 1 }, () => expectedRequest),
      );
      expect(reportApi.exports("campaigns")).toHaveLength(0);
      expect(reportApi.exports("campaigns", CARD_CAMPAIGN.id)).toHaveLength(failFirst ? 2 : 1);
    });
  }
});

for (const type of ["campaigns", "drips"]) {
  test.describe(`${type} report caller`, () => {
    test("Next before the initial debounce keeps page 2 selected", async ({ page, reportApi }) => {
      const now = new Date("2026-10-01T09:00:00Z");
      await page.clock.install({ time: now });
      // Freeze before mounting so opening/clicking cannot consume the 300ms.
      await page.clock.pauseAt(now);
      await reportApi.open(type);
      await page.getByRole("button", { name: "Next", exact: true }).click();
      await expectRow(page, { page: 2 });
      await expect(page.getByTestId("report-pagination")).toContainText("Page 2 of 3");
      const before = reportApi.reports(type).length;

      await page.clock.runFor(350);
      await expectRow(page, { page: 2 });
      await expect(page.getByTestId("report-pagination")).toContainText("Page 2 of 3");
      expect(reportApi.reports(type)).toHaveLength(before);
      expect(reportApi.reports(type).at(-1).params.page).toBe("2");

      // Real edits still debounce and reset pagination, including clearing.
      for (const input of ["  Debounce & +fixture  ", ""]) {
        const start = reportApi.reports(type).length;
        await search(page).fill(input);
        await page.clock.runFor(299);
        await expect(page.getByTestId("report-pagination")).toContainText("Page 2 of 3");
        expect(reportApi.reports(type)).toHaveLength(start);
        await page.clock.runFor(1);
        await expectRow(page, { search: input.trim() });
        await expect(page.getByTestId("report-pagination")).toContainText("Page 1 of 3");
        expect(reportApi.reports(type).slice(start).map(r => r.params)).toEqual([
          { page: "1", page_size: "50", sender: "", delivery: "", search: input.trim() },
        ]);
        await page.getByRole("button", { name: "Next", exact: true }).click();
        await expectRow(page, { search: input.trim(), page: 2 });
      }
    });

    test("view-only users can read and filter reports without CSV controls or requests", async ({ page, reportApi }) => {
      await page.clock.install();
      reportApi.setCampaignPermissions(["view"]);
      const downloads = [];
      page.on("download", download => downloads.push(download));
      await reportApi.open(type);
      await filterViewOnlyReport(page, reportApi, type);
      expect(downloads).toEqual([]);
    });

    test("losing export permission after reload removes CSV controls but keeps reports usable", async ({ page, reportApi }) => {
      await page.clock.install();
      const downloads = [];
      page.on("download", download => downloads.push(download));
      await reportApi.open(type);
      await expect(exportButton(page)).toBeVisible();
      await expect(exportButton(page)).toBeEnabled();
      await page.getByTestId("report-dialog").getByRole("button", { name: "Close", exact: true }).click();
      if (type === "campaigns") {
        await expect(page.getByTestId(`campaign-export-${ITEM_ID}`)).toBeVisible();
      }
      const authReads = reportApi.requests.filter(r => r.path === "/api/auth/me").length;
      reportApi.setCampaignPermissions(["view"]);
      await page.reload();
      await reportApi.openReport(type);
      // Development StrictMode can fetch auth more than once per mount.
      expect(reportApi.requests.filter(r => r.path === "/api/auth/me").length).toBeGreaterThan(authReads);
      await filterViewOnlyReport(page, reportApi, type);
      expect(downloads).toEqual([]);
    });

    test("failed report GETs recover with Retry using the current filters", async ({ page, reportApi }) => {
      await page.clock.install();
      reportApi.failReports("http");
      await reportApi.open(type, { waitForReport: false });
      const dialog = page.getByTestId("report-dialog");
      const retry = dialog.getByRole("button", { name: "Retry", exact: true });
      await expect(dialog).toContainText(REPORT_ERROR);
      await expect(rows(page)).toHaveCount(0);
      await retry.click();
      await expectRow(page, {});
      await expect(retry).toHaveCount(0);

      // Keep the connection down while the user changes every filter. Retry
      // must not reuse the query from the first failure or the initial report.
      reportApi.failReports("network", "http", "http");
      await sender(page).selectOption(SENDERS[1]);
      await expect(dialog).toContainText("Network Error");
      await delivery(page).selectOption("failed");
      await expect(dialog).toContainText(REPORT_ERROR);
      await search(page).fill("Retry & +fixture");
      await page.clock.runFor(350);
      const selected = { sender: SENDERS[1], delivery: "failed", search: "Retry & +fixture" };
      await expect.poll(() => reportApi.reports(type).at(-1).params.search).toBe(selected.search);
      await expect(dialog).toContainText(REPORT_ERROR);
      await expectFilters(page, selected);
      await expect(rows(page)).toHaveCount(0);
      const before = reportApi.reports(type).length;
      await retry.click();
      await expectRow(page, selected);
      await expect(retry).toHaveCount(0);
      await expect(dialog).not.toContainText(REPORT_ERROR);
      await expectFilters(page, selected);
      expect(reportApi.reports(type).slice(before).map(r => r.params)).toEqual([
        { ...selected, page: "1", page_size: "50" },
      ]);
    });

    test("polling survives consecutive outages and recovers without losing filters or pagination", async ({ page, reportApi }) => {
      await page.clock.install();
      await reportApi.open(type);
      await sender(page).selectOption("Unknown");
      await expectRow(page, { sender: "Unknown" });
      await delivery(page).selectOption("read");
      await expectRow(page, { sender: "Unknown", delivery: "read" });
      await search(page).fill("poll recovery");
      await page.clock.runFor(350);
      const selected = { sender: "Unknown", delivery: "read", search: "poll recovery" };
      await expectRow(page, selected);
      await perPage(page).selectOption("25");
      await expect(page.getByTestId("report-pagination")).toContainText("Page 1 of 5");
      await page.getByRole("button", { name: "Next", exact: true }).click();
      await expectRow(page, { ...selected, page: 2 });
      const before = reportApi.reports(type).length;
      reportApi.failReports("network", "http");
      for (const [index, message] of ["Network Error", REPORT_ERROR].entries()) {
        await page.clock.runFor(15100);
        await expect.poll(() => reportApi.reports(type).length).toBe(before + index + 1);
        await expect(page.getByTestId("report-dialog")).toContainText(message);
        await expect(page.getByRole("button", { name: "Retry", exact: true })).toBeVisible();
        await expectRow(page, { ...selected, page: 2 });
        await expectFilters(page, selected);
        await expect(perPage(page)).toHaveValue("25");
      }
      // Do not press Retry: the scheduled poll must clear the error itself.
      await page.clock.runFor(15100);
      await expect.poll(() => reportApi.reports(type).length).toBe(before + 3);
      await expect(page.getByRole("button", { name: "Retry", exact: true })).toHaveCount(0);
      await expect(page.getByTestId("report-dialog")).not.toContainText(REPORT_ERROR);
      await expectRow(page, { ...selected, page: 2 });
      await expectFilters(page, selected);
      await expect(page.getByTestId("report-pagination")).toContainText("Page 2 of 5");
      expect(reportApi.reports(type).slice(before).map(r => r.params)).toEqual(
        Array.from({ length: 3 }, () => ({ ...selected, page: "2", page_size: "25" })),
      );
    });

    test("failed CSV export creates no download and can succeed without reopening", async ({ page, reportApi }) => {
      await reportApi.open(type);
      await sender(page).selectOption(SENDERS[1]);
      await expectRow(page, { sender: SENDERS[1] });
      await delivery(page).selectOption("read");
      await expectRow(page, { sender: SENDERS[1], delivery: "read" });
      await search(page).fill("  Export & +fixture  ");
      const selected = { sender: SENDERS[1], delivery: "read", search: "Export & +fixture" };
      await expectRow(page, selected);
      await page.getByRole("button", { name: "Next", exact: true }).click();
      await expectRow(page, { ...selected, page: 2 });
      const downloads = [];
      page.on("download", download => downloads.push(download));
      // A real 503 response exercises the blob-response error handling.
      reportApi.failExports("http");
      await exportButton(page).click();
      await expect(page.locator("[data-sonner-toast][data-type='error']")).toContainText("Request failed with status code 503");
      await expect(exportButton(page)).toBeEnabled();
      expect(reportApi.exports(type)).toHaveLength(1);
      expect(downloads).toHaveLength(0);
      await expectFilters(page, { ...selected, search: "  Export & +fixture  " });
      await expectRow(page, { ...selected, page: 2 });

      const downloadPromise = page.waitForEvent("download");
      await exportButton(page).click();
      const download = await downloadPromise;
      expect(await download.failure()).toBeNull();
      expect(download.suggestedFilename()).toBe(`${ITEM_NAME.replace(/\s/g, "_")}_report.csv`);
      expect(await readFile(await download.path(), "utf8")).toBe(CSV);
      await expect(exportButton(page)).toBeEnabled();
      expect(downloads).toHaveLength(1);
      expect(reportApi.exports(type).map(r => r.params)).toEqual([selected, selected]);
      await expectRow(page, { ...selected, page: 2 });
      await expectFilters(page, { ...selected, search: "  Export & +fixture  " });
    });

    test("sender changes reset pagination, including Unknown attribution", async ({ page, reportApi }) => {
      await page.clock.install();
      await reportApi.open(type);
      await page.getByRole("button", { name: "Next", exact: true }).click();
      await expectRow(page, { page: 2 });
      const start = reportApi.reports(type).length;
      await sender(page).selectOption(SENDERS[1]);
      await expectRow(page, { sender: SENDERS[1] });
      await expect(page.getByTestId("report-pagination")).toContainText("Page 1 of 3");
      expect(reportApi.reports(type).slice(start).map(r => r.params.page)).toEqual(["1"]);
      await page.getByRole("button", { name: "Next", exact: true }).click();
      await expectRow(page, { sender: SENDERS[1], page: 2 });
      await sender(page).selectOption("Unknown");
      await expectRow(page, { sender: "Unknown" });
      await expect(page.getByTestId("report-pagination")).toContainText("Page 1 of 3");
      expect(reportApi.reports(type).at(-1).params.sender).toBe("Unknown");
    });

    test("rapid sender, delivery and search changes reject older responses", async ({ page, reportApi }) => {
      await reportApi.open(type);
      // Hold each superseded response until AFTER the latest result is visible.
      // This deterministically tests out-of-order completion, not network speed.
      reportApi.hold(p => p.sender === SENDERS[0] || p.delivery === "failed" || p.search === "older");
      await sender(page).selectOption(SENDERS[0]);
      await expect.poll(() => reportApi.held.length).toBe(1);
      await sender(page).selectOption(SENDERS[1]);
      await expectRow(page, { sender: SENDERS[1] });
      await delivery(page).selectOption("failed");
      await expect.poll(() => reportApi.held.length).toBe(2);
      await delivery(page).selectOption("read");
      await expectRow(page, { sender: SENDERS[1], delivery: "read" });
      await search(page).fill("older");
      await expect.poll(() => reportApi.held.length).toBe(3);
      await search(page).fill("newest");
      const latest = { sender: SENDERS[1], delivery: "read", search: "newest" };
      await expectRow(page, latest);
      // Catch even transient stale renders, rather than only checking the last row.
      await page.evaluate(() => {
        window.reportRenders = [];
        new MutationObserver(() => {
          const tbody = document.querySelector('[data-testid="report-dialog"] tbody');
          if (tbody) window.reportRenders.push(tbody.textContent);
        }).observe(document.querySelector('[data-testid="report-dialog"]'), { childList: true, subtree: true, characterData: true });
      });
      for (const old of [...reportApi.held].reverse()) {
        await old.release();
        // Allow a late fulfilled response to reach React before asserting.
        await page.waitForTimeout(100);
        await expectRow(page, latest);
      }
      expect(await page.evaluate(() => window.reportRenders.every(text => text.includes("newest")))).toBe(true);
      await expect(sender(page)).toHaveValue(SENDERS[1]);
      await expect(delivery(page)).toHaveValue("read");
      await expect(search(page)).toHaveValue("newest");
    });

    test("polling preserves sender and filters even when sender options disappear", async ({ page, reportApi }) => {
      await page.clock.install();
      await reportApi.open(type);
      await sender(page).selectOption(SENDERS[1]);
      await delivery(page).selectOption("read");
      await search(page).fill("poll fixture");
      const selected = { sender: SENDERS[1], delivery: "read", search: "poll fixture" };
      await expectRow(page, selected);
      await page.getByRole("button", { name: "Next", exact: true }).click();
      await expectRow(page, { ...selected, page: 2 });
      reportApi.omitSenders();
      const before = reportApi.reports(type).length;
      await page.clock.runFor(15100);
      await expect.poll(() => reportApi.reports(type).length).toBeGreaterThan(before);
      expect(reportApi.reports(type).at(-1).params).toEqual({
        ...selected, page: "2", page_size: "50",
      });
      await expectRow(page, { ...selected, page: 2 });
      await expect(sender(page)).toHaveValue(SENDERS[1]);
      await expect(sender(page).locator("option", { hasText: SENDERS[1] })).toHaveCount(1);
    });

    test("closing and reopening resets all filters and pagination", async ({ page, reportApi }) => {
      await reportApi.open(type);
      await sender(page).selectOption("Unknown");
      await delivery(page).selectOption("failed");
      await search(page).fill("reopen fixture");
      await perPage(page).selectOption("25");
      await expectRow(page, { sender: "Unknown", delivery: "failed", search: "reopen fixture" });
      await page.getByRole("button", { name: "Next", exact: true }).click();
      await expectRow(page, { sender: "Unknown", delivery: "failed", search: "reopen fixture", page: 2 });
      await page.getByTestId("report-dialog").getByRole("button", { name: "Close", exact: true }).click();
      await expect(page.getByTestId("report-dialog")).toHaveCount(0);
      const before = reportApi.reports(type).length;
      await page.getByTestId(`${type === "drips" ? "drip" : "campaign"}-report-${ITEM_ID}`).click();
      await expectRow(page, {});
      await expect(sender(page)).toHaveValue("");
      await expect(delivery(page)).toHaveValue("");
      await expect(search(page)).toHaveValue("");
      await expect(perPage(page)).toHaveValue("50");
      expect(reportApi.reports(type).slice(before).at(-1).params).toEqual({
        page: "1", page_size: "50", sender: "", delivery: "", search: "",
      });
    });

    test("actual CSV downloads match sender, trimmed search and delivery, not pagination", async ({ page, reportApi }) => {
      await reportApi.open(type);
      // Cover URL encoding and Unknown as well as an ordinary +phone sender.
      for (const selectedSender of [SENDERS[1], "Unknown"]) {
        await sender(page).selectOption(selectedSender);
        await delivery(page).selectOption("read");
        await search(page).fill("  Fixture & +name  ");
        await expect(exportButton(page)).toBeDisabled();
        const selected = { sender: selectedSender, delivery: "read", search: "Fixture & +name" };
        await expectRow(page, selected);
        await page.getByRole("button", { name: "Next", exact: true }).click();
        await expectRow(page, { ...selected, page: 2 });
        const downloadPromise = page.waitForEvent("download");
        await exportButton(page).click();
        const download = await downloadPromise;
        expect(download.suggestedFilename()).toBe(`${ITEM_NAME.replace(/\s/g, "_")}_report.csv`);
        expect(await download.failure()).toBeNull();
        expect(await readFile(await download.path(), "utf8")).toBe(CSV);
        const exported = reportApi.exports(type).at(-1);
        expect(exported.params).toEqual(selected);
        const displayed = reportApi.reports(type).at(-1).params;
        expect({ sender: displayed.sender, search: displayed.search, delivery: displayed.delivery }).toEqual(exported.params);
        expect(displayed.page).toBe("2");
        // Trigger a fresh debounced search on the next iteration.
        await search(page).fill("");
        await expectRow(page, { sender: selectedSender, delivery: "read" });
      }
      expect(reportApi.exports(type)).toHaveLength(2);
    });
  });
}
