// BASE_URL=https://<preview-host> pnpm --filter @workspace/vgrups-connect test:mr-report-send
// A Playwright Chromium installation is required; this never calls the real API.
// Every /api/** request is fulfilled here; no API is allowed through to a backend.
import { test, expect } from "@playwright/test";
import { mkdir } from "node:fs/promises";

// Nix environments can use their system Chromium instead of the downloaded binary.
test.use({ launchOptions: process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH
  ? { executablePath: process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH } : {} });

const today = new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Kolkata" }).format(new Date());

test("daily report Send now is confirmed once, auditable, and never retries uncertain attempts", async ({ browser }) => {
  test.setTimeout(60000);
  const context = await browser.newContext({ viewport: { width: 1280, height: 900 }, timezoneId: "UTC", serviceWorkers: "block" });
  await context.addInitScript(() => localStorage.setItem("vg_token", "synthetic-admin-token"));
  const page = await context.newPage();
  const permissions = {
    field_sales: ["view", "manage"], settings: ["view", "manage"],
    reports: ["view", "manage", "send"], whatsapp: ["view", "send"],
  };
  const original = {
    id: "n-original", channel: "whatsapp", name: "Field Admin", user_id: "admin-1",
    report_id: "r-daily", submission_id: "closing-snapshot",
    status: "unavailable", provider_io: false, can_send_now: true,
    recipient_address: "+15550000000", created_at: new Date().toISOString(),
  };
  const report = {
    id: "r-daily", date: today, mr_name: "Synthetic MR", employee_id: "TEST-01",
    plan_submitted_at: new Date().toISOString(), closing_submitted_at: new Date().toISOString(),
    plan: { planned_visits: 4, special_plan: "Fixture plan", visits: [], quotations: [], followups: [] },
    closing: { completed_visits: 3, remarks: "Fixture closing", order_details: [], app_quotation_details: [] },
    summary: { planned_visits: 4, completed_visits: 3, pending_visits: 1, orders: 0, sales: 0, achievement_pct: 0 },
    notifications: [
      original,
      { id: "n-blocked", channel: "email", name: "No Channel", status: "unavailable", provider_io: false, can_send_now: true, recipient_address: "old@example.test" },
      { id: "n-permission", channel: "whatsapp", name: "Denied User", status: "unavailable", provider_io: false, can_send_now: true, recipient_address: "+15550000002" },
      { id: "n-sent", channel: "whatsapp", name: "Already Sent", status: "sent", can_send_now: false },
      { id: "n-sending", channel: "whatsapp", name: "Sending", status: "sending", can_send_now: false },
      { id: "n-uncertain", channel: "whatsapp", name: "Uncertain", status: "uncertain", can_send_now: false },
      { id: "n-part-uncertain", channel: "whatsapp", name: "Multipart", status: "uncertain", part: 1, can_send_now: false },
      { id: "n-part-accepted", channel: "whatsapp", name: "Multipart", status: "sent", part: 2, can_send_now: false },
      { id: "receipt-partial", channel: "whatsapp", name: "Partial Report", status: "uncertain", can_send_now: false,
        delivery: { status: "partial", required_parts: 2, delivered_parts: 1, read_parts: 1 } },
      { id: "receipt-read", channel: "whatsapp", name: "Read Report", status: "sent", can_send_now: false,
        sender_number: "+15550000001",
        delivery: { status: "read", required_parts: 2, delivered_parts: 2, read_parts: 2,
          delivered_at: "2026-10-05T08:00:03.000Z", read_at: "2026-10-05T08:00:08.000Z" } },
      { id: "receipt-manual", channel: "whatsapp", name: "Manual Report", original_notification_id: "receipt-partial",
        sender_number: "+15550000002",
        status: "uncertain", can_send_now: false,
        delivery: { status: "delivered", required_parts: 2, delivered_parts: 2, read_parts: 1 } },
      { id: "receipt-failed", channel: "whatsapp", name: "Failed Receipt", status: "sent", can_send_now: false,
        sender_number: "+15550000003",
        delivery: { status: "failed", required_parts: 1, delivered_parts: 0, read_parts: 0 } },
      { id: "receipt-legacy", channel: "whatsapp", name: "Unknown Legacy", status: "sent", can_send_now: false,
        delivery: { status: "unknown", required_parts: null, delivered_parts: 0, read_parts: 0 } },
    ],
  };
  let postCount = 0;
  const sendBodies = [];
  const externalRequests = [];
  const attempts = [];
  const apiRequests = [];
  const unexpectedWrites = [];

  await page.route("**/*", async (route) => {
    const url = new URL(route.request().url());
    if (url.pathname.startsWith("/api/")) {
      const method = route.request().method();
      apiRequests.push({ path: url.pathname, method });
      let fixture = { items: [] };
      if (url.pathname === "/api/auth/me") fixture = { id: "synthetic-admin", name: "Synthetic Admin", role: "admin", permissions };
      else if (url.pathname === "/api/field/visits") fixture = { items: [], stats: { planned_today: 0, visited_today: 0, total_visits: 0, order_value: 0 } };
      else if (url.pathname === "/api/field/stats") fixture = { planned_today: 0, visited_today: 0, total_visits: 0, order_value: 0 };
      else if (url.pathname === "/api/field/targets") fixture = { targets: [], is_manager: true };
      else if (url.pathname === "/api/field/mrs") fixture = { items: [] };
      else if (url.pathname === "/api/field/daily-reports") fixture = { items: [JSON.parse(JSON.stringify(report))], is_manager: true };
      if (method === "POST" && /\/field\/report-notifications\/[^/]+\/send-now$/.test(url.pathname)) {
        postCount += 1;
        sendBodies.push(route.request().postDataJSON());
        const id = url.pathname.split("/").at(-2);
        if (id === "n-blocked") return route.fulfill({ status: 409, contentType: "application/json", body: JSON.stringify({ detail: "Channel unavailable" }) });
        if (id === "n-permission") return route.fulfill({ status: 403, contentType: "application/json", body: JSON.stringify({ detail: "Permission denied" }) });
        await new Promise((resolve) => setTimeout(resolve, 800));
        const attempt = {
          id: "n-manual", original_notification_id: id, channel: "whatsapp", name: "Field Admin",
          report_id: original.report_id, submission_id: original.submission_id, user_id: original.user_id,
          status: "sent", recipient_address: "+15550001111", requested_by: "Synthetic Admin",
          created_at: new Date().toISOString(),
        };
        attempts.push(attempt);
        report.notifications = [attempt, ...report.notifications.map((item) => item.id === id ? { ...item, can_send_now: false } : item)];
        return route.fulfill({ status: 200, contentType: "application/json", body: JSON.stringify({ attempt }) });
      }
      if (["POST", "PUT", "PATCH", "DELETE"].includes(method)) {
        unexpectedWrites.push({ path: url.pathname, method });
        return route.abort();
      }
      return route.fulfill({ status: 200, contentType: "application/json", body: JSON.stringify(fixture) });
    }
    if (url.hostname !== new URL(process.env.BASE_URL || `https://${process.env.REPLIT_DEV_DOMAIN}`).hostname) {
      externalRequests.push(url.href);
      return route.abort();
    }
    return route.continue();
  });

  try {
    const baseURL = process.env.BASE_URL || `https://${process.env.REPLIT_DEV_DOMAIN}`;
    await page.goto(`${baseURL}/field-sales`);
    await page.getByTestId("field-tab-reports").click();
    await page.getByTestId("dr-row-r-daily").waitFor();
    await page.getByTestId("dr-row-r-daily").click();
    await expect(page.getByTestId("dr-send-n-original")).toBeVisible();
    await expect(page.getByTestId("dr-status-receipt-read")).toHaveText("Send: Accepted");
    await expect(page.getByTestId("dr-receipt-times-receipt-read")).toContainText("All parts delivered at:");
    await expect(page.getByTestId("dr-receipt-times-receipt-read")).toContainText("08:00:03");
    await expect(page.getByTestId("dr-receipt-times-receipt-read")).toContainText("08:00:08");
    await expect(page.getByTestId("dr-receipt-times-receipt-read").locator("time").first())
      .toHaveAttribute("datetime", "2026-10-05T08:00:03.000Z");
    await expect(page.getByTestId("dr-receipt-times-receipt-manual")).toContainText("Time unavailable");
    await expect(page.getByTestId("dr-receipt-times-receipt-partial").locator("time")).toHaveCount(0);
    await expect(page.getByTestId("dr-delivery-receipt-read")).toContainText("Receipt: Read");
    await expect(page.getByTestId("dr-delivery-receipt-partial")).toContainText("1 delivered, 1 read / 2 required parts");
    await expect(page.getByTestId("dr-delivery-receipt-manual")).toContainText("Receipt: Delivered");
    await expect(page.getByTestId("dr-delivery-receipt-manual")).toContainText("Send remains uncertain; resend blocked");
    await expect(page.getByTestId("dr-delivery-receipt-failed")).toContainText("Receipt: Failed");
    await expect(page.getByTestId("dr-delivery-receipt-legacy")).toContainText("unknown required parts");
    await expect(page.getByTestId("dr-sender-receipt-read")).toHaveText("Sender number: +15550000001");
    await expect(page.getByTestId("dr-sender-receipt-manual")).toHaveText("Sender number: +15550000002");
    await expect(page.getByTestId("dr-sender-receipt-failed")).toHaveText("Sender number: +15550000003");
    await expect(page.getByTestId("dr-sender-receipt-legacy")).toHaveText("Sender number: Unknown");
    await expect(page.getByTestId("dr-sender-n-blocked")).toHaveCount(0);
    await expect(page.getByTestId("dr-delivery-n-sent")).toContainText("Not confirmed");
    await expect(page.getByTestId("dr-delivery-n-blocked")).toHaveCount(0);
    for (const id of ["receipt-partial", "receipt-read", "receipt-manual", "receipt-failed", "receipt-legacy"]) {
      await expect(page.getByTestId(`dr-send-${id}`)).toHaveCount(0);
    }
    for (const id of ["n-sent", "n-sending", "n-uncertain", "n-part-uncertain", "n-part-accepted"]) {
      await expect(page.getByTestId(`dr-send-${id}`)).toHaveCount(0);
    }

    await page.getByTestId("dr-send-n-original").click();
    await expect(page.getByRole("heading", { name: "Send this saved report now?" })).toBeVisible();
    await page.getByRole("button", { name: "Cancel" }).click();
    expect(postCount).toBe(0);
    await page.getByTestId("dr-send-n-original").click();
    const confirm = page.getByTestId("dr-confirm-send");
    await confirm.click();
    await confirm.click({ force: true, timeout: 500 }).catch(() => {});
    await expect(page.getByText("+15550001111")).toBeVisible();
    expect(postCount).toBe(1);
    expect(sendBodies).toEqual([{ confirm: true }]);
    await expect(page.getByTestId("dr-send-n-original")).toHaveCount(0);

    for (const [id, message] of [["n-blocked", "Channel unavailable"], ["n-permission", "Permission denied"]]) {
      const before = attempts.length;
      await page.getByTestId(`dr-send-${id}`).click();
      await page.getByTestId("dr-confirm-send").click();
      await expect(page.getByRole("alert")).toHaveText(message);
      await expect(page.getByTestId("dr-confirm-send")).toBeDisabled();
      expect(postCount).toBe(id === "n-blocked" ? 2 : 3);
      expect(attempts.length).toBe(before);
      await page.getByRole("button", { name: "Cancel" }).click();
    }

    await page.getByRole("button", { name: "Close" }).click();
    report.notifications.find((item) => item.id === "receipt-partial").delivery =
      { status: "read", required_parts: 2, delivered_parts: 2, read_parts: 2 };
    await page.getByTestId("dr-refresh").click();
    await page.getByTestId("dr-row-r-daily").click();
    await expect(page.getByTestId("dr-delivery-receipt-partial")).toContainText("Receipt: Read");
    await expect(page.getByTestId("dr-status-receipt-partial")).toHaveText("Send: uncertain");
    await expect(page.getByTestId("dr-send-receipt-partial")).toHaveCount(0);
    await expect(page.getByText("+15550001111")).toBeVisible();
    await expect(page.getByTestId("dr-send-n-original")).toHaveCount(0);

    // Simulate the role losing reports.send while the server marks all history ineligible.
    permissions.reports = ["view"];
    report.notifications.forEach((item) => { item.can_send_now = false; });
    await page.getByRole("button", { name: "Close" }).click();
    await page.reload();
    await page.getByTestId("field-tab-reports").click();
    await page.getByTestId("dr-row-r-daily").click();
    await expect(page.locator('[data-testid^="dr-send-"]')).toHaveCount(0);
    await expect(page.getByText("+15550001111")).toBeVisible();
    await expect(page.getByText("Part 1")).toBeVisible();
    await expect(page.getByText("Part 2")).toBeVisible();
    await expect(page.getByTestId("dr-delivery-receipt-partial")).toContainText("Receipt: Read");

    await page.setViewportSize({ width: 390, height: 844 });
    await page.getByRole("button", { name: "Close" }).click();
    // Use a separate missed report notification, not the already-reserved original.
    report.notifications.push({ ...original, id: "n-mobile", can_send_now: true });
    await page.getByTestId("dr-refresh").click();
    await page.getByTestId("dr-row-r-daily").click();
    await page.getByTestId("dr-send-n-mobile").click();
    await expect(page.getByTestId("dr-confirm-send")).toBeVisible();
    await expect(page.getByRole("button", { name: "Cancel" })).toBeVisible();
    await mkdir("test-results", { recursive: true });
    await page.screenshot({ path: "test-results/daily-reports-send-now-mobile.png" });
    await page.getByRole("button", { name: "Cancel" }).click();

    expect(apiRequests.length).toBeGreaterThan(0);
    expect(unexpectedWrites).toEqual([]);
    expect(postCount).toBe(3);
  } finally {
    await context.close();
  }
});
