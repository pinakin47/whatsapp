// Isolated server rendering: no browser, auth, database, providers or listening port.
// node --test artifacts/vgrups-connect/tests/catalogue-receipt-evidence.test.mjs
import { test, before, after } from "node:test";
import assert from "node:assert/strict";
import { fileURLToPath } from "node:url";
import { createServer } from "vite";
import { createElement } from "react";
import { renderToStaticMarkup } from "react-dom/server";

let server;
let Evidence;
before(async () => {
  server = await createServer({
    configFile: false,
    root: fileURLToPath(new URL("../", import.meta.url)),
    server: { middlewareMode: true, hmr: false },
    esbuild: { jsx: "automatic" },
  });
  Evidence = (await server.ssrLoadModule("/src/components/CatalogueReceiptEvidence.jsx")).default;
});
after(async () => { await server?.close(); });
const render = props => renderToStaticMarkup(createElement(Evidence, props));

test("unknown historical evidence and times are not guessed", () => {
  const html = render({});
  assert.match(html, /Receipt status: Unknown/);
  assert.match(html, /0\/Unknown attachments delivery-confirmed/);
  assert.match(html, /Delivered at: Unknown/);
  assert.match(html, /Read at: Unknown/);
});

test("partial evidence shows confirmed counts without claiming whole delivery", () => {
  const html = render({ delivery: {
    status: "partial", required_parts: 2, delivered_parts: 1, read_parts: 1, failed_parts: 0,
    delivered_at: null, read_at: null,
  } });
  assert.match(html, /Receipt status: partial/);
  assert.match(html, /1\/2 attachments delivery-confirmed/);
  assert.match(html, /1 read-confirmed/);
  assert.match(html, /Delivered at: Unknown/);
});

test("read without an explicit delivery time keeps that time unknown", () => {
  const html = render({ attachment: true, delivery: {
    status: "read", delivered_at: null, read_at: "2026-10-07T10:00:00.000Z",
  } });
  assert.match(html, /attachment-receipt/);
  assert.match(html, /Receipt status: read/);
  assert.match(html, /Delivered at: Unknown/);
  assert.match(html, /Read at: 2026-10-07T10:00:00.000Z/);
  assert.doesNotMatch(html, /attachments delivery-confirmed/);
});

test("complete attempts display both explicit provider stage times", () => {
  const html = render({ delivery: {
    status: "read", required_parts: 2, delivered_parts: 2, read_parts: 2, failed_parts: 0,
    delivered_at: "2026-10-07T10:00:00.000Z", read_at: "2026-10-07T10:05:00.000Z",
  } });
  assert.match(html, /2\/2 attachments delivery-confirmed/);
  assert.match(html, /2 read-confirmed/);
  assert.match(html, /Delivered at: 2026-10-07T10:00:00.000Z/);
  assert.match(html, /Read at: 2026-10-07T10:05:00.000Z/);
});
