import React from "react";
import { Card } from "../ui/card";

const arr = (a) => (Array.isArray(a) ? a : []);
const lab = (v) => (v == null || v === "" ? "-" : String(v).replace(/_/g, " "));
const dt = (v) => (v ? new Date(v).toLocaleString() : "-");
const Sec = ({ title, children, testId }) => <Card className="p-4" data-testid={testId}><h3 className="text-xs font-semibold uppercase tracking-wide text-muted-foreground mb-2">{title}</h3>{children}</Card>;
const List = ({ items, render, empty }) => (items.length ? <ul className="space-y-1 text-sm">{items.map((x, i) => <li key={i} className="rounded bg-muted/50 px-2 py-1 break-words">{render(x)}</li>)}</ul> : <p className="text-sm text-muted-foreground">{empty}</p>);

export default function MRFieldActivity({ d }) {
  const f = d.field_day;
  const loc = f?.location;
  return (
    <>
      <Sec title="Field day (MR replies on WhatsApp)" testId="mr-ivr-field-day">
        {!f ? <p className="text-sm text-muted-foreground">No field day started for {d.date}.</p> : (
          <div className="space-y-1 text-sm">
            <div>Day status: <b>{lab(f.status)}</b>{f.started_at ? ` - started ${dt(f.started_at)}` : ""}</div>
            <div>Location: <b>{lab(f.location_status)}</b>{loc && loc.latitude != null ? ` - ${loc.latitude}, ${loc.longitude} (${dt(loc.recorded_at)})` : ""}</div>
            <p className="text-xs text-muted-foreground">A typed Location Shared reply is the MR's own statement, not GPS evidence. Coordinates appear only when a real location pin was received.</p>
            <div>Midday status: <b>{lab(f.midday_status)}</b>{f.midday_updated_at ? ` - ${dt(f.midday_updated_at)}` : ""}</div>
            <div>Closing: <b>{lab(f.closing_status)}</b></div>
            {f.closing_draft && <div className="rounded border border-amber-300 bg-amber-50 px-2 py-1 text-amber-800" data-testid="mr-ivr-closing-draft">Pending closing draft: <span className="break-words">{typeof f.closing_draft === "string" ? f.closing_draft : JSON.stringify(f.closing_draft)}</span></div>}
            {f.closing_summary && <div className="rounded bg-muted/50 px-2 py-1 break-words" data-testid="mr-ivr-closing-summary">Closing summary: {typeof f.closing_summary === "string" ? f.closing_summary : JSON.stringify(f.closing_summary)}</div>}
          </div>)}
      </Sec>
      <Sec title="Field entries (orders and follow-ups)" testId="mr-ivr-field-entries">
        <List items={arr(d.field_entries)} empty="No field entries." render={(e) => <>{dt(e.created_at)} - <b>{lab(e.kind)}</b> - {e.data?.customer || "-"}{e.data?.value != null && e.data?.value !== "" ? ` - value ${e.data.value}` : ""}{e.data?.products ? ` - ${Array.isArray(e.data.products) ? e.data.products.join(", ") : e.data.products}` : ""}{e.data?.details ? ` - ${e.data.details}` : ""}</>} />
      </Sec>
      <Sec title="Leave requests" testId="mr-ivr-leave">
        <List items={arr(d.leave_requests)} empty="No leave requests." render={(l) => <>{l.date} - <b>{lab(l.status)}</b> - {l.reason || "no reason"} (requested {dt(l.requested_at)})</>} />
      </Sec>
      <Sec title="Manager requests" testId="mr-ivr-manager-requests">
        <List items={arr(d.manager_requests)} empty="No manager requests." render={(m) => <><b>{lab(m.reason)}</b> - {lab(m.status)} - assigned to {m.assigned_to || "nobody yet"} (requested {dt(m.requested_at)})</>} />
      </Sec>
    </>
  );
}
