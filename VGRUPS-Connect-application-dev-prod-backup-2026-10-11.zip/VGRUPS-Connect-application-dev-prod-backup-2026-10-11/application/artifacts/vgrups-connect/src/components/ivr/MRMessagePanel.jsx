import React, { useRef, useState } from "react";
import api, { apiError } from "../../lib/api";
import { toast } from "sonner";
import { Card } from "../ui/card";
import { Button } from "../ui/button";
import { Textarea } from "../ui/textarea";
import { Loader2 } from "lucide-react";
import { useSenders, findSender, senderLabel } from "../../lib/useSenders";

export default function MRMessagePanel({ mrId, date, canSend, active, onSent }) {
  const [kind, setKind] = useState("encouragement");
  const [msg, setMsg] = useState("");
  const [ok, setOk] = useState(false);
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState(null);
  const senders = useSenders();
  const mrSender = findSender(senders, senders.mr);
  const req = useRef({ id: null, text: null });

  const preview = async () => {
    setBusy(true);
    try { const r = await api.get(`/mr-ivr/mrs/${mrId}/preview`, { params: { kind, date } }); setMsg(r.data.message || ""); setOk(false); setResult(null); }
    catch (e) { toast.error(apiError(e)); } finally { setBusy(false); }
  };
  const send = async () => {
    const text = msg.trim();
    if (!text || !ok) return;
    if (req.current.text !== text) req.current = { id: crypto.randomUUID(), text };
    setBusy(true);
    try {
      const r = await api.post(`/mr-ivr/mrs/${mrId}/messages`, { message: text, confirm_send: true, request_id: req.current.id });
      setResult(r.data); setOk(false);
      if (r.data.status === "sent") toast.success("Accepted by provider (not a delivery confirmation)");
      else toast.error(r.data.error || `Status: ${r.data.status}`);
      onSent && onSent();
    } catch (e) { toast.error(apiError(e) + " - retry reuses the same request ID to avoid duplicates"); } finally { setBusy(false); }
  };
  if (!canSend) return null;
  const off = !canSend || !active;
  return (
    <Card className="p-4 space-y-3" data-testid="mr-ivr-message-panel">
      <div className="font-semibold text-sm">Send a message now</div>
      <p className="text-xs text-muted-foreground" data-testid="mr-ivr-message-sender">{senders.loading ? "Checking MR sender…" : mrSender ? <>MR messages send from <b>{senderLabel(mrSender)}</b>{mrSender.status !== "connected" ? <span className="text-amber-700"> (offline)</span> : null}.</> : "No MR sender number is assigned. Assign one in WhatsApp Connections."}</p>
      {!canSend && <p className="text-xs text-muted-foreground">Needs whatsapp.send, settings.manage and field_sales.view.</p>}
      {canSend && !active && <p className="text-xs text-red-600">This MR is inactive; manual messages are disabled.</p>}
      <div className="flex flex-wrap gap-2">
        <select value={kind} onChange={(e) => setKind(e.target.value)} disabled={off} className="h-9 rounded-md border bg-background px-2 text-sm" data-testid="mr-ivr-message-kind">
          <option value="encouragement">Encouragement</option><option value="push">Push</option>
        </select>
        <Button size="sm" variant="outline" onClick={preview} disabled={off || busy} data-testid="mr-ivr-message-preview">Preview for {date}</Button>
      </div>
      <Textarea rows={5} value={msg} disabled={off} onChange={(e) => { setMsg(e.target.value); setOk(false); }} placeholder="Preview a template or write your own" data-testid="mr-ivr-message-text" />
      <label className="flex items-start gap-2 text-sm"><input type="checkbox" className="mt-1" checked={ok} disabled={off} onChange={(e) => setOk(e.target.checked)} data-testid="mr-ivr-message-confirm" />I confirm this exact message will be sent to the MR on WhatsApp now.</label>
      <Button onClick={send} disabled={off || busy || !ok || !msg.trim()} className="bg-[#3B5B2A] hover:bg-[#2D4720]" data-testid="mr-ivr-message-send">{busy ? <Loader2 className="h-4 w-4 animate-spin" /> : "Send message"}</Button>
      {result && <p className="text-xs text-muted-foreground" data-testid="mr-ivr-message-result">Status: <b>{result.status}</b>{result.status === "sent" ? " - accepted by provider, delivery not guaranteed." : ""}{result.error ? ` ${result.error}` : ""}{result.status !== "sent" && result.status !== "failed" ? " Outcome uncertain; it will not be retried automatically." : ""}</p>}
    </Card>
  );
}
