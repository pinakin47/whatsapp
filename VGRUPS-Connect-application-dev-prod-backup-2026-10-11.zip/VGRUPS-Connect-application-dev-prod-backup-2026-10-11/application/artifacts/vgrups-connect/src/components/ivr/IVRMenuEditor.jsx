import React, { useState } from "react";
import { Card } from "../ui/card";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Textarea } from "../ui/textarea";
import { Switch } from "../ui/switch";
import { Plus, Trash2, ChevronDown, ChevronRight, ArrowUp, ArrowDown } from "lucide-react";

export const IVR_ACTIONS = ["menu", "message", "catalogue", "category", "product_search", "pricing", "order", "order_status", "business", "support", "sales"];
export const MAX_OPTIONS = 9;
export const MAX_DEPTH = 4;
const sel = "h-9 rounded-md border border-input bg-background px-2 text-sm";

export const newNode = () => ({ label: "New option", response: "", handoff: false, action: "message", category: "", options: [] });

function Node({ node, index, depth, onChange, onRemove, onMove, count }) {
  const [open, setOpen] = useState(depth === 1);
  const kids = node.options || [];
  const known = IVR_ACTIONS.includes(node.action || "message");
  const set = (p) => onChange({ ...node, ...p });
  const setKid = (i, n) => set({ options: kids.map((k, j) => (j === i ? n : k)) });
  const tid = `ivr-node-${depth}-${index}`;
  return (
    <Card className="p-3" data-testid={tid}>
      <div className="flex items-center gap-2">
        <button type="button" onClick={() => setOpen(!open)} className="text-muted-foreground" aria-label="Toggle">{open ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}</button>
        <span className="h-7 w-7 shrink-0 rounded-lg bg-[#3B5B2A] text-white flex items-center justify-center text-sm font-bold">{index + 1}</span>
        <Input className="flex-1" placeholder="Option label" value={node.label || ""} onChange={(e) => set({ label: e.target.value })} data-testid={`${tid}-label`} />
        <Button size="icon" variant="ghost" className="h-8 w-8" disabled={index === 0} onClick={() => onMove(-1)}><ArrowUp className="h-3.5 w-3.5" /></Button>
        <Button size="icon" variant="ghost" className="h-8 w-8" disabled={index === count - 1} onClick={() => onMove(1)}><ArrowDown className="h-3.5 w-3.5" /></Button>
        <Button size="icon" variant="ghost" className="h-8 w-8" onClick={onRemove} data-testid={`${tid}-delete`}><Trash2 className="h-3.5 w-3.5 text-destructive" /></Button>
      </div>
      {open && (
        <div className="mt-3 space-y-2 pl-6">
          <div className="grid sm:grid-cols-2 gap-2">
            <select className={sel} value={node.action || "message"} onChange={(e) => set({ action: e.target.value })} data-testid={`${tid}-action`}>
              {!known && <option value={node.action}>{node.action} (existing)</option>}
              {IVR_ACTIONS.map((a) => <option key={a} value={a}>{a}</option>)}
            </select>
            {node.action === "category" && <Input placeholder="Catalog category name" value={node.category || ""} onChange={(e) => set({ category: e.target.value })} data-testid={`${tid}-category`} />}
          </div>
          <Textarea rows={2} placeholder="Reply text sent when the customer picks this option" value={node.response || ""} onChange={(e) => set({ response: e.target.value })} data-testid={`${tid}-response`} />
          <label className="flex items-center gap-2 text-xs text-muted-foreground cursor-pointer"><Switch checked={!!node.handoff} onCheckedChange={(v) => set({ handoff: v })} />Hand off to a human after replying</label>
          {depth < MAX_DEPTH ? (
            <div className="space-y-2 border-l pl-3">
              {kids.map((k, i) => (
                <Node key={i} node={k} index={i} depth={depth + 1} count={kids.length}
                  onChange={(n) => setKid(i, n)}
                  onRemove={() => set({ options: kids.filter((_, j) => j !== i) })}
                  onMove={(d) => { const a = [...kids]; [a[i], a[i + d]] = [a[i + d], a[i]]; set({ options: a }); }} />
              ))}
              {kids.length < MAX_OPTIONS
                ? <Button size="sm" variant="outline" onClick={() => set({ options: [...kids, newNode()], action: node.action === "message" || !node.action ? "menu" : node.action })} data-testid={`${tid}-add-sub`}><Plus className="h-3.5 w-3.5 mr-1" />Add submenu option</Button>
                : <p className="text-xs text-muted-foreground">Maximum {MAX_OPTIONS} options reached.</p>}
            </div>
          ) : <p className="text-xs text-muted-foreground">Maximum depth ({MAX_DEPTH}) reached.</p>}
        </div>
      )}
    </Card>
  );
}

export default function IVRMenuEditor({ options, onChange }) {
  const opts = options || [];
  return (
    <div className="space-y-2">
      {opts.map((o, i) => (
        <Node key={i} node={o} index={i} depth={1} count={opts.length}
          onChange={(n) => onChange(opts.map((k, j) => (j === i ? n : k)))}
          onRemove={() => onChange(opts.filter((_, j) => j !== i))}
          onMove={(d) => { const a = [...opts]; [a[i], a[i + d]] = [a[i + d], a[i]]; onChange(a); }} />
      ))}
      {opts.length < MAX_OPTIONS
        ? <Button size="sm" variant="outline" onClick={() => onChange([...opts, newNode()])} data-testid="ivr-add-option"><Plus className="h-3.5 w-3.5 mr-1" />Add option</Button>
        : <p className="text-xs text-muted-foreground">Maximum {MAX_OPTIONS} options per menu.</p>}
    </div>
  );
}
