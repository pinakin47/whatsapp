import React from "react";
import { Card } from "../ui/card";

const STAGES = [
  ["Morning menu", "1 Start day visit, 2 View today's plan, 3 Talk to manager, 4 Mark leave. FIELD is entry 7 and legacy numbers are unchanged."],
  ["Location", "After start: share an actual WhatsApp location pin to record coordinates. Typing 1 Location Shared prompts for the pin; it does not record coordinates. 2 Unable to share, 3 Talk to manager."],
  ["Visit type", "DAY VISIT: 1 Doctor, 2 Hospital, 3 Clinic, 4 Pharmacy / Medical shop, 5 Distributor / Stockist, 6 Diagnostic centre, 7 Institution, 8 Other customer."],
  ["Visit details", "Name, purpose, products discussed, order received, follow-up, remarks. Then 1 Completed, 2 Not available, 3 Reschedule, 4 Add another visit."],
  ["Midday", "Status 1 Field visits continuing, 2 Visits completed, 3 Customer meeting in progress, 4 Returning to office, 5 Need manager assistance."],
  ["Midday reminder", "If no reply after the reminder delay: 1 Continuing, 2 Completed, 3 Returning to office, 4 Talk to manager."],
  ["Closing", "Counts of visits, doctors, hospitals, pharmacies, distributors; orders yes/no and sales value; leads, follow-ups, remarks; then summary 1 Submit, 2 Edit or 3 Manager. Evening invitation 2 Complete later keeps a pending draft. LATER pauses and PENDING resumes it."],
  ["Manager reasons", "1 Customer issue, 2 Order issue, 3 Field/travel issue, 4 Reporting issue, 5 Personal emergency, 6 Other. Requests are recorded and assigned in the Inbox when an active manager is available; otherwise shown as unassigned."],
];
const CMDS = [["STATUS", "Today's progress"], ["ORDER", "Report an order"], ["FOLLOWUP", "Log a follow-up"], ["PENDING", "Pending items"], ["HELP", "Command list"], ["DAY VISIT", "Start next visit"], ["CLOSING", "Start day closing"], ["FIELD", "Open field menu (entry 7)"]];

export default function MRFlowReference() {
  return (
    <Card className="p-4 space-y-3" data-testid="mr-ivr-flow-reference">
      <div className="font-semibold text-sm">Field flow reference</div>
      <div className="flex flex-wrap gap-1.5">{CMDS.map(([c, t]) => <span key={c} title={t} className="text-[11px] rounded bg-muted px-2 py-0.5"><b>{c}</b> {t}</span>)}</div>
      <ol className="space-y-2 text-xs">{STAGES.map(([t, b], i) => <li key={t}><span className="font-medium">{i + 1}. {t}.</span> <span className="text-muted-foreground">{b}</span></li>)}</ol>
    </Card>
  );
}
