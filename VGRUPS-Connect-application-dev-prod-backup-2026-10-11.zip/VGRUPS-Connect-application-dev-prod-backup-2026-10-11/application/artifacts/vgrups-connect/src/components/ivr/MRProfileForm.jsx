import React, { useState } from "react";
import api, { apiError } from "../../lib/api";
import { toast } from "sonner";
import { Card } from "../ui/card";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Label } from "../ui/label";
import { Textarea } from "../ui/textarea";
import { Switch } from "../ui/switch";
import { Loader2 } from "lucide-react";

export const DEFAULT_PROFILE = {
  ivr_enabled: true, field_flow_enabled: false, midday_enabled: false, midday_time: "13:00", reminder_minutes: 30, closing_deadline: "21:00", greeting: "", enabled: false, opt_in: false, encouragement_time: "11:00", push_time: "16:00", days: [0, 1, 2, 3, 4, 5],
  encouragement_template: "Hi {name}, your daily sales goal is INR {daily_goal}. Keep progressing with your {planned_visits} planned visits. Reply PLAN or CLOSING for your private reporting menu.",
  push_template: "Hi {name}, sales recorded today: INR {sales}. Pending visits: {pending_visits}. Next planned stop: {next_destination}. Follow up on open enquiries and share your closing report.",
};
const DAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
const VARS = "{name} {employee_id} {date} {daily_goal} {planned_visits} {completed_visits} {pending_visits} {sales} {next_destination}";

export default function MRProfileForm({ mrId, initial, canEdit, onSaved }) {
  const [p, setP] = useState({ ...DEFAULT_PROFILE, ...(initial || {}) });
  const [confirm, setConfirm] = useState(false);
  const [busy, setBusy] = useState(false);
  const set = (k, v) => setP((x) => ({ ...x, [k]: v }));
  const toggleDay = (d) => set("days", p.days.includes(d) ? p.days.filter((x) => x !== d) : [...p.days, d].sort());

  const save = async () => {
    const live = p.enabled || p.midday_enabled;
    if (p.midday_enabled && !p.field_flow_enabled) return toast.error("Midday check needs the field flow enabled");
    if (p.midday_enabled && !p.ivr_enabled) return toast.error("Midday check needs the private IVR menu enabled");
    const rm = Number(p.reminder_minutes);
    if (!Number.isInteger(rm) || rm < 15 || rm > 180) return toast.error("Reminder delay must be 15 to 180 minutes");
    if (live && !p.opt_in) return toast.error("Scheduled messages need the MR opt-in confirmed");
    if (live && !confirm) return toast.error("Confirm enabling scheduled messages");
    if (p.enabled && p.encouragement_time === p.push_time) return toast.error("Encouragement and push times must differ");
    if (p.enabled && !p.days.length) return toast.error("Choose at least one weekday");
    setBusy(true);
    try {
      const body = { ...p, reminder_minutes: rm, ...(live ? { confirm_enable: true } : {}) };
      const r = await api.put(`/mr-ivr/mrs/${mrId}/profile`, body);
      setP({ ...DEFAULT_PROFILE, ...(r.data.profile || r.data) });
      setConfirm(false); toast.success("MR profile saved"); onSaved && onSaved();
    } catch (e) { toast.error(apiError(e)); } finally { setBusy(false); }
  };
  const reset = async () => {
    if (!window.confirm("Disable and reset this MR's IVR profile? Message history is kept.")) return;
    setBusy(true);
    try { const r = await api.delete(`/mr-ivr/mrs/${mrId}/profile`); setP({ ...DEFAULT_PROFILE, ...(r.data?.profile || r.data || {}) }); setConfirm(false); toast.success("Profile reset"); onSaved && onSaved(); }
    catch (e) { toast.error(apiError(e)); } finally { setBusy(false); }
  };

  return (
    <Card className="p-4 space-y-4" data-testid="mr-ivr-profile">
      <div className="font-semibold text-sm">IVR profile</div>
      <p className="text-xs text-muted-foreground">Save to activate this MR's private menu. The shared 08:00/20:00 reporting invitations and administrator reports are controlled separately in Settings → MRs. Reset disables this individual menu and its coaching schedule.</p>
      {!canEdit && <p className="text-xs text-muted-foreground">View only. Editing needs settings.manage and whatsapp.send.</p>}
      <fieldset disabled={!canEdit || busy} className="space-y-4 min-w-0">
        <label className="flex items-center gap-2 text-sm"><Switch checked={!!p.ivr_enabled} onCheckedChange={(v) => { set("ivr_enabled", v); if (!v) set("midday_enabled", false); }} data-testid="mr-ivr-profile-ivr-enabled" />Private MR IVR menu enabled</label>
        <div><Label>MR greeting</Label><Textarea rows={2} value={p.greeting} onChange={(e) => set("greeting", e.target.value)} data-testid="mr-ivr-profile-greeting" /></div>
        <div className="border-t pt-4 space-y-3">
          <div className="text-sm font-medium">Scheduled messages <span className="text-xs text-muted-foreground font-normal">(off by default)</span></div>
          <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={!!p.opt_in} onChange={(e) => set("opt_in", e.target.checked)} data-testid="mr-ivr-profile-opt-in" />This MR has opted in to WhatsApp reminders</label>
          <label className="flex items-center gap-2 text-sm"><Switch checked={!!p.enabled} onCheckedChange={(v) => { set("enabled", v); if (!v) setConfirm(false); }} data-testid="mr-ivr-profile-enabled" />Send scheduled messages</label>
          {(p.enabled || p.midday_enabled) && <label className="flex items-start gap-2 text-sm text-amber-700"><input type="checkbox" className="mt-1" checked={confirm} onChange={(e) => setConfirm(e.target.checked)} data-testid="mr-ivr-profile-confirm-enable" />I confirm real WhatsApp messages will be sent automatically on these schedules.</label>}
          <div className="grid sm:grid-cols-2 gap-3">
            <div><Label>Encouragement time</Label><Input type="time" value={p.encouragement_time} onChange={(e) => set("encouragement_time", e.target.value)} data-testid="mr-ivr-profile-enc-time" /></div>
            <div><Label>Push time</Label><Input type="time" value={p.push_time} onChange={(e) => set("push_time", e.target.value)} data-testid="mr-ivr-profile-push-time" /></div>
          </div>
          <div className="flex flex-wrap gap-3">{DAYS.map((d, i) => <label key={d} className="flex items-center gap-1 text-sm"><input type="checkbox" checked={p.days.includes(i)} onChange={() => toggleDay(i)} data-testid={`mr-ivr-profile-day-${i}`} />{d}</label>)}</div>
          <div><Label>Encouragement template</Label><Textarea rows={3} value={p.encouragement_template} onChange={(e) => set("encouragement_template", e.target.value)} data-testid="mr-ivr-profile-enc-template" /></div>
          <div><Label>Push template</Label><Textarea rows={3} value={p.push_template} onChange={(e) => set("push_template", e.target.value)} data-testid="mr-ivr-profile-push-template" /></div>
          <p className="text-[11px] text-muted-foreground break-words">Allowed placeholders: {VARS}</p>
        </div>
        <div className="border-t pt-4 space-y-3" data-testid="mr-ivr-profile-field">
          <div className="text-sm font-medium">Field activity flow <span className="text-xs text-muted-foreground font-normal">(off by default)</span></div>
          <p className="text-xs text-muted-foreground">Enables the FIELD entry (7) in this MR's menu: day start, location, visits, midday status and day closing. Existing menu numbers are unchanged. Location Shared is a typed reply, not GPS evidence.</p>
          <label className="flex items-center gap-2 text-sm"><Switch checked={!!p.field_flow_enabled} onCheckedChange={(v) => { set("field_flow_enabled", v); if (!v) set("midday_enabled", false); }} data-testid="mr-ivr-profile-field-enabled" />Field activity flow enabled</label>
          <label className="flex items-center gap-2 text-sm"><Switch checked={!!p.midday_enabled} disabled={!p.field_flow_enabled || !p.ivr_enabled} onCheckedChange={(v) => { set("midday_enabled", v); if (!v && !p.enabled) setConfirm(false); }} data-testid="mr-ivr-profile-midday-enabled" />Send midday status check</label>
          {!p.opt_in && p.midday_enabled && <p className="text-xs text-amber-700">Midday messages need the opt-in above to be ticked.</p>}
          <div className="grid sm:grid-cols-3 gap-3">
            <div><Label>Midday time (IST)</Label><Input type="time" value={p.midday_time} onChange={(e) => set("midday_time", e.target.value)} data-testid="mr-ivr-profile-midday-time" /></div>
            <div><Label>Reminder after (min)</Label><Input type="number" min={15} max={180} value={p.reminder_minutes} onChange={(e) => set("reminder_minutes", e.target.value)} data-testid="mr-ivr-profile-reminder-minutes" /></div>
            <div><Label>Closing deadline</Label><Input type="time" value={p.closing_deadline} onChange={(e) => set("closing_deadline", e.target.value)} data-testid="mr-ivr-profile-closing-deadline" /></div>
          </div>
        </div>
      </fieldset>
      {canEdit && <div className="flex gap-2">
        <Button onClick={save} disabled={busy} className="bg-[#3B5B2A] hover:bg-[#2D4720]" data-testid="mr-ivr-profile-save">{busy ? <Loader2 className="h-4 w-4 animate-spin" /> : "Save profile"}</Button>
        <Button variant="outline" onClick={reset} disabled={busy} data-testid="mr-ivr-profile-reset">Disable / reset</Button>
      </div>}
    </Card>
  );
}
