export default function CatalogueReceiptEvidence({ delivery, attachment = false }) {
  return <div className="space-y-1 text-xs" data-testid={attachment ? "attachment-receipt" : "attempt-receipt"}>
    <div>Receipt status: {String(delivery?.status || "Unknown").replace(/_/g, " ")}</div>
    {!attachment && <div>{delivery?.delivered_parts ?? 0}/{delivery?.required_parts ?? "Unknown"} attachments delivery-confirmed,
      {" "}{delivery?.read_parts ?? 0} read-confirmed, {delivery?.failed_parts ?? 0} receipt failures</div>}
    <div>Delivered at: {delivery?.delivered_at || "Unknown"} · Read at: {delivery?.read_at || "Unknown"}</div>
  </div>;
}
