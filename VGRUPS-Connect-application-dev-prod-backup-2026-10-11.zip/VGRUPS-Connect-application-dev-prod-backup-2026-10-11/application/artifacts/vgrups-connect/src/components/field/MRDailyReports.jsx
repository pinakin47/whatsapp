import React, { useCallback, useEffect, useRef, useState } from "react";
import api, { apiError } from "../../lib/api";
import { downloadReportCsv } from "../../lib/downloadReportCsv";
import { useAuth } from "../../context/AuthContext";
import { Card } from "../ui/card";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Label } from "../ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "../ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../ui/table";
import { Loader2, RefreshCw } from "lucide-react";
import MRReportNotifications from "./MRReportNotifications";

const inr = (n) => `\u20B9${Number(n || 0).toLocaleString("en-IN")}`;
const val = (v) => (v === null || v === undefined || v === "" ? "-" : v);
const tm = (t) => (t ? new Date(t).toLocaleString() : "Not submitted");
const pct = (p) => (p === null || p === undefined ? "Not set" : `${p}%`);
const today = () => new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Kolkata" }).format(new Date());
const arr = (a) => (Array.isArray(a) ? a : []);

const Field = ({ k, v }) => (<div className="flex justify-between gap-3 text-sm py-1 border-b border-dashed last:border-0"><span className="text-muted-foreground">{k}</span><span className="font-medium text-right">{v}</span></div>);
const Sec = ({ title, children }) => (<section><h3 className="text-xs font-semibold uppercase tracking-wide text-muted-foreground mb-1">{title}</h3>{children}</section>);
const List = ({ items, render }) => (items && items.length ? <ul className="space-y-1 text-sm">{items.map((x, i) => <li key={i} className="rounded bg-muted/50 px-2 py-1">{render(x)}</li>)}</ul> : <p className="text-sm text-muted-foreground">None recorded</p>);

export default function MRDailyReports() {
  const { can } = useAuth();
  const [exporting, setExporting] = useState(false);
  const [date, setDate] = useState(today());
  const [mrId, setMrId] = useState("");
  const [mrs, setMrs] = useState([]);
  const [items, setItems] = useState(null);
  const [manager, setManager] = useState(false);
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  const [sel, setSel] = useState(null);
  const [mrErr, setMrErr] = useState("");
  const seq = useRef(0);
  const q = useRef({ date, mrId });
  q.current = { date, mrId };

  const load = useCallback(() => {
    setBusy(true);
    const my = ++seq.current;
    const { date: d, mrId: m } = q.current;
    api.get("/field/daily-reports", { params: { date: d, ...(m ? { mr_id: m } : {}) } })
      .then((r) => { if (my !== seq.current) return; setItems(r.data.items || []); setManager(!!r.data.is_manager); setErr(""); })
      .catch((e) => { if (my === seq.current) setErr(apiError(e)); })
      .finally(() => { if (my === seq.current) setBusy(false); });
  }, []);
  const loadMrs = useCallback(() => { setMrErr(""); api.get("/field/mrs").then((r) => setMrs(r.data.items || [])).catch((e) => setMrErr(apiError(e))); }, []);
  useEffect(() => { loadMrs(); }, [loadMrs]);
  useEffect(() => { setItems(null); load(); }, [date, mrId, load]);
  useEffect(() => { const t = setInterval(load, 30000); return () => clearInterval(t); }, [load]);

  const tot = (items || []).reduce((a, r) => { const m = r.summary || {}; ["planned_visits", "completed_visits", "pending_visits", "orders", "sales"].forEach((k) => { a[k] += Number(m[k]) || 0; }); return a; }, { planned_visits: 0, completed_visits: 0, pending_visits: 0, orders: 0, sales: 0 });
  const selItem = sel && items ? items.find((i) => i.id === sel) : null;
  const notificationSent = (attempt, originalId) => {
    if (attempt) setItems((rows) => rows?.map((row) => row.id !== sel ? row : {
      ...row, notifications: [
        attempt,
        ...(row.notifications || []).filter((n) => n.id !== attempt.id).map((n) =>
          n.id === originalId ? { ...n, can_send_now: false } : n),
      ],
    }));
    load();
  };

  return (
    <div className="space-y-3" data-testid="mr-daily-reports">
      <Card className="p-3 flex flex-wrap items-end gap-3">
        <div><Label htmlFor="dr-date">Date</Label><Input id="dr-date" type="date" value={date} onChange={(e) => e.target.value && setDate(e.target.value)} data-testid="dr-date" /></div>
        {(manager || mrs.length > 1) && (
          <div><Label htmlFor="dr-mr">MR</Label>
            <select id="dr-mr" value={mrId} onChange={(e) => setMrId(e.target.value)} className="h-10 rounded-md border bg-background px-3 text-sm block min-w-[10rem]" data-testid="dr-mr">
              <option value="">All MRs</option>{mrs.map((m) => <option key={m.id} value={m.id}>{m.name}</option>)}
            </select></div>
        )}
        <Button variant="outline" onClick={load} disabled={busy} data-testid="dr-refresh"><RefreshCw className={`h-3.5 w-3.5 mr-1 ${busy ? "animate-spin" : ""}`} />Refresh</Button>
        {can("field_sales", "export") && <Button variant="outline" disabled={exporting || busy || !items || !!err}
          onClick={async () => {
            setExporting(true);
            try { await downloadReportCsv("/field/daily-reports.csv", "mr_delivery_report.csv", { date, ...(mrId ? { mr_id: mrId } : {}) }); }
            catch (e) { setErr(apiError(e)); }
            finally { setExporting(false); }
          }}>Export delivery CSV</Button>}
        <span className="text-xs text-muted-foreground ml-auto">Auto-refreshes every 30 seconds</span>
      </Card>
      {mrErr && <Card className="p-3 text-sm text-red-600 flex items-center justify-between gap-3" data-testid="dr-mr-error">MR filter failed to load: {mrErr}<Button size="sm" variant="outline" onClick={loadMrs}>Retry</Button></Card>}
      {items && (
        <div className="grid grid-cols-2 md:grid-cols-5 gap-3" data-testid="dr-totals">
          {[["Planned visits", tot.planned_visits], ["Completed visits", tot.completed_visits], ["Pending visits", tot.pending_visits], ["Orders", tot.orders], ["Sales", inr(tot.sales)]].map(([k, v]) => (
            <Card key={k} className="p-3"><div className="text-xl font-bold">{v}</div><div className="text-xs text-muted-foreground">{k}</div></Card>
          ))}
          <p className="col-span-2 md:col-span-5 text-xs text-muted-foreground">Totals sum the MR-reported answers shown below. They do not mark individual doctor visits as checked in.</p>
        </div>
      )}
      <p className="text-xs text-muted-foreground">Daily goal is the expected sales an MR entered in the morning plan. It is separate from the monthly assigned target on the Targets tab.</p>

      {err && !items ? (
        <Card className="p-8 text-center text-sm" data-testid="dr-error"><p className="text-red-600 mb-3">{err}</p><Button size="sm" variant="outline" onClick={load}>Retry</Button></Card>
      ) : !items ? (
        <Card className="p-10 text-center"><Loader2 className="h-5 w-5 animate-spin mx-auto" /></Card>
      ) : (
        <Card className="overflow-hidden">
          {err && <div className="px-4 py-2 text-xs text-red-600 border-b flex items-center gap-3">Refresh failed: {err}<Button size="sm" variant="outline" onClick={load}>Retry</Button></div>}
          <div className="overflow-x-auto"><Table>
            <TableHeader><TableRow><TableHead>MR</TableHead><TableHead>Plan</TableHead><TableHead>Closing</TableHead><TableHead>Visits</TableHead><TableHead className="hidden md:table-cell">Sales</TableHead><TableHead>Achievement</TableHead></TableRow></TableHeader>
            <TableBody>
              {items.map((r) => (
                <TableRow key={r.id} className="cursor-pointer" tabIndex={0} onClick={() => setSel(r.id)} onKeyDown={(e) => (e.key === "Enter" || e.key === " ") && setSel(r.id)} data-testid={`dr-row-${r.id}`}>
                  <TableCell><div className="font-medium text-sm">{r.mr_name}</div><div className="text-xs text-muted-foreground">{r.employee_id || ""}</div></TableCell>
                  <TableCell className="text-xs">{r.plan_submitted_at ? "Submitted" : "Pending"}</TableCell>
                  <TableCell className="text-xs">{r.closing_submitted_at ? "Submitted" : "Pending"}</TableCell>
                  <TableCell className="text-sm">{val(r.summary?.completed_visits)}/{val(r.summary?.planned_visits)}</TableCell>
                  <TableCell className="hidden md:table-cell text-sm">{r.summary?.sales == null ? "-" : inr(r.summary.sales)}</TableCell>
                  <TableCell className="text-sm">{pct(r.summary?.achievement_pct)}</TableCell>
                </TableRow>
              ))}
              {items.length === 0 && <TableRow><TableCell colSpan={6} className="text-center py-10 text-muted-foreground">No MR reports for {date}{mrId ? " and this MR" : ""}. Reports appear after an MR replies to the invitation.</TableCell></TableRow>}
            </TableBody>
          </Table></div>
        </Card>
      )}

      <Dialog open={!!sel} onOpenChange={(o) => !o && setSel(null)}>
        <DialogContent className="max-w-2xl max-h-[90dvh] overflow-y-auto">
          {sel && !selItem && (<DialogHeader><DialogTitle>Report unavailable</DialogTitle><DialogDescription>This report is no longer in the current results. Close this window and refresh.</DialogDescription></DialogHeader>)}
          {selItem && (() => {
            const { plan: p = {}, closing: c = {}, summary: s = {}, notifications: n = [] } = selItem;
            return (
              <>
                <DialogHeader><DialogTitle>{selItem.mr_name} - {selItem.date}</DialogTitle><DialogDescription>Employee ID {selItem.employee_id || "-"}</DialogDescription></DialogHeader>
                <div className="space-y-5">
                  <Sec title="Summary">
                    <Field k="Planned / completed / pending visits" v={`${val(s.planned_visits)} / ${val(s.completed_visits)} / ${val(s.pending_visits)}`} />
                    <Field k="Doctor / customer visits" v={`${val(s.doctor_visits)} / ${val(s.customer_visits)}`} />
                    <Field k="Calls / orders / quotations" v={`${val(s.calls)} / ${val(s.orders)} / ${val(s.quotations)}`} />
                    <Field k="Sales" v={s.sales == null ? "-" : inr(s.sales)} />
                    <Field k="Daily goal (morning expected sales)" v={s.daily_goal == null ? "Not set" : inr(s.daily_goal)} />
                    <Field k="Achievement" v={pct(s.achievement_pct)} />
                    <Field k="Tomorrow visits" v={val(s.tomorrow_visits)} />
                  </Sec>
                  <Sec title={`Morning plan - ${tm(selItem.plan_submitted_at)}`}>
                    <Field k="Planned visits" v={val(p.planned_visits)} />
                    <Field k="Expected sales" v={p.expected_sales == null ? "-" : inr(p.expected_sales)} />
                    <Field k="Special plan" v={val(p.special_plan)} />
                    <div className="mt-2 space-y-2">
                      <List items={p.visits} render={(v) => `${v.name} - ${val(v.location)} - ${val(v.purpose)}`} />
                      <div className="text-xs text-muted-foreground">Quotations planned</div>
                      <List items={p.quotations} render={(x) => `${x.customer} - ${val(x.product)} - ${x.value == null ? "-" : inr(x.value)}`} />
                      <div className="text-xs text-muted-foreground">Follow-ups</div>
                      <List items={p.followups} render={(x) => x} />
                    </div>
                  </Sec>
                  <Sec title={`Closing report - ${tm(selItem.closing_submitted_at)}`}>
                    <Field k="Completed visits" v={val(c.completed_visits)} />
                    <Field k="Doctor / customer visits" v={`${val(c.doctor_visits)} / ${val(c.customer_visits)}`} />
                    <Field k="Calls / orders" v={`${val(c.calls)} / ${val(c.orders)}`} />
                    <Field k="Sales" v={c.sales == null ? "-" : inr(c.sales)} />
                    <Field k="Quotations" v={val(c.quotations)} />
                    <Field k="Quotation details" v={val(c.quotation_details)} />
                    <Field k="New customers" v={Array.isArray(c.new_customers) ? (c.new_customers.length ? c.new_customers.join(", ") : "-") : val(c.new_customers)} />
                    <Field k="Daily achievement" v={val(c.daily_achievement)} />
                    <Field k="Problems" v={val(c.problems)} />
                    <Field k="Remarks" v={val(c.remarks)} />
                    <Field k="Tomorrow visits" v={val(c.tomorrow_visits)} />
                    <div className="mt-2 space-y-2">
                      <div className="text-xs text-muted-foreground">Orders</div>
                      <List items={arr(c.order_details)} render={(o) => `${val(o.order_no)} - ${o.total == null ? "-" : inr(o.total)} - ${val(o.status)} - ${Array.isArray(o.items) ? o.items.map((i) => (typeof i === "object" ? [i.name || i.product, i.qty || i.quantity].filter(Boolean).join(" x ") : i)).join(", ") || "no items" : val(o.items)}`} />
                      <div className="text-xs text-muted-foreground">App quotations</div>
                      <List items={arr(c.app_quotation_details)} render={(o) => `${val(o.quote_no)} - ${o.total == null ? "-" : inr(o.total)} - ${Array.isArray(o.items) ? o.items.map((i) => (typeof i === "object" ? [i.name || i.product, i.qty || i.quantity].filter(Boolean).join(" x ") : i)).join(", ") || "no items" : val(o.items)}`} />
                      <div className="text-xs text-muted-foreground">Pending follow-ups</div>
                      <List items={c.pending_followups} render={(x) => x} />
                      <div className="text-xs text-muted-foreground">Tomorrow plan</div>
                      <List items={c.tomorrow_plan} render={(v) => `${v.name} - ${val(v.location)} - ${val(v.purpose)} - expected order ${val(v.expected_order)} - expected sales ${v.expected_sales == null ? "-" : inr(v.expected_sales)}`} />
                    </div>
                  </Sec>
                  <Sec title="Admin notifications">
                    <MRReportNotifications key={selItem.id} notifications={n} onSent={notificationSent} />
                  </Sec>
                </div>
              </>
            );
          })()}
        </DialogContent>
      </Dialog>
    </div>
  );
}
