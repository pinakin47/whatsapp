import React, { useRef, useState } from "react";
import api, { apiError } from "../../lib/api";
import { Button } from "../ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "../ui/dialog";

function ReceiptTime({ stage, value, confirmed }) {
  const date = value ? new Date(value) : null;
  const valid = date && Number.isFinite(date.getTime());
  if (!valid && !confirmed) return null;
  return <span className="block">
    {stage}: {valid ? <time dateTime={value} title={date.toISOString()}>
      {date.toLocaleString(undefined, { year: "numeric", month: "short", day: "numeric",
        hour: "2-digit", minute: "2-digit", second: "2-digit", timeZoneName: "short" })}
    </time> : "Time unavailable"}
  </span>;
}

export default function MRReportNotifications({ notifications, onSent }) {
  const [confirm, setConfirm] = useState(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const sending = useRef(false);

  const send = async () => {
    if (!confirm || sending.current) return;
    sending.current = true;
    setBusy(true);
    setError("");
    try {
      const { data } = await api.post(`/field/report-notifications/${encodeURIComponent(confirm.id)}/send-now`, { confirm: true });
      onSent(data.attempt, confirm.id);
      setConfirm(null);
    } catch (e) {
      setError(apiError(e));
      // Refresh eligibility even after a timeout: a reserved attempt must never be retried.
      onSent(null, confirm.id);
    } finally {
      sending.current = false;
      setBusy(false);
    }
  };

  return <>
    {notifications.length ? <ul className="space-y-2 text-sm" data-testid="dr-notifications">
      {notifications.map((x) => <li key={x.id} className="rounded bg-muted/50 px-2 py-2 space-y-1">
        <div className="flex flex-wrap justify-between gap-2">
          <span className="capitalize">{x.channel} - {x.name || x.user_id}{x.part ? ` · Part ${x.part}` : ""}</span>
          <span data-testid={`dr-status-${x.id}`} className={`capitalize ${x.status === "sent" ? "text-green-600" : x.status === "uncertain" ? "text-amber-600" : "text-muted-foreground"}`}>Send: {x.status === "sent" ? "Accepted" : x.status}</span>
        </div>
        {x.channel === "whatsapp" && <p className="text-xs font-mono" data-testid={`dr-sender-${x.id}`}>Sender number: {x.sender_number || "Unknown"}</p>}
        {x.channel === "whatsapp" && <p className="text-xs" data-testid={`dr-delivery-${x.id}`}>
          Receipt: {({ read: "Read", delivered: "Delivered", failed: "Failed", partial: "Partially delivered", unknown: "Not confirmed" })[x.delivery?.status] || "Not confirmed"}
          {x.delivery && ` · ${x.delivery.delivered_parts} delivered, ${x.delivery.read_parts} read / ${x.delivery.required_parts ?? "unknown"} required ${x.part ? "part" : "parts"}`}
          {x.status === "uncertain" && " · Send remains uncertain; resend blocked"}
        </p>}
        {x.channel === "whatsapp" && <p className="text-xs text-muted-foreground" data-testid={`dr-receipt-times-${x.id}`}>
          <ReceiptTime stage={x.part ? "Delivered at" : "All parts delivered at"} value={x.delivery?.delivered_at}
            confirmed={["delivered", "read"].includes(x.delivery?.status)} />
          <ReceiptTime stage={x.part ? "Read at" : "All parts read at"} value={x.delivery?.read_at}
            confirmed={x.delivery?.status === "read"} />
        </p>}
        <p className="text-xs text-muted-foreground">
          {x.original_notification_id ? "Confirmed manual attempt" : "Original attempt"}
          {x.created_at ? ` · Attempt created ${new Date(x.created_at).toLocaleString()}` : ""}
          {x.requested_by ? ` · Requested by ${x.requested_by}` : ""}
          {x.recipient_address ? ` · ${x.recipient_address}` : ""}
        </p>
        {x.error && <p className="text-xs text-muted-foreground">{x.error}</p>}
        {x.can_send_now && x.status === "unavailable" && !x.part && <Button size="sm" variant="outline"
          disabled={busy} data-testid={`dr-send-${x.id}`} onClick={() => { setError(""); setConfirm(x); }}>Send now</Button>}
      </li>)}
    </ul> : <p className="text-sm text-muted-foreground">No notifications recorded</p>}
    <Dialog open={!!confirm} onOpenChange={(open) => { if (!open && !sending.current) setConfirm(null); }}>
      <DialogContent className="max-w-md" onEscapeKeyDown={(e) => busy && e.preventDefault()} onPointerDownOutside={(e) => busy && e.preventDefault()}>
        <DialogHeader>
          <DialogTitle>Send this saved report now?</DialogTitle>
          <DialogDescription>
            Send the original closing snapshot to {confirm?.name || confirm?.user_id} via {confirm?.channel}, using their current contact details.
            This sends a real message. The original unavailable record will stay unchanged. A reserved, sent or uncertain attempt cannot be retried.
          </DialogDescription>
        </DialogHeader>
        {error && <p role="alert" className="text-sm text-red-600">{error}</p>}
        <div className="flex justify-end gap-2">
          <Button variant="outline" disabled={busy} onClick={() => setConfirm(null)}>Cancel</Button>
          <Button disabled={busy || !!error} onClick={send} data-testid="dr-confirm-send">{busy ? "Sending…" : "Confirm send"}</Button>
        </div>
      </DialogContent>
    </Dialog>
  </>;
}
