import React, { useCallback, useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import { FileText, Image as ImageIcon, Upload, Trash2, ExternalLink, CalendarClock } from "lucide-react";
import api, { apiError } from "../lib/api";
import CatalogueHistory from "./CatalogueHistory";
import { useAuth } from "../context/AuthContext";
import { Card } from "./ui/card";
import { Button } from "./ui/button";
import { Skeleton } from "./ui/skeleton";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "./ui/alert-dialog";

const MB = 1024 * 1024;

function normalize(file) {
  const n = (file.name || "").toLowerCase();
  if (n.endsWith(".pdf")) return { type: "application/pdf", max: 10 * MB, label: "PDF up to 10 MB" };
  if (n.endsWith(".jpg") || n.endsWith(".jpeg")) return { type: "image/jpeg", max: 5 * MB, label: "JPEG up to 5 MB" };
  return null;
}
const fmtSize = (b) => (b >= MB ? `${(b / MB).toFixed(1)} MB` : `${Math.max(1, Math.round(b / 1024))} KB`);
const fmtDate = (s) => { try { return new Date(s).toLocaleDateString(undefined, { day: "numeric", month: "short", year: "numeric" }); } catch (e) { return ""; } };

function DailyStatus() {
  const [d, setD] = useState(null);
  const [err, setErr] = useState(false);
  const load = useCallback(() => {
    setErr(false);
    api.get("/catalog/daily-mr").then((r) => setD(r.data)).catch(() => setErr(true));
  }, []);
  useEffect(() => { load(); }, [load]);
  const tz = d?.timezone || "IST";
  let badge = "Checking";
  let tone = "bg-muted text-muted-foreground";
  if (d) {
    if (d.enabled === false) { badge = "Paused"; tone = "bg-amber-100 text-amber-700 dark:bg-amber-500/15 dark:text-amber-300"; }
    else if (d.activated === false) { badge = "Activates after publishing"; tone = "bg-blue-100 text-blue-700 dark:bg-blue-500/15 dark:text-blue-300"; }
    else { badge = "Active"; tone = "bg-green-100 text-green-700 dark:bg-green-500/15 dark:text-green-300"; }
  }
  return (
    <Card className="p-4 mb-4" data-testid="catalog-daily-status" aria-live="polite">
      <div className="flex flex-wrap items-center gap-2 mb-2">
        <CalendarClock className="h-4 w-4 text-[#6E8B5B]" />
        <h2 className="text-sm font-semibold font-heading">Daily MR catalogue</h2>
        <span className={`rounded-full px-2.5 py-0.5 text-xs font-medium ${tone}`} data-testid="catalog-daily-badge">{badge}</span>
      </div>
      {err ? (
        <div className="text-sm text-destructive" role="alert">
          Could not load daily status. <button className="underline" onClick={load}>Retry</button>
        </div>
      ) : !d ? <Skeleton className="h-12 w-full" /> : (
        <div className="text-sm text-muted-foreground space-y-1.5">
          <p>All active registered MRs automatically receive reporting invitations at 08:00 and 20:00 IST, and one catalogue each day at {d.time || "09:00"} {tz}. Each catalogue includes every distinct product image and all uploaded JPEG and PDF files.</p>
          <p>MRs who opted out or were explicitly paused are excluded.</p>
          {d.enabled === false && <p className="text-foreground">Daily catalogue delivery is currently paused.</p>}
          {d.enabled !== false && d.activated === false && <p className="text-foreground">Automatic enrollment will activate after publishing; the scheduler is not running yet.</p>}
          <CatalogueHistory daily />
        </div>
      )}
    </Card>
  );
}

export default function CatalogFiles() {
  const { can } = useAuth();
  const [files, setFiles] = useState(null);
  const [loadErr, setLoadErr] = useState(false);
  const [queue, setQueue] = useState([]);
  const [busy, setBusy] = useState(false);
  const [removing, setRemoving] = useState(null);
  const inputRef = useRef(null);

  const load = useCallback(() => {
    setLoadErr(false);
    return api.get("/catalog/files").then((r) => setFiles(r.data.items || [])).catch(() => { setLoadErr(true); setFiles((f) => f || []); });
  }, []);
  useEffect(() => { if (can("catalog", "view")) load(); }, [load]); // eslint-disable-line

  if (!can("catalog", "view")) return null;
  const patch = (i, p) => setQueue((q) => q.map((x, k) => (k === i ? { ...x, ...p } : x)));

  const onPick = async (e) => {
    const list = Array.from(e.target.files || []);
    e.target.value = "";
    if (!list.length || busy) return;
    const rows = list.map((f) => {
      const n = normalize(f);
      let error = null;
      if (!n) error = "Only JPEG/JPG and PDF files are accepted";
      else if (f.size > n.max) error = `Too large (${n.label})`;
      else if (f.size === 0) error = "File is empty";
      return { name: f.name, file: f, n, status: error ? "error" : "waiting", error };
    });
    setQueue(rows);
    setBusy(true);
    for (let i = 0; i < rows.length; i++) {
      const r = rows[i];
      if (r.status === "error") continue;
      try {
        patch(i, { status: "uploading" });
        const { data: req } = await api.post("/catalog/files/request-upload", { name: r.file.name, content_type: r.n.type, size: r.file.size });
        const res = await fetch(req.upload_url, { method: "PUT", body: r.file, headers: { "Content-Type": r.n.type } });
        if (!res.ok) throw new Error(`Upload failed (${res.status})`);
        patch(i, { status: "finishing" });
        await api.post(`/catalog/files/${req.media_id}/complete`, {});
        patch(i, { status: "done" });
      } catch (err) {
        patch(i, { status: "error", error: apiError(err) });
      }
    }
    setBusy(false);
    await load();
    toast.success("Upload run finished");
  };

  const open = async (f) => {
    const tab = window.open("", "_blank");
    if (!tab) { toast.error("Your browser blocked the new tab. Allow pop-ups for this site and try again."); return; }
    tab.opener = null;
    try {
      const { data } = await api.get(`/catalog/files/${f.id}/download-url`);
      tab.location.href = data.url;
    } catch (err) {
      tab.close();
      toast.error(apiError(err));
    }
  };

  const remove = async () => {
    const f = removing;
    setRemoving(null);
    try {
      await api.delete(`/catalog/files/${f.id}`);
      toast.success("File removed");
      load();
    } catch (err) { toast.error(apiError(err)); }
  };

  return (
    <section className="mb-6" aria-labelledby="catalog-files-title">
      <DailyStatus />
      <Card className="p-4">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mb-3">
          <div>
            <h2 id="catalog-files-title" className="text-sm font-semibold font-heading">Catalogue files</h2>
            <p className="text-xs text-muted-foreground">JPEG up to 5 MB, PDF up to 10 MB. Included in every daily catalogue.</p>
          </div>
          {can("catalog", "create") && (
            <>
              <input ref={inputRef} type="file" multiple accept=".jpg,.jpeg,.pdf,image/jpeg,application/pdf" className="sr-only" onChange={onPick} data-testid="catalog-file-input" aria-label="Upload catalogue files" />
              <Button size="sm" disabled={busy} onClick={() => inputRef.current?.click()} data-testid="catalog-upload-button">
                <Upload className="h-3.5 w-3.5 mr-1" /> {busy ? "Uploading…" : "Upload files"}
              </Button>
            </>
          )}
        </div>

        {queue.length > 0 && (
          <ul className="mb-3 space-y-1 text-xs" data-testid="catalog-upload-queue" aria-live="polite">
            {queue.map((q, i) => (
              <li key={i} className="flex justify-between gap-2 rounded bg-muted px-2.5 py-1.5">
                <span className="truncate">{q.name}</span>
                <span className={q.status === "error" ? "text-destructive" : q.status === "done" ? "text-green-700 dark:text-green-400" : "text-muted-foreground"}>
                  {q.status === "error" ? q.error : q.status === "uploading" ? "Uploading…" : q.status === "finishing" ? "Finalising…" : q.status === "done" ? "Uploaded" : "Waiting"}
                </span>
              </li>
            ))}
          </ul>
        )}

        <div data-testid="catalog-files-list">
          {files === null ? (
            <div className="space-y-2" aria-busy="true"><Skeleton className="h-10 w-full" /><Skeleton className="h-10 w-full" /></div>
          ) : loadErr ? (
            <div className="text-sm text-destructive" role="alert">Could not load files. <button className="underline" onClick={load}>Retry</button></div>
          ) : files.length === 0 ? (
            <div className="rounded-lg border border-dashed py-6 text-center text-sm text-muted-foreground" data-testid="catalog-files-empty">
              No catalogue files yet.{can("catalog", "create") ? " Upload a JPEG or PDF to include it in the daily catalogue." : ""}
            </div>
          ) : (
            <ul className="divide-y">
              {files.map((f) => (
                <li key={f.id} className="flex items-center gap-3 py-2" data-testid={`catalog-file-${f.id}`}>
                  {f.content_type === "application/pdf" ? <FileText className="h-5 w-5 shrink-0 text-[#6E8B5B]" /> : <ImageIcon className="h-5 w-5 shrink-0 text-[#6E8B5B]" />}
                  <div className="min-w-0 flex-1">
                    <div className="text-sm font-medium truncate">{f.name}</div>
                    <div className="text-xs text-muted-foreground">{fmtSize(f.size)} · {fmtDate(f.created_at)}</div>
                  </div>
                  <Button variant="outline" size="sm" onClick={() => open(f)} aria-label={`Open ${f.name}`} data-testid={`catalog-file-open-${f.id}`}><ExternalLink className="h-3.5 w-3.5 sm:mr-1" /><span className="hidden sm:inline">Open</span></Button>
                  {can("catalog", "delete") && (
                    <Button variant="outline" size="sm" onClick={() => setRemoving(f)} aria-label={`Remove ${f.name}`} data-testid={`catalog-file-remove-${f.id}`}><Trash2 className="h-3.5 w-3.5 sm:mr-1" /><span className="hidden sm:inline">Remove</span></Button>
                  )}
                </li>
              ))}
            </ul>
          )}
        </div>
      </Card>

      <AlertDialog open={!!removing} onOpenChange={(o) => !o && setRemoving(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Remove this file?</AlertDialogTitle>
            <AlertDialogDescription>
              {removing?.name} will be excluded from future catalogues. Catalogues already delivered stay in history.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={remove} data-testid="catalog-file-remove-confirm">Remove</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </section>
  );
}
