import { useCallback, useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { toast } from "sonner";
import { Loader2 } from "lucide-react";
import api, { apiError } from "../lib/api";
import { downloadReportCsv } from "../lib/downloadReportCsv";
import { useAuth } from "../context/AuthContext";
import { catalogSendRequest, lookupCatalogSendRequest } from "../lib/catalogSendRequest";
import { useSenders, SenderSelect, resolveSender, findSender, senderLabel } from "../lib/useSenders";
import { Button } from "./ui/button";
import { Label } from "./ui/label";
import { Textarea } from "./ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "./ui/dialog";
import CatalogueHistory from "./CatalogueHistory";

export const normalizePhone = (m) => (m || "").replace(/[\s().-]/g, "");
export const isValidPhone = (p) => /^\+[1-9][0-9]{7,14}$/.test(p);
export const formatMobile = (m) => {
  const p = normalizePhone(m);
  if (!isValidPhone(p)) return m || "";
  const d = p.slice(1);
  if (d.startsWith("91") && d.length === 12) return `+91 ${d.slice(2, 7)} ${d.slice(7)}`;
  return `+${d.slice(0, d.length - 10 > 0 ? d.length - 10 : 2)} ${d.slice(d.length - 10 > 0 ? d.length - 10 : 2).replace(/(\d{3})(?=\d)/g, "$1 ")}`;
};
const TERMINAL = ["accepted", "needs_review", "cancelled"];

export default function ContactWhatsAppDialog({ contact, mode, onClose }) {
  const [exporting, setExporting] = useState(false);
  const { user, can } = useAuth();
  const phone = normalizePhone(contact.mobile);
  const cid = contact.contact_id ?? contact.id;
  const isCat = mode === "catalogue";
  const allowed = can("inbox", "send") && (isCat ? can("catalog", "send") && can("catalog", "view") : true);
  const blocker = cid == null ? "This contact is unavailable."
    : contact.opted_out ? "This contact has opted out of WhatsApp."
    : !isValidPhone(phone) ? "Mobile needs an international number starting with + and the country code."
    : !allowed ? "You do not have permission to send this." : "";

  const senders = useSenders();
  const senderSlot = `contact-sender:${user?.id}:${cid}:${mode}`;
  const [senderPick, setSenderPick] = useState(() => { try { return sessionStorage.getItem(senderSlot) || ""; } catch { return ""; } });
  const sid = resolveSender(senders, senderPick);
  useEffect(() => { if (sid) { try { sessionStorage.setItem(senderSlot, sid); } catch {} } }, [sid, senderSlot]);
  const sender = findSender(senders, sid);
  const [conn, setConn] = useState(null);
  const [connErr, setConnErr] = useState("");
  const draftSlot = `contact-message-draft:${user?.id}:${cid}`;
  const [body, setBody] = useState(() => { try { return sessionStorage.getItem(draftSlot) || ""; } catch { return ""; } });
  const [busy, setBusy] = useState(false);
  const [pending, setPending] = useState(null); // {key, complete}
  const [error, setError] = useState("");
  const [outcome, setOutcome] = useState(null);
  const [assets, setAssets] = useState(null);
  const [assetErr, setAssetErr] = useState("");
  const [status, setStatus] = useState(null);
  const [retrySameKey, setRetrySameKey] = useState(false);
  const busyRef = useRef(false);
  useEffect(() => {
    if (isCat || !user?.id) return;
    try { if (body) sessionStorage.setItem(draftSlot, body); else sessionStorage.removeItem(draftSlot); } catch {}
  }, [body, draftSlot, isCat, user?.id]);

  const checkConn = useCallback(async () => {
    setConn(null); setConnErr("");
    try { const { data } = await api.get("/whatsapp/status"); setConn(data); }
    catch (e) { setConnErr(`Cannot check WhatsApp connection: ${apiError(e)}`); }
  }, []);
  useEffect(() => { checkConn(); }, [checkConn]);

  const loadAssets = useCallback(async () => {
    setAssets(null); setAssetErr("");
    try { const { data } = await api.get("/contacts/catalogue-assets"); setAssets(data); }
    catch (e) { setAssetErr(`Cannot load catalogue: ${apiError(e)}`); }
  }, []);
  useEffect(() => { if (isCat) loadAssets(); }, [isCat, loadAssets]);

  // Restore saved attempt (never sends).
  const payloadFor = useCallback(() => {
    const base = isCat ? { phone, body: "FULL_CATALOGUE" } : { phone, body: body.trim() };
    return sid ? { ...base, session_id: sid } : base;
  }, [isCat, phone, body, sid]);
  const productId = isCat ? "contact-catalogue" : "contact-message";
  useEffect(() => {
    if (!user?.id || !isValidPhone(phone)) return;
    if (!isCat && !body.trim()) { setPending(null); return; }
    let off = false;
    lookupCatalogSendRequest(user.id, productId, payloadFor()).then((a) => { if (!off) setPending(a); }).catch(() => { if (!off) setError("Cannot read saved send state. Do not send until browser storage is available."); });
    return () => { off = true; };
  }, [user?.id, productId, payloadFor, isCat, body, phone, blocker]);

  const checkStatus = useCallback(async (key) => {
    try {
      const { data } = await api.get(`/contacts/catalogue-attempts/${key}`);
      setStatus(data); setRetrySameKey(false); setError("");
      return data;
    } catch (e) { if (e.response?.status === 404) setRetrySameKey(true); setError(`Cannot check status: ${apiError(e)} Your request is saved and will not be duplicated.`); return null; }
  }, []);
  const pendingKey = pending?.key;
  useEffect(() => { if (isCat && pendingKey) checkStatus(pendingKey); }, [isCat, pendingKey, checkStatus]);
  useEffect(() => {
    if (!isCat || !pendingKey || !status || TERMINAL.includes(status.status)) return;
    const t = setInterval(() => checkStatus(pendingKey), 3000);
    return () => clearInterval(t);
  }, [isCat, pendingKey, status, checkStatus]);
  useEffect(() => {
    if (status && ["accepted", "cancelled"].includes(status.status)) pending?.complete();
  }, [status, pending]);

  const online = senders.items.length ? sender?.status === "connected" : (isCat ? !!conn?.qr_connected : !!conn?.active);
  const sessionPart = sid ? { session_id: sid } : {};
  const catActive = isCat && ((pending && !status && !retrySameKey) || (status && !["accepted", "cancelled"].includes(status.status)));
  const noAssets = isCat && assets && assets.total === 0;

  const sendMessage = async () => {
    if (busyRef.current || blocker || !online || !body.trim() || outcome) return;
    busyRef.current = true; setBusy(true); setError("");
    try {
      const attempt = await catalogSendRequest(user.id, "contact-message", payloadFor());
      setPending(attempt);
      const { data } = await api.post(`/contacts/${encodeURIComponent(cid)}/message`, { body: body.trim(), request_key: attempt.key, expected_phone: phone, ...sessionPart });
      if (!data.wamid) throw new Error("WhatsApp did not confirm acceptance.");
      attempt.complete(); setPending(null);
      sessionStorage.removeItem(draftSlot);
      setOutcome({ state: "accepted", detail: "WhatsApp accepted the message. Acceptance does not confirm delivery or reading." });
      toast.success(`WhatsApp accepted the message for ${contact.name}.`);
    } catch (e) {
      setError(`Send failed: ${apiError(e)} If uncertain, use Check original send. Retrying reuses the original request.`);
    } finally { busyRef.current = false; setBusy(false); }
  };
  const recover = async () => {
    if (busyRef.current || !pending) return;
    busyRef.current = true; setBusy(true); setError("");
    try {
      const { data } = await api.post("/whatsapp/send/recover", { phone, body: body.trim(), request_key: pending.key, ...sessionPart });
      if (data.state === "accepted" && data.message?.wamid) {
        pending.complete(); setPending(null);
        sessionStorage.removeItem(draftSlot);
        setOutcome({ state: "accepted", detail: "Original send confirmed. Nothing was resent. Acceptance does not confirm delivery or reading." });
      } else setOutcome({ state: "unresolved", detail: "Still unresolved. The original request is kept; nothing was resent." });
    } catch (e) { setError(`Cannot confirm: ${apiError(e)} The saved request is kept.`); }
    finally { busyRef.current = false; setBusy(false); }
  };
  const sendCatalogue = async () => {
    if (busyRef.current || blocker || !online || catActive || !assets?.total) return;
    busyRef.current = true; setBusy(true); setError("");
    try {
      const attempt = await catalogSendRequest(user.id, "contact-catalogue", payloadFor());
      setPending(attempt);
      const { data } = await api.post(`/contacts/${encodeURIComponent(cid)}/catalogue`, { request_key: attempt.key, expected_phone: phone, ...sessionPart });
      setStatus(data); setRetrySameKey(false);
      toast.success("Catalogue queued for sending.");
    } catch (e) {
      setRetrySameKey(true);
      setError(`Request failed: ${apiError(e)} Use Check status or retry; the same request key is reused.`);
    } finally { busyRef.current = false; setBusy(false); }
  };

  const retryWithSameKey = isCat ? (pending && !status) : false;
  return (
    <Dialog open onOpenChange={(o) => { if (!o && !busy) onClose(); }}>
      <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto" data-testid={`wa-dialog-${mode}`}>
        <DialogHeader>
          <DialogTitle>{isCat ? "Send full catalogue" : "Send WhatsApp message"}</DialogTitle>
          <DialogDescription>Goes only to this contact. Nothing is sent until you confirm.</DialogDescription>
        </DialogHeader>
        <div className="rounded-lg border border-border p-3 text-sm">
          <div className="font-medium" data-testid="wa-recipient-name">{contact.name}</div>
          <div className="font-mono text-xs text-muted-foreground" data-testid="wa-recipient-phone">{formatMobile(contact.mobile) || "No number"}</div>
        </div>
        <SenderSelect senders={senders} value={senderPick} onChange={setSenderPick} disabled={busy || !!pending || !!outcome} testId="wa-sender-select" />
        {sender && <p className="text-xs text-muted-foreground" data-testid="wa-sender-confirm">Will be sent from {senderLabel(sender)}{sender.status !== "connected" ? " (offline)" : ""}.</p>}
        {blocker && <p className="text-sm text-destructive" data-testid="wa-blocker">{blocker}</p>}
        {connErr && <p className="text-sm text-destructive">{connErr} <button className="underline" onClick={checkConn}>Retry</button></p>}
        {conn && !online && (
          <p className="text-sm text-amber-700" data-testid="wa-offline">
            {isCat ? "Catalogue sending needs a QR-connected WhatsApp number." : "No active WhatsApp connection."}{" "}
            <Link to="/whatsapp" className="underline" onClick={onClose}>Open WhatsApp Connections</Link>
          </p>
        )}
        {!isCat && (
          <div>
            <Label>Message</Label>
            <Textarea data-testid="wa-message-body" rows={5} value={body} disabled={busy || !!outcome} onChange={(e) => setBody(e.target.value)} />
          </div>
        )}
        {isCat && (
          <div className="text-sm space-y-2" data-testid="wa-catalogue-summary">
            {assetErr && <p className="text-destructive">{assetErr} <button className="underline" onClick={loadAssets}>Retry</button></p>}
            {!assets && !assetErr && <div className="h-16 rounded-md bg-muted animate-pulse" />}
            {assets && (
              <>
                <p>{assets.total} files: {assets.image_count} images, {assets.pdf_count} PDF.</p>
                {assets.items.length > 0 && (
                  <ul className="max-h-40 overflow-y-auto rounded-md border border-border divide-y text-xs">
                    {assets.items.map((a, i) => <li key={`${a.name}-${i}`} className="flex justify-between gap-2 px-2 py-1"><span className="truncate">{a.name}</span><span className="text-muted-foreground shrink-0">{a.content_type}</span></li>)}
                  </ul>
                )}
              </>
            )}
            {noAssets && <p>No catalogue files yet. <Link to="/catalog" className="underline" onClick={onClose}>Open Catalog</Link></p>}
            {status && (
              <div className="rounded-md bg-muted p-2 text-xs" data-testid="wa-catalogue-status">
                <div className="font-semibold capitalize">{String(status.status).replace(/_/g, " ")}</div>
                <div className="font-mono">Sender number: {status.sender_number || "Unknown"}</div>
                <div>{status.accepted_parts}/{status.total_parts} accepted{status.removed_parts ? `, ${status.removed_parts} removed` : ""}{status.uncertain_parts ? `, ${status.uncertain_parts} uncertain` : ""}</div>
                {status.error && <div className="text-destructive">{status.error}</div>}
                {pendingKey && can("crm", "export") && can("catalog", "export") && <Button size="sm" variant="outline" disabled={exporting}
                  onClick={async () => {
                    setExporting(true);
                    try { await downloadReportCsv(`/contacts/catalogue-attempts/${encodeURIComponent(pendingKey)}/report.csv`, "individual_catalogue_delivery.csv"); }
                    catch (e) { toast.error(apiError(e)); }
                    finally { setExporting(false); }
                  }}>Export attempt CSV</Button>}
                {status.status === "accepted" && <div>WhatsApp accepted the files. This does not confirm delivery or reading.</div>}
                {status.status === "needs_review" && <div>Some parts are uncertain. Check the chat before sending again.</div>}
                {!TERMINAL.includes(status.status) && <div className="flex items-center gap-1 mt-1"><Loader2 className="h-3 w-3 animate-spin" /> Updating every 3 seconds</div>}
              </div>
            )}
          </div>
        )}
        {isCat && can("crm", "view") && can("catalog", "view") &&
          <CatalogueHistory contactRef={cid} refreshKey={`${status?.id || ""}:${status?.status || ""}`} />}
        {outcome && <p className="text-sm rounded-md bg-muted p-2" data-testid="wa-outcome">{outcome.detail}</p>}
        {error && <p className="text-sm text-destructive" data-testid="wa-error">{error}</p>}
        <DialogFooter className="gap-2 sm:gap-2 flex-col sm:flex-row">
          {!isCat && pending && !outcome && <Button variant="outline" disabled={busy} onClick={recover} data-testid="wa-recover">Check original send</Button>}
          {isCat && pending && <Button variant="outline" disabled={busy} onClick={() => checkStatus(pending.key)} data-testid="wa-check-status">Check status</Button>}
          <Button variant="outline" disabled={busy} onClick={onClose}>Close</Button>
          {isCat ? (
            <Button data-testid="wa-send-catalogue" className="bg-[#3B5B2A] hover:bg-[#2D4720]" onClick={sendCatalogue}
              disabled={busy || !!blocker || !online || catActive || !assets?.total}>
              {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : retryWithSameKey ? "Retry same request" : "Send full catalogue"}
            </Button>
          ) : (
            <Button data-testid="wa-send-message" className="bg-[#3B5B2A] hover:bg-[#2D4720]" onClick={sendMessage}
              disabled={busy || !!blocker || !online || !body.trim() || !!outcome}>
              {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : pending ? "Retry same request" : "Send message"}
            </Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
