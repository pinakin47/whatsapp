import React, { useCallback, useEffect, useState } from "react";
import api, { apiError } from "../../lib/api";
import { toast } from "sonner";
import { useAuth } from "../../context/AuthContext";
import { DemoBadge } from "../common";
import ConfirmDialog from "../ConfirmDialog";
import { Card } from "../ui/card";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Label } from "../ui/label";
import { Switch } from "../ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "../ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../ui/table";
import { Avatar, AvatarFallback } from "../ui/avatar";
import { Plus, Loader2, Pencil, Trash2 } from "lucide-react";

const PHONE_RE = /^\+[1-9]\d{7,14}$/;
const blank = { name: "", email: "", phone: "", password: "", role: "", active: true };

export default function UsersPanel({ roles, refreshSession }) {
  const { can, user: me } = useAuth();
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [loadErr, setLoadErr] = useState("");
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(blank);
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState("");
  const [del, setDel] = useState(null);

  const load = useCallback(() => {
    setLoadErr("");
    return api.get("/users").then((r) => setUsers(r.data.items || [])).catch((e) => setLoadErr(apiError(e))).finally(() => setLoading(false));
  }, []);
  useEffect(() => { load(); }, [load]);

  const openNew = () => { setEditing(null); setForm({ ...blank, role: roles[roles.length - 1]?.key || "" }); setErr(""); setOpen(true); };
  const openEdit = (u) => { setEditing(u); setForm({ name: u.name, email: u.email, phone: u.phone || "", password: "", role: u.role, active: !!u.active }); setErr(""); setOpen(true); };

  const save = async () => {
    const phone = (form.phone || "").trim().replace(/[\s-]/g, "");
    if (phone && !PHONE_RE.test(phone)) { setErr("Enter phone in international format, e.g. +919876543210"); return; }
    setSaving(true); setErr("");
    try {
      if (editing) {
        const body = { name: form.name, email: form.email, phone: phone || null, role: form.role, active: form.active };
        if (form.password.trim()) body.password = form.password;
        await api.put(`/users/${editing.id}`, body);
        toast.success("User updated");
        if (editing.id === me?.id) await refreshSession();
      } else {
        await api.post("/users", { name: form.name, email: form.email, phone: phone || null, password: form.password, role: form.role, active: form.active });
        toast.success("User created");
      }
      setOpen(false); load();
    } catch (e) { setErr(apiError(e)); } finally { setSaving(false); }
  };

  const confirmDelete = async () => {
    const u = del; setDel(null);
    try { await api.delete(`/users/${u.id}`); toast.success("User removed"); load(); }
    catch (e) { toast.error(apiError(e)); }
  };

  return (
    <>
      {can("settings", "create") && (
        <div className="flex justify-end mb-3">
          <Button data-testid="add-user-button" onClick={openNew} className="bg-[#3B5B2A] hover:bg-[#2D4720]"><Plus className="h-4 w-4 mr-1" /> New User</Button>
        </div>
      )}
      {loadErr && <Card className="p-4 mb-3 text-sm text-destructive flex items-center justify-between">{loadErr}<Button size="sm" variant="outline" onClick={load}>Retry</Button></Card>}
      <Card className="overflow-hidden">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader><TableRow><TableHead>User</TableHead><TableHead>Role</TableHead><TableHead className="hidden sm:table-cell">Email</TableHead><TableHead>Status</TableHead><TableHead className="w-24" /></TableRow></TableHeader>
            <TableBody>
              {loading && [0, 1, 2].map((i) => <TableRow key={i}><TableCell colSpan={5}><div className="h-6 rounded bg-muted animate-pulse" /></TableCell></TableRow>)}
              {users.map((u) => (
                <TableRow key={u.id} data-testid={`user-row-${u.id}`}>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <Avatar className="h-8 w-8"><AvatarFallback className="bg-[#6E8B5B] text-white text-xs">{(u.name || "?").slice(0, 2).toUpperCase()}</AvatarFallback></Avatar>
                      <span className="font-medium flex items-center gap-1">{u.name} {u.is_demo && <DemoBadge />}{u.id === me?.id && <span className="text-[10px] text-muted-foreground">(you)</span>}</span>
                    </div>
                  </TableCell>
                  <TableCell><span className="text-xs rounded-full bg-[#F0F4EE] text-[#3B5B2A] px-2 py-0.5">{u.role_label || u.role}</span></TableCell>
                  <TableCell className="hidden sm:table-cell text-muted-foreground text-sm">{u.email}</TableCell>
                  <TableCell>{u.active ? <span className="text-xs text-green-600">Active</span> : <span className="text-xs text-muted-foreground">Disabled</span>}</TableCell>
                  <TableCell>
                    <div className="flex justify-end">
                      {can("settings", "edit") && <Button size="icon" variant="ghost" data-testid={`user-edit-${u.id}`} onClick={() => openEdit(u)}><Pencil className="h-4 w-4" /></Button>}
                      {can("settings", "delete") && <Button size="icon" variant="ghost" data-testid={`user-delete-${u.id}`} onClick={() => setDel(u)}><Trash2 className="h-4 w-4 text-destructive" /></Button>}
                    </div>
                  </TableCell>
                </TableRow>
              ))}
              {!loading && users.length === 0 && !loadErr && <TableRow><TableCell colSpan={5} className="text-center py-10 text-muted-foreground">No team members yet</TableCell></TableRow>}
            </TableBody>
          </Table>
        </div>
      </Card>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>{editing ? "Edit User" : "Create User"}</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div><Label>Name</Label><Input data-testid="user-name-input" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
            <div><Label>Email</Label><Input data-testid="user-email-input" type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></div>
            <div><Label>WhatsApp phone (international)</Label><Input data-testid="user-phone-input" type="tel" placeholder="+919876543210" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} /><p className="text-xs text-muted-foreground mt-1">Optional. Used for admin WhatsApp reports.</p></div>
            <div><Label>{editing ? "New password" : "Password"}</Label><Input data-testid="user-password-input" type="password" autoComplete="new-password" placeholder={editing ? "Leave blank to keep current" : ""} value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} /></div>
            <div><Label>Role</Label>
              <Select value={form.role} onValueChange={(v) => setForm({ ...form, role: v })}>
                <SelectTrigger data-testid="user-role-select"><SelectValue placeholder="Select role" /></SelectTrigger>
                <SelectContent>{roles.map((r) => <SelectItem key={r.key} value={r.key}>{r.label}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="flex items-center justify-between rounded-lg border border-border p-3">
              <div><Label>Active</Label><p className="text-xs text-muted-foreground">Disabled users cannot sign in</p></div>
              <Switch checked={form.active} onCheckedChange={(v) => setForm({ ...form, active: v })} />
            </div>
            {err && <p className="text-sm text-destructive" data-testid="user-form-error">{err}</p>}
          </div>
          <DialogFooter>
            <Button data-testid="user-save-button" disabled={saving || !form.name || !form.email || !form.role || (!editing && !form.password)} onClick={save} className="bg-[#3B5B2A] hover:bg-[#2D4720]">{saving ? <Loader2 className="h-4 w-4 animate-spin" /> : editing ? "Save" : "Create"}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      <ConfirmDialog open={!!del} onOpenChange={(o) => !o && setDel(null)} title="Remove this user?" description={del ? `${del.name} (${del.email}) will lose access. You cannot remove yourself or the last admin.` : ""} confirmLabel="Remove" destructive onConfirm={confirmDelete} testId="user-delete-confirm" />
    </>
  );
}
