import React, { useCallback, useEffect, useState } from "react";
import api, { apiError } from "../../lib/api";
import { toast } from "sonner";
import { useAuth } from "../../context/AuthContext";
import { Card } from "../ui/card";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Label } from "../ui/label";
import { Textarea } from "../ui/textarea";
import { Switch } from "../ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "../ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../ui/table";
import MRIvrSettings from "./MRIvrSettings";
import { Loader2, Plus, Pencil, Trash2, RefreshCw } from "lucide-react";

const EMPTY = { name: "", phone: "", email: "", employee_id: "", active: true };
const DEF_REM = { enabled: false, time: "09:00", timezone: "Asia/Kolkata", message: "Good morning {name} ,kindly send the todays visits schedule up load as pr the following instructions .and evening day end submit todays report .", message_gap_seconds: 5 };
const PHONE_RE = /^\+[1-9]\d{7,14}$/;

export default function MRsPanel() {
  const { can } = useAuth();
  const manage = can("settings", "manage");
  const [items, setItems] = useState(null);
  const [error, setError] = useState("");
  const [form, setForm] = useState(null);
  const [busy, setBusy] = useState(false);
  const [del, setDel] = useState(null);
  const [rem, setRem] = useState(null);
  const [remErr, setRemErr] = useState("");
  const [savingRem, setSavingRem] = useState(false);
  const [confirmOn, setConfirmOn] = useState(false);
  const [hist, setHist] = useState([]);
  const [histLoading, setHistLoading] = useState(false);

  const load = useCallback(() => {
    setError("");
    api.get("/settings/mrs").then((r) => setItems(r.data.items || [])).catch((e) => setError(apiError(e)));
  }, []);
  const loadRem = useCallback(() => {
    setRemErr("");
    api.get("/settings/mr-reminders").then((r) => setRem({ ...DEF_REM, ...r.data })).catch((e) => setRemErr(apiError(e)));
  }, []);
  const loadHist = useCallback(() => {
    setHistLoading(true);
    api.get("/settings/mr-reminders/history").then((r) => setHist(r.data.items || [])).catch((e) => toast.error(apiError(e))).finally(() => setHistLoading(false));
  }, []);
  useEffect(() => { load(); loadRem(); loadHist(); }, [load, loadRem, loadHist]);

  const save = async () => {
    const f = { ...form, name: form.name.trim(), phone: form.phone.trim().replace(/[\s-]/g, ""), email: form.email.trim(), employee_id: form.employee_id.trim() };
    if (!f.name) return toast.error("Name is required");
    if (!PHONE_RE.test(f.phone)) return toast.error("Enter phone in international format, e.g. +919876543210");
    if (f.email && !/^\S+@\S+\.\S+$/.test(f.email)) return toast.error("Enter a valid email");
    setBusy(true);
    try {
      const body = { name: f.name, phone: f.phone, email: f.email, employee_id: f.employee_id, active: !!f.active };
      if (f.id) await api.put(`/settings/mrs/${f.id}`, body); else await api.post("/settings/mrs", body);
      toast.success("MR saved"); setForm(null); load();
    } catch (e) { toast.error(apiError(e)); } finally { setBusy(false); }
  };
  const remove = async () => {
    setBusy(true);
    try { await api.delete(`/settings/mrs/${del.id}`); toast.success("MR deleted"); setDel(null); load(); }
    catch (e) { toast.error(apiError(e)); } finally { setBusy(false); }
  };
  const saveRem = async () => {
    const gap = Number(rem.message_gap_seconds);
    if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(rem.time)) return toast.error("Time must be HH:MM (IST)");
    if (!Number.isInteger(gap) || gap < 1 || gap > 300) return toast.error("Message gap must be a whole number from 1 to 300");
    if (!rem.message.trim()) return toast.error("Message is required");
    setSavingRem(true);
    try {
      const r = await api.put("/settings/mr-reminders", { ...rem, timezone: "Asia/Kolkata", message_gap_seconds: gap });
      setRem({ ...DEF_REM, ...r.data }); setConfirmOn(false); toast.success("Reminder settings saved");
    } catch (e) { toast.error(apiError(e)); } finally { setSavingRem(false); }
  };
  const toggleRem = (v) => { setRem({ ...rem, enabled: v }); if (!v) setConfirmOn(false); };
  const active = (items || []).filter((m) => m.active).length;

  return (
    <div className="space-y-6">
      <Card className="overflow-hidden" data-testid="mrs-card">
        <div className="flex items-center justify-between p-4 border-b">
          <div><div className="font-semibold text-sm">Medical Representatives</div><div className="text-xs text-muted-foreground">Active MRs are included automatically in daily reporting, catalogue sharing and MR replies. No recipient selection is needed.{items ? ` · ${active} active of ${items.length}` : ""}</div></div>
          {manage && <Button size="sm" className="bg-[#3B5B2A] hover:bg-[#2D4720]" onClick={() => setForm({ ...EMPTY })} data-testid="mr-add"><Plus className="h-3.5 w-3.5 mr-1" />Add MR</Button>}
        </div>
        {error ? (
          <div className="p-8 text-center text-sm" data-testid="mrs-error"><p className="text-red-600 mb-3">{error}</p><Button size="sm" variant="outline" onClick={load}>Retry</Button></div>
        ) : !items ? (
          <div className="p-10 text-center"><Loader2 className="h-5 w-5 animate-spin mx-auto" /></div>
        ) : (
          <div className="overflow-x-auto"><Table>
            <TableHeader><TableRow><TableHead>Name</TableHead><TableHead>Phone</TableHead><TableHead className="hidden md:table-cell">Email</TableHead><TableHead className="hidden md:table-cell">Employee ID</TableHead><TableHead>Status</TableHead><TableHead className="hidden lg:table-cell">Login</TableHead><TableHead className="hidden lg:table-cell">Updated</TableHead>{manage && <TableHead className="w-24" />}</TableRow></TableHeader>
            <TableBody>
              {items.map((m) => (
                <TableRow key={m.id} data-testid={`mr-row-${m.id}`}>
                  <TableCell className="font-medium text-sm">{m.name}</TableCell>
                  <TableCell className="text-sm font-mono">{m.phone}</TableCell>
                  <TableCell className="hidden md:table-cell text-sm">{m.email || "-"}</TableCell>
                  <TableCell className="hidden md:table-cell text-sm">{m.employee_id || "-"}</TableCell>
                  <TableCell><span className={`text-xs ${m.active ? "text-green-600" : "text-muted-foreground"}`}>{m.active ? "Active" : "Inactive"}</span></TableCell>
                  <TableCell className="hidden lg:table-cell text-xs text-muted-foreground">{m.user_id ? "Linked" : "None"}</TableCell>
                  <TableCell className="hidden lg:table-cell text-xs text-muted-foreground">{m.updated_at ? new Date(m.updated_at).toLocaleString() : ""}</TableCell>
                  {manage && <TableCell><div className="flex gap-1 justify-end">
                    <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => setForm({ ...EMPTY, ...m })} data-testid={`mr-edit-${m.id}`}><Pencil className="h-3.5 w-3.5" /></Button>
                    <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => setDel(m)} data-testid={`mr-delete-${m.id}`}><Trash2 className="h-3.5 w-3.5 text-destructive" /></Button>
                  </div></TableCell>}
                </TableRow>
              ))}
              {items.length === 0 && <TableRow><TableCell colSpan={8} className="text-center py-10 text-muted-foreground">No MRs added yet.{manage ? " Use Add MR to create the first record." : ""}</TableCell></TableRow>}
            </TableBody>
          </Table></div>
        )}
      </Card>

      <MRIvrSettings />

      <Card className="p-4 space-y-4" data-testid="mr-reminder-card">
        <div><div className="font-semibold text-sm">Legacy text-only reminder</div><div className="text-xs text-muted-foreground">While the reporting IVR is enabled it suppresses this reminder. Daily WhatsApp text to active MRs asking for the visit schedule and the end-of-day report.</div></div>
        {remErr ? (
          <div className="text-sm text-center py-4"><p className="text-red-600 mb-3">{remErr}</p><Button size="sm" variant="outline" onClick={loadRem}>Retry</Button></div>
        ) : !rem ? <div className="py-6 text-center"><Loader2 className="h-5 w-5 animate-spin mx-auto" /></div> : (
          <>
            <div className="text-xs rounded-lg bg-amber-50 dark:bg-amber-500/10 text-amber-800 dark:text-amber-300 border border-amber-200 dark:border-amber-500/20 px-3 py-2 space-y-1">
              <p>Sends run through the linked WhatsApp QR/gateway session; the server and the linked session must be running at the scheduled time. Messages go only to MR records marked active, never to customers.</p>
              <p>WhatsApp only: no email messages and no automatic evening sends. The morning text only asks MRs to submit their day-end report. Enabling requires settings.manage and whatsapp.send permissions.</p>
            </div>
            <div className="flex items-center gap-2 text-sm"><Switch checked={rem.enabled} disabled={!manage} onCheckedChange={toggleRem} data-testid="mr-reminder-enabled" /><span>{rem.enabled ? "Enabled" : "Off"}</span></div>
            <div className="grid md:grid-cols-3 gap-3">
              <div><Label>Time (IST, HH:MM)</Label><Input type="time" value={rem.time} disabled={!manage} onChange={(e) => setRem({ ...rem, time: e.target.value })} data-testid="mr-reminder-time" /></div>
              <div><Label>Timezone</Label><Input value="Asia/Kolkata" disabled /></div>
              <div><Label>Gap between messages (1-300 s)</Label><Input type="number" min={1} max={300} step={1} value={rem.message_gap_seconds} disabled={!manage} onChange={(e) => setRem({ ...rem, message_gap_seconds: e.target.value })} data-testid="mr-reminder-gap" /></div>
            </div>
            <div><Label>Message</Label><Textarea rows={4} value={rem.message} disabled={!manage} onChange={(e) => setRem({ ...rem, message: e.target.value })} data-testid="mr-reminder-message" /><p className="text-xs text-muted-foreground mt-1">Placeholders: {"{name}"} and {"{employee_id}"} are replaced per MR.</p></div>
            {manage && rem.enabled && (
              <label className="flex items-start gap-2 text-sm cursor-pointer"><input type="checkbox" className="mt-1" checked={confirmOn} onChange={(e) => setConfirmOn(e.target.checked)} data-testid="mr-reminder-confirm" />
                <span>I confirm this will send real WhatsApp messages every day at {rem.time} IST to all active MRs.</span></label>
            )}
            {manage && <Button onClick={saveRem} disabled={savingRem || (rem.enabled && !confirmOn)} className="bg-[#3B5B2A] hover:bg-[#2D4720]" data-testid="mr-reminder-save">{savingRem ? <Loader2 className="h-4 w-4 animate-spin" /> : "Save reminder settings"}</Button>}
          </>
        )}
      </Card>

      <Card className="overflow-hidden" data-testid="mr-history-card">
        <div className="flex items-center justify-between p-4 border-b">
          <div><div className="font-semibold text-sm">Reminder history</div><div className="text-xs text-muted-foreground">Refresh after the scheduled time to see sent or uncertain attempts. A provider timeout is never retried automatically.</div></div>
          <Button size="sm" variant="outline" onClick={loadHist} disabled={histLoading} data-testid="mr-history-refresh"><RefreshCw className={`h-3.5 w-3.5 mr-1 ${histLoading ? "animate-spin" : ""}`} />Refresh</Button>
        </div>
        <div className="overflow-x-auto"><Table>
          <TableHeader><TableRow><TableHead>Date</TableHead><TableHead>MR</TableHead><TableHead className="hidden md:table-cell">Employee ID</TableHead><TableHead>Status</TableHead><TableHead className="hidden md:table-cell">Detail</TableHead></TableRow></TableHeader>
          <TableBody>
            {hist.map((h) => (
              <TableRow key={h.id} data-testid={`mr-history-${h.id}`}>
                <TableCell className="text-sm">{h.date}</TableCell><TableCell className="text-sm">{h.name}</TableCell><TableCell className="hidden md:table-cell text-sm">{h.employee_id || "-"}</TableCell>
                <TableCell><span className={`text-xs capitalize ${h.status === "sent" ? "text-green-600" : h.status === "uncertain" ? "text-amber-600" : "text-muted-foreground"}`}>{h.status}</span></TableCell>
                <TableCell className="hidden md:table-cell text-xs text-muted-foreground">{h.error || (h.created_at ? new Date(h.created_at).toLocaleString() : "")}</TableCell>
              </TableRow>
            ))}
            {hist.length === 0 && <TableRow><TableCell colSpan={5} className="text-center py-8 text-muted-foreground">No reminders recorded yet</TableCell></TableRow>}
          </TableBody>
        </Table></div>
      </Card>

      <Dialog open={!!form} onOpenChange={(o) => !o && setForm(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>{form?.id ? "Edit MR" : "Add MR"}</DialogTitle></DialogHeader>
          {form && <div className="space-y-3">
            <div><Label>Name</Label><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} data-testid="mr-form-name" /></div>
            <div><Label>Phone (international)</Label><Input placeholder="+919876543210" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} data-testid="mr-form-phone" /></div>
            <div><Label>Email</Label><Input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} data-testid="mr-form-email" /><p className="text-xs text-muted-foreground mt-1">If it matches an existing MR login, the record is linked automatically.</p></div>
            <div><Label>Employee ID</Label><Input value={form.employee_id} onChange={(e) => setForm({ ...form, employee_id: e.target.value })} data-testid="mr-form-employee" /></div>
            <label className="flex items-center gap-2 text-sm"><Switch checked={!!form.active} onCheckedChange={(v) => setForm({ ...form, active: v })} data-testid="mr-form-active" />Active</label>
          </div>}
          <DialogFooter><Button variant="outline" onClick={() => setForm(null)}>Cancel</Button><Button onClick={save} disabled={busy} className="bg-[#3B5B2A] hover:bg-[#2D4720]" data-testid="mr-form-save">{busy ? <Loader2 className="h-4 w-4 animate-spin" /> : "Save"}</Button></DialogFooter>
        </DialogContent>
      </Dialog>
      <Dialog open={!!del} onOpenChange={(o) => !o && setDel(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>Delete MR</DialogTitle></DialogHeader>
          <p className="text-sm">Delete {del?.name}? Their login (if any) is not affected.</p>
          <DialogFooter><Button variant="outline" onClick={() => setDel(null)}>Cancel</Button><Button variant="destructive" onClick={remove} disabled={busy} data-testid="mr-delete-confirm">Delete</Button></DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
