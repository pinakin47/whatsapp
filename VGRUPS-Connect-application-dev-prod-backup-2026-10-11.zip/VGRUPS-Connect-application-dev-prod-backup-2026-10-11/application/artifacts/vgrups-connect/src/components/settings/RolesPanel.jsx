import React, { useState } from "react";
import api, { apiError } from "../../lib/api";
import { toast } from "sonner";
import { useAuth } from "../../context/AuthContext";
import ConfirmDialog from "../ConfirmDialog";
import { Card } from "../ui/card";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Label } from "../ui/label";
import { Checkbox } from "../ui/checkbox";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "../ui/dialog";
import { Plus, Loader2, Pencil, Trash2, Lock } from "lucide-react";

const ALIAS = { crm: "contacts", contacts: "crm" };
const slug = (s) => s.toLowerCase().trim().replace(/[^a-z0-9]+/g, "_").replace(/^_|_$/g, "");

export default function RolesPanel({ roles, modules, actions, reload, refreshSession }) {
  const { can, user: me } = useAuth();
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState({ key: "", label: "", permissions: {} });
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState("");
  const [del, setDel] = useState(null);

  const openNew = () => { setEditing(null); setForm({ key: "", label: "", permissions: {} }); setErr(""); setOpen(true); };
  const openEdit = (r) => { setEditing(r); setForm({ key: r.key, label: r.label, permissions: JSON.parse(JSON.stringify(r.permissions || {})) }); setErr(""); setOpen(true); };

  const toggle = (m, a, on) => {
    setForm((f) => {
      const p = { ...f.permissions };
      [m, ALIAS[m]].filter(Boolean).forEach((mod) => {
        if (!modules.includes(mod)) return;
        const set = new Set(p[mod] || []);
        on ? set.add(a) : set.delete(a);
        p[mod] = actions.filter((x) => set.has(x));
      });
      return { ...f, permissions: p };
    });
  };

  const save = async () => {
    setSaving(true); setErr("");
    const permissions = {};
    Object.entries(form.permissions).forEach(([m, a]) => { if (a.length) permissions[m] = a; });
    try {
      if (editing) await api.put(`/roles/${editing.key}`, { key: editing.key, label: form.label, permissions });
      else await api.post("/roles", { key: form.key, label: form.label, permissions });
      toast.success(editing ? "Role updated" : "Role created");
      setOpen(false); await reload();
      if (editing?.key === me?.role || editing) await refreshSession();
    } catch (e) { setErr(apiError(e)); } finally { setSaving(false); }
  };

  const confirmDelete = async () => {
    const r = del; setDel(null);
    try { await api.delete(`/roles/${r.key}`); toast.success("Role deleted"); reload(); }
    catch (e) { toast.error(apiError(e)); }
  };

  const count = (r) => Object.values(r.permissions || {}).reduce((n, a) => n + a.length, 0);

  return (
    <>
      {can("settings", "create") && <div className="flex justify-end mb-3"><Button data-testid="add-role-button" onClick={openNew} className="bg-[#3B5B2A] hover:bg-[#2D4720]"><Plus className="h-4 w-4 mr-1" /> New Role</Button></div>}
      <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-3">
        {roles.map((r) => (
          <Card key={r.key} className="p-4" data-testid={`role-card-${r.key}`}>
            <div className="flex items-start justify-between gap-2">
              <div className="min-w-0">
                <div className="font-semibold flex items-center gap-1.5">{r.label}{r.protected && <Lock className="h-3.5 w-3.5 text-muted-foreground" />}</div>
                <div className="text-[11px] font-mono text-muted-foreground">{r.key}</div>
              </div>
              {!r.protected && (
                <div className="flex shrink-0">
                  {can("settings", "edit") && <Button size="icon" variant="ghost" data-testid={`role-edit-${r.key}`} onClick={() => openEdit(r)}><Pencil className="h-4 w-4" /></Button>}
                  {can("settings", "delete") && <Button size="icon" variant="ghost" data-testid={`role-delete-${r.key}`} onClick={() => setDel(r)}><Trash2 className="h-4 w-4 text-destructive" /></Button>}
                </div>
              )}
            </div>
            <div className="text-xs text-muted-foreground mt-2">{r.protected ? "Protected role, full access, not editable" : `${count(r)} permissions across ${Object.values(r.permissions || {}).filter((a) => a.length).length} modules`}</div>
            <div className="flex flex-wrap gap-1 mt-2">
              {modules.filter((m) => (r.permissions?.[m] || []).length).slice(0, 8).map((m) => <span key={m} className="text-[10px] rounded-full bg-[#F0F4EE] text-[#3B5B2A] px-2 py-0.5 capitalize">{m.replace(/_/g, " ")}</span>)}
            </div>
          </Card>
        ))}
      </div>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editing ? `Edit role: ${editing.label}` : "Create Role"}</DialogTitle>
            <DialogDescription>CRM and Contacts share permissions and change together.</DialogDescription>
          </DialogHeader>
          <div className="grid sm:grid-cols-2 gap-3">
            <div><Label>Label</Label><Input data-testid="role-label-input" value={form.label} onChange={(e) => setForm({ ...form, label: e.target.value, key: editing ? form.key : slug(e.target.value) })} /></div>
            <div><Label>Key</Label><Input data-testid="role-key-input" disabled={!!editing} value={form.key} onChange={(e) => setForm({ ...form, key: slug(e.target.value) })} /></div>
          </div>
          <div className="overflow-x-auto rounded-lg border border-border">
            <table className="w-full text-xs">
              <thead><tr className="bg-muted/50"><th className="text-left p-2 sticky left-0 bg-muted">Module</th>{actions.map((a) => <th key={a} className="p-2 capitalize font-medium">{a}</th>)}</tr></thead>
              <tbody>
                {modules.map((m) => (
                  <tr key={m} className="border-t border-border">
                    <td className="p-2 capitalize font-medium sticky left-0 bg-card whitespace-nowrap">{m.replace(/_/g, " ")}</td>
                    {actions.map((a) => (
                      <td key={a} className="p-2 text-center">
                        <Checkbox data-testid={`perm-${m}-${a}`} aria-label={`${m} ${a}`} checked={(form.permissions[m] || []).includes(a)} onCheckedChange={(v) => toggle(m, a, !!v)} />
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {err && <p className="text-sm text-destructive" data-testid="role-form-error">{err}</p>}
          <DialogFooter><Button data-testid="role-save-button" disabled={saving || !form.label || !form.key} onClick={save} className="bg-[#3B5B2A] hover:bg-[#2D4720]">{saving ? <Loader2 className="h-4 w-4 animate-spin" /> : "Save role"}</Button></DialogFooter>
        </DialogContent>
      </Dialog>
      <ConfirmDialog open={!!del} onOpenChange={(o) => !o && setDel(null)} title="Delete this role?" description={del ? `"${del.label}" will be removed. Roles still assigned to users cannot be deleted until those users are reassigned.` : ""} confirmLabel="Delete" destructive onConfirm={confirmDelete} testId="role-delete-confirm" />
    </>
  );
}
