import React, { useCallback, useEffect, useState } from "react";
import api, { apiError } from "../../lib/api";
import { toast } from "sonner";
import { useAuth } from "../../context/AuthContext";
import { Card } from "../ui/card";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Label } from "../ui/label";
import { Switch } from "../ui/switch";
import { Loader2 } from "lucide-react";

const DEF = { enabled: false, morning_time: "08:00", closing_time: "20:00", timezone: "Asia/Kolkata", message_gap_seconds: 5, email_reports: true, whatsapp_reports: true };
const TIME_RE = /^([01]\d|2[0-3]):[0-5]\d$/;

export default function MRIvrSettings() {
  const { can } = useAuth();
  const manage = can("settings", "manage");
  const [s, setS] = useState(null);
  const [err, setErr] = useState("");
  const [confirm, setConfirm] = useState(false);
  const [saving, setSaving] = useState(false);

  const load = useCallback(() => {
    setErr("");
    api.get("/settings/mr-ivr").then((r) => setS({ ...DEF, ...r.data })).catch((e) => setErr(apiError(e)));
  }, []);
  useEffect(() => { load(); }, [load]);

  const save = async () => {
    const gap = Number(s.message_gap_seconds);
    if (!TIME_RE.test(s.morning_time) || !TIME_RE.test(s.closing_time)) return toast.error("Times must be HH:MM (IST)");
    if (!Number.isInteger(gap) || gap < 1 || gap > 300) return toast.error("Message gap must be a whole number from 1 to 300");
    setSaving(true);
    try {
      const r = await api.put("/settings/mr-ivr", { ...s, timezone: "Asia/Kolkata", message_gap_seconds: gap, confirm_enable: !!(s.enabled && confirm) });
      setS({ ...DEF, ...r.data }); setConfirm(false); toast.success("Reporting IVR settings saved");
    } catch (e) { toast.error(apiError(e)); } finally { setSaving(false); }
  };
  const set = (k, v) => setS({ ...s, [k]: v });

  return (
    <Card className="p-4 space-y-4" data-testid="mr-ivr-card">
      <div><div className="font-semibold text-sm">Reporting IVR (twice daily)</div><div className="text-xs text-muted-foreground">A morning WhatsApp invitation for the day plan and a closing invitation for the day-end report, with summaries sent to admins.</div></div>
      {err ? (
        <div className="text-sm text-center py-4"><p className="text-red-600 mb-3">{err}</p><Button size="sm" variant="outline" onClick={load}>Retry</Button></div>
      ) : !s ? <div className="py-6 text-center"><Loader2 className="h-5 w-5 animate-spin mx-auto" /></div> : (
        <>
          <div className="text-xs rounded-lg bg-amber-50 dark:bg-amber-500/10 text-amber-800 dark:text-amber-300 border border-amber-200 dark:border-amber-500/20 px-3 py-2 space-y-1">
            <p>When enabled, a daily message is sent to every active MR with reporting enabled at each scheduled time. Newly added active MRs are included automatically. If a report is already submitted, that MR receives a brief confirmation instead of another prompt.</p>
            <p>Recipients: all active admin and super_admin accounts. Email and WhatsApp use the contact details configured for each account in Team Settings. A missing contact or an unconfigured channel is recorded as unavailable for that recipient. Report channels switched off below are simply not sent and not recorded.</p>
            <p>WhatsApp opt-outs and MRs with reporting individually disabled are excluded. The server and linked WhatsApp QR session must be running at the scheduled times. An uncertain provider call (for example a timeout) is never retried automatically.</p>
            <p>While this is enabled it suppresses the legacy text-only reminder below. Editing requires settings.manage.</p>
          </div>
          <label className="flex items-center gap-2 text-sm"><Switch checked={s.enabled} disabled={!manage} onCheckedChange={(v) => { set("enabled", v); if (!v) setConfirm(false); }} data-testid="mr-ivr-enabled" /><span>{s.enabled ? "Enabled" : "Off"}</span></label>
          <div className="grid md:grid-cols-4 gap-3">
            <div><Label>Morning invitation (IST)</Label><Input type="time" value={s.morning_time} disabled={!manage} onChange={(e) => set("morning_time", e.target.value)} data-testid="mr-ivr-morning" /></div>
            <div><Label>Closing invitation (IST)</Label><Input type="time" value={s.closing_time} disabled={!manage} onChange={(e) => set("closing_time", e.target.value)} data-testid="mr-ivr-closing" /></div>
            <div><Label>Timezone</Label><Input value="Asia/Kolkata" disabled /></div>
            <div><Label>Gap between messages (1-300 s)</Label><Input type="number" min={1} max={300} step={1} value={s.message_gap_seconds} disabled={!manage} onChange={(e) => set("message_gap_seconds", e.target.value)} data-testid="mr-ivr-gap" /></div>
          </div>
          <div className="flex flex-wrap gap-6 text-sm">
            <label className="flex items-center gap-2"><Switch checked={!!s.email_reports} disabled={!manage} onCheckedChange={(v) => set("email_reports", v)} data-testid="mr-ivr-email" />Email admin reports</label>
            <label className="flex items-center gap-2"><Switch checked={!!s.whatsapp_reports} disabled={!manage} onCheckedChange={(v) => set("whatsapp_reports", v)} data-testid="mr-ivr-whatsapp" />WhatsApp admin reports</label>
          </div>
          {manage && s.enabled && (
            <label className="flex items-start gap-2 text-sm cursor-pointer"><input type="checkbox" className="mt-1" checked={confirm} onChange={(e) => setConfirm(e.target.checked)} data-testid="mr-ivr-confirm" />
              <span>I confirm this will send real WhatsApp invitations to active MRs at {s.morning_time} and {s.closing_time} IST every day, and notify admins by the channels selected.</span></label>
          )}
          {manage && <Button onClick={save} disabled={saving || (s.enabled && !confirm)} className="bg-[#3B5B2A] hover:bg-[#2D4720]" data-testid="mr-ivr-save">{saving ? <Loader2 className="h-4 w-4 animate-spin" /> : "Save reporting IVR settings"}</Button>}
        </>
      )}
    </Card>
  );
}
