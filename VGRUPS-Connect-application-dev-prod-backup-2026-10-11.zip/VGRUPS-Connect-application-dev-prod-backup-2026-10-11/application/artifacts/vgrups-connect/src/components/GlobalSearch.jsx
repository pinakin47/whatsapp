import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Users, Kanban, Package, ShoppingCart } from "lucide-react";
import api from "../lib/api";
import {
  CommandDialog, CommandInput, CommandList, CommandEmpty, CommandGroup, CommandItem,
} from "./ui/command";

export default function GlobalSearch({ open, setOpen }) {
  const [q, setQ] = useState("");
  const [res, setRes] = useState({ contacts: [], leads: [], products: [], orders: [] });
  const navigate = useNavigate();

  useEffect(() => {
    if (!q || q.length < 2) { setRes({ contacts: [], leads: [], products: [], orders: [] }); return; }
    const t = setTimeout(() => {
      api.get(`/search?q=${encodeURIComponent(q)}`).then((r) => setRes(r.data)).catch(() => {});
    }, 250);
    return () => clearTimeout(t);
  }, [q]);

  const go = (path) => { setOpen(false); setQ(""); navigate(path); };

  return (
    <CommandDialog open={open} onOpenChange={setOpen}>
      <CommandInput data-testid="global-search-input" placeholder="Search contacts, leads, products, orders…" value={q} onValueChange={setQ} />
      <CommandList>
        <CommandEmpty>{q.length < 2 ? "Type at least 2 characters…" : "No results found."}</CommandEmpty>
        {res.contacts?.length > 0 && (
          <CommandGroup heading="Contacts">
            {res.contacts.map((c) => (
              <CommandItem key={c.id} onSelect={() => go("/crm")} value={`contact-${c.id}`}>
                <Users className="h-4 w-4 mr-2" /> {c.name} · {c.mobile}
              </CommandItem>
            ))}
          </CommandGroup>
        )}
        {res.leads?.length > 0 && (
          <CommandGroup heading="Leads">
            {res.leads.map((l) => (
              <CommandItem key={l.id} onSelect={() => go("/leads")} value={`lead-${l.id}`}>
                <Kanban className="h-4 w-4 mr-2" /> {l.title}
              </CommandItem>
            ))}
          </CommandGroup>
        )}
        {res.products?.length > 0 && (
          <CommandGroup heading="Products">
            {res.products.map((p) => (
              <CommandItem key={p.id} onSelect={() => go("/catalog")} value={`product-${p.id}`}>
                <Package className="h-4 w-4 mr-2" /> {p.name} · {p.code}
              </CommandItem>
            ))}
          </CommandGroup>
        )}
        {res.orders?.length > 0 && (
          <CommandGroup heading="Orders">
            {res.orders.map((o) => (
              <CommandItem key={o.id} onSelect={() => go("/orders")} value={`order-${o.id}`}>
                <ShoppingCart className="h-4 w-4 mr-2" /> {o.order_no} · ₹{o.total}
              </CommandItem>
            ))}
          </CommandGroup>
        )}
      </CommandList>
    </CommandDialog>
  );
}
