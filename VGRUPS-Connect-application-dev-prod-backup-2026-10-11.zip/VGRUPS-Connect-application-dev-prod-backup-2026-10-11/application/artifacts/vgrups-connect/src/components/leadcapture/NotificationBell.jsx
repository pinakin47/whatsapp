import React, { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Bell } from "lucide-react";
import { toast } from "sonner";
import api, { apiError } from "../../lib/api";
import { usePoll, fmt } from "../../lib/leadCapture";

export default function NotificationBell() {
  const { data, error, reload } = usePoll("/lead-capture/notifications", null, 5000);
  const [open, setOpen] = useState(false);
  const nav = useNavigate();
  const seen = useRef(null);
  const items = data?.items || [];
  const unread = data?.unread ?? 0;

  useEffect(() => {
    if (!data) return;
    const ids = new Set(items.map((n) => n.id));
    if (seen.current) {
      items.filter((n) => !n.read && !seen.current.has(n.id)).forEach((n) =>
        toast(n.title, { description: n.body, action: n.lead_id ? { label: "Open", onClick: () => nav(`/leads/whatsapp/${n.lead_id}`) } : undefined }));
    }
    seen.current = ids;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [data]);

  const openItem = async (n) => {
    setOpen(false);
    if (!n.read) { try { await api.patch(`/lead-capture/notifications/${n.id}/read`, {}); reload(); } catch (e) { toast.error(apiError(e)); } }
    if (n.lead_id) nav(`/leads/whatsapp/${n.lead_id}`);
  };

  return (
    <div className="relative">
      <button data-testid="notification-bell" aria-label="Lead notifications" onClick={() => setOpen((o) => !o)} className="p-2 rounded-lg hover:bg-muted relative">
        <Bell className="h-5 w-5" />
        {unread > 0 && <span data-testid="notification-unread" className="absolute -top-0.5 -right-0.5 min-w-[16px] h-4 px-1 rounded-full bg-[#DC2626] text-white text-[10px] flex items-center justify-center">{unread > 99 ? "99+" : unread}</span>}
      </button>
      {open && (
        <>
          <div className="fixed inset-0 z-40" onClick={() => setOpen(false)} />
          <div className="absolute right-0 mt-2 w-80 max-w-[90vw] z-50 rounded-lg border border-border bg-background shadow-lg max-h-96 overflow-y-auto" data-testid="notification-panel">
            <div className="px-3 py-2 text-xs font-semibold border-b border-border">Lead notifications</div>
            {error && !data && <div className="p-3 text-xs text-red-600">{error}</div>}
            {data && !items.length && <div className="p-4 text-xs text-muted-foreground">No notifications.</div>}
            {items.map((n) => (
              <button key={n.id} onClick={() => openItem(n)} data-testid={`notification-${n.id}`} className={`block w-full text-left px-3 py-2 border-b border-border last:border-0 hover:bg-muted ${n.read ? "opacity-60" : ""}`}>
                <div className="text-sm font-medium">{n.title}{n.display_id ? ` - ${n.display_id}` : ""}</div>
                <div className="text-xs text-muted-foreground">{n.body}</div>
                <div className="text-[10px] text-muted-foreground mt-0.5">{fmt(n.created_at)}</div>
              </button>
            ))}
          </div>
        </>
      )}
    </div>
  );
}
