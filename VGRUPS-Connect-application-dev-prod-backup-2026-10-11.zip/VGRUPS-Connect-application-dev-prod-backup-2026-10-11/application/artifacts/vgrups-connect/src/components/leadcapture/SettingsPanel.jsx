import React, { useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import api, { apiError } from "../../lib/api";
import { usePoll, fmt } from "../../lib/leadCapture";
import { Card } from "../ui/card";
import { Button } from "../ui/button";
import { ErrorBox, Skeleton } from "./Bits";

const Check = ({ id, checked, onChange, disabled, children }) => (
  <label className="flex items-start gap-2 text-sm" htmlFor={id}>
    <input id={id} data-testid={id} type="checkbox" className="mt-1" checked={!!checked} disabled={disabled} onChange={(e) => onChange(e.target.checked)} />
    <span>{children}</span>
  </label>
);

export default function SettingsPanel({ canManage }) {
  const { data, error, loading, reload } = usePoll("/lead-capture/settings", null, 5000);
  const [draft, setDraft] = useState(null);
  const [dirty, setDirty] = useState(false);
  const [confirm, setConfirm] = useState(false);
  const [saving, setSaving] = useState(false);
  const dirtyRef = useRef(false);
  dirtyRef.current = dirty;

  // Only seed the draft from the server when there are no unsaved edits.
  useEffect(() => { if (data && !dirtyRef.current) setDraft(data); }, [data]);
  const set = (k, v) => { setDraft((d) => ({ ...d, [k]: v })); setDirty(true); };

  if (error && !data) return <ErrorBox message={error} onRetry={reload} />;
  if (loading || !draft) return <Skeleton rows={4} />;
  const enabling = draft.enabled && (!data.enabled || (draft.ask_missing_phone && !data.ask_missing_phone) || (draft.voice_enabled && !data.voice_enabled) || (draft.ai_auto_reply && !data.ai_auto_reply));
  const needConfirm = enabling && !confirm;
  const invalid = draft.enabled && !draft.authorized_messages_confirmed;

  const save = async () => {
    setSaving(true);
    try {
      const body = { enabled: !!draft.enabled, authorized_messages_confirmed: !!draft.authorized_messages_confirmed, ask_missing_phone: !!draft.ask_missing_phone, voice_enabled: !!draft.voice_enabled, ai_auto_reply: !!draft.ai_auto_reply };
      if (enabling) body.confirm_enable = true;
      const r = await api.put("/lead-capture/settings", body);
      setDraft(r.data); setDirty(false); setConfirm(false); toast.success("Settings saved"); reload();
    } catch (e) { toast.error(apiError(e)); } finally { setSaving(false); }
  };

  return (
    <Card className="p-5 space-y-4 max-w-2xl" data-testid="lc-settings">
      <div>
        <h3 className="font-semibold">WhatsApp lead capture setup</h3>
        <p className="text-xs text-muted-foreground">Capture is off by default. {data.enabled_since ? `Enabled since ${fmt(data.enabled_since)}.` : "It has never been enabled."}</p>
      </div>
      {!data.ai_configured && <ErrorBox message="AI extraction is not configured. Messages will land in the Review Queue." />}
      <Check id="lc-set-consent" checked={draft.authorized_messages_confirmed} disabled={!canManage} onChange={(v) => set("authorized_messages_confirmed", v)}>
        I confirm capture only processes legitimately authorized company-app messages, sent or received, in business conversations associated with MRs. Personal chats are never read.
      </Check>
      <Check id="lc-set-enabled" checked={draft.enabled} disabled={!canManage || !draft.authorized_messages_confirmed} onChange={(v) => { set("enabled", v); setConfirm(false); }}>
        Enable WhatsApp lead capture
      </Check>
      <Check id="lc-set-askphone" checked={draft.ask_missing_phone} disabled={!canManage} onChange={(v) => set("ask_missing_phone", v)}>
        Ask for the phone number when a lead is missing one
      </Check>
      <Check id="lc-set-ai-reply" checked={draft.ai_auto_reply} disabled={!canManage || (!data.ai_reply_configured && !draft.ai_auto_reply)} onChange={(v) => { set("ai_auto_reply", v); setConfirm(false); }}>
        Automatically reply to MR messages with OpenAI
        <span className="block text-xs text-muted-foreground">Uses recent chat context and the MR&apos;s own lead/report information. Existing menu choices and draft answers remain unchanged. AI guides report submission; it does not submit reports itself. Human takeover pauses replies.</span>
      </Check>
      {!data.ai_reply_configured && <p className="text-xs text-amber-700">A personal OpenAI key is required for automatic replies. Configure it securely, not in chat.</p>}
      <Check id="lc-set-voice" checked={draft.voice_enabled} disabled={!canManage} onChange={(v) => set("voice_enabled", v)}>
        Allow voice phone-number requests
        <span className="block text-xs text-amber-700">Voice is awaiting connection, caller and HTTPS configuration (status: {String(draft.voice_status).replace(/_/g, " ")}). No call is reported as placed until the provider confirms.</span>
      </Check>
      {enabling && (
        <div className="rounded-lg border border-amber-300 bg-amber-50 dark:bg-amber-950/20 p-3 text-sm space-y-2">
          <p>This starts lead creation and/or automatic requests and AI replies sent to MRs. AI usage is billed to your OpenAI account. Confirm to proceed.</p>
          <Check id="lc-set-confirm" checked={confirm} onChange={setConfirm}>Yes, activate now</Check>
        </div>
      )}
      {!canManage ? <p className="text-xs text-muted-foreground">Only administrators with settings permission can change these.</p> : (
        <div className="flex gap-2">
          <Button data-testid="lc-set-save" disabled={!dirty || saving || invalid || needConfirm} onClick={save} className="bg-[#3B5B2A] hover:bg-[#2D4720]">{saving ? "Saving..." : "Save settings"}</Button>
          {dirty && <Button variant="outline" onClick={() => { setDraft(data); setDirty(false); setConfirm(false); }}>Discard</Button>}
        </div>
      )}
      {canManage && (
        <section className="border-t pt-4 space-y-2" data-testid="lc-ai-reply-activity">
          <h4 className="text-sm font-semibold">Recent MR AI replies</h4>
          <p className="text-xs text-muted-foreground">Accepted means the provider accepted the message, not that the MR read it. Sending or uncertain attempts are never automatically resent. Accepted replies appear in Inbox.</p>
          {!(data.ai_reply_activity || []).length ? <p className="text-xs text-muted-foreground">No automatic replies yet.</p> : (
            <ul className="space-y-2">
              {data.ai_reply_activity.map((row) => (
                <li key={row.id} className="rounded border p-3 text-xs space-y-1 break-words">
                  <div className="flex flex-wrap justify-between gap-1"><strong>{row.mr_name || "MR"}</strong><span>{String(row.status || "").replace(/_/g, " ")}</span></div>
                  <p className="text-muted-foreground">{fmt(row.created_at)}</p>
                  {row.reply && <p className="whitespace-pre-wrap">{row.reply}</p>}
                  {row.error && <p className="text-amber-700">{row.error}</p>}
                </li>
              ))}
            </ul>
          )}
        </section>
      )}
    </Card>
  );
}
