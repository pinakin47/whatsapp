import React, { useState } from "react";
import { toast } from "sonner";
import api, { apiError } from "../../lib/api";
import { fmt } from "../../lib/leadCapture";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Card } from "../ui/card";
import { Empty, ErrorBox, LeadLink, Pill, RequestsTable, Skeleton } from "./Bits";

const wrap = (res, render, rows) => {
  if (res.error && !res.data) return <ErrorBox message={res.error} onRetry={res.reload} />;
  if (!res.data) return <Skeleton rows={rows} />;
  return render(res.data);
};

const FIELDS = ["contact_name", "hospital_name", "clinic_name", "doctor_name", "mobile", "location", "requirement", "product_interest", "quantity"];
const RETRYABLE = ["needs_verification", "ai_extraction_failed", "ownership_conflict"];

function ApproveForm({ row, opts, onDone }) {
  const ex = row.extracted || {};
  const [f, setF] = useState(() => Object.fromEntries([...FIELDS, "lead_type", "priority"].map((k) => [k, ex[k] ?? ""])));
  const [ok, setOk] = useState(false);
  const [busy, setBusy] = useState(false);
  const submit = async () => {
    setBusy(true);
    try {
      const body = { confirm_verified: true };
      Object.entries(f).forEach(([k, v]) => { if (v !== "" && v != null) body[k] = v; });
      const r = await api.post(`/lead-capture/review/${row.id}/approve`, body);
      toast.success("Lead approved and verified"); onDone(r.data?.lead_id);
    } catch (e) { toast.error(apiError(e)); } finally { setBusy(false); }
  };
  const lbl = (k) => k.replace(/_/g, " ");
  return (
    <div className="mt-3 border-t border-border pt-3 space-y-2" data-testid={`lc-approve-${row.id}`}>
      <div className="text-xs font-semibold">Correct and approve</div>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
        {FIELDS.map((k) => <div key={k}><label className="text-xs text-muted-foreground capitalize">{lbl(k)}</label><Input value={f[k]} onChange={(e) => setF({ ...f, [k]: e.target.value })} /></div>)}
        {[["lead_type", opts?.lead_types], ["priority", opts?.priorities]].map(([k, list]) => <div key={k}><label className="text-xs text-muted-foreground capitalize">{lbl(k)}</label>
          <select className="h-9 w-full rounded-md border border-input bg-background px-2 text-sm" value={f[k]} onChange={(e) => setF({ ...f, [k]: e.target.value })}><option value="">-</option>{(list || []).map((x) => <option key={x} value={x}>{x}</option>)}</select></div>)}
      </div>
      <label className="flex items-start gap-2 text-sm"><input type="checkbox" className="mt-1" checked={ok} onChange={(e) => setOk(e.target.checked)} data-testid={`lc-verified-${row.id}`} />I verified this corrected information against the original message.</label>
      <Button size="sm" disabled={!ok || busy} onClick={submit} data-testid={`lc-approve-btn-${row.id}`} className="bg-[#3B5B2A] hover:bg-[#2D4720]">{busy ? "Approving..." : "Approve and create lead"}</Button>
    </div>
  );
}

export function ReviewPanel({ res, canManage, opts }) {
  const [busy, setBusy] = useState(null);
  const [open, setOpen] = useState(null);
  const retry = async (id) => {
    setBusy(id);
    try { await api.post(`/lead-capture/review/${id}/retry`, {}); toast.success("Extraction retried"); res.reload(); }
    catch (e) { toast.error(apiError(e)); } finally { setBusy(null); }
  };
  return wrap(res, (d) => !d.items.length ? <Empty title="Review queue is clear" hint="Messages that could not be extracted automatically show up here." /> : (
    <div className="space-y-2">{d.items.map((r) => (
      <Card key={r.id} className="p-3 text-sm" data-testid={`lc-review-${r.id}`}>
        <div className="flex flex-wrap items-center gap-2"><b>{r.mr_name || "MR"}</b><Pill value={r.status} /><span className="text-xs text-muted-foreground">{fmt(r.created_at)}</span>
          {r.lead_id && <LeadLink id={r.lead_id} display="Open lead" />}
          {RETRYABLE.includes(r.status) && <Button size="sm" variant="outline" className="ml-auto" disabled={busy === r.id} onClick={() => retry(r.id)}>{busy === r.id ? "Retrying..." : "Retry extraction"}</Button>}</div>
        <p className="mt-1 whitespace-pre-wrap break-words">{r.body}</p>
        {r.error && <p className="text-xs text-red-600 mt-1">{r.error}</p>}
        {r.extracted && <pre className="mt-2 text-xs bg-muted/50 rounded p-2 overflow-x-auto">{JSON.stringify(r.extracted, null, 2)}</pre>}
        {canManage && !r.lead_id && r.status !== "completed" && (open === r.id ? <ApproveForm row={r} opts={opts} onDone={() => { setOpen(null); res.reload(); }} /> : <Button size="sm" className="mt-2" variant="outline" data-testid={`lc-open-approve-${r.id}`} onClick={() => setOpen(r.id)}>Correct and approve</Button>)}
      </Card>))}</div>), 4);
}

export const RequestsPanel = ({ res }) => wrap(res, (d) => <RequestsTable items={d.items} showLead />, 4);

export const ActivityPanel = ({ res }) => wrap(res, (d) => !d.items.length ? <Empty title="No WhatsApp activity yet" hint="Messages from MRs appear here after capture is enabled." /> : (
  <div className="space-y-2">{d.items.map((a) => (
    <Card key={a.id} className="p-3 text-sm" data-testid={`lc-activity-${a.id}`}>
      <div className="text-xs text-muted-foreground">{a.mr_name || a.sender || "-"} - {a.direction} - {fmt(a.created_at)}</div>
      <p className="whitespace-pre-wrap break-words">{a.body}</p></Card>))}</div>), 5);

export const AnalyticsPanel = ({ res }) => wrap(res, (d) => (
  <div className="space-y-4" data-testid="lc-analytics">
    <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
      {[["Total", d.total], ["Missing phone", d.missing_phone], ["Phone completed", d.phone_completed], ["Needs verification", d.needs_verification], ["Hot", d.hot], ["Follow-up due", d.followup_due], ["Converted", d.converted], ["Lost", d.lost]].map(([k, v]) => (
        <Card key={k} className="p-3"><div className="text-xl font-bold">{v ?? 0}</div><div className="text-xs text-muted-foreground">{k}</div></Card>))}
    </div>
    {!(d.by_mr || []).length ? <Empty title="No per-MR data yet" /> : (
      <div className="overflow-x-auto rounded-lg border border-border"><table className="w-full text-sm">
        <thead className="bg-muted/50 text-xs text-muted-foreground"><tr><th className="text-left p-2">MR</th><th className="text-right p-2">Total</th><th className="text-right p-2">Converted</th><th className="text-right p-2">Missing phone</th></tr></thead>
        <tbody>{d.by_mr.map((m) => <tr key={m.mr_id ?? m.mr_name} className="border-t border-border"><td className="p-2">{m.mr_name}</td><td className="p-2 text-right">{m.total}</td><td className="p-2 text-right">{m.converted}</td><td className="p-2 text-right">{m.missing_phone}</td></tr>)}</tbody>
      </table></div>)}
  </div>), 3);
