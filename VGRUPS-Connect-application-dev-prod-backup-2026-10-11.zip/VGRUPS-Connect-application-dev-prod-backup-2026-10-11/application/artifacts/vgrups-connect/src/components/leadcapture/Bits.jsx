import React from "react";
import { Link } from "react-router-dom";
import { Button } from "../ui/button";
import { label, requestText, fmt } from "../../lib/leadCapture";

const TONE = {
  won: "bg-green-100 text-green-800", lost: "bg-red-100 text-red-800", new: "bg-blue-100 text-blue-800",
  urgent: "bg-red-100 text-red-800", high: "bg-amber-100 text-amber-800", follow_up: "bg-purple-100 text-purple-800",
};

export const Pill = ({ value, tone }) => (
  <span className={`inline-block rounded px-2 py-0.5 text-[11px] font-medium ${TONE[tone || value] || "bg-muted text-foreground"}`}>{label(value)}</span>
);

export const ErrorBox = ({ message, onRetry }) => (
  <div className="rounded-lg border border-red-200 bg-red-50 dark:bg-red-950/20 p-4 text-sm text-red-700 flex items-center gap-3" data-testid="lc-error">
    <span className="flex-1">{message}</span>{onRetry && <Button size="sm" variant="outline" onClick={onRetry}>Retry</Button>}
  </div>
);

export const Empty = ({ title, hint }) => (
  <div className="rounded-lg border border-dashed border-border p-10 text-center" data-testid="lc-empty">
    <div className="text-sm font-semibold">{title}</div>
    {hint && <div className="text-xs text-muted-foreground mt-1">{hint}</div>}
  </div>
);

export const Skeleton = ({ rows = 5 }) => (
  <div className="space-y-2" data-testid="lc-loading">
    {Array.from({ length: rows }).map((_, i) => <div key={i} className="h-11 rounded bg-muted animate-pulse" />)}
  </div>
);

export const LeadLink = ({ id, display }) => (
  <Link to={`/leads/whatsapp/${id}`} className="font-medium text-[#3B5B2A] dark:text-[#8BAA78] hover:underline">{display || `#${id}`}</Link>
);

export function RequestsTable({ items, showLead }) {
  if (!items.length) return <Empty title="No requests yet" hint="Phone-number requests appear here once queued." />;
  return (
    <div className="overflow-x-auto rounded-lg border border-border">
      <table className="w-full text-sm">
        <thead className="bg-muted/50 text-xs text-muted-foreground"><tr>
          {showLead && <th className="text-left p-2">Lead</th>}{showLead && <th className="text-left p-2">MR</th>}
          <th className="text-left p-2">Channel</th><th className="text-left p-2">Status</th><th className="text-left p-2">Time</th></tr></thead>
        <tbody>{items.map((r) => (
          <tr key={r.id} className="border-t border-border align-top" data-testid={`lc-request-${r.id}`}>
            {showLead && <td className="p-2"><LeadLink id={r.lead_id} display={r.display_id} /></td>}
            {showLead && <td className="p-2">{r.mr_name || "-"}</td>}
            <td className="p-2">{r.channel === "voice" ? "Voice (IVR)" : "WhatsApp"}</td>
            <td className="p-2">{requestText(r)}{r.error && <div className="text-xs text-red-600">{r.error}</div>}</td>
            <td className="p-2 whitespace-nowrap">{fmt(r.created_at)}</td>
          </tr>))}</tbody>
      </table>
    </div>
  );
}
