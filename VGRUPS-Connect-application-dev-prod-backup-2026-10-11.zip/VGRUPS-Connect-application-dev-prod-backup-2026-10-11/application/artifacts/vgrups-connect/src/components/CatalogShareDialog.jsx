import React, { useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import api, { apiError } from "../lib/api";
import { useAuth } from "../context/AuthContext";
import { catalogSendRequest, lookupCatalogSendRequest } from "../lib/catalogSendRequest";
import { Link } from "react-router-dom";
import { trackEvent, catalogShareFailureCategory } from "../lib/analytics";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "./ui/dialog";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { useSenders, SenderSelect, resolveSender, findSender, senderLabel } from "../lib/useSenders";

function productMessage(product) {
  return [
    product.name,
    product.code && `Code: ${product.code}`,
    product.category && `Category: ${product.category}`,
    product.description,
    product.pack_size && `Pack: ${product.pack_size}`,
    `Price: ₹${product.selling_price}`,
    `MRP: ₹${product.mrp}`,
    `Stock: ${product.stock}`,
  ].filter(Boolean).join("\n");
}

export default function CatalogShareDialog({ product, onClose }) {
  const { can, user } = useAuth();
  const [mode, setMode] = useState(can("crm", "view") ? "contact" : "phone");
  const [search, setSearch] = useState("");
  const [contacts, setContacts] = useState([]);
  const [selected, setSelected] = useState(null);
  const [phone, setPhone] = useState("");
  const [contactsLoading, setContactsLoading] = useState(true);
  const [contactsError, setContactsError] = useState("");
  const [connection, setConnection] = useState(null);
  const [connectionError, setConnectionError] = useState("");
  const [error, setError] = useState("");
  const [sending, setSending] = useState(false);
  const [checking, setChecking] = useState(false);
  const [pendingAttempt, setPendingAttempt] = useState(null);
  const [outcome, setOutcome] = useState(null);
  const sendingRef = useRef(false);
  const busy = sending || checking;
  const openedTrackedRef = useRef(false);
  const message = productMessage(product);
  const normalizedPhone = phone.replace(/[\s().-]/g, "");
  const validPhone = /^\+[1-9][0-9]{7,14}$/.test(normalizedPhone);
  const senders = useSenders();
  const senderSlot = `catalog-sender:${user?.id}:${product.id}`;
  const [senderPick, setSenderPick] = useState(() => { try { return sessionStorage.getItem(senderSlot) || ""; } catch { return ""; } });
  const sid = resolveSender(senders, senderPick);
  useEffect(() => { if (sid) { try { sessionStorage.setItem(senderSlot, sid); } catch {} } }, [sid, senderSlot]);
  const sender = findSender(senders, sid);
  const ready = senders.items.length ? sender?.status === "connected" : !!connection?.active;
  const sessionPart = sid ? { session_id: sid } : {};
  const payload = { body: message, ...sessionPart, ...(mode === "contact" ? { contact_id: selected?.id } : { phone: normalizedPhone }) };

  useEffect(() => {
    let cancelled = false;
    setPendingAttempt(null);
    setOutcome(null);
    if (!user?.id || (mode === "contact" ? !selected : !validPhone)) return;
    const snapshot = { body: message, ...sessionPart, ...(mode === "contact" ? { contact_id: selected.id } : { phone: normalizedPhone }) };
    lookupCatalogSendRequest(user.id, product.id, snapshot)
      .then(attempt => { if (!cancelled && attempt) setPendingAttempt({ ...attempt, payload: snapshot }); })
      .catch(() => { if (!cancelled) setError("Cannot read saved send state. Do not start another send until storage is available."); });
    return () => { cancelled = true; };
  }, [user?.id, product.id, message, mode, selected?.id, normalizedPhone, validPhone, sid]);

  useEffect(() => {
    if (openedTrackedRef.current) return;
    openedTrackedRef.current = true;
    trackEvent("catalog_share_opened", { recipient_mode: mode });
  }, [mode]);

  const checkConnection = async () => {
    setConnection(null);
    setConnectionError("");
    try {
      const { data } = await api.get("/whatsapp/status");
      setConnection(data);
      if (!data.active) setConnectionError("No WhatsApp connection. Connect in WhatsApp → Connections, or configure the existing Cloud API.");
    } catch (e) { setConnectionError(`Cannot check WhatsApp connection: ${apiError(e)}`); }
  };
  useEffect(() => { checkConnection(); }, []);
  useEffect(() => {
    if (mode !== "contact") return;
    let cancelled = false;
    setContactsLoading(true);
    setContactsError("");
    const timer = setTimeout(async () => {
      try {
        const { data } = await api.get(`/contacts?search=${encodeURIComponent(search)}&limit=100`);
        if (!cancelled) setContacts(data.items.filter(c => !c.is_demo && !c.deleted));
      } catch (e) {
        if (!cancelled) { setContacts([]); setContactsError(`Cannot load contacts: ${apiError(e)}`); }
      } finally { if (!cancelled) setContactsLoading(false); }
    }, 250);
    return () => { cancelled = true; clearTimeout(timer); };
  }, [mode, search]);

  const send = async (event) => {
    event.preventDefault();
    if (sendingRef.current || outcome?.state === "accepted" || !can("inbox", "send") || !ready) return;
    if (mode === "contact" ? !selected : !validPhone) {
      setError("Choose a contact or enter a valid international number with + and country code.");
      return;
    }
    sendingRef.current = true;
    setSending(true);
    setError("");
    let stage = "preparation";
    let accepted = false;
    try {
      const attempt = await catalogSendRequest(user.id, product.id, payload);
      setPendingAttempt({ ...attempt, payload });
      stage = "request";
      const { data } = await api.post("/whatsapp/send", { ...payload, request_key: attempt.key });
      stage = "confirmation";
      if (!data.wamid || !["sent", "delivered", "read"].includes(data.status)) {
        throw new Error("WhatsApp did not confirm acceptance. Check Inbox before retrying.");
      }
      accepted = true;
      trackEvent("catalog_share_send_accepted", { recipient_mode: mode });
      attempt.complete();
      toast.success(`WhatsApp accepted the product message for ${mode === "contact" ? selected.name : normalizedPhone}.`);
      onClose();
    } catch (e) {
      // Local cleanup/UI errors after acceptance are not failed sends.
      if (!accepted) {
        trackEvent("catalog_share_send_failed", {
          recipient_mode: mode,
          failure_category: catalogShareFailureCategory(e, stage),
        });
      }
      setError(`Send failed: ${apiError(e)} Check Inbox if the result is uncertain. Retrying this same recipient and message reuses the original request; it will not send a second copy.`);
    } finally { sendingRef.current = false; setSending(false); }
  };

  const recover = async () => {
    if (sendingRef.current || !pendingAttempt || !can("inbox", "send")) return;
    sendingRef.current = true;
    setChecking(true);
    setError("");
    try {
      const { data } = await api.post("/whatsapp/send/recover", {
        ...pendingAttempt.payload, request_key: pendingAttempt.key,
      });
      if (data.state === "accepted" && data.message?.wamid) {
        // Keep the recipient locked after confirmation; only Close ends this attempt.
        setOutcome({ state: "accepted", detail: "WhatsApp acceptance is confirmed for this original request. No message was resent. Acceptance does not confirm delivery or reading." });
        toast.success("Original WhatsApp send confirmed — no resend.");
      } else {
        setOutcome({ state: "unresolved", detail: data.detail || "Acceptance is still unresolved. The reservation is retained; no message was resent." });
      }
    } catch (e) {
      setError(`Cannot confirm the send: ${apiError(e)} The saved request key has not been cleared. No recovery resend was attempted.`);
    } finally { sendingRef.current = false; setChecking(false); }
  };

  const close = () => {
    if (sendingRef.current) return;
    if (outcome?.state === "accepted") pendingAttempt?.complete();
    onClose();
  };

  return (
    <Dialog open onOpenChange={(open) => { if (!open) close(); }}>
      <DialogContent className="max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Share on WhatsApp</DialogTitle>
          <DialogDescription>Send {product.name} through your existing WhatsApp connection. Only message recipients who expect to hear from you.</DialogDescription>
        </DialogHeader>
        <form onSubmit={send} className="space-y-4">
          <SenderSelect senders={senders} value={senderPick} onChange={setSenderPick} disabled={busy || !!pendingAttempt || outcome?.state === "accepted"} testId="catalog-share-sender" />
          {sender && <p className="text-xs text-muted-foreground">This will be sent from {senderLabel(sender)}.</p>}
          <fieldset disabled={busy || outcome?.state === "accepted"} className="space-y-3">
            <legend className="text-sm font-medium mb-2">Recipient</legend>
            <div className="flex gap-4 text-sm">
              {can("crm", "view") && <label className="flex gap-2"><input type="radio" name="recipient-mode" checked={mode === "contact"} onChange={() => { setMode("contact"); setError(""); }} /> Real contact</label>}
              <label className="flex gap-2"><input type="radio" name="recipient-mode" checked={mode === "phone"} onChange={() => { setMode("phone"); setError(""); }} /> International number</label>
            </div>
            {mode === "contact" ? <>
              <label htmlFor="share-contact-search" className="text-sm">Search contacts</label>
              <Input id="share-contact-search" value={search} onChange={e => setSearch(e.target.value)} placeholder="Name or mobile number" />
              {selected && <p className="text-sm">Selected: {selected.name} — {selected.mobile}</p>}
              {contactsError && <p role="alert" className="text-sm text-destructive">{contactsError} You can enter a number instead.</p>}
              <div className="max-h-36 overflow-y-auto border rounded-md">
                {contactsLoading ? <p className="p-3 text-sm">Loading contacts…</p> : contacts.length ? contacts.map(contact =>
                  <button key={contact.id} type="button" aria-pressed={selected?.id === contact.id} onClick={() => { setSelected(contact); setError(""); }} className={`block w-full text-left p-2 text-sm hover:bg-muted ${selected?.id === contact.id ? "bg-muted" : ""}`}>
                    {contact.name} — {contact.mobile || "No mobile number"}
                  </button>) : <p className="p-3 text-sm">No real contacts found. Search again or enter a number.</p>}
              </div>
              <p className="text-xs text-muted-foreground">Saved mobile numbers must include a country code. If a contact has a local-only number, use International number instead.</p>
            </> : <>
              <label htmlFor="share-phone" className="text-sm">Phone number including country code</label>
              <Input id="share-phone" type="tel" autoComplete="tel" value={phone} onChange={e => { setPhone(e.target.value); setError(""); }} placeholder="+919876543210" aria-invalid={Boolean(phone) && !validPhone} />
              <p className="text-xs text-muted-foreground">Start with + and country code; use 8–15 digits. No country code is added automatically.</p>
            </>}
          </fieldset>
          <div>
            <p className="text-sm font-medium mb-2">Message preview</p>
            <pre className="whitespace-pre-wrap break-words bg-muted rounded-md p-3 text-sm font-sans">{message}</pre>
          </div>
          {!can("inbox", "send") && <p role="alert" className="text-sm text-destructive">You do not have permission to send Inbox messages.</p>}
          {!connection && !connectionError && <p className="text-sm">Checking WhatsApp connection…</p>}
          {connectionError && <div><p role="alert" className="text-sm text-destructive">{connectionError}</p><Button type="button" variant="outline" size="sm" disabled={busy} onClick={checkConnection}>Check connection again</Button></div>}
          {pendingAttempt && outcome?.state !== "accepted" && <div className="rounded-md border p-3 space-y-2" data-testid="catalog-share-recovery">
            <p className="text-sm">A saved attempt exists for this recipient and message. Check its outcome without sending again.</p>
            <Button type="button" variant="outline" disabled={busy || !can("inbox", "send")} onClick={recover} data-testid="catalog-share-check-outcome">{checking ? "Checking…" : "Check send outcome"}</Button>
          </div>}
          {outcome && <p role="status" data-testid={`catalog-share-${outcome.state}`} className="rounded-md bg-muted p-3 text-sm">{outcome.detail}</p>}
          {pendingAttempt && !busy && can("inbox", "view") && <Link to="/inbox" className="inline-block text-sm underline" onClick={close}>Open Inbox to check the message</Link>}
          {error && <p role="alert" className="text-sm text-destructive">{error}</p>}
          <p className="text-xs text-muted-foreground">Acceptance does not confirm delivery or reading. Check the message in Inbox.</p>
          <div className="flex justify-end gap-2">
            <Button type="button" variant="outline" disabled={busy} onClick={close}>{outcome?.state === "accepted" ? "Close" : "Cancel"}</Button>
            <Button type="submit" data-testid="catalog-share-send" disabled={busy || outcome?.state === "accepted" || !can("inbox", "send") || !ready || (mode === "contact" ? !selected : !validPhone)}>{sending ? "Sending…" : pendingAttempt ? "Retry same request" : "Send product"}</Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}