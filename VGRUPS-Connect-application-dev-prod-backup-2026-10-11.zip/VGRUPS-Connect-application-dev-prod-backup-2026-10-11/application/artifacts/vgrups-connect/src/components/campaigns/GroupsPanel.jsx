import React, { useEffect, useRef, useState } from "react";
import api, { apiError } from "../../lib/api";
import { toast } from "sonner";
import { useAuth } from "../../context/AuthContext";
import ConfirmDialog from "../ConfirmDialog";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Label } from "../ui/label";
import { Checkbox } from "../ui/checkbox";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "../ui/dialog";
import { Users, Plus, Pencil, Trash2, Loader2, Search, ArrowLeft } from "lucide-react";

export default function GroupsPanel({ open, onOpenChange, groups, reload }) {
  const { can } = useAuth();
  const canWrite = can("campaigns", "create") || can("campaigns", "edit");
  const [editing, setEditing] = useState(null); // null list view, {} new, group edit
  const [name, setName] = useState("");
  const [selected, setSelected] = useState([]);
  const [search, setSearch] = useState("");
  const [contacts, setContacts] = useState([]);
  const [known, setKnown] = useState({});
  const [loadingC, setLoadingC] = useState(false);
  const [cErr, setCErr] = useState("");
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState("");
  const [del, setDel] = useState(null);
  const timer = useRef();

  useEffect(() => { if (!open) setEditing(null); }, [open]);

  useEffect(() => {
    if (!editing) return;
    clearTimeout(timer.current);
    timer.current = setTimeout(() => {
      setLoadingC(true); setCErr("");
      api.get("/contacts", { params: { search, limit: 100 } }).then((r) => {
        const items = r.data.items || [];
        setContacts(items);
        setKnown((k) => { const n = { ...k }; items.forEach((c) => { n[c.id] = c; }); return n; });
      }).catch((e) => setCErr(apiError(e))).finally(() => setLoadingC(false));
    }, 250);
    return () => clearTimeout(timer.current);
  }, [search, editing]);

  const start = (g) => { setEditing(g || {}); setName(g?.name || ""); setSelected(g?.contact_ids || []); setSearch(""); setErr(""); };
  const toggle = (id) => setSelected((s) => (s.includes(id) ? s.filter((x) => x !== id) : [...s, id]));

  const save = async () => {
    setSaving(true); setErr("");
    const body = { name: name.trim(), contact_ids: selected };
    try {
      if (editing.id) await api.put(`/campaign-groups/${editing.id}`, body); else await api.post("/campaign-groups", body);
      toast.success("Group saved"); await reload(); setEditing(null);
    } catch (e) { setErr(apiError(e)); } finally { setSaving(false); }
  };
  const confirmDelete = async () => {
    const g = del; setDel(null);
    try { await api.delete(`/campaign-groups/${g.id}`); toast.success("Group deleted"); reload(); }
    catch (e) { toast.error(apiError(e)); }
  };

  return (
    <>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          {!editing ? (
            <>
              <DialogHeader><DialogTitle>Contact groups</DialogTitle><DialogDescription>Build a group first, then pick it as the audience for a broadcast.</DialogDescription></DialogHeader>
              <div className="space-y-2">
                {groups.map((g) => (
                  <div key={g.id} className="flex items-center justify-between rounded-lg border border-border p-3" data-testid={`group-row-${g.id}`}>
                    <div className="min-w-0"><div className="font-medium truncate">{g.name}</div><div className="text-xs text-muted-foreground">{(g.contact_ids || []).length} members</div></div>
                    <div className="flex">
                      {can("campaigns", "edit") && <Button size="icon" variant="ghost" data-testid={`group-edit-${g.id}`} onClick={() => start(g)}><Pencil className="h-4 w-4" /></Button>}
                      {can("campaigns", "delete") && <Button size="icon" variant="ghost" data-testid={`group-delete-${g.id}`} onClick={() => setDel(g)}><Trash2 className="h-4 w-4 text-destructive" /></Button>}
                    </div>
                  </div>
                ))}
                {groups.length === 0 && <div className="text-center py-8 text-sm text-muted-foreground"><Users className="h-6 w-6 mx-auto mb-2 opacity-40" />No groups yet. Create one to start a broadcast.</div>}
              </div>
              {can("campaigns", "create") && <DialogFooter><Button data-testid="group-new-button" onClick={() => start(null)} className="bg-[#3B5B2A] hover:bg-[#2D4720]"><Plus className="h-4 w-4 mr-1" /> New group</Button></DialogFooter>}
            </>
          ) : (
            <>
              <DialogHeader><DialogTitle className="flex items-center gap-2"><Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => setEditing(null)}><ArrowLeft className="h-4 w-4" /></Button>{editing.id ? "Edit group" : "New group"}</DialogTitle>
                <DialogDescription>Contacts who have opted out stay in the group but are never sent to.</DialogDescription></DialogHeader>
              <div><Label>Group name</Label><Input data-testid="group-name-input" value={name} onChange={(e) => setName(e.target.value)} /></div>
              <div>
                <div className="flex items-center justify-between mb-1"><Label>Contacts</Label><span className="text-xs font-medium text-[#3B5B2A]" data-testid="group-member-count">{selected.length} selected</span></div>
                <div className="relative"><Search className="h-4 w-4 absolute left-2.5 top-2.5 text-muted-foreground" /><Input className="pl-8" data-testid="group-contact-search" placeholder="Search contacts" value={search} onChange={(e) => setSearch(e.target.value)} /></div>
                <div className="mt-2 max-h-56 overflow-y-auto rounded-lg border border-border divide-y divide-border">
                  {loadingC && <div className="p-3 text-xs text-muted-foreground flex items-center gap-2"><Loader2 className="h-3 w-3 animate-spin" /> Loading</div>}
                  {cErr && <div className="p-3 text-xs text-destructive">{cErr}</div>}
                  {!loadingC && !cErr && contacts.length === 0 && <div className="p-3 text-xs text-muted-foreground">No contacts found</div>}
                  {contacts.map((c) => (
                    <label key={c.id} className="flex items-center gap-2 p-2 text-sm cursor-pointer hover:bg-muted/40">
                      <Checkbox checked={selected.includes(c.id)} onCheckedChange={() => toggle(c.id)} data-testid={`group-contact-${c.id}`} />
                      <span className="truncate flex-1">{c.name}{c.company ? <span className="text-muted-foreground"> / {c.company}</span> : null}</span>
                      <span className="text-[11px] text-muted-foreground">{c.phone}</span>
                    </label>
                  ))}
                </div>
                <div className="flex gap-3 mt-1">
                  <button type="button" className="text-xs text-[#3B5B2A] underline" onClick={() => setSelected((s) => Array.from(new Set([...s, ...contacts.map((c) => c.id)])))}>Select shown</button>
                  <button type="button" className="text-xs text-muted-foreground underline" onClick={() => setSelected([])}>Clear all</button>
                </div>
                {selected.length > 0 && <p className="text-[11px] text-muted-foreground mt-1 line-clamp-2">{selected.slice(0, 6).map((id) => known[id]?.name).filter(Boolean).join(", ")}{selected.length > 6 ? "..." : ""}</p>}
              </div>
              {err && <p className="text-sm text-destructive" data-testid="group-form-error">{err}</p>}
              <DialogFooter><Button data-testid="group-save-button" disabled={saving || !name.trim() || !canWrite} onClick={save} className="bg-[#3B5B2A] hover:bg-[#2D4720]">{saving ? <Loader2 className="h-4 w-4 animate-spin" /> : "Save group"}</Button></DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>
      <ConfirmDialog open={!!del} onOpenChange={(o) => !o && setDel(null)} title="Delete this group?" description={del ? `"${del.name}" will be deleted. Contacts themselves are not affected.` : ""} confirmLabel="Delete" destructive onConfirm={confirmDelete} testId="group-delete-confirm" />
    </>
  );
}
