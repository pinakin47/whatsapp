import React, { useRef } from "react";
import axios from "axios";
import api, { apiError } from "../../lib/api";
import { Button } from "../ui/button";
import { Progress } from "../ui/progress";
import { Paperclip, X, FileText, Image as ImageIcon } from "lucide-react";

export const MAX_FILES = 5;
const LIMITS = { "image/png": 5, "image/jpeg": 5, "image/webp": 5, "application/pdf": 10 };

// items: [{key,name,size,content_type,state:'uploading'|'ready'|'error',progress,id,error}]
export default function AttachmentPicker({ items, setItems }) {
  const input = useRef();
  const patch = (key, p) => setItems((list) => list.map((i) => (i.key === key ? { ...i, ...p } : i)));

  const upload = async (file, key) => {
    try {
      const { data: req } = await api.post("/campaigns/media/request-upload", { name: file.name, content_type: file.type, size: file.size });
      await axios.put(req.upload_url, file, {
        headers: { "Content-Type": file.type },
        onUploadProgress: (e) => patch(key, { progress: e.total ? Math.round((e.loaded / e.total) * 100) : 50 }),
      });
      const { data: meta } = await api.post(`/campaigns/media/${req.media_id}/complete`, {});
      if (meta.state !== "ready") throw new Error("File is not ready");
      patch(key, { state: "ready", progress: 100, id: meta.id || req.media_id });
    } catch (e) { patch(key, { state: "error", error: apiError(e) }); }
  };

  const onPick = (e) => {
    const files = Array.from(e.target.files || []);
    e.target.value = "";
    const room = MAX_FILES - items.length;
    const add = [];
    files.forEach((f, idx) => {
      const key = `${Date.now()}-${idx}-${f.name}`;
      const lim = LIMITS[f.type];
      let error = "";
      if (idx >= room) error = `Maximum ${MAX_FILES} attachments`;
      else if (!lim) error = "Only PNG, JPEG, WebP or PDF allowed";
      else if (f.size > lim * 1024 * 1024) error = `Larger than ${lim} MB limit`;
      add.push({ key, localUrl: (!error && f.type.startsWith('image/')) ? URL.createObjectURL(f) : '', name: f.name, size: f.size, content_type: f.type, state: error ? "error" : "uploading", progress: 0, error, file: error ? null : f });
    });
    setItems((l) => [...l, ...add]);
    add.forEach((a) => { if (a.file) upload(a.file, a.key); });
  };

  return (
    <div data-testid="attachment-picker">
      <input ref={input} type="file" multiple hidden accept="image/png,image/jpeg,image/webp,application/pdf" onChange={onPick} data-testid="attachment-input" />
      <Button type="button" size="sm" variant="outline" disabled={items.filter((i) => i.state !== "error").length >= MAX_FILES} onClick={() => input.current.click()}><Paperclip className="h-3.5 w-3.5 mr-1" /> Add images or PDF</Button>
      <p className="text-[11px] text-muted-foreground mt-1">Up to {MAX_FILES} files. PNG, JPEG, WebP up to 5 MB; PDF up to 10 MB.</p>
      <div className="space-y-2 mt-2">
        {items.map((i) => (
          <div key={i.key} className="rounded-lg border border-border p-2 text-xs" data-testid="attachment-item">
            <div className="flex items-center gap-2">
              {i.content_type === "application/pdf" ? <FileText className="h-4 w-4 shrink-0" /> : <ImageIcon className="h-4 w-4 shrink-0" />}
              <span className="truncate flex-1">{i.name}</span>
              <span className="text-muted-foreground">{((i.size || 0) / 1048576).toFixed(2)} MB</span>
              <Button type="button" size="icon" variant="ghost" className="h-6 w-6" aria-label={`Remove ${i.name}`} onClick={() => setItems((l) => l.filter((x) => x.key !== i.key))}><X className="h-3.5 w-3.5" /></Button>
            </div>
            {i.state === "uploading" && <Progress value={i.progress} className="h-1.5 mt-1.5" />}
            {i.state === "ready" && <div className="text-green-700 mt-1">Uploaded</div>}
            {i.state === "error" && <div className="text-destructive mt-1">{i.error}</div>}
          </div>
        ))}
      </div>
    </div>
  );
}
