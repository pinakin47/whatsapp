import React from "react";
import { useAuth } from "../../context/AuthContext";
import { StatusBadge, DemoBadge } from "../common";
import { Card } from "../ui/card";
import { Button } from "../ui/button";
import { Progress } from "../ui/progress";
import { Megaphone, Send, Reply, XCircle, Play, Pause, Trash2, Ban, Download, Paperclip, AlertTriangle, Clock, Pencil, FileBarChart } from "lucide-react";

function Stat({ icon: Icon, label, value }) {
  return (
    <div className="flex items-center gap-2">
      <Icon className="h-4 w-4 text-muted-foreground" />
      <div><div className="text-sm font-semibold">{Number(value || 0).toLocaleString("en-IN")}</div><div className="text-[10px] text-muted-foreground">{label}</div></div>
    </div>
  );
}

export const istText = (iso) => new Date(iso).toLocaleString("en-IN", { timeZone: "Asia/Kolkata", dateStyle: "medium", timeStyle: "short" }) + " IST";

export default function CampaignCard({ c, onAction, onDelete, onExport, onEdit, onReport }) {
  const { can } = useAuth();
  const s = c.stats || {};
  const done = (s.sent || 0) + (s.failed || 0) + (s.skipped || 0);
  const pct = s.total ? Math.round((done / s.total) * 100) : 0;
  const review = c.status === "attention_required";
  const editable = ["draft", "scheduled", "paused"].includes(c.status) && !(s.sent > 0 || s.uncertain > 0 || s.failed > 0);
  const files = c.attachment_details || c.attachments || [];
  return (
    <Card className="p-5" data-testid={`campaign-card-${c.id}`}>
      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-2 min-w-0">
          <div className="h-9 w-9 rounded-lg bg-[#F0F4EE] dark:bg-[#1D2B1E] flex items-center justify-center shrink-0"><Megaphone className="h-4 w-4 text-[#3B5B2A]" /></div>
          <div className="min-w-0">
            <div className="font-semibold flex items-center gap-2 truncate">{c.name} {c.is_demo && <DemoBadge />}</div>
            {c.scheduled_at && <div className="text-[11px] text-muted-foreground flex items-center gap-1"><Clock className="h-3 w-3" />{istText(c.scheduled_at)}</div>}
          </div>
        </div>
        {review ? <span className="text-xs rounded-full bg-amber-100 text-amber-800 px-2 py-0.5 whitespace-nowrap" data-testid={`campaign-review-${c.id}`}>Needs review</span> : <StatusBadge status={c.status} />}
      </div>
      {!c.is_demo && c.message && <p className="text-xs text-muted-foreground mt-2 line-clamp-2">{c.message}</p>}
      {files.length > 0 && (
        <div className="flex flex-wrap gap-1 mt-2">
          {files.map((a, i) => <span key={a.id || i} className="text-[10px] inline-flex items-center gap-1 rounded bg-muted px-1.5 py-0.5 max-w-[11rem]"><Paperclip className="h-3 w-3 shrink-0" /><span className="truncate">{a.name || a.filename || a}</span></span>)}
        </div>
      )}
      {(review || c.last_error || s.uncertain > 0) && (
        <div className="mt-3 rounded-lg border border-amber-300 bg-amber-50 p-2.5 text-xs text-amber-900" data-testid={`campaign-alert-${c.id}`}>
          <div className="flex items-center gap-1 font-medium"><AlertTriangle className="h-3.5 w-3.5" /> {review ? "Needs review" : "Attention"}</div>
          {s.uncertain > 0 && <p className="mt-1">{s.uncertain} message(s) have an uncertain outcome. They may or may not have been delivered, so they are not retried to avoid duplicates. Check WhatsApp before sending again.</p>}
          {c.last_error && <p className="mt-1 break-words">{c.last_error}</p>}
        </div>
      )}
      {s.total > 0 && (
        <div className="mt-3">
          <div className="flex justify-between text-[11px] text-muted-foreground mb-1"><span>{done}/{s.total} processed</span><span>{pct}%</span></div>
          <Progress value={pct} className="h-2" />
        </div>
      )}
      <div className="grid grid-cols-4 gap-2 mt-4">
        <Stat icon={Send} label="Sent" value={s.sent} />
        <Stat icon={Reply} label="Replies" value={s.replies} />
        <Stat icon={Ban} label="Opt-out" value={s.skipped} />
        <Stat icon={XCircle} label="Failed" value={s.failed} />
      </div>
      {s.uncertain > 0 && <div className="text-[11px] text-amber-800 mt-2">Uncertain: {s.uncertain}</div>}
      {s.total > 0 && (
        <div className="flex gap-2 mt-3">
          {can("campaigns", "view") && <Button size="sm" variant="outline" className="flex-1" data-testid={`campaign-report-${c.id}`} onClick={() => onReport(c)}><FileBarChart className="h-3.5 w-3.5 mr-1" /> Report</Button>}
          {can("campaigns", "export") && <Button size="sm" variant="outline" className="flex-1" data-testid={`campaign-export-${c.id}`} onClick={() => onExport(c)}><Download className="h-3.5 w-3.5 mr-1" /> Export CSV</Button>}
        </div>
      )}
      {!c.is_demo && (
        <div className="flex gap-2 mt-4">
          {c.status === "draft" && can("campaigns", "send") && <Button size="sm" variant="outline" className="flex-1" data-testid={`campaign-send-${c.id}`} onClick={() => onAction(c, "send")}><Play className="h-3.5 w-3.5 mr-1" /> Start</Button>}
          {c.status === "running" && can("campaigns", "edit") && <Button size="sm" variant="outline" className="flex-1" data-testid={`campaign-pause-${c.id}`} onClick={() => onAction(c, "pause")}><Pause className="h-3.5 w-3.5 mr-1" /> Pause</Button>}
          {["paused", "scheduled"].includes(c.status) && can("campaigns", "send") && <Button size="sm" variant="outline" className="flex-1" data-testid={`campaign-resume-${c.id}`} onClick={() => onAction(c, "resume")}><Play className="h-3.5 w-3.5 mr-1" /> Resume</Button>}
          {editable && can("campaigns", "edit") && <Button size="sm" variant="outline" data-testid={`campaign-edit-${c.id}`} onClick={() => onEdit(c)}><Pencil className="h-3.5 w-3.5 mr-1" /> Edit</Button>}
          {can("campaigns", "delete") && <Button size="sm" variant="outline" className="text-destructive" aria-label="Delete campaign" data-testid={`campaign-delete-${c.id}`} onClick={() => onDelete(c)}><Trash2 className="h-3.5 w-3.5 mr-1" /> Delete</Button>}
        </div>
      )}
    </Card>
  );
}
