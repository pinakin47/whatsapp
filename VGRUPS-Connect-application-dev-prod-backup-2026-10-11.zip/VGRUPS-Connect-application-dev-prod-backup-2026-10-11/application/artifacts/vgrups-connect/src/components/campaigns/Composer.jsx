import React, { useEffect, useState } from "react";
import api, { apiError } from "../../lib/api";
import { toast } from "sonner";
import AttachmentPicker from "./AttachmentPicker";
import ConfirmDialog from "../ConfirmDialog";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Label } from "../ui/label";
import { Textarea } from "../ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "../ui/dialog";
import GapField from "./GapField";
import MessagePreview from "./MessagePreview";
import { useAuth } from "../../context/AuthContext";
import { Loader2 } from "lucide-react";
import { useSenders, SenderSelect, resolveSender, findSender, senderLabel } from "../../lib/useSenders";

const CONTACT_TYPES = ["lead", "customer", "doctor", "hospital", "pharmacy", "distributor", "cf", "medical_shop", "institution"];
const blank = { gap: 5, sender_session_id: "", name: "", message: "", template_name: "", mode: "now", date: "", time: "", audienceType: "group", group_id: "", contact_type: "", city: "", tag: "" };

export function istToUtcIso(date, time) {
  if (!date || !time) return null;
  const d = new Date(`${date}T${time}:00+05:30`);
  return isNaN(d.getTime()) ? null : d.toISOString();
}

const istParts = (iso) => {
  if (!iso) return { date: "", time: "" };
  const p = Object.fromEntries(new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Kolkata", year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", hourCycle: "h23" }).formatToParts(new Date(iso)).map((x) => [x.type, x.value]));
  return { date: `${p.year}-${p.month}-${p.day}`, time: `${p.hour}:${p.minute}` };
};
const fromCampaign = (c) => {
  const a = c.audience || { type: "all" };
  const { date, time } = istParts(c.scheduled_at);
  return { ...blank, name: c.name || "", message: c.message || "", template_name: c.template_name || "", mode: c.scheduled_at ? "schedule" : "draft", date, time,
    audienceType: a.type === "group" ? "group" : a.type === "filter" ? "filter" : "all", group_id: a.group_id || "", contact_type: a.contact_type || "", city: a.city || "", tag: a.tag || "",
    gap: Number(c.message_gap_seconds) || 5, sender_session_id: c.sender_session_id || "" };
};

export default function Composer({ open, onOpenChange, groups, templates, onCreated, onManageGroups, editing }) {
  const { can } = useAuth();
  const canSend = can("campaigns", "send");
  const [f, setF] = useState(blank);
  const [files, setFiles] = useState([]);
  const [saving, setSaving] = useState(false);
  const [confirm, setConfirm] = useState(false);
  const [err, setErr] = useState("");
  const senders = useSenders();
  const sid = resolveSender(senders, f.sender_session_id);
  const set = (p) => setF((x) => ({ ...x, ...p }));

  useEffect(() => {
    if (!open) return;
    setErr("");
    if (editing) {
      setF(fromCampaign(editing));
      setFiles((editing.attachment_details || []).filter((a) => a.id).map((a) => ({ key: a.id, id: a.id, name: a.name || a.filename || "file", size: a.size, content_type: a.content_type, state: "ready" })));
    } else { setF({ ...blank, group_id: "" }); setFiles([]); }
    // eslint-disable-next-line
  }, [open, editing?.id]);
  useEffect(() => {
    if (open && !editing && groups.length) setF((x) => (x.audienceType === "group" && !x.group_id ? { ...x, group_id: groups[0].id } : x));
    // eslint-disable-next-line
  }, [open, groups, editing?.id]);

  const uploading = files.some((x) => x.state === "uploading");
  const iso = f.mode === "schedule" ? istToUtcIso(f.date, f.time) : null;
  const schedErr = f.mode === "schedule" ? (!iso ? "Choose a date and time (India Standard Time)" : new Date(iso) <= new Date() ? "Scheduled time must be in the future" : "") : "";
  const audOk = f.audienceType !== "group" || !!f.group_id;
  const senderOk = senders.loading || senders.items.length === 0 || !!sid;
  const valid = senderOk && f.name.trim() && f.message.trim() && !schedErr && audOk && !uploading;

  const pickTemplate = (name) => { const t = templates.find((x) => x.name === name); set({ template_name: name, message: t ? t.body : f.message }); };

  const submit = async () => {
    setConfirm(false); setSaving(true); setErr("");
    const audience = f.audienceType === "group" ? { type: "group", group_id: f.group_id }
      : f.audienceType === "all" ? { type: "all" } : { type: "filter", contact_type: f.contact_type, city: f.city, tag: f.tag };
    try {
      const body = {
        ...(editing?.variables ? { variables: editing.variables } : {}),
        name: f.name.trim(), message: f.message, template_name: f.template_name || null, audience: editing?.audience ? { ...editing.audience, ...audience } : audience,
        message_gap_seconds: f.gap, sender_session_id: sid || null,
        attachments: files.filter((x) => x.state === "ready").map((x) => x.id),
        send_now: f.mode === "now", scheduled_at: f.mode === "schedule" ? iso : null,
      };
      if (editing) await api.put(`/campaigns/${editing.id}`, body); else await api.post("/campaigns", body);
      toast.success(editing ? "Campaign updated" : f.mode === "now" ? "Broadcast submitted" : f.mode === "schedule" ? "Broadcast scheduled" : "Draft saved");
      onOpenChange(false); onCreated();
    } catch (e) { setErr(apiError(e)); } finally { setSaving(false); }
  };

  const onSave = () => { if (f.mode === "draft") submit(); else setConfirm(true); };
  const group = groups.find((g) => g.id === f.group_id);
  const label = f.mode === "now" ? "Send now" : f.mode === "schedule" ? "Schedule" : editing ? "Save changes" : "Save draft";

  return (
    <>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle data-testid="composer-title">{editing ? `Edit broadcast: ${editing.name}` : "New WhatsApp Broadcast"}</DialogTitle>
            <DialogDescription>{editing ? "Editing an unsent campaign. Changes apply before any message is sent. " : ""}Contacts who opted out are never sent to. Sending respects per-number daily limits.</DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <SenderSelect senders={senders} value={f.sender_session_id} onChange={(v) => set({ sender_session_id: v })} disabled={saving} testId="campaign-sender-select" />
            <div><Label>Campaign Name *</Label><Input data-testid="campaign-name-input" value={f.name} onChange={(e) => set({ name: e.target.value })} /></div>
            <div>
              <div className="flex items-center justify-between"><Label>Audience</Label><button type="button" className="text-xs text-[#3B5B2A] underline" onClick={onManageGroups} data-testid="manage-groups-link">Manage groups</button></div>
              <Select value={f.audienceType} onValueChange={(v) => set({ audienceType: v })}>
                <SelectTrigger data-testid="campaign-audience-type"><SelectValue /></SelectTrigger>
                <SelectContent><SelectItem value="group">Saved group</SelectItem><SelectItem value="all">All contacts</SelectItem><SelectItem value="filter">Filtered</SelectItem></SelectContent>
              </Select>
            </div>
            {f.audienceType === "group" && (groups.length === 0
              ? <p className="text-xs rounded-lg border border-dashed border-border p-3 text-muted-foreground">No groups yet. <button type="button" className="underline text-[#3B5B2A]" onClick={onManageGroups}>Create a group</button> to choose an audience.</p>
              : <div>
                <Select value={f.group_id} onValueChange={(v) => set({ group_id: v })}>
                  <SelectTrigger data-testid="campaign-group-select"><SelectValue placeholder="Choose group" /></SelectTrigger>
                  <SelectContent>{groups.map((g) => <SelectItem key={g.id} value={g.id}>{g.name} ({(g.contact_ids || []).length})</SelectItem>)}</SelectContent>
                </Select>
                {group && <p className="text-[11px] text-muted-foreground mt-1">{(group.contact_ids || []).length} contacts in group. Opted-out contacts are skipped.</p>}
              </div>)}
            {f.audienceType === "filter" && (
              <div className="grid grid-cols-2 gap-2">
                <div><Label className="text-xs">Contact Type</Label>
                  <Select value={f.contact_type || "any"} onValueChange={(v) => set({ contact_type: v === "any" ? "" : v })}>
                    <SelectTrigger><SelectValue placeholder="Any" /></SelectTrigger>
                    <SelectContent><SelectItem value="any">Any</SelectItem>{CONTACT_TYPES.map((t) => <SelectItem key={t} value={t}>{t.replace(/_/g, " ")}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
                <div><Label className="text-xs">City</Label><Input value={f.city} onChange={(e) => set({ city: e.target.value })} /></div>
                <div className="col-span-2"><Label className="text-xs">Tag</Label><Input value={f.tag} onChange={(e) => set({ tag: e.target.value })} placeholder="e.g. vip" /></div>
              </div>
            )}
            {templates.length > 0 && (
              <div><Label>Use approved template (optional)</Label>
                <Select value={f.template_name || "none"} onValueChange={(v) => pickTemplate(v === "none" ? "" : v)}>
                  <SelectTrigger data-testid="campaign-template-select"><SelectValue placeholder="None" /></SelectTrigger>
                  <SelectContent><SelectItem value="none">None (custom message)</SelectItem>{templates.map((t) => <SelectItem key={t.id} value={t.name}>{t.name}{t.status === "approved" ? " (approved)" : ""}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            )}
            <div><Label>Message *</Label><Textarea rows={4} data-testid="campaign-message-input" value={f.message} onChange={(e) => set({ message: e.target.value })} placeholder="Hi {name}! New offers on VGRUPS products..." />
              <p className="text-[11px] text-muted-foreground mt-1">Variables: {"{name}"} {"{company}"} {"{city}"}, filled per contact.</p></div>
            <div><Label className="mb-1 block">Attachments</Label><AttachmentPicker items={files} setItems={setFiles} /></div>
            <MessagePreview message={f.message} files={files} />
            <GapField value={f.gap} onChange={(v) => set({ gap: v })} />
            <div>
              <Label>Delivery</Label>
              <Select value={f.mode} onValueChange={(v) => set({ mode: v })}>
                <SelectTrigger data-testid="campaign-mode-select"><SelectValue /></SelectTrigger>
                <SelectContent>{canSend && <SelectItem value="now">Send now</SelectItem>}{canSend && <SelectItem value="schedule">Schedule automatically</SelectItem>}<SelectItem value="draft">Save draft</SelectItem></SelectContent>
              </Select>
            </div>
            {f.mode === "schedule" && (
              <div className="rounded-lg border border-border p-3 space-y-2">
                <div className="grid grid-cols-2 gap-2">
                  <div><Label className="text-xs">Date (IST)</Label><Input type="date" data-testid="campaign-schedule-date" value={f.date} onChange={(e) => set({ date: e.target.value })} /></div>
                  <div><Label className="text-xs">Time (IST)</Label><Input type="time" data-testid="campaign-schedule-time" value={f.time} onChange={(e) => set({ time: e.target.value })} /></div>
                </div>
                <p className="text-[11px] text-muted-foreground">Times are India Standard Time (UTC+05:30). The campaign sends automatically while the service is running and your WhatsApp number is connected.</p>
                {schedErr && (f.date || f.time) && <p className="text-xs text-destructive" data-testid="schedule-error">{schedErr}</p>}
              </div>
            )}
            {err && <p className="text-sm text-destructive" data-testid="campaign-form-error">{err}</p>}
          </div>
          <DialogFooter>
            <Button data-testid="campaign-save-button" disabled={saving || !valid} onClick={onSave} className="bg-[#3B5B2A] hover:bg-[#2D4720]">{saving ? <Loader2 className="h-4 w-4 animate-spin" /> : uploading ? "Uploading files..." : label}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      <ConfirmDialog open={confirm} onOpenChange={setConfirm}
        title={f.mode === "now" ? "Send this broadcast now?" : "Schedule this broadcast?"}
        description={`${f.mode === "now" ? "Real WhatsApp messages will start sending immediately" : `It will send automatically on ${f.date} at ${f.time} IST`}${sid && findSender(senders, sid) ? ` from ${senderLabel(findSender(senders, sid))}` : ""}${group && f.audienceType === "group" ? ` to group "${group.name}" (${(group.contact_ids || []).length} contacts)` : ""}. Opted-out contacts are skipped.`}
        confirmLabel={f.mode === "now" ? "Send now" : "Schedule"} onConfirm={submit} testId="campaign-confirm-send" />
    </>
  );
}
