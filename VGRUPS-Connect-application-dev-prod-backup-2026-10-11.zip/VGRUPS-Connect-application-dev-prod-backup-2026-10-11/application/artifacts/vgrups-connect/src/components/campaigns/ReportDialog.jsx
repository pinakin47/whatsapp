import React, { useEffect, useRef, useState } from "react";
import api, { apiError } from "../../lib/api";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "../ui/dialog";
import { Button } from "../ui/button";
import { Download } from "lucide-react";

const istText = (iso) => iso ? new Date(iso).toLocaleString("en-IN", { timeZone: "Asia/Kolkata", dateStyle: "medium", timeStyle: "short" }) + " IST" : "-";
const CARDS = [["total", "Total"], ["sent", "Sent"], ["delivered", "Delivered (incl. read)"], ["read", "Read"], ["failed", "Failed"], ["skipped", "Skipped"], ["uncertain", "Uncertain"], ["pending", "Pending"]];

// type: "campaigns" | "drips"
export default function ReportDialog(props) {
  return <ReportContent key={`${props.type}/${props.item?.id}/${props.open}`} {...props} />;
}

function ReportContent({ open, onOpenChange, item, type = "campaigns", canExport, onExport }) {
  const [rep, setRep] = useState(null);
  const [err, setErr] = useState("");
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(50);
  const [searchInput, setSearchInput] = useState("");
  const previousSearchInput = useRef(searchInput);
  const [search, setSearch] = useState("");
  const [delivery, setDelivery] = useState("");
  const [sender, setSender] = useState("");
  const [senderNumbers, setSenderNumbers] = useState([]);
  const [retry, setRetry] = useState(0);
  const [exporting, setExporting] = useState(false);
  const id = item?.id;
  useEffect(() => {
    // Only input edits should reset pagination, not the initial effect.
    if (previousSearchInput.current === searchInput) return;
    previousSearchInput.current = searchInput;
    const timer = setTimeout(() => { setSearch(searchInput.trim()); setPage(1); }, 300);
    return () => clearTimeout(timer);
  }, [searchInput]);
  useEffect(() => {
    if (!open || !id) { setRep(null); return; }
    const controller = new AbortController();
    let timer;
    setRep(null);
    setErr("");
    const load = async () => {
      try {
        const r = await api.get(`/${type}/${id}/report`, {
          params: { page, page_size: pageSize, search, delivery, sender }, signal: controller.signal,
        });
        if (controller.signal.aborted) return;
        // Histories may shrink or the active filter may stop matching a row.
        const lastPage = Math.max(1, r.data.pagination.pages);
        if (page > lastPage) {
          setPage(lastPage); return;
        }
        setRep(r.data); setSenderNumbers(r.data.sender_numbers || []); setErr("");
      } catch (e) {
        if (!controller.signal.aborted) setErr(apiError(e));
      } finally {
        if (!controller.signal.aborted) timer = setTimeout(load, 15000);
      }
    };
    load();
    return () => { controller.abort(); clearTimeout(timer); };
  }, [open, id, type, page, pageSize, search, delivery, sender, retry]);
  const exportCsv = async () => {
    setExporting(true);
    try { await onExport(item, { search, delivery, sender }); }
    finally { setExporting(false); }
  };
  const s = rep?.summary || {};
  const pagination = rep?.pagination;
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto" data-testid="report-dialog">
        <DialogHeader>
          <DialogTitle>Delivery report: {rep?.campaign?.name || item?.name}</DialogTitle>
          <DialogDescription>
            Sent means handed to WhatsApp. Delivered and read need a receipt from the recipient's phone; a missing receipt is not treated as delivered.
            {rep?.campaign && ` Status: ${(rep.campaign.status || "").replace(/_/g, " ")}. Gap: ${rep.campaign.message_gap_seconds}s between messages.${rep.campaign.scheduled_at ? ` Scheduled ${istText(rep.campaign.scheduled_at)}.` : ""}`}
          </DialogDescription>
        </DialogHeader>
        {err && <div className="text-sm text-destructive flex items-center gap-3">{err}<Button size="sm" variant="outline" onClick={() => setRetry((r) => r + 1)}>Retry</Button></div>}
        <div className="flex flex-wrap gap-2">
          <input aria-label="Search report recipients" placeholder="Search name or mobile" maxLength={200} value={searchInput}
            onChange={(e) => setSearchInput(e.target.value)} className="flex-1 min-w-[140px] rounded-md border border-border bg-background px-3 py-2 text-xs" />
          <select aria-label="Filter report delivery" value={delivery} onChange={(e) => { setDelivery(e.target.value); setPage(1); }}
            className="rounded-md border border-border bg-background px-2 text-xs">
            <option value="">All outcomes</option>
            {["pending", "sent", "delivered", "read", "failed", "skipped", "uncertain"].map((v) => <option key={v} value={v}>{v === "sent" ? "Sent — no complete receipt" : v === "delivered" ? "Delivered — not yet read" : v[0].toUpperCase() + v.slice(1)}</option>)}
          </select>
          <select aria-label="Filter report sender number" value={sender} onChange={(e) => { setSender(e.target.value); setPage(1); }}
            className="rounded-md border border-border bg-background px-2 py-2 text-xs">
            <option value="">All sender numbers</option>
            {[...new Set([...senderNumbers, ...(sender ? [sender] : [])])].map((number) =>
              <option key={number} value={number}>{number}</option>)}
          </select>
          <select aria-label="Recipients per page" value={pageSize} onChange={(e) => { setPageSize(Number(e.target.value)); setPage(1); }}
            className="rounded-md border border-border bg-background px-2 text-xs">
            {[25, 50, 100, 200].map((v) => <option key={v} value={v}>{v} per page</option>)}
          </select>
        </div>
        {!rep && !err && <div className="h-24 rounded-lg bg-muted animate-pulse" />}
        {rep && (
          <>
            <p className="text-xs text-muted-foreground font-mono">Pinned sender number: {rep.campaign?.sender_number || "Unknown"}</p>
            <div className="grid grid-cols-4 gap-2" data-testid="report-summary">
              {CARDS.map(([k, l]) => <div key={k} className="rounded-lg border border-border p-2 text-center"><div className="text-sm font-semibold">{Number(s[k] || 0).toLocaleString("en-IN")}</div><div className="text-[10px] text-muted-foreground">{l}</div></div>)}
            </div>
            <div className="flex justify-between items-center">
              <span className="text-[11px] text-muted-foreground">Totals cover the entire history. Refreshes every 15 seconds.</span>
              {canExport && <Button size="sm" variant="outline" data-testid="report-export" disabled={exporting || searchInput.trim() !== search} onClick={exportCsv}><Download className="h-3.5 w-3.5 mr-1" /> {exporting ? "Exporting…" : "Export all matching CSV"}</Button>}
            </div>
            <div className="overflow-x-auto border border-border rounded-lg">
              <table className="w-full text-xs">
                <thead className="bg-muted/60 text-left"><tr>{["Recipient", "Mobile", "Sender number", "Status", "Delivery", "Replied", "Sent at", "Error"].map((h) => <th key={h} className="px-2 py-1.5 font-medium">{h}</th>)}</tr></thead>
                <tbody>
                  {(rep.recipients || []).map((r, i) => (
                    <tr key={r.id || i} className="border-t border-border/60 align-top">
                      <td className="px-2 py-1.5">{r.name || "-"}</td>
                      <td className="px-2 py-1.5 font-mono">{r.mobile}</td>
                      <td className="px-2 py-1.5 font-mono whitespace-nowrap">{r.sender_number || "Unknown"}</td>
                      <td className="px-2 py-1.5 capitalize">{r.status || "-"}</td>
                      <td className="px-2 py-1.5 capitalize">{r.delivery || "no receipt yet"}{(r.part_deliveries || []).length > 1 && <div className="text-[10px] text-muted-foreground">{r.part_deliveries.map((p) => p.status || "none").join(", ")}</div>}</td>
                      <td className="px-2 py-1.5">{r.replied ? "Yes" : "No"}</td>
                      <td className="px-2 py-1.5">{istText(r.sent_at)}</td>
                      <td className="px-2 py-1.5 text-destructive max-w-[12rem] break-words">{r.error || ""}</td>
                    </tr>
                  ))}
                  {!(rep.recipients || []).length && <tr><td colSpan={8} className="p-6 text-center text-muted-foreground">{search || delivery || sender ? "No recipients match these filters." : "No recipients yet. They appear once sending starts."}</td></tr>}
                </tbody>
              </table>
            </div>
            <div className="flex flex-wrap justify-between items-center gap-2 text-xs" data-testid="report-pagination">
              <span>{pagination?.total ? `${((page - 1) * pageSize + 1).toLocaleString("en-IN")}–${Math.min(page * pageSize, pagination.total).toLocaleString("en-IN")} of ${pagination.total.toLocaleString("en-IN")} matching recipients` : "0 matching recipients"}</span>
              <div className="flex items-center gap-2">
                <Button size="sm" variant="outline" disabled={page <= 1} onClick={() => setPage((p) => p - 1)}>Previous</Button>
                <span>Page {page} of {Math.max(1, pagination?.pages || 0)}</span>
                <Button size="sm" variant="outline" disabled={!pagination || page >= pagination.pages} onClick={() => setPage((p) => p + 1)}>Next</Button>
              </div>
            </div>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}
