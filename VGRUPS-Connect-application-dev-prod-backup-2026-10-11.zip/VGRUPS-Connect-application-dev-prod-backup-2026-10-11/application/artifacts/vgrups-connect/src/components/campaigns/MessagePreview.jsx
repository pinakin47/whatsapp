import React, { useEffect, useState } from "react";
import api, { apiError } from "../../lib/api";
import { toast } from "sonner";
import { FileText, Paperclip } from "lucide-react";

const SAMPLE = { name: "Dr. Ananya Rao", company: "Sunrise Pharmacy", city: "Hyderabad" };
export const renderSample = (t) => (t || "").replace(/\{(name|company|city)\}/g, (_, k) => SAMPLE[k]);

async function openAuthed(id) {
  try {
    const r = await api.get(`/campaigns/media/${id}/download`, { responseType: "blob" });
    const url = URL.createObjectURL(r.data);
    window.open(url, "_blank", "noopener");
    setTimeout(() => URL.revokeObjectURL(url), 60000);
  } catch (e) { toast.error(apiError(e)); }
}

function Thumb({ file }) {
  const [src, setSrc] = useState(file.localUrl || "");
  useEffect(() => {
    if (file.localUrl || !file.id) return;
    let url = "", dead = false;
    api.get(`/campaigns/media/${file.id}/download`, { responseType: "blob" })
      .then((r) => { if (!dead) { url = URL.createObjectURL(r.data); setSrc(url); } }).catch(() => {});
    return () => { dead = true; if (url) URL.revokeObjectURL(url); };
  }, [file.id, file.localUrl]);
  if (!src) return <div className="h-24 w-full rounded bg-muted/60 text-[10px] text-muted-foreground flex items-center justify-center">Loading image</div>;
  return <img src={src} alt={file.name || "attachment"} className="rounded max-h-40 w-full object-cover" />;
}

// files: [{id,name,content_type,state,localUrl}]
export default function MessagePreview({ message, files = [], testId = "message-preview" }) {
  const ready = files.filter((f) => !f.state || f.state === "ready");
  return (
    <div className="rounded-lg border border-border bg-[#F7F9F6] dark:bg-[#0B120C] p-3" data-testid={testId}>
      <div className="text-[10px] uppercase tracking-wide text-muted-foreground mb-2">Preview (illustrative sample: {"{name}"}, {"{company}"}, {"{city}"})</div>
      <div className="max-w-[85%] ml-auto rounded-2xl rounded-br-sm bg-[#3B5B2A] text-white px-3.5 py-2 text-sm space-y-2">
        {ready.filter((f) => (f.content_type || "").startsWith("image/")).map((f, i) => <Thumb key={f.id || f.key || i} file={f} />)}
        <div className="whitespace-pre-wrap break-words">{message ? renderSample(message) : <span className="text-white/60">Your message appears here</span>}</div>
      </div>
      {ready.length > 0 && (
        <div className="flex flex-wrap gap-1 mt-2 justify-end">
          {ready.map((f, i) => (
            <button type="button" key={f.id || f.key || i} disabled={!f.id} onClick={() => openAuthed(f.id)}
              className="text-[10px] inline-flex items-center gap-1 rounded bg-muted px-1.5 py-0.5 max-w-[11rem] hover:bg-muted/70">
              {f.content_type === "application/pdf" ? <FileText className="h-3 w-3 shrink-0" /> : <Paperclip className="h-3 w-3 shrink-0" />}
              <span className="truncate">{f.name || f.filename || "file"}</span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
