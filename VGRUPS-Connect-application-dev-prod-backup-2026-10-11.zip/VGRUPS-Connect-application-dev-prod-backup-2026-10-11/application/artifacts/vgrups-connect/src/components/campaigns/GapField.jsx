import React from "react";
import { Input } from "../ui/input";
import { Label } from "../ui/label";

export const clampGap = (v) => Math.min(300, Math.max(1, Math.round(Number(v) || 5)));

export default function GapField({ value, onChange }) {
  const preset = value === 5 || value === 10;
  return (
    <div data-testid="gap-field">
      <Label>Seconds between individual messages</Label>
      <div className="flex items-center gap-2 mt-1">
        {[5, 10].map((n) => (
          <button key={n} type="button" data-testid={`gap-${n}`} onClick={() => onChange(n)}
            className={`text-xs rounded-full px-3 py-1.5 ${value === n ? "bg-[#3B5B2A] text-white" : "bg-muted text-muted-foreground hover:bg-muted/70"}`}>{n} seconds</button>
        ))}
        <span className="text-xs text-muted-foreground">Custom</span>
        <Input type="number" min={1} max={300} aria-label="Custom seconds between messages" data-testid="gap-custom" className="h-8 w-20"
          value={preset ? "" : value} placeholder="1-300"
          onChange={(e) => onChange(e.target.value === "" ? 5 : clampGap(e.target.value))} />
      </div>
      <p className="text-[11px] text-muted-foreground mt-1">Wait between each message sent (1 to 300 seconds). Currently {value} seconds.</p>
    </div>
  );
}
