import React, { useEffect, useState } from "react";
import api, { apiError } from "../../lib/api";
import { useAuth } from "../../context/AuthContext";
import ProductChooser from "./ProductChooser";
import { toast } from "sonner";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "../ui/dialog";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Label } from "../ui/label";
import { Textarea } from "../ui/textarea";
import { Plus, Trash2, Loader2 } from "lucide-react";
import { inr, lineTotal } from "./util";

const PK = "vg_sale_pending";
const sha = async (o) => { const b = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(JSON.stringify(o))); return Array.from(new Uint8Array(b)).map((x) => x.toString(16).padStart(2, "0")).join(""); };
const readPending = () => { try { return JSON.parse(sessionStorage.getItem(PK) || "null"); } catch (e) { return null; } };
const G = "bg-[#3B5B2A] hover:bg-[#2D4720] text-white";
let k = 0;
const blank = () => ({ key: ++k, product_id: "", product_name: "", quantity: "1", unit_price: "" });

export default function SaleForm({ open, onClose, sale, onSaved }) {
  const edit = !!sale;
  const [f, setF] = useState({ customer_name: "", phone: "", email: "", address: "" });
  const [items, setItems] = useState([blank()]);
  const [errs, setErrs] = useState({});
  const [saving, setSaving] = useState(false);
  const { user } = useAuth();
  const [uncertain, setUncertain] = useState(false);

  useEffect(() => {
    if (!open) return;
    setErrs({}); const pd = readPending(); setUncertain(!!pd && pd.actor === user?.id);
    if (sale) {
      setF({ customer_name: sale.customer_name || "", phone: sale.phone || "", email: sale.email || "", address: sale.address || "" });
      setItems((sale.items || []).map((i) => ({ key: ++k, product_id: i.product_id, product_name: i.product_name, quantity: String(i.quantity), unit_price: String(i.unit_price) })));
    } else { setF({ customer_name: "", phone: "", email: "", address: "" }); setItems([blank()]); }
  }, [open, sale, user?.id]);

  const chF = (n, v) => {
    setF((p) => ({ ...p, [n]: v }));
    setErrs((p) => { const next = { ...p }; delete next[n]; return next; });
  };
  const chI = (kk, patch) => {
    setItems((p) => p.map((i) => (i.key === kk ? { ...i, ...patch } : i)));
    setErrs((p) => {
      const line = { ...p[kk] };
      Object.keys(patch).forEach((field) => delete line[field === "product_id" ? "product" : field]);
      return { ...p, [kk]: line };
    });
  };
  const grand = items.reduce((s, i) => s + lineTotal(i.quantity, i.unit_price), 0);

  const validate = () => {
    const e = {};
    if (!f.customer_name.trim()) e.customer_name = "Customer name is required";
    const ph = f.phone.replace(/[\s-]/g, "").replace(/^(\+91|91|0)(?=\d{10}$)/, "");
    if (!f.phone.trim()) e.phone = "Phone number is required";
    else if (!/^[6-9]\d{9}$/.test(ph)) e.phone = "Enter a valid 10-digit Indian mobile number";
    if (f.email.trim() && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(f.email.trim())) e.email = "Enter a valid email";
    items.forEach((i) => {
      const x = {};
      if (!i.product_id) x.product = "Select a product";
      if (!/^[1-9]\d*$/.test(String(i.quantity).trim()) || Number(i.quantity) > 1000000) x.quantity = "Whole number from 1 to 1,000,000";
      if (!/^\d{1,10}(\.\d{1,2})?$/.test(String(i.unit_price).trim())) x.unit_price = "0 or more, up to 12 digits, max 2 decimals";
      if (Object.keys(x).length) e[i.key] = x;
    });
    setErrs(e);
    return { ok: Object.keys(e).length === 0, ph };
  };

  const submit = async () => {
    const { ok, ph } = validate();
    if (!ok) { toast.error("Please fix the highlighted fields"); return; }
    const body = {
      customer_name: f.customer_name.trim(), phone: ph, email: f.email.trim(), address: f.address.trim(),
      items: items.map((i) => ({ product_id: i.product_id, quantity: Number(i.quantity), unit_price: Number(i.unit_price) })),
    };
    setSaving(true);
    try {
      if (edit) await api.patch(`/sales/${sale.id}`, { ...body, revision: sale.revision });
      else {
        const hash = await sha(body); let pd = readPending();
        if (pd?.actor === user?.id && pd.hash !== hash) {
          setUncertain(true);
          throw new Error("An earlier save is unresolved. Check that save below, or retry its original details before creating another sale.");
        }
        if (!pd || pd.actor !== user?.id || pd.hash !== hash) { pd = { actor: user?.id, hash, key: crypto.randomUUID() }; sessionStorage.setItem(PK, JSON.stringify(pd)); }
        try { await api.post("/sales", { ...body, request_key: pd.key }); }
        catch (e) { if (e?.response && e.response.status < 500) sessionStorage.removeItem(PK); else setUncertain(true); throw e; }
        sessionStorage.removeItem(PK); setUncertain(false);
      }

      toast.success(edit ? "Sale updated." : "Sale successfully saved.");
      onSaved(); onClose();
    } catch (e) { toast.error(e?.response ? apiError(e) : "No response from server. The sale may have been saved. Press Save Sale again to retry safely."); } finally { setSaving(false); }
  };

  const Err = ({ m }) => (m ? <p className="text-xs text-destructive mt-1">{m}</p> : null);
  const checkEarlierSave = async () => {
    const pd = readPending();
    if (!pd || pd.actor !== user?.id) return;
    setSaving(true);
    try {
      const { data } = await api.get("/sales/save-status", { params: { request_key: pd.key } });
      if (!data.found) {
        toast.info("No saved sale is confirmed yet. Retry the original details using the same save key.");
        return;
      }
      sessionStorage.removeItem(PK);
      setUncertain(false);
      toast.info(`Earlier sale ${data.sale_id} ${data.deleted ? "was removed by an administrator" : "was successfully saved"}. Review your history before saving another sale.`);
      onSaved();
    } catch (e) { toast.error(apiError(e)); }
    finally { setSaving(false); }
  };
  return (
    <Dialog open={open} onOpenChange={(v) => !v && !saving && onClose()}>
      <DialogContent className="max-w-3xl max-h-[92dvh] overflow-y-auto" data-testid="sale-form">
        <DialogHeader><DialogTitle>{edit ? `Edit Sale ${sale.sale_id}` : "Create New Sale"}</DialogTitle><DialogDescription>Totals are calculated automatically and verified by the server.</DialogDescription></DialogHeader>
        {uncertain && !edit && <div className="text-xs rounded bg-amber-100 text-amber-800 dark:bg-amber-500/15 dark:text-amber-300 p-2" data-testid="sale-uncertain">The last save may have reached the server. Retry the same details to reuse its save key. Resolve that save before creating a different sale.<Button type="button" size="sm" variant="outline" className="ml-2" disabled={saving} onClick={checkEarlierSave}>Check earlier save</Button></div>}
        <fieldset disabled={saving} className="space-y-3 min-w-0 border-0 p-0 m-0">
        <div className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Customer information</div>
        <div className="grid sm:grid-cols-2 gap-3">
          <div><Label>Customer Name *</Label><Input value={f.customer_name} onChange={(e) => chF("customer_name", e.target.value)} data-testid="sale-customer" /><Err m={errs.customer_name} /></div>
          <div><Label>Phone Number *</Label><Input inputMode="tel" value={f.phone} onChange={(e) => chF("phone", e.target.value)} placeholder="9876543210" data-testid="sale-phone" /><Err m={errs.phone} /></div>
          <div><Label>Email</Label><Input type="email" value={f.email} onChange={(e) => chF("email", e.target.value)} data-testid="sale-email" /><Err m={errs.email} /></div>
          <div><Label>Address</Label><Textarea rows={1} value={f.address} onChange={(e) => chF("address", e.target.value)} data-testid="sale-address" /></div>
        </div>
        <div className="text-xs font-semibold uppercase tracking-wide text-muted-foreground mt-2">Products</div>
        <div className="hidden sm:grid grid-cols-[1fr_90px_120px_110px_36px] gap-2 text-xs font-medium text-muted-foreground" aria-hidden="true"><span>Product</span><span>Qty / Nos</span><span>Unit Price</span><span>Total</span><span><span className="sr-only">Remove</span></span></div>
        <div className="space-y-3">
          {items.map((i, idx) => {
            const e = errs[i.key] || {};
            return (
              <div key={i.key} className="grid grid-cols-2 sm:grid-cols-[1fr_90px_120px_110px_36px] gap-2 items-start rounded-lg border p-2 sm:border-0 sm:p-0" data-testid={`sale-item-${idx}`}>
                <div className="col-span-2 sm:col-span-1"><Label className="sm:hidden">Product</Label>
                  <ProductChooser label={i.product_name} ariaLabel={`Product ${idx + 1}`} testId={`sale-product-${idx}`} onPick={(p) => chI(i.key, { product_id: p.id, product_name: p.name, unit_price: i.unit_price === "" && p.selling_price != null ? String(p.selling_price) : i.unit_price })} /><Err m={e.product} /></div>
                <div><Label className="sm:hidden">Qty</Label><Input inputMode="numeric" aria-label={`Quantity ${idx + 1}`} value={i.quantity} onChange={(ev) => chI(i.key, { quantity: ev.target.value })} placeholder="Qty" data-testid={`sale-qty-${idx}`} /><Err m={e.quantity} /></div>
                <div><Label className="sm:hidden">Unit price</Label><Input inputMode="decimal" aria-label={`Unit price ${idx + 1}`} value={i.unit_price} onChange={(ev) => chI(i.key, { unit_price: ev.target.value })} placeholder="Unit price" data-testid={`sale-price-${idx}`} /><Err m={e.unit_price} /></div>
                <div className="h-10 flex items-center text-sm font-semibold" data-testid={`sale-line-${idx}`}>{inr(lineTotal(i.quantity, i.unit_price))}</div>
                <Button type="button" aria-label={`Remove product ${idx + 1}`} size="icon" variant="ghost" className="h-10 w-9" disabled={items.length === 1} onClick={() => { setItems((p) => p.filter((x) => x.key !== i.key)); }} data-testid={`sale-remove-${idx}`}><Trash2 className="h-4 w-4 text-destructive" /></Button>
              </div>
            );
          })}
          <Button type="button" variant="outline" size="sm" onClick={() => { setItems((p) => [...p, blank()]); }} data-testid="sale-add-product"><Plus className="h-4 w-4 mr-1" />Add Product</Button>
        </div>
        <div className="rounded-lg bg-[#F0F4EE] dark:bg-[#1D2B1E] p-3 text-sm space-y-1">
          <div className="flex justify-between"><span className="text-muted-foreground">Subtotal</span><span data-testid="sale-subtotal">{inr(grand)}</span></div>
          <div className="flex justify-between text-base font-bold"><span>Grand Total</span><span data-testid="sale-grand">{inr(grand)}</span></div>
        </div>
        </fieldset>
        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={onClose} disabled={saving} data-testid="sale-cancel">Cancel</Button>
          <Button className={G} onClick={submit} disabled={saving} data-testid="sale-save">{saving ? <Loader2 className="h-4 w-4 animate-spin" /> : edit ? "Save Changes" : "Save Sale"}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
