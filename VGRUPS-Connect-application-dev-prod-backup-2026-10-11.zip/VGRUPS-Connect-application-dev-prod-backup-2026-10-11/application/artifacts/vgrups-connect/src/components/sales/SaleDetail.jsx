import React, { useCallback, useEffect, useRef, useState } from "react";
import api, { apiError } from "../../lib/api";
import { toast } from "sonner";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "../ui/dialog";
import { AlertDialog, AlertDialogContent, AlertDialogHeader, AlertDialogTitle, AlertDialogDescription, AlertDialogFooter, AlertDialogCancel, AlertDialogAction } from "../ui/alert-dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../ui/table";
import { Button } from "../ui/button";
import { StatusBadge } from "../common";
import { Loader2, Printer, Pencil, Trash2 } from "lucide-react";
import { STATUSES, inr, fmtIST, fmtDate, fmtTime, printSale } from "./util";

export default function SaleDetail({ id, canEdit, canDelete, onClose, onChanged, onEdit }) {
  const [s, setS] = useState(null);
  const [err, setErr] = useState("");
  const [confirm, setConfirm] = useState(false);
  const [busy, setBusy] = useState(false);
  const request = useRef(0);
  const load = useCallback(() => {
    const current = ++request.current;
    setErr("");
    api.get(`/sales/${id}`).then((r) => { if (current === request.current) setS(r.data); })
      .catch((e) => { if (current === request.current) setErr(apiError(e)); });
  }, [id]);
  useEffect(() => { setS(null); setConfirm(false); if (id) load(); return () => { request.current++; }; }, [id, load]);

  const setStatus = async (status) => {
    setBusy(true);
    try { await api.patch(`/sales/${id}`, { status, revision: s.revision }); toast.success("Status updated"); load(); onChanged(); }
    catch (e) { toast.error(apiError(e)); load(); } finally { setBusy(false); }
  };
  const del = async () => {
    setBusy(true);
    try { await api.delete(`/sales/${id}`, { params: { revision: s.revision } }); toast.success("Sale deleted"); setConfirm(false); onChanged(); onClose(); }
    catch (e) { toast.error(apiError(e)); setConfirm(false); load(); } finally { setBusy(false); }
  };
  const L = ({ k, v }) => <div className="text-sm"><span className="text-muted-foreground">{k}: </span><span className="break-words">{v || "-"}</span></div>;

  return (
    <>
      <Dialog open={!!id} onOpenChange={(v) => !v && onClose()}>
        <DialogContent className="max-w-2xl max-h-[92dvh] overflow-y-auto" data-testid="sale-detail">
          <DialogHeader><DialogTitle className="font-heading">{s?.company?.name || "VGRUPS HEALTHCARE"} - Sale Details</DialogTitle><DialogDescription>{s?.sale_id || "Loading"}</DialogDescription></DialogHeader>
          {err && <div className="text-sm text-destructive">{err} <Button size="sm" variant="outline" onClick={load}>Retry</Button></div>}
          {!s && !err && <div className="py-10 text-center"><Loader2 className="h-5 w-5 animate-spin mx-auto" /></div>}
          {s && (
            <div className="space-y-4">
              <div className="flex flex-wrap items-center gap-2">
                <StatusBadge status={s.status} />
                <div className="ml-auto flex flex-wrap gap-2">
                  {canEdit && (
                    <Select value={s.status} onValueChange={setStatus} disabled={busy}>
                      <SelectTrigger className="w-36 h-9" data-testid="sale-status-select"><SelectValue /></SelectTrigger>
                      <SelectContent>{STATUSES.map((x) => <SelectItem key={x} value={x} className="capitalize">{x}</SelectItem>)}</SelectContent>
                    </Select>
                  )}
                  {canEdit && <Button size="sm" variant="outline" onClick={() => onEdit(s)} data-testid="sale-edit"><Pencil className="h-3.5 w-3.5 mr-1" />Edit</Button>}
                  <Button size="sm" variant="outline" onClick={() => { if (!printSale(s, s.company)) toast.error("Allow pop-ups to print"); }} data-testid="sale-print"><Printer className="h-3.5 w-3.5 mr-1" />Print</Button>
                  {canDelete && <Button size="sm" variant="outline" className="text-destructive" onClick={() => setConfirm(true)} data-testid="sale-delete"><Trash2 className="h-3.5 w-3.5 mr-1" />Delete</Button>}
                </div>
              </div>
              <div className="grid sm:grid-cols-2 gap-1"><L k="Sale ID" v={s.sale_id} /><L k="Date" v={fmtIST(s.created_at)} /><L k="MR Name" v={s.mr_name} /></div>
              <div className="rounded-lg border p-3 space-y-1"><div className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Customer</div>
                <L k="Customer Name" v={s.customer_name} /><L k="Phone" v={s.phone} /><L k="Email" v={s.email} /><L k="Address" v={s.address} /></div>
              <div className="rounded-lg border overflow-x-auto"><Table>
                <TableHeader><TableRow><TableHead>Product</TableHead><TableHead className="text-right">Qty</TableHead><TableHead className="text-right">Unit Price</TableHead><TableHead className="text-right">Total</TableHead></TableRow></TableHeader>
                <TableBody>{(s.items || []).map((i, n) => <TableRow key={n}><TableCell>{i.product_name}</TableCell><TableCell className="text-right">{i.quantity}</TableCell><TableCell className="text-right">{inr(i.unit_price)}</TableCell><TableCell className="text-right">{inr(i.line_total)}</TableCell></TableRow>)}</TableBody>
              </Table></div>
              <div className="text-right text-xl font-bold text-[#3B5B2A] dark:text-[#8FB57A]" data-testid="sale-detail-total">Grand Total: {inr(s.grand_total)}</div>
              <div className="grid sm:grid-cols-3 gap-1"><L k="Created By" v={s.created_by_name} /><L k="Created Date" v={fmtDate(s.created_at)} /><L k="Created Time" v={fmtTime(s.created_at)} /></div>
              {Array.isArray(s.audit) && s.audit.length > 0 && (
                <div><div className="text-xs font-semibold uppercase tracking-wide text-muted-foreground mb-1">Audit trail</div>
                  <ul className="space-y-1 text-xs">{s.audit.map((a, n) => <li key={n} className="rounded bg-muted/50 px-2 py-1"><b className="capitalize">{a.action}</b> by {a.user_name} - {fmtIST(a.created_at)}{a.detail ? <span className="text-muted-foreground"> - {typeof a.detail === "string" ? a.detail : JSON.stringify(a.detail)}</span> : null}</li>)}</ul></div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
      <AlertDialog open={confirm} onOpenChange={setConfirm}>
        <AlertDialogContent>
          <AlertDialogHeader><AlertDialogTitle>Delete sale {s?.sale_id}?</AlertDialogTitle><AlertDialogDescription>The sale is removed from all lists and totals. An audit entry is kept.</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter><AlertDialogCancel>Keep</AlertDialogCancel><AlertDialogAction onClick={(e) => { e.preventDefault(); del(); }} disabled={busy} className="bg-destructive text-destructive-foreground" data-testid="sale-delete-confirm">Delete</AlertDialogAction></AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
