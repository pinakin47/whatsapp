import React, { useEffect, useRef, useState } from "react";
import api, { apiError } from "../../lib/api";
import { Input } from "../ui/input";
import { Button } from "../ui/button";
import { Search } from "lucide-react";
import { inr } from "./util";

// Searchable, paged chooser. url: /sales/products (paged) or /sales/mrs (search only).
export default function ProductChooser({ url = "/sales/products", paged = true, label, placeholder = "Select product", allLabel, onPick, testId, ariaLabel }) {
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState("");
  const [rows, setRows] = useState([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const seq = useRef(0);

  useEffect(() => {
    if (!open) return undefined;
    const my = ++seq.current;
    const t = setTimeout(() => {
      setBusy(true); setErr("");
      api.get(url, { params: { q: q || undefined, ...(paged ? { page } : {}) } })
        .then((r) => {
          if (my !== seq.current) return;
          const items = Array.isArray(r.data?.items) ? r.data.items : [];
          setRows((p) => (paged && page > 1 ? [...p, ...items.filter((x) => !p.some((y) => y.id === x.id))] : items));
          setTotal(Number(r.data?.total) || items.length);
        })
        .catch((e) => { if (my === seq.current) setErr(apiError(e)); })
        .finally(() => { if (my === seq.current) setBusy(false); });
    }, q && page === 1 ? 300 : 0);
    return () => clearTimeout(t);
  }, [open, q, page, url, paged]);

  const pick = (p) => { onPick(p); setOpen(false); setQ(""); setPage(1); };
  const more = paged && rows.length < total;
  return (
    <div className="relative">
      <button type="button" aria-label={ariaLabel || placeholder} aria-haspopup="listbox" aria-expanded={open} onClick={() => { setOpen(!open); setPage(1); setRows([]); }} data-testid={testId} className="w-full h-10 px-3 rounded-md border bg-background text-left text-sm truncate">
        {label || <span className="text-muted-foreground">{placeholder}</span>}
      </button>
      {open && (
        <div className="absolute z-50 mt-1 w-full min-w-[240px] rounded-md border bg-popover shadow-lg p-2">
          <div className="relative mb-2"><Search className="h-3.5 w-3.5 absolute left-2 top-3 text-muted-foreground" /><Input autoFocus aria-label="Search" className="pl-7" placeholder="Search" value={q} onChange={(e) => { setQ(e.target.value); setPage(1); setRows([]); }} /></div>
          <div className="max-h-56 overflow-y-auto" role="listbox">
            {allLabel && <button type="button" className="w-full text-left px-2 py-1.5 rounded hover:bg-muted text-sm" onClick={() => pick(null)}>{allLabel}</button>}
            {err && <div className="p-2 text-xs text-destructive">{err}</div>}
            {!busy && !err && rows.length === 0 && <div className="p-2 text-xs text-muted-foreground">No results.</div>}
            {rows.map((p) => (
              <button type="button" role="option" key={p.id} className="w-full text-left px-2 py-1.5 rounded hover:bg-muted text-sm" onClick={() => pick(p)}>
                <div className="font-medium truncate">{p.name}{p.active === false ? " (inactive)" : ""}</div>
                {paged && <div className="text-xs text-muted-foreground">{p.code || "-"} {p.selling_price != null ? `- ${inr(p.selling_price)}` : ""}</div>}
              </button>
            ))}
            {busy && <div className="p-2 text-xs text-muted-foreground">Loading...</div>}
            {more && !busy && <Button type="button" size="sm" variant="ghost" className="w-full" onClick={() => setPage(page + 1)} data-testid="chooser-load-more">Load more ({rows.length} of {total})</Button>}
          </div>
        </div>
      )}
    </div>
  );
}
