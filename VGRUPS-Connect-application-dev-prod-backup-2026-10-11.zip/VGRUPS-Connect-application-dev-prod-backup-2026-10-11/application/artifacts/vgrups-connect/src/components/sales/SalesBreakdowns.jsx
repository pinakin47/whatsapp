import React from "react";
import { Card } from "../ui/card";
import { inr } from "./util";

export default function SalesBreakdowns({ customers = [], products = [], truncated }) {
  const Col = ({ title, rows, sub, testId }) => (
    <Card className="p-4" data-testid={testId}>
      <h3 className="text-xs font-semibold uppercase tracking-wide text-muted-foreground mb-2">{title}</h3>
      {rows.length === 0 ? <p className="text-sm text-muted-foreground">No sales to break down.</p> : (
        <ul className="space-y-1 text-sm max-h-64 overflow-y-auto">{rows.map((r, i) => (
          <li key={r.id || r.name + i} className="flex justify-between gap-3 rounded bg-muted/50 px-2 py-1"><span className="min-w-0 break-words">{r.name}<span className="text-xs text-muted-foreground"> - {sub(r)}</span></span><b className="shrink-0">{inr(r.value)}</b></li>
        ))}</ul>)}
    </Card>
  );
  return (
    <div className="space-y-2">
      <div className="grid md:grid-cols-2 gap-3">
        <Col title="Customer-wise sales" rows={customers} sub={(r) => `${r.count} sale${r.count === 1 ? "" : "s"}`} testId="sales-by-customer" />
        <Col title="Product-wise sales" rows={products} sub={(r) => `${r.quantity} units`} testId="sales-by-product" />
      </div>
      {truncated && <p className="text-xs text-muted-foreground">Breakdowns show the top entries only. Narrow the filters to see the rest.</p>}
    </div>
  );
}
