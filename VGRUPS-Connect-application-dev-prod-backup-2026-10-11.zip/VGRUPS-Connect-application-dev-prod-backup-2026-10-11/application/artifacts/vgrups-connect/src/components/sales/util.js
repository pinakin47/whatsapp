export const STATUSES = ["Submitted", "Confirmed", "Processing", "Completed", "Cancelled"];
export const inr = (n) => `\u20B9${Number(n || 0).toLocaleString("en-IN", { minimumFractionDigits: 0, maximumFractionDigits: 2 })}`;
export const fmtIST = (v) => (v ? new Intl.DateTimeFormat("en-IN", { timeZone: "Asia/Kolkata", day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit", hour12: true }).format(new Date(v)) : "-");
export const fmtDate = (v) => (v ? new Intl.DateTimeFormat("en-IN", { timeZone: "Asia/Kolkata", day: "2-digit", month: "short", year: "numeric" }).format(new Date(v)) : "-");
export const fmtTime = (v) => (v ? new Intl.DateTimeFormat("en-IN", { timeZone: "Asia/Kolkata", hour: "2-digit", minute: "2-digit", hour12: true }).format(new Date(v)) : "-");
export const lineTotal = (q, p) => {
  const qn = Number(q), pn = Number(p);
  if (!Number.isFinite(qn) || !Number.isFinite(pn)) return 0;
  return (qn * Math.round(pn * 100)) / 100;
};
export const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
export const productsText = (s) => (s.items || []).map((i) => `${i.product_name} x${i.quantity}`).join(", ");
export async function blobError(e) {
  try {
    const d = e?.response?.data;
    if (d instanceof Blob) { const j = JSON.parse(await d.text()); return typeof j.detail === "string" ? j.detail : "Export failed"; }
  } catch (x) { /* ignore */ }
  return e?.response?.status === 422 ? "Too many matching sales (over 10,000). Narrow the filters and try again." : (e?.message || "Export failed");
}
export function printSale(s, company) {
  const c = company || {};
  const rows = (s.items || []).map((i) => `<tr><td>${esc(i.product_name)}</td><td class="r">${esc(i.quantity)}</td><td class="r">${esc(inr(i.unit_price))}</td><td class="r">${esc(inr(i.line_total))}</td></tr>`).join("");
  const w = window.open("", "_blank", "width=800,height=900");
  if (!w) return false;
  w.document.write(`<html><head><title>Sale ${esc(s.sale_id)}</title><style>body{font-family:Georgia,serif;color:#1c2a1c;padding:32px}h1{margin:0;color:#3B5B2A;letter-spacing:2px}table{width:100%;border-collapse:collapse;margin-top:12px}th,td{border-bottom:1px solid #ccc;padding:6px;text-align:left}.r{text-align:right}.m{color:#555;font-size:13px}.t{font-size:20px;font-weight:bold;text-align:right;margin-top:14px}h3{margin:20px 0 4px;font-size:13px;letter-spacing:1px}</style></head><body>
<h1>${esc(c.name || "VGRUPS HEALTHCARE")}</h1><div class="m">${esc([c.address, c.phone, c.email].filter(Boolean).join(" | "))}</div>
<h2>SALE DETAILS</h2><div>Sale ID: <b>${esc(s.sale_id)}</b></div><div>Date: ${esc(fmtIST(s.created_at))}</div><div>MR: ${esc(s.mr_name)}</div><div>Status: ${esc(s.status)}</div>
<h3>CUSTOMER</h3><div>${esc(s.customer_name)}</div><div>${esc(s.phone)}</div><div>${esc(s.email || "")}</div><div>${esc(s.address || "")}</div>
<h3>PRODUCTS</h3><table><thead><tr><th>Product</th><th class="r">Qty</th><th class="r">Unit Price</th><th class="r">Total</th></tr></thead><tbody>${rows}</tbody></table>
<div class="m" style="text-align:right;margin-top:8px">Subtotal: ${esc(inr(s.subtotal))}</div><div class="t">Grand Total: ${esc(inr(s.grand_total))}</div>
<p class="m">Created by ${esc(s.created_by_name)} on ${esc(fmtIST(s.created_at))}</p></body></html>`);
  w.document.close(); w.focus(); setTimeout(() => w.print(), 250);
  return true;
}
