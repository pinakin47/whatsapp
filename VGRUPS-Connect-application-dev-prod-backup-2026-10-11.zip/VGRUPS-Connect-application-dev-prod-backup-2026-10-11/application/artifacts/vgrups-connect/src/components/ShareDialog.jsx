import React, { useRef } from "react";
import { QRCodeCanvas } from "qrcode.react";
import { toast } from "sonner";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "./ui/dialog";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Copy, Download, MessageCircle } from "lucide-react";

export function ShareDialog({ open, onOpenChange, url, title = "Share link", message = "" }) {
  const ref = useRef(null);
  const copy = async () => {
    try { await navigator.clipboard.writeText(url); }
    catch { const el = ref.current?.parentElement?.querySelector("input"); if (el) { el.select(); document.execCommand("copy"); } }
    toast.success("Link copied to clipboard");
  };
  const shareWa = () => window.open(`https://wa.me/?text=${encodeURIComponent((message ? message + " " : "") + url)}`, "_blank");
  const download = () => {
    const canvas = ref.current?.querySelector("canvas");
    if (!canvas) return;
    const a = document.createElement("a");
    a.href = canvas.toDataURL("image/png");
    a.download = "vgrups-qr.png";
    a.click();
  };
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-sm" data-testid="share-dialog">
        <DialogHeader><DialogTitle>{title}</DialogTitle><DialogDescription>Scan the QR, copy the link, or share on WhatsApp.</DialogDescription></DialogHeader>
        <div className="flex flex-col items-center gap-4">
          <div ref={ref} className="p-3 bg-white rounded-xl border" data-testid="share-qr">
            <QRCodeCanvas value={url || " "} size={180} fgColor="#3B5B2A" level="M" includeMargin />
          </div>
          <div className="w-full flex gap-2">
            <Input readOnly value={url} className="text-xs" data-testid="share-url-input" />
            <Button size="icon" variant="outline" onClick={copy} data-testid="share-copy-button"><Copy className="h-4 w-4" /></Button>
          </div>
          <div className="w-full flex gap-2">
            <Button variant="outline" className="flex-1" onClick={download} data-testid="share-download-button"><Download className="h-4 w-4 mr-1.5" /> Download QR</Button>
            <Button className="flex-1 bg-[#25D366] hover:bg-[#1da851] text-white" onClick={shareWa} data-testid="share-whatsapp-button"><MessageCircle className="h-4 w-4 mr-1.5" /> WhatsApp</Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
