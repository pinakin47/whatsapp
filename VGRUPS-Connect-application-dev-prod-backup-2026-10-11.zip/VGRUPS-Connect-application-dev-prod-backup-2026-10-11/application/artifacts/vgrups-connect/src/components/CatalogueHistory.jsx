import { useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import api, { apiError } from "../lib/api";
import { downloadReportCsv } from "../lib/downloadReportCsv";
import { trackEvent } from "../lib/analytics";
import { useAuth } from "../context/AuthContext";
import { Button } from "./ui/button";
import CatalogueReceiptEvidence from "./CatalogueReceiptEvidence";

const PAGE = 20;
const readable = (s) => String(s || "Unknown").replace(/_/g, " ");

// Saved reads only. This component deliberately has no send or retry actions.
export default function CatalogueHistory({ daily = false, contactRef, refreshKey = "" }) {
  const { user, can } = useAuth();
  const base = daily ? "/catalog/daily-mr" : "/contacts/catalogue-history";
  const canExport = can("catalog", "export") && (daily || can("crm", "export"));
  const [offset, setOffset] = useState(0);
  const [page, setPage] = useState(null);
  const [error, setError] = useState("");
  const [reload, setReload] = useState(0);
  const [selected, setSelected] = useState(null);
  const [detail, setDetail] = useState(null);
  const [detailError, setDetailError] = useState("");
  const [detailReload, setDetailReload] = useState(0);
  const [exporting, setExporting] = useState(false);
  const pendingOlderPage = useRef(false);
  const pendingDetailOpen = useRef(false);
  const historyType = daily ? "daily" : "individual";
  const params = new URLSearchParams({ offset: String(offset), limit: String(PAGE) });
  if (contactRef != null) params.set("contact_ref", contactRef);
  const query = params.toString();

  useEffect(() => {
    pendingOlderPage.current = false; pendingDetailOpen.current = false;
    setOffset(0); setSelected(null); setDetail(null);
  }, [base, contactRef, user?.id]);

  useEffect(() => {
    let active = true;
    pendingDetailOpen.current = false;
    setPage(null); setError(""); setSelected(null); setDetail(null);
    api.get(`${base}?${query}`).then(({ data }) => {
      if (!active) return;
      setPage(data);
      if (pendingOlderPage.current) {
        pendingOlderPage.current = false;
        trackEvent("catalogue_history_older_page_opened", { history_type: historyType });
      }
    })
      .catch((e) => { if (active) setError(apiError(e)); });
    return () => { active = false; };
  }, [base, query, reload, refreshKey, user?.id]);

  useEffect(() => {
    let active = true;
    setDetail(null); setDetailError("");
    if (selected) api.get(`${base}/${encodeURIComponent(selected)}`)
      .then(({ data }) => {
        if (!active) return;
        setDetail(data);
        if (pendingDetailOpen.current) {
          pendingDetailOpen.current = false;
          trackEvent("catalogue_history_detail_opened", { history_type: historyType });
        }
      })
      .catch((e) => { if (active) setDetailError(apiError(e)); });
    return () => { active = false; };
  }, [base, selected, detailReload, user?.id]);

  const exportCsv = async (path, exportScope) => {
    if (!canExport) return;
    setExporting(true);
    try {
      await downloadReportCsv(path, daily ? "daily_mr_catalogue_delivery.csv" : "individual_catalogue_delivery.csv");
      trackEvent("catalogue_history_csv_exported", { history_type: historyType, export_scope: exportScope });
    }
    catch (e) { toast.error(apiError(e)); }
    finally { setExporting(false); }
  };

  return (
    <section className="space-y-2 text-sm" data-testid={daily ? "daily-catalogue-history" : "individual-catalogue-history"}>
      <h3 className="font-semibold">{daily ? "Saved daily attempts" : "My saved catalogue attempts"}</h3>
      <p className="text-xs text-muted-foreground">Read-only history. Accepted means provider acceptance, not delivery or reading. Receipts match exact saved provider IDs; all required attachments need evidence to confirm the whole attempt. Unknown times are not guessed. Refresh to load newly saved receipts.</p>
      {error ? <p className="text-destructive" role="alert">{error} <Button size="sm" variant="outline" onClick={() => setReload((n) => n + 1)}>Reload history</Button></p>
        : !page ? <p role="status">Loading saved attempts…</p>
        : <>
          {!page.items.length && <p>No saved attempts on this page.</p>}
          <ul className="max-h-72 overflow-y-auto divide-y rounded-md border text-xs">
            {page.items.map((row) => (
              <li key={row.id} className="p-2 space-y-1">
                <div className="font-medium">{row.name || row.mr_name || row.phone || "Unknown recipient"}</div>
                <div>{row.date || row.created_at || "Date unknown"} · {readable(row.status)} · {row.total_parts ?? "Unknown"} parts</div>
                <div className="font-mono">Sender number: {row.sender_number || "Unknown"}</div>
                <CatalogueReceiptEvidence delivery={row.delivery} />
                {row.error && <p className="text-destructive">{row.error}</p>}
                <Button size="sm" variant="outline" onClick={() => {
                  if (selected !== row.id) pendingDetailOpen.current = true;
                  setSelected(row.id);
                }}>View saved attempt</Button>
              </li>
            ))}
          </ul>
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-xs">{page.items.length ? `${offset + 1}–${offset + page.items.length}` : "0"} of {page.total}</span>
            <Button size="sm" variant="outline" disabled={!offset} onClick={() => {
              pendingOlderPage.current = false;
              setOffset(Math.max(0, offset - PAGE));
            }}>Previous attempts</Button>
            <Button size="sm" variant="outline" disabled={!page.has_more} onClick={() => {
              pendingOlderPage.current = true;
              setOffset(offset + PAGE);
            }}>Older attempts</Button>
            <Button size="sm" variant="outline" onClick={() => setReload((n) => n + 1)}>Refresh history</Button>
            {canExport && <Button size="sm" variant="outline" disabled={exporting || !page.items.length}
              onClick={() => exportCsv(`${daily ? `${base}.csv` : "/contacts/catalogue-history.csv"}?${query}`, "page")}>Export this page CSV</Button>}
          </div>
        </>}
      {selected && <div className="rounded-md border p-3 space-y-2" data-testid="catalogue-saved-detail">
        <div className="flex flex-wrap justify-between gap-2"><h4 className="font-semibold">Saved attempt details</h4>
          <Button size="sm" variant="outline" onClick={() => setDetailReload((n) => n + 1)}>Refresh saved receipts</Button>
          <Button size="sm" variant="ghost" onClick={() => {
            pendingDetailOpen.current = false;
            setSelected(null);
          }}>Close details</Button></div>
        {detailError ? <p role="alert" className="text-destructive">{detailError} <Button size="sm" variant="outline" onClick={() => setDetailReload((n) => n + 1)}>Reload details</Button></p>
          : !detail ? <p role="status">Loading saved details…</p> : <>
            <div className="text-xs break-words">Attempt: {detail.id}</div>
            <div>{detail.name || detail.mr_name || "Unknown recipient"} · {detail.phone || "Phone unknown"}</div>
            <div>{detail.date || detail.created_at || "Date unknown"} · {readable(detail.status)}</div>
            <div className="font-mono text-xs">Sender number: {detail.sender_number || "Unknown"}</div>
            <div className="text-xs">{detail.accepted_parts}/{detail.total_parts ?? "Unknown"} accepted, {detail.removed_parts} removed, {detail.uncertain_parts} uncertain</div>
            <CatalogueReceiptEvidence delivery={detail.delivery} />
            {detail.error && <p className="text-destructive">{detail.error}</p>}
            {!detail.parts.length && <p className="text-xs">No saved attachment evidence.</p>}
            <ul className="max-h-56 overflow-y-auto divide-y text-xs">
              {detail.parts.map((part) => <li key={part.id} className="py-2 break-words">
                <div>{part.name || part.id} · {readable(part.status)}</div>
                <div>Provider message ID: {part.wamid || "Unknown"}</div>
                <div>Saved at: {part.created_at || "Unknown"}</div>
                <CatalogueReceiptEvidence delivery={part.delivery} attachment />
                {part.error && <div className="text-destructive">{part.error}</div>}
              </li>)}
            </ul>
            {canExport && <Button size="sm" variant="outline" disabled={exporting}
              onClick={() => exportCsv(`${base}/${encodeURIComponent(detail.id)}/report.csv`, "detail")}>Export saved attempt CSV</Button>}
          </>}
      </div>}
    </section>
  );
}
