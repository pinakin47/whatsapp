import React from "react";

export function PageHeader({ title, subtitle, actions, testId }) {
  return (
    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mb-6" data-testid={testId}>
      <div>
        <h1 className="text-2xl sm:text-3xl font-bold font-heading tracking-tight text-foreground">{title}</h1>
        {subtitle && <p className="text-sm text-muted-foreground mt-1">{subtitle}</p>}
      </div>
      {actions && <div className="flex items-center gap-2">{actions}</div>}
    </div>
  );
}

const STATUS_COLORS = {
  new: "bg-blue-100 text-blue-700 dark:bg-blue-500/15 dark:text-blue-300",
  contacted: "bg-indigo-100 text-indigo-700 dark:bg-indigo-500/15 dark:text-indigo-300",
  qualified: "bg-cyan-100 text-cyan-700 dark:bg-cyan-500/15 dark:text-cyan-300",
  interested: "bg-teal-100 text-teal-700 dark:bg-teal-500/15 dark:text-teal-300",
  quotation: "bg-amber-100 text-amber-700 dark:bg-amber-500/15 dark:text-amber-300",
  negotiation: "bg-orange-100 text-orange-700 dark:bg-orange-500/15 dark:text-orange-300",
  won: "bg-green-100 text-green-700 dark:bg-green-500/15 dark:text-green-300",
  lost: "bg-red-100 text-red-700 dark:bg-red-500/15 dark:text-red-300",
  follow_up: "bg-purple-100 text-purple-700 dark:bg-purple-500/15 dark:text-purple-300",
  approved: "bg-green-100 text-green-700 dark:bg-green-500/15 dark:text-green-300",
  pending: "bg-amber-100 text-amber-700 dark:bg-amber-500/15 dark:text-amber-300",
  draft: "bg-gray-100 text-gray-700 dark:bg-gray-500/15 dark:text-gray-300",
  rejected: "bg-red-100 text-red-700 dark:bg-red-500/15 dark:text-red-300",
  paid: "bg-green-100 text-green-700 dark:bg-green-500/15 dark:text-green-300",
  delivered: "bg-green-100 text-green-700 dark:bg-green-500/15 dark:text-green-300",
  shipped: "bg-blue-100 text-blue-700 dark:bg-blue-500/15 dark:text-blue-300",
};

export function StatusBadge({ status, children }) {
  const cls = STATUS_COLORS[status] || "bg-muted text-muted-foreground";
  return (
    <span className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium capitalize ${cls}`}>
      {children || (status || "").replace(/_/g, " ")}
    </span>
  );
}

export function DemoBadge() {
  return <span className="inline-flex items-center rounded px-1.5 py-0.5 text-[10px] font-medium bg-[#F0F4EE] text-[#3B5B2A] border border-[#3B5B2A]/20">DEMO</span>;
}
