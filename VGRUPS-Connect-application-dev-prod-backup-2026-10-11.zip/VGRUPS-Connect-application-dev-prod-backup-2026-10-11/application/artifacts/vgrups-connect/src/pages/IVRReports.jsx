import React, { useCallback, useEffect, useRef, useState } from "react";
import api, { apiError } from "../lib/api";
import { useAuth } from "../context/AuthContext";
import { PageHeader } from "../components/common";
import { Card } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../components/ui/table";
import { Loader2, RefreshCw } from "lucide-react";

const PERIODS = [["today", "Today"], ["week", "This week"], ["month", "This month"]];
const STATS = [["conversations", "Conversations"], ["new_conversations", "New conversations"], ["product_enquiries", "Product enquiries"], ["catalogue_requests", "Catalogue requests"], ["pricing_enquiries", "Pricing enquiries"], ["orders", "Orders"], ["order_status_requests", "Order status requests"], ["distributor_enquiries", "Distributor enquiries"], ["sales_enquiries", "Sales enquiries"], ["support_requests", "Support requests"], ["human_handoffs", "Human handoffs"]];

export default function IVRReports() {
  const { can } = useAuth();
  const allowed = can("reports", "view");
  const [period, setPeriod] = useState("today");
  const [data, setData] = useState(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const seq = useRef(0);

  const load = useCallback((p, quiet) => {
    const id = ++seq.current;
    if (!quiet) { setLoading(true); setData(null); }
    api.get("/ivr/analytics", { params: { period: p } })
      .then((r) => { if (id === seq.current) { setData(r.data); setError(""); } })
      .catch((e) => { if (id === seq.current && !quiet) setError(apiError(e)); })
      .finally(() => { if (id === seq.current) setLoading(false); });
  }, []);

  useEffect(() => {
    if (!allowed) return undefined;
    setError(""); load(period, false);
    const t = setInterval(() => load(period, true), 30000);
    return () => clearInterval(t);
  }, [period, allowed, load]);

  if (!allowed) return <div className="p-10 text-center text-sm text-muted-foreground" data-testid="reports-denied">You do not have permission to view reports.</div>;
  const s = data?.summary || {};
  const items = data?.items || [];
  return (
    <div className="p-4 md:p-6 animate-fade-up">
      <PageHeader title="IVR Reports" subtitle="WhatsApp IVR activity, refreshed every 30 seconds" testId="reports-header"
        actions={<div className="flex items-center gap-2">
          <div className="flex rounded-lg border overflow-hidden">{PERIODS.map(([k, l]) => <button key={k} onClick={() => setPeriod(k)} data-testid={`reports-period-${k}`} className={`px-3 py-1.5 text-sm ${period === k ? "bg-[#3B5B2A] text-white" : "hover:bg-muted"}`}>{l}</button>)}</div>
          <Button size="icon" variant="outline" onClick={() => load(period, false)} data-testid="reports-refresh"><RefreshCw className={`h-4 w-4 ${loading ? "animate-spin" : ""}`} /></Button>
        </div>} />
      {error ? (
        <div className="p-10 text-center text-sm" data-testid="reports-error"><p className="text-red-600 mb-3">{error}</p><Button variant="outline" onClick={() => load(period, false)}>Retry</Button></div>
      ) : !data ? (
        <div className="p-10 text-center"><Loader2 className="h-5 w-5 animate-spin mx-auto" /></div>
      ) : (
        <>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
            {STATS.map(([k, l]) => <Card key={k} className="p-3" data-testid={`stat-${k}`}><div className="text-xs text-muted-foreground">{l}</div><div className="text-2xl font-semibold mt-1">{s[k] ?? 0}</div></Card>)}
          </div>
          <Card className="overflow-hidden">
            <p className="px-4 py-3 text-xs text-muted-foreground">Most recent 500 IVR events. Summary counts cover the whole selected period.</p>
            <div className="overflow-x-auto"><Table>
              <TableHeader><TableRow><TableHead>Time</TableHead><TableHead>Customer</TableHead><TableHead>Message</TableHead><TableHead>Option</TableHead><TableHead>Result</TableHead><TableHead className="hidden md:table-cell">Linked</TableHead><TableHead>Handoff</TableHead><TableHead className="hidden md:table-cell">Status</TableHead></TableRow></TableHeader>
              <TableBody>
                {items.map((r) => (
                  <TableRow key={r.id} data-testid={`ivr-report-row-${r.id}`}>
                    <TableCell className="text-xs text-muted-foreground whitespace-nowrap">{r.created_at ? new Date(r.created_at).toLocaleString() : ""}</TableCell>
                    <TableCell className="text-sm"><div>{r.customer_name || "-"}</div><div className="text-xs font-mono text-muted-foreground">{r.phone}</div></TableCell>
                    <TableCell className="text-sm max-w-xs whitespace-pre-wrap break-words">{r.message || "-"}</TableCell>
                    <TableCell className="text-sm">{r.option || "-"}</TableCell>
                    <TableCell className="text-sm">{r.result || "-"}</TableCell>
                    <TableCell className="hidden md:table-cell text-xs text-muted-foreground">{[r.lead_id && `Lead ${r.lead_id}`, r.order_id && `Order ${r.order_id}`, r.task_id && `Task ${r.task_id}`].filter(Boolean).join(", ") || "-"}</TableCell>
                    <TableCell className="text-xs">{r.handoff ? "Yes" : "No"}</TableCell>
                    <TableCell className="hidden md:table-cell text-xs capitalize">{r.conversation_status || "-"}</TableCell>
                  </TableRow>
                ))}
                {items.length === 0 && <TableRow><TableCell colSpan={8} className="text-center py-10 text-muted-foreground">No IVR activity in this period</TableCell></TableRow>}
              </TableBody>
            </Table></div>
          </Card>
        </>
      )}
    </div>
  );
}
