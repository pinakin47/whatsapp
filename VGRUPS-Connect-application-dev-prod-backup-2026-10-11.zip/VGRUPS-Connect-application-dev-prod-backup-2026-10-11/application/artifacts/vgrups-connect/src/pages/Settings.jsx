import React, { useCallback, useEffect, useState } from "react";
import api, { apiError } from "../lib/api";
import { toast } from "sonner";
import { useAuth } from "../context/AuthContext";
import { PageHeader } from "../components/common";
import UsersPanel from "../components/settings/UsersPanel";
import MRsPanel from "../components/settings/MRsPanel";
import RolesPanel from "../components/settings/RolesPanel";
import { Card } from "../components/ui/card";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "../components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../components/ui/table";
import { ShieldCheck } from "lucide-react";

const DEFAULT_ACTIONS = ["view", "create", "edit", "delete", "export", "send", "approve", "assign", "manage"];

export default function Settings() {
  const { can, setUser } = useAuth();
  const [roles, setRoles] = useState([]);
  const [modules, setModules] = useState([]);
  const [actions, setActions] = useState(DEFAULT_ACTIONS);
  const [logs, setLogs] = useState([]);

  const loadRoles = useCallback(() => api.get("/roles").then((r) => {
    setRoles(r.data.roles || []); setModules(r.data.modules || []); setActions(r.data.actions || DEFAULT_ACTIONS);
  }).catch((e) => toast.error(apiError(e))), []);

  const refreshSession = useCallback(async () => {
    try { const r = await api.get("/auth/me"); setUser(r.data); } catch (e) { /* session refresh best effort */ }
  }, [setUser]);

  useEffect(() => {
    loadRoles();
    if (can("settings", "view")) api.get("/audit-logs").then((r) => setLogs(r.data.items)).catch(() => {});
    // eslint-disable-next-line
  }, []);

  return (
    <div className="p-4 md:p-6 animate-fade-up">
      <PageHeader title="Settings" subtitle="Team, roles, permissions & audit" testId="settings-header" />
      <Tabs defaultValue="users">
        <TabsList>
          <TabsTrigger value="users" data-testid="settings-tab-users">Team</TabsTrigger>
          <TabsTrigger value="roles" data-testid="settings-tab-roles">Roles & Permissions</TabsTrigger>
          {can("settings", "view") && <TabsTrigger value="mrs" data-testid="settings-tab-mrs">MRs</TabsTrigger>}
          <TabsTrigger value="audit" data-testid="settings-tab-audit">Audit Log</TabsTrigger>
        </TabsList>
        <TabsContent value="users" className="mt-4"><UsersPanel roles={roles} refreshSession={refreshSession} /></TabsContent>
        <TabsContent value="roles" className="mt-4"><RolesPanel roles={roles} modules={modules} actions={actions} reload={loadRoles} refreshSession={refreshSession} /></TabsContent>
        {can("settings", "view") && <TabsContent value="mrs" className="mt-4"><MRsPanel /></TabsContent>}
        <TabsContent value="audit" className="mt-4">
          <Card className="overflow-hidden">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader><TableRow><TableHead>User</TableHead><TableHead>Action</TableHead><TableHead>Module</TableHead><TableHead>Result</TableHead><TableHead className="hidden md:table-cell">Time</TableHead></TableRow></TableHeader>
                <TableBody>
                  {logs.map((l) => (
                    <TableRow key={l.id} data-testid={`audit-row-${l.id}`}>
                      <TableCell className="text-sm">{l.user_name || l.user_email || "-"}</TableCell>
                      <TableCell><span className="text-xs font-mono rounded bg-muted px-1.5 py-0.5">{l.action}</span></TableCell>
                      <TableCell className="text-sm capitalize">{l.module}</TableCell>
                      <TableCell><span className={`text-xs ${l.result === "success" ? "text-green-600" : "text-red-600"}`}>{l.result}</span></TableCell>
                      <TableCell className="hidden md:table-cell text-xs text-muted-foreground">{l.created_at ? new Date(l.created_at).toLocaleString() : ""}</TableCell>
                    </TableRow>
                  ))}
                  {logs.length === 0 && <TableRow><TableCell colSpan={5} className="text-center py-10 text-muted-foreground"><ShieldCheck className="h-6 w-6 mx-auto mb-2 opacity-40" />No audit records yet</TableCell></TableRow>}
                </TableBody>
              </Table>
            </div>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
