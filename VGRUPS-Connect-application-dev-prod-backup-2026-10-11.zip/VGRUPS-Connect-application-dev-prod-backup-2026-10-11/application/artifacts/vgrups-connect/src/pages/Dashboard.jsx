import React, { useEffect, useState } from "react";
import api from "../lib/api";
import { PageHeader } from "../components/common";
import { Card } from "../components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../components/ui/select";
import {
  Users, UserPlus, MessageSquare, Mail, CalendarClock, ShoppingCart, IndianRupee,
  Wallet, Megaphone, Reply, Percent, TrendingUp, TrendingDown,
} from "lucide-react";
import {
  ResponsiveContainer, AreaChart, Area, BarChart, Bar, LineChart, Line,
  PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend,
} from "recharts";

const RANGES = [
  { v: "today", l: "Today" }, { v: "yesterday", l: "Yesterday" }, { v: "7days", l: "Last 7 days" },
  { v: "30days", l: "Last 30 days" }, { v: "this_month", l: "This month" }, { v: "last_month", l: "Last month" },
];
const COLORS = ["#3B5B2A", "#6E8B5B", "#D97706", "#2563EB", "#9333EA", "#DC2626", "#0891B2", "#65A30D"];

const CARDS = [
  { key: "total_contacts", label: "Total Contacts", icon: Users, fmt: (v) => v },
  { key: "new_leads", label: "New Leads", icon: UserPlus, fmt: (v) => v },
  { key: "open_conversations", label: "Open Conversations", icon: MessageSquare, fmt: (v) => v },
  { key: "unread_messages", label: "Unread Messages", icon: Mail, fmt: (v) => v },
  { key: "todays_followups", label: "Today's Follow-ups", icon: CalendarClock, fmt: (v) => v },
  { key: "orders", label: "Orders", icon: ShoppingCart, fmt: (v) => v },
  { key: "revenue", label: "Revenue", icon: IndianRupee, fmt: (v) => `₹${Number(v).toLocaleString("en-IN")}` },
  { key: "pending_payments", label: "Pending Payments", icon: Wallet, fmt: (v) => `₹${Number(v).toLocaleString("en-IN")}` },
  { key: "campaign_messages", label: "Campaign Messages", icon: Megaphone, fmt: (v) => Number(v).toLocaleString("en-IN") },
  { key: "campaign_replies", label: "Campaign Replies", icon: Reply, fmt: (v) => v },
  { key: "conversion_rate", label: "Conversion Rate", icon: Percent, fmt: (v) => `${v}%` },
];

function ChartCard({ title, children, testId }) {
  return (
    <Card className="p-5" data-testid={testId}>
      <h3 className="text-sm font-semibold font-heading mb-4">{title}</h3>
      <div className="h-64 w-full min-w-0">{children}</div>
    </Card>
  );
}

export default function Dashboard() {
  const [range, setRange] = useState("30days");
  const [stats, setStats] = useState(null);
  const [charts, setCharts] = useState(null);

  useEffect(() => {
    api.get(`/dashboard/stats?rng=${range}`).then((r) => setStats(r.data));
    api.get(`/dashboard/charts?rng=${range}`).then((r) => setCharts(r.data));
  }, [range]);

  return (
    <div className="p-4 md:p-6 animate-fade-up">
      <PageHeader
        title="Dashboard"
        subtitle="VGRUPS Healthcare — business command center"
        testId="dashboard-header"
        actions={
          <Select value={range} onValueChange={setRange}>
            <SelectTrigger className="w-40" data-testid="dashboard-range-select"><SelectValue /></SelectTrigger>
            <SelectContent>
              {RANGES.map((r) => <SelectItem key={r.v} value={r.v}>{r.l}</SelectItem>)}
            </SelectContent>
          </Select>
        }
      />

      {/* Stat cards */}
      <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-3 md:gap-4">
        {CARDS.map((c) => (
          <Card key={c.key} className="p-4 hover:shadow-md transition-shadow" data-testid={`stat-card-${c.key}`}>
            <div className="flex items-center justify-between">
              <div className="h-9 w-9 rounded-lg bg-[#F0F4EE] dark:bg-[#1D2B1E] flex items-center justify-center">
                <c.icon className="h-[18px] w-[18px] text-[#3B5B2A] dark:text-[#8BAA78]" />
              </div>
            </div>
            <div className="mt-3 text-2xl font-bold font-heading tracking-tight">
              {stats ? c.fmt(stats[c.key]) : "—"}
            </div>
            <div className="text-xs text-muted-foreground mt-0.5">{c.label}</div>
          </Card>
        ))}
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mt-5">
        <ChartCard title="Lead Trend" testId="chart-lead-trend">
          {charts && (
            <ResponsiveContainer>
              <AreaChart data={charts.lead_trend}>
                <defs>
                  <linearGradient id="gLead" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3B5B2A" stopOpacity={0.35} />
                    <stop offset="95%" stopColor="#3B5B2A" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis dataKey="date" fontSize={11} stroke="hsl(var(--muted-foreground))" />
                <YAxis fontSize={11} stroke="hsl(var(--muted-foreground))" />
                <Tooltip contentStyle={{ fontSize: 12, borderRadius: 8 }} />
                <Area type="monotone" dataKey="leads" stroke="#3B5B2A" strokeWidth={2} fill="url(#gLead)" />
              </AreaChart>
            </ResponsiveContainer>
          )}
        </ChartCard>

        <ChartCard title="Sales Trend (₹)" testId="chart-sales-trend">
          {charts && (
            <ResponsiveContainer>
              <LineChart data={charts.sales_trend}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis dataKey="date" fontSize={11} stroke="hsl(var(--muted-foreground))" />
                <YAxis fontSize={11} stroke="hsl(var(--muted-foreground))" />
                <Tooltip contentStyle={{ fontSize: 12, borderRadius: 8 }} />
                <Line type="monotone" dataKey="value" stroke="#D97706" strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          )}
        </ChartCard>

        <ChartCard title="WhatsApp Conversation Trend" testId="chart-conversation-trend">
          {charts && (
            <ResponsiveContainer>
              <BarChart data={charts.conversation_trend}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis dataKey="date" fontSize={11} stroke="hsl(var(--muted-foreground))" />
                <YAxis fontSize={11} stroke="hsl(var(--muted-foreground))" />
                <Tooltip contentStyle={{ fontSize: 12, borderRadius: 8 }} />
                <Bar dataKey="conversations" fill="#6E8B5B" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          )}
        </ChartCard>

        <ChartCard title="Campaign Performance" testId="chart-campaign-performance">
          {charts && (
            <ResponsiveContainer>
              <BarChart data={charts.campaign_performance}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis dataKey="name" fontSize={10} stroke="hsl(var(--muted-foreground))" />
                <YAxis fontSize={11} stroke="hsl(var(--muted-foreground))" />
                <Tooltip contentStyle={{ fontSize: 12, borderRadius: 8 }} />
                <Legend wrapperStyle={{ fontSize: 11 }} />
                <Bar dataKey="sent" fill="#3B5B2A" radius={[3, 3, 0, 0]} />
                <Bar dataKey="delivered" fill="#6E8B5B" radius={[3, 3, 0, 0]} />
                <Bar dataKey="read" fill="#D97706" radius={[3, 3, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          )}
        </ChartCard>

        <ChartCard title="Lead Source" testId="chart-lead-source">
          {charts && (
            <ResponsiveContainer>
              <PieChart>
                <Pie data={charts.lead_source} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={85} label={(e) => e.name}>
                  {charts.lead_source.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                </Pie>
                <Tooltip contentStyle={{ fontSize: 12, borderRadius: 8 }} />
              </PieChart>
            </ResponsiveContainer>
          )}
        </ChartCard>

        <ChartCard title="MR Performance" testId="chart-mr-performance">
          {charts && (
            <ResponsiveContainer>
              <BarChart data={charts.mr_performance} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis type="number" fontSize={11} stroke="hsl(var(--muted-foreground))" />
                <YAxis type="category" dataKey="name" fontSize={10} width={90} stroke="hsl(var(--muted-foreground))" />
                <Tooltip contentStyle={{ fontSize: 12, borderRadius: 8 }} />
                <Legend wrapperStyle={{ fontSize: 11 }} />
                <Bar dataKey="leads" fill="#6E8B5B" radius={[0, 3, 3, 0]} />
                <Bar dataKey="won" fill="#3B5B2A" radius={[0, 3, 3, 0]} />
              </BarChart>
            </ResponsiveContainer>
          )}
        </ChartCard>
      </div>
    </div>
  );
}
