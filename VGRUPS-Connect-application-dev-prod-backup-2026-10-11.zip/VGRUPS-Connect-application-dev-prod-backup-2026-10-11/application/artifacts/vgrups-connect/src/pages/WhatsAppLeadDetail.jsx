import React, { useEffect, useRef, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import { toast } from "sonner";
import api, { apiError } from "../lib/api";
import { useAuth } from "../context/AuthContext";
import { PageHeader } from "../components/common";
import { Card } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { usePoll, label, fmt } from "../lib/leadCapture";
import { ErrorBox, Pill, RequestsTable, Skeleton, Empty } from "../components/leadcapture/Bits";

const TEXT = ["title", "contact_name", "designation", "company", "hospital_name", "clinic_name", "doctor_name", "pharmacy_name", "distributor_name", "institution_name", "mobile", "alternative_phone", "email", "location", "address", "product_interest", "quantity", "next_followup_at"];
const AREA = ["requirement", "notes"];
const ADMIN_AREA = ["admin_remarks"];
const SEL = ["lead_type", "priority", "status"];
const pick = (lead) => Object.fromEntries([...TEXT, ...AREA, ...ADMIN_AREA, ...SEL, "assigned_to", "verification_status"].map((k) => [k, lead[k] ?? ""]));
const sc = "h-9 w-full rounded-md border border-input bg-background px-2 text-sm";

function HistoryPager({page, total = 0, onPage, name}) {
  if (total <= 50) return null;
  return <div className="flex items-center justify-between gap-2 mt-3 text-xs">
    <Button variant="outline" size="sm" aria-label={`Newer ${name}`} disabled={page <= 1} onClick={() => onPage(page - 1)}>Newer</Button>
    <span>Page {page} of {Math.ceil(total / 50)} · {total} records</span>
    <Button variant="outline" size="sm" aria-label={`Older ${name}`} disabled={page * 50 >= total} onClick={() => onPage(page + 1)}>Older</Button>
  </div>;
}

export default function WhatsAppLeadDetail() {
  const { id } = useParams();
  const nav = useNavigate();
  const { user } = useAuth();
  const [activityPage, setActivityPage] = useState(1);
  const [timelinePage, setTimelinePage] = useState(1);
  useEffect(() => { setActivityPage(1); setTimelinePage(1); }, [id]);
  const { data, error, loading, reload } = usePoll(`/lead-capture/leads/${id}`, {activity_page: activityPage, timeline_page: timelinePage}, 5000);
  const opts = usePoll("/lead-capture/options", null, 60000).data;
  const [draft, setDraft] = useState(null);
  const [base, setBase] = useState(null);
  const [busy, setBusy] = useState("");
  const seeded = useRef(null);
  const draftRef = useRef(null); draftRef.current = draft;

  // Seed the draft once per lead. Later polls refresh read-only sections only.
  useEffect(() => { if (data?.lead && seeded.current !== id) { seeded.current = id; const p = pick(data.lead); setDraft(p); setBase(p); } }, [data, id]);

  if (error && !data) return <div className="p-6"><ErrorBox message={error} onRetry={reload} /></div>;
  if (loading || !data || !draft) return <div className="p-6"><Skeleton rows={6} /></div>;
  const { lead, activities = [], timeline = [], requests = [] } = data;
  const canEdit = data.can_edit; const isAdmin = !!opts?.can_manage;
  const changed = TEXT.concat(AREA, ADMIN_AREA, SEL, ["assigned_to", "verification_status"]).filter((k) => String(draft[k]) !== String(base[k]));
  const set = (k) => (e) => setDraft({ ...draft, [k]: e.target.value });

  const run = async (key, fn, ok) => { setBusy(key); try { await fn(); toast.success(ok); reload(); } catch (e) { toast.error(apiError(e)); } finally { setBusy(""); } };
  const save = () => run("save", async () => {
    const body = {};
    changed.forEach((k) => { if (k === "assigned_to" && !isAdmin) return; if ((k === "admin_remarks" || k === "verification_status") && !isAdmin) return; body[k] = k === "assigned_to" ? (draft[k] || null) : draft[k]; });
    const r = await api.patch(`/lead-capture/leads/${id}`, body);
    const nl = r.data?.lead || r.data; if (nl?.id) { const p = pick(nl); setDraft(p); setBase(p); } else setBase(draft);
  }, "Lead updated");
  const del = async () => {
    if (!window.confirm("Delete this lead permanently?")) return;
    try { await api.delete(`/lead-capture/leads/${id}`); toast.success("Lead deleted"); nav("/leads/whatsapp"); } catch (e) { toast.error(apiError(e)); }
  };

  const F = ({ k, name, wide }) => <div className={wide ? "col-span-2" : ""}><label className="text-xs text-muted-foreground">{name || label(k)}</label>
    <Input value={draft[k]} disabled={!canEdit} onChange={set(k)} data-testid={`lc-field-${k}`} type={k === "next_followup_at" ? "datetime-local" : "text"} /></div>;
  const S = ({ k, list }) => <div><label className="text-xs text-muted-foreground">{label(k)}</label>
    <select className={sc} disabled={!canEdit} value={draft[k]} onChange={set(k)} data-testid={`lc-field-${k}`}><option value="">-</option>{list.map((x) => <option key={x} value={x}>{label(x)}</option>)}</select></div>;
  const T = ({ k, ro }) => <div className="col-span-2"><label className="text-xs text-muted-foreground">{label(k)}</label>
    <textarea className="w-full rounded-md border border-input bg-background p-2 text-sm min-h-[70px]" disabled={!canEdit || ro} value={draft[k]} onChange={set(k)} data-testid={`lc-field-${k}`} /></div>;

  return (
    <div className="p-4 md:p-6 space-y-4 animate-fade-up" data-testid="wa-lead-detail">
      <PageHeader title={`${lead.display_id || `Lead ${lead.id}`} - ${lead.title || lead.contact_name || "Untitled"}`} subtitle={`Captured ${fmt(lead.created_at)} from ${lead.mr_name || "MR"}${lead.employee_id ? ` (${lead.employee_id})` : ""}`}
        actions={<Link to="/leads/whatsapp" className="text-sm inline-flex items-center gap-1 text-muted-foreground"><ArrowLeft className="h-4 w-4" />All WhatsApp leads</Link>} />
      {error && <ErrorBox message={`Refresh failed: ${error}`} onRetry={reload} />}
      <div className="flex flex-wrap gap-2 items-center"><Pill value={lead.status} /><Pill value={lead.priority} />
        <span className="text-xs">Capture: {label(lead.capture_status)}</span><span className="text-xs">Verification: {label(lead.verification_status)}</span>
        {lead.confidence != null && <span className="text-xs">Confidence: {lead.confidence}</span>}</div>
      <div className="grid lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 space-y-4 min-w-0">
          <Card className="p-4">
            <h3 className="text-xs font-semibold uppercase tracking-wide text-muted-foreground mb-3">Lead details {!canEdit && "(read only)"}</h3>
            <div className="grid grid-cols-2 gap-3">
               {F({k: "title", wide: true})}{F({k: "contact_name"})}{F({k: "designation"})}{F({k: "company"})}{F({k: "hospital_name"})}{F({k: "clinic_name"})}{F({k: "doctor_name"})}{F({k: "pharmacy_name"})}{F({k: "distributor_name"})}{F({k: "institution_name"})}
               {F({k: "mobile"})}{F({k: "alternative_phone"})}{F({k: "email"})}{F({k: "location"})}{F({k: "address", wide: true})}
               {S({k: "lead_type", list: opts?.lead_types || []})}{S({k: "priority", list: opts?.priorities || []})}{S({k: "status", list: opts?.statuses || []})}
               {F({k: "product_interest"})}{F({k: "quantity"})}{F({k: "next_followup_at", name: "Next follow-up"})}
               {T({k: "requirement"})}{T({k: "notes"})}
              {isAdmin && <>
                <div><label className="text-xs text-muted-foreground">Assigned MR</label>
                  <select className={sc} disabled={!canEdit} value={draft.assigned_to} onChange={set("assigned_to")} data-testid="lc-field-assigned_to"><option value="">-</option>{(opts?.mrs || []).map((m) => <option key={m.id} value={m.mr_id}>{m.name}</option>)}</select></div>
                <div><label className="text-xs text-muted-foreground">Verification</label>
                  <select className={sc} disabled={!canEdit} value={draft.verification_status} onChange={set("verification_status")} data-testid="lc-field-verification_status"><option value="Admin verified">Admin verified</option><option value="Needs Verification">Needs Verification</option>{!["Admin verified", "Needs Verification"].includes(draft.verification_status) && <option value={draft.verification_status}>{draft.verification_status || "Unverified"}</option>}</select></div>
                 {T({k: "admin_remarks"})}
              </>}
            </div>
            {canEdit && <div className="flex gap-2 mt-4"><Button data-testid="lc-save" disabled={!changed.length || busy === "save"} onClick={save} className="bg-[#3B5B2A] hover:bg-[#2D4720]">{busy === "save" ? "Saving..." : "Save changes"}</Button>
              {changed.length > 0 && <Button variant="outline" onClick={() => setDraft(base)}>Discard</Button>}
              {data.can_delete && <Button variant="outline" className="ml-auto text-red-600" onClick={del} data-testid="lc-delete">Delete</Button>}</div>}
          </Card>
          <Card className="p-4 space-y-2" data-testid="lc-evidence">
            <h3 className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Original message and extraction</h3>
            {lead.original_message ? <p className="text-sm whitespace-pre-wrap break-words rounded bg-muted/50 p-2">{lead.original_message}</p> : <p className="text-sm text-muted-foreground">No original message stored.</p>}
            {lead.ai_extracted && <pre className="text-xs bg-muted/50 rounded p-2 overflow-x-auto">{typeof lead.ai_extracted === "string" ? lead.ai_extracted : JSON.stringify(lead.ai_extracted, null, 2)}</pre>}
          </Card>
          <Card className="p-4"><h3 className="text-xs font-semibold uppercase tracking-wide text-muted-foreground mb-2">Conversation evidence</h3>
            {!activities.length ? <Empty title="No messages recorded" /> : <div className="space-y-2">{activities.map((a) => (
               <div key={a.id} className="rounded bg-muted/50 p-2 text-sm"><div className="text-xs text-muted-foreground">{a.mr_name || a.sender} - {a.direction} - {fmt(a.created_at)} IST</div><p className="whitespace-pre-wrap break-words">{a.body}</p>
                 {a.extracted && <pre className="mt-1 text-xs overflow-x-auto">{JSON.stringify(a.extracted, null, 2)}</pre>}</div>))}</div>}
            <HistoryPager page={activityPage} total={data.activity_total} onPage={setActivityPage} name="messages" />
          </Card>
        </div>
        <div className="space-y-4 min-w-0">
          <Card className="p-4 space-y-2"><h3 className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Actions</h3>
            {!lead.mobile && <p className="text-xs text-amber-700">Phone number is missing.</p>}
            {canEdit && <Button variant="outline" className="w-full" disabled={busy === "phone"} data-testid="lc-request-phone" onClick={() => run("phone", () => api.post(`/lead-capture/leads/${id}/request-phone`, {}), "Phone request queued")}>Request phone number</Button>}
            {isAdmin && <Button variant="outline" className="w-full" disabled={busy === "notif"} data-testid="lc-repair-alerts" onClick={() => run("notif", () => api.post(`/lead-capture/leads/${id}/notifications`, {}), "Admin alerts repaired")}>Repair admin alerts</Button>}
            <p className="text-xs text-muted-foreground">Voice requests wait for Twilio connection. Nothing is shown as delivered without evidence.</p>
            <p className="text-[11px] text-muted-foreground">Signed in as {user?.name}</p>
          </Card>
          <Card className="p-4"><h3 className="text-xs font-semibold uppercase tracking-wide text-muted-foreground mb-2">Phone requests</h3><RequestsTable items={requests} /></Card>
          <Card className="p-4" data-testid="lc-timeline"><h3 className="text-xs font-semibold uppercase tracking-wide text-muted-foreground mb-2">Audit history (immutable)</h3>
            {!timeline.length ? <p className="text-sm text-muted-foreground">No events.</p> : <ol className="space-y-2 border-l border-border pl-3">{timeline.map((t) => (
               <li key={t.id} className="text-sm"><div className="font-medium">{label(t.event)}</div><div className="text-xs text-muted-foreground break-words">{t.detail}</div><div className="text-[10px] text-muted-foreground">{fmt(t.created_at)} IST</div></li>))}</ol>}
            <HistoryPager page={timelinePage} total={data.timeline_total} onPage={setTimelinePage} name="audit events" />
          </Card>
        </div>
      </div>
    </div>
  );
}
