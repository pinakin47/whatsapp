import React, { useEffect, useState } from "react";
import api, { apiError } from "../lib/api";
import { toast } from "sonner";
import { PageHeader } from "../components/common";
import { Card } from "../components/ui/card";
import { Button } from "../components/ui/button";
import {
  Send, Mail, CreditCard, Bot, MessageSquare, Globe, Target,
  CheckCircle2, XCircle, Loader2, RefreshCw,
} from "lucide-react";

const ICONS = { whatsapp: Send, brevo: Mail, razorpay: CreditCard, ai: Bot, sms: MessageSquare, google: Globe, meta_ads: Target };

export default function Integrations() {
  const [data, setData] = useState({});
  const [testing, setTesting] = useState("");

  const load = () => api.get("/integrations").then((r) => setData(r.data));
  useEffect(() => { load(); }, []);

  const test = async (key) => {
    setTesting(key);
    try {
      const { data: res } = await api.post(`/integrations/${key}/test`);
      if (res.ok) toast.success(res.message);
      else toast.warning(res.message);
    } catch (e) { toast.error(apiError(e)); } finally { setTesting(""); }
  };

  return (
    <div className="p-4 md:p-6 animate-fade-up">
      <PageHeader title="Integrations" subtitle="Connect WhatsApp, email, payments, AI & more" testId="integrations-header" />
      <Card className="p-4 mb-5 bg-[#F0F4EE] dark:bg-[#1D2B1E] border-[#3B5B2A]/20">
        <p className="text-sm text-[#3B5B2A] dark:text-[#8BAA78]">
          Credentials are stored as backend environment variables and never exposed to the browser.
          Add the listed variables to <span className="font-mono">backend/.env</span> to activate each integration.
        </p>
      </Card>
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {Object.entries(data).map(([key, it]) => {
          const Icon = ICONS[key] || Globe;
          return (
            <Card key={key} className="p-5" data-testid={`integration-card-${key}`}>
              <div className="flex items-start justify-between">
                <div className="h-10 w-10 rounded-lg bg-[#F0F4EE] dark:bg-[#1D2B1E] flex items-center justify-center">
                  <Icon className="h-5 w-5 text-[#3B5B2A] dark:text-[#8BAA78]" />
                </div>
                {it.configured
                  ? <span className="flex items-center gap-1 text-xs text-green-600"><CheckCircle2 className="h-4 w-4" /> Connected</span>
                  : <span className="flex items-center gap-1 text-xs text-[#D97706]"><XCircle className="h-4 w-4" /> Not Connected</span>}
              </div>
              <div className="font-semibold font-heading mt-3">{it.name}</div>
              <div className="text-xs text-muted-foreground mt-1">{it.docs}</div>
              {!it.configured && (
                <div className="mt-2 flex flex-wrap gap-1">
                  {it.required_env.map((v) => <span key={v} className="text-[10px] font-mono rounded bg-muted px-1.5 py-0.5">{v}</span>)}
                </div>
              )}
              <Button variant="outline" size="sm" className="mt-4 w-full" data-testid={`test-integration-${key}`} onClick={() => test(key)} disabled={testing === key}>
                {testing === key ? <Loader2 className="h-4 w-4 animate-spin" /> : <><RefreshCw className="h-3.5 w-3.5 mr-1" /> Test Connection</>}
              </Button>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
