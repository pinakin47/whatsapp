import React from "react";
import { PageHeader } from "../components/common";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "../components/ui/tabs";
import WhatsAppConnections from "./WhatsAppConnections";
import WhatsAppTemplates from "./WhatsAppTemplates";
import BotSettings from "./BotSettings";

export default function WhatsAppHub() {
  return (
    <div className="p-4 md:p-6 animate-fade-up">
      <PageHeader title="WhatsApp" subtitle="Connect numbers via QR, auto-reply bot, and message templates" testId="whatsapp-hub-header" />
      <Tabs defaultValue="connections">
        <TabsList>
          <TabsTrigger value="connections" data-testid="wa-tab-connections">Connections</TabsTrigger>
          <TabsTrigger value="bot" data-testid="wa-tab-bot">Auto-Reply</TabsTrigger>
          <TabsTrigger value="templates" data-testid="wa-tab-templates">Templates</TabsTrigger>
        </TabsList>
        <TabsContent value="connections" className="mt-4">
          <WhatsAppConnections />
        </TabsContent>
        <TabsContent value="bot" className="mt-4">
          <BotSettings />
        </TabsContent>
        <TabsContent value="templates" className="mt-4">
          <div className="-mx-4 -mt-4 md:-mx-6 md:-mt-6">
            <WhatsAppTemplates embedded />
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
