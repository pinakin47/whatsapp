import React, { useEffect, useState } from "react";
import api, { apiError } from "../lib/api";
import { toast } from "sonner";
import { PageHeader, DemoBadge } from "../components/common";
import { Card } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Checkbox } from "../components/ui/checkbox";
import { CalendarClock, CheckCircle2 } from "lucide-react";

const PRIORITY = { high: "text-red-600", medium: "text-amber-600", low: "text-green-600" };

export default function Tasks() {
  const [items, setItems] = useState([]);
  const load = () => api.get("/tasks").then((r) => setItems(r.data.items));
  useEffect(() => { load(); }, []);

  const toggle = async (t) => {
    const next = t.status === "done" ? "pending" : "done";
    try { await api.patch(`/tasks/${t.id}?status=${next}`); load(); }
    catch (e) { toast.error(apiError(e)); }
  };

  const pending = items.filter((t) => t.status !== "done");
  const done = items.filter((t) => t.status === "done");

  return (
    <div className="p-4 md:p-6 animate-fade-up">
      <PageHeader title="Tasks & Follow-ups" subtitle={`${pending.length} pending`} testId="tasks-header" />
      <div className="space-y-2">
        {pending.map((t) => (
          <Card key={t.id} className="p-3 flex items-center gap-3" data-testid={`task-row-${t.id}`}>
            <Checkbox checked={false} onCheckedChange={() => toggle(t)} data-testid={`task-check-${t.id}`} />
            <div className="flex-1 min-w-0">
              <div className="text-sm font-medium flex items-center gap-2">{t.title} {t.is_demo && <DemoBadge />}</div>
              <div className="text-xs text-muted-foreground flex items-center gap-2 mt-0.5">
                <CalendarClock className="h-3.5 w-3.5" /> {t.due_date ? new Date(t.due_date).toLocaleDateString() : "No date"} · <span className="capitalize">{t.task_type?.replace(/_/g, " ")}</span>
              </div>
            </div>
            <span className={`text-xs font-medium capitalize ${PRIORITY[t.priority] || ""}`}>{t.priority}</span>
          </Card>
        ))}
        {done.length > 0 && <div className="text-xs text-muted-foreground pt-4 pb-1">Completed</div>}
        {done.map((t) => (
          <Card key={t.id} className="p-3 flex items-center gap-3 opacity-60" data-testid={`task-row-${t.id}`}>
            <Checkbox checked onCheckedChange={() => toggle(t)} data-testid={`task-check-${t.id}`} />
            <div className="flex-1 text-sm line-through">{t.title}</div>
            <CheckCircle2 className="h-4 w-4 text-green-600" />
          </Card>
        ))}
        {items.length === 0 && <div className="text-center py-10 text-muted-foreground">No tasks</div>}
      </div>
    </div>
  );
}
