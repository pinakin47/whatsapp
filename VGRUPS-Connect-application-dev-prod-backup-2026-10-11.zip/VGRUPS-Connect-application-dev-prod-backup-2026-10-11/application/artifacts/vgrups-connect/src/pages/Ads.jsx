import React, { useEffect, useState, useCallback } from "react";
import api, { apiError } from "../lib/api";
import { toast } from "sonner";
import { PageHeader } from "../components/common";
import { Card } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { Switch } from "../components/ui/switch";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../components/ui/table";
import { Target, Copy, Loader2, Zap, Facebook, Chrome, Webhook, Save, Eye, EyeOff } from "lucide-react";

const BACKEND = process.env.REACT_APP_BACKEND_URL;

export default function Ads() {
  const [cfg, setCfg] = useState(null);
  const [data, setData] = useState({ items: [], counts: {} });
  const [saving, setSaving] = useState(false);
  const [testing, setTesting] = useState(false);
  const [showTok, setShowTok] = useState(false);

  const load = useCallback(() => {
    api.get("/ads/config").then((r) => setCfg(r.data)).catch((e) => toast.error(apiError(e)));
    api.get("/ads/leads").then((r) => setData(r.data)).catch(() => {});
  }, []);
  useEffect(() => { load(); }, [load]);

  const metaUrl = `${BACKEND}/api/webhooks/meta-leads`;
  const genericUrl = `${BACKEND}/api/webhooks/lead`;
  const copy = (t) => { navigator.clipboard.writeText(t); toast.success("Copied"); };

  const saveCfg = async () => { setSaving(true); try { await api.put("/ads/config", cfg); toast.success("Webhook settings saved"); } catch (e) { toast.error(apiError(e)); } finally { setSaving(false); } };
  const sendTest = async () => { setTesting(true); try { await api.post("/ads/test-lead"); toast.success("Test lead captured into CRM"); load(); } catch (e) { toast.error(apiError(e)); } finally { setTesting(false); } };

  const counts = data.counts || {};
  const Stat = ({ icon: Ic, label, value, color }) => (
    <Card className="p-4 flex items-center gap-3"><div className={`h-10 w-10 rounded-lg flex items-center justify-center ${color}`}><Ic className="h-5 w-5" /></div><div><div className="text-xs text-muted-foreground">{label}</div><div className="text-lg font-bold">{value}</div></div></Card>
  );

  if (!cfg) return <div className="p-10 text-center"><Loader2 className="h-5 w-5 animate-spin mx-auto" /></div>;

  return (
    <div className="p-4 md:p-6 animate-fade-up">
      <PageHeader title="Ad Lead Capture" subtitle="Funnel Google & Meta lead-form enquiries straight into your CRM" testId="ads-header"
        actions={<Button onClick={sendTest} disabled={testing} variant="outline" data-testid="ads-test-lead-button">{testing ? <Loader2 className="h-4 w-4 animate-spin" /> : <><Zap className="h-4 w-4 mr-1.5" /> Send Test Lead</>}</Button>} />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-5">
        <Stat icon={Target} label="Total Ad Leads" value={counts.total || 0} color="bg-[#F0F4EE] text-[#3B5B2A] dark:bg-[#1D2B1E] dark:text-[#8BAA78]" />
        <Stat icon={Facebook} label="Meta / FB / IG" value={(counts.meta || 0) + (counts.facebook || 0) + (counts.instagram || 0)} color="bg-blue-100 text-blue-700 dark:bg-blue-500/15 dark:text-blue-300" />
        <Stat icon={Chrome} label="Google" value={counts.google || 0} color="bg-amber-100 text-amber-700 dark:bg-amber-500/15 dark:text-amber-300" />
        <Stat icon={Webhook} label="Webhook" value={counts.ad_webhook || 0} color="bg-purple-100 text-purple-700 dark:bg-purple-500/15 dark:text-purple-300" />
      </div>

      <div className="grid lg:grid-cols-2 gap-4 mb-6">
        <Card className="p-5">
          <div className="font-semibold mb-3 flex items-center gap-2"><Webhook className="h-4 w-4 text-[#3B5B2A]" /> Webhook Endpoints</div>
          <Label className="text-xs">Meta Lead Ads (verify + receive)</Label>
          <div className="flex gap-2 mb-3 mt-1"><Input readOnly value={metaUrl} className="text-xs" data-testid="ads-meta-url" /><Button size="icon" variant="outline" onClick={() => copy(metaUrl)}><Copy className="h-4 w-4" /></Button></div>
          <Label className="text-xs">Generic / Google / Zapier (POST JSON)</Label>
          <div className="flex gap-2 mt-1"><Input readOnly value={genericUrl} className="text-xs" data-testid="ads-generic-url" /><Button size="icon" variant="outline" onClick={() => copy(genericUrl)}><Copy className="h-4 w-4" /></Button></div>
          <p className="text-[11px] text-muted-foreground mt-2">POST a JSON body like {`{ "name": "...", "phone": "+91...", "email": "...", "source": "google", "campaign": "..." }`}</p>
        </Card>
        <Card className="p-5">
          <div className="font-semibold mb-3 flex items-center gap-2"><Save className="h-4 w-4 text-[#3B5B2A]" /> Meta Verify Settings</div>
          <Label className="text-xs">Verify Token (paste the same value in Meta App → Webhooks)</Label>
          <div className="flex gap-2 mt-1">
            <Input type={showTok ? "text" : "password"} value={cfg.verify_token} onChange={(e) => setCfg({ ...cfg, verify_token: e.target.value })} data-testid="ads-verify-token" />
            <Button size="icon" variant="outline" onClick={() => setShowTok((s) => !s)} data-testid="ads-token-reveal">{showTok ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}</Button>
          </div>
          <label className="flex items-center gap-2 mt-3 text-sm cursor-pointer"><Switch checked={cfg.enabled} onCheckedChange={(v) => setCfg({ ...cfg, enabled: v })} data-testid="ads-enabled-toggle" /> Capture enabled</label>
          <Button className="mt-4 bg-[#3B5B2A] hover:bg-[#2D4720]" onClick={saveCfg} disabled={saving} data-testid="ads-save-config">{saving ? <Loader2 className="h-4 w-4 animate-spin" /> : "Save Settings"}</Button>
        </Card>
      </div>

      <Card className="overflow-hidden">
        <div className="p-4 font-semibold border-b">Captured Ad Leads</div>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader><TableRow><TableHead>Name</TableHead><TableHead>Mobile</TableHead><TableHead>Source</TableHead><TableHead>Campaign</TableHead><TableHead>Status</TableHead></TableRow></TableHeader>
            <TableBody>
              {data.items.map((l) => (
                <TableRow key={l.id} data-testid={`ad-lead-${l.id}`}>
                  <TableCell className="font-medium">{l.contact_name}</TableCell>
                  <TableCell className="text-muted-foreground">{l.mobile}</TableCell>
                  <TableCell><span className="text-xs rounded-full bg-muted px-2 py-0.5 capitalize">{l.source}</span></TableCell>
                  <TableCell className="text-muted-foreground text-xs">{l.campaign || "—"}</TableCell>
                  <TableCell className="capitalize">{l.status}</TableCell>
                </TableRow>
              ))}
              {data.items.length === 0 && <TableRow><TableCell colSpan={5} className="text-center py-10 text-muted-foreground">No ad leads yet. Connect a webhook or send a test lead.</TableCell></TableRow>}
            </TableBody>
          </Table>
        </div>
      </Card>
    </div>
  );
}
