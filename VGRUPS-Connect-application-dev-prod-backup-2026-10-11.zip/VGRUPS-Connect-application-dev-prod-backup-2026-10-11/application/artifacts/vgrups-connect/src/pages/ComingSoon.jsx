import React from "react";
import { PageHeader } from "../components/common";
import { Card } from "../components/ui/card";
import { Rocket } from "lucide-react";

export default function ComingSoon({ title, phase, description }) {
  return (
    <div className="p-4 md:p-6 animate-fade-up">
      <PageHeader title={title} testId={`coming-soon-${title.toLowerCase().replace(/[^a-z]/g, "-")}`} />
      <Card className="p-10 flex flex-col items-center text-center max-w-xl mx-auto mt-8">
        <div className="h-14 w-14 rounded-2xl bg-[#F0F4EE] dark:bg-[#1D2B1E] flex items-center justify-center mb-4">
          <Rocket className="h-7 w-7 text-[#3B5B2A] dark:text-[#8BAA78]" />
        </div>
        <h3 className="text-lg font-semibold font-heading">{title}</h3>
        <p className="text-sm text-muted-foreground mt-2">{description}</p>
        {phase && <span className="mt-4 text-xs rounded-full bg-[#3B5B2A] text-white px-3 py-1.5">Planned: {phase}</span>}
      </Card>
    </div>
  );
}
