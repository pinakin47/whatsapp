import React, { useEffect, useState } from "react";
import api, { apiError } from "../lib/api";
import { toast } from "sonner";
import { Card } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { Textarea } from "../components/ui/textarea";
import { Switch } from "../components/ui/switch";
import { Bot, Loader2, MessageSquare, ArrowDown } from "lucide-react";

const FIELDS = [
  { key: "welcome", label: "Welcome message", type: "textarea" },
  { key: "askName", label: "Ask for name", type: "input" },
  { key: "askProduct", label: "Ask for product", type: "input" },
  { key: "askQuantity", label: "Ask for quantity", type: "input" },
  { key: "handoff", label: "Closing / handoff message", type: "textarea" },
];

export default function BotSettings() {
  const [cfg, setCfg] = useState(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => { api.get("/bot/config").then((r) => setCfg(r.data)).catch((e) => toast.error(apiError(e))); }, []);

  const save = async () => {
    setSaving(true);
    try { await api.put("/bot/config", cfg); toast.success("Auto-reply bot saved"); }
    catch (e) { toast.error(apiError(e)); } finally { setSaving(false); }
  };

  if (!cfg) return <div className="p-10 text-center text-muted-foreground"><Loader2 className="h-5 w-5 animate-spin mx-auto" /></div>;

  return (
    <div data-testid="bot-settings" className="grid lg:grid-cols-2 gap-6">
      <div className="space-y-4">
        <Card className="p-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-lg bg-[#F0F4EE] dark:bg-[#1D2B1E] flex items-center justify-center"><Bot className="h-5 w-5 text-[#3B5B2A] dark:text-[#8BAA78]" /></div>
            <div>
              <div className="font-semibold">Auto-Reply Bot</div>
              <div className="text-xs text-muted-foreground">Greets new chats & captures name, product, quantity → creates a CRM lead</div>
            </div>
          </div>
          <Switch checked={cfg.enabled} onCheckedChange={(v) => setCfg({ ...cfg, enabled: v })} data-testid="bot-enabled-toggle" />
        </Card>

        {FIELDS.map((f) => (
          <div key={f.key}>
            <Label>{f.label}</Label>
            {f.type === "textarea"
              ? <Textarea rows={2} className="mt-1.5" data-testid={`bot-${f.key}`} value={cfg[f.key]} onChange={(e) => setCfg({ ...cfg, [f.key]: e.target.value })} />
              : <Input className="mt-1.5" data-testid={`bot-${f.key}`} value={cfg[f.key]} onChange={(e) => setCfg({ ...cfg, [f.key]: e.target.value })} />}
          </div>
        ))}
        <Button onClick={save} disabled={saving} data-testid="bot-save-button" className="bg-[#3B5B2A] hover:bg-[#2D4720]">
          {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : "Save Bot"}
        </Button>
        <p className="text-xs text-muted-foreground">Customers can type <b>agent</b> for human handover, or <b>STOP</b> to opt out of marketing.</p>
      </div>

      <div>
        <Label className="mb-2 block">Conversation Preview</Label>
        <div className="rounded-xl bg-[#E5DDD5] dark:bg-[#0B141A] p-4 space-y-2">
          {[cfg.welcome, cfg.askName].map((t, i) => (
            <div key={`b${i}`} className="flex"><div className="bg-white dark:bg-[#202C33] rounded-lg rounded-bl-sm px-3 py-2 text-sm max-w-[80%] text-gray-800 dark:text-gray-100">{t}</div></div>
          ))}
          <div className="flex justify-end"><div className="bg-[#DCF8C6] dark:bg-[#005C4B] rounded-lg rounded-br-sm px-3 py-2 text-sm max-w-[80%] text-gray-800 dark:text-gray-50">Rajesh Sharma</div></div>
          <div className="flex"><div className="bg-white dark:bg-[#202C33] rounded-lg rounded-bl-sm px-3 py-2 text-sm max-w-[80%] text-gray-800 dark:text-gray-100">{cfg.askProduct}</div></div>
          <div className="flex justify-end"><div className="bg-[#DCF8C6] dark:bg-[#005C4B] rounded-lg rounded-br-sm px-3 py-2 text-sm max-w-[80%] text-gray-800 dark:text-gray-50">Nitrile Gloves</div></div>
          <div className="flex"><div className="bg-white dark:bg-[#202C33] rounded-lg rounded-bl-sm px-3 py-2 text-sm max-w-[80%] text-gray-800 dark:text-gray-100">{cfg.askQuantity}</div></div>
          <div className="flex justify-end"><div className="bg-[#DCF8C6] dark:bg-[#005C4B] rounded-lg rounded-br-sm px-3 py-2 text-sm max-w-[80%] text-gray-800 dark:text-gray-50">500 boxes</div></div>
          <div className="flex"><div className="bg-white dark:bg-[#202C33] rounded-lg rounded-bl-sm px-3 py-2 text-sm max-w-[80%] text-gray-800 dark:text-gray-100">{cfg.handoff}</div></div>
        </div>
        <div className="flex items-center justify-center gap-2 text-xs text-[#3B5B2A] dark:text-[#8BAA78] mt-3">
          <ArrowDown className="h-4 w-4" /> Auto-creates a CRM lead with product & quantity
        </div>
      </div>
    </div>
  );
}
