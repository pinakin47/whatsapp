import React, { useEffect, useState, useCallback } from "react";
import { useSearchParams } from "react-router-dom";
import api, { apiError } from "../lib/api";
import { toast } from "sonner";
import { Card } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { Textarea } from "../components/ui/textarea";
import { Accordion, AccordionItem, AccordionTrigger, AccordionContent } from "../components/ui/accordion";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogTrigger } from "../components/ui/dialog";
import { Briefcase, MapPin, IndianRupee, Loader2, HeartPulse, CheckCircle2 } from "lucide-react";

const emptyApp = { name: "", mobile: "", email: "", location: "", qualification: "", experience: "", current_company: "", current_salary: "", expected_salary: "", joining: "", resume_url: "", notes: "", consent: false };
const QUALS = ["10th", "12th", "Diploma", "Graduate", "Post Graduate", "Professional", "Other"];
const EXPS = ["Fresher", "<1 year", "1-2 years", "3-5 years", "5-10 years", "10+ years"];
const JOINS = ["Immediately", "Within 7 days", "Within 15 days", "Within 30 days", "More than 30 days"];

export default function Careers() {
  const [positions, setPositions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [applyPos, setApplyPos] = useState(null);
  const [form, setForm] = useState(emptyApp);
  const [saving, setSaving] = useState(false);
  const [done, setDone] = useState(false);
  const [appId, setAppId] = useState("");
  const [params] = useSearchParams();

  const load = useCallback(() => {
    api.get("/careers/positions").then((r) => setPositions(r.data.items)).catch((e) => toast.error(apiError(e))).finally(() => setLoading(false));
  }, []);
  useEffect(() => { load(); }, [load]);

  useEffect(() => {
    const pid = params.get("position");
    if (pid && positions.length) {
      const p = positions.find((x) => x.id === pid);
      if (p) setApplyPos(p);
    }
  }, [params, positions]);

  const apply = async () => {
    setSaving(true);
    try {
      const r = await api.post("/careers/apply", { ...form, position_id: applyPos.id });
      setAppId(r.data.application_id || "");
      setDone(true);
    } catch (e) { toast.error(apiError(e)); } finally { setSaving(false); }
  };
  const closeApply = () => { setApplyPos(null); setForm(emptyApp); setDone(false); setAppId(""); };

  return (
    <div className="min-h-screen bg-[#FAFAF7] dark:bg-[#0E140C]">
      <header className="bg-[#3B5B2A] text-white">
        <div className="max-w-4xl mx-auto px-6 py-14">
          <div className="flex items-center gap-2 text-sm text-white/80 mb-4"><HeartPulse className="h-5 w-5" /> VGRUPS HEALTHCARE</div>
          <h1 className="text-4xl sm:text-5xl font-bold tracking-tight">Join our mission for better healthcare</h1>
          <p className="text-white/80 mt-4 max-w-2xl text-base">We're growing fast. Explore open roles across sales, clinical, nursing, accounts and marketing — and apply in under a minute.</p>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-6 py-10">
        <h2 className="text-lg font-semibold mb-4" data-testid="careers-heading">Open Positions ({positions.length})</h2>
        {loading ? <div className="py-10 text-center"><Loader2 className="h-5 w-5 animate-spin mx-auto" /></div> : (
          <div className="space-y-4">
            {positions.map((p) => (
              <Card key={p.id} className="p-5" data-testid={`careers-position-${p.id}`}>
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div>
                    <div className="flex items-center gap-2"><div className="h-9 w-9 rounded-lg bg-[#F0F4EE] dark:bg-[#1D2B1E] flex items-center justify-center"><Briefcase className="h-4 w-4 text-[#3B5B2A]" /></div><div><div className="font-semibold text-base">{p.title}</div><div className="text-xs text-muted-foreground">{p.department} · {p.type}</div></div></div>
                    <div className="flex flex-wrap gap-3 mt-3 text-xs text-muted-foreground">
                      {p.location && <span className="inline-flex items-center gap-1"><MapPin className="h-3.5 w-3.5" />{p.location}</span>}
                      {(p.salary_min || p.salary_max) ? <span className="inline-flex items-center gap-1"><IndianRupee className="h-3.5 w-3.5" />{p.salary_min?.toLocaleString("en-IN")} – {p.salary_max?.toLocaleString("en-IN")}/mo</span> : null}
                    </div>
                  </div>
                  <Button className="bg-[#3B5B2A] hover:bg-[#2D4720]" onClick={() => setApplyPos(p)} data-testid={`careers-apply-${p.id}`}>Apply Now</Button>
                </div>
                <p className="text-sm text-muted-foreground mt-3">{p.summary}</p>
                {(p.requirements || []).length > 0 && <div className="flex flex-wrap gap-1.5 mt-3">{p.requirements.map((r, i) => <span key={i} className="text-[11px] rounded-full bg-muted px-2 py-0.5">{r}</span>)}</div>}
                {(p.qa || []).length > 0 && (
                  <Accordion type="single" collapsible className="mt-3">
                    <AccordionItem value="qa" className="border-0">
                      <AccordionTrigger className="text-sm py-2 text-[#3B5B2A] dark:text-[#8BAA78]">Frequently asked questions</AccordionTrigger>
                      <AccordionContent>
                        <div className="space-y-2">{p.qa.map((x, i) => <div key={i}><div className="text-sm font-medium">{x.q}</div><div className="text-sm text-muted-foreground">{x.a}</div></div>)}</div>
                      </AccordionContent>
                    </AccordionItem>
                  </Accordion>
                )}
              </Card>
            ))}
            {positions.length === 0 && <div className="py-10 text-center text-muted-foreground">No open positions right now. Please check back soon.</div>}
          </div>
        )}
      </main>

      <Dialog open={!!applyPos} onOpenChange={(v) => !v && closeApply()}>
        <DialogContent className="max-w-md">
          {done ? (
            <div className="text-center py-6" data-testid="careers-apply-success">
              <CheckCircle2 className="h-12 w-12 text-green-600 mx-auto mb-3" />
              <h3 className="text-lg font-semibold">Application received!</h3>
              <p className="text-sm text-muted-foreground mt-1">Thanks for applying to {applyPos?.title}. Our HR team will reach out shortly.</p>
              {appId && <div className="mt-3 inline-block rounded-lg bg-[#F0F4EE] dark:bg-[#1D2B1E] px-4 py-2 font-mono text-sm text-[#3B5B2A] dark:text-[#8BAA78]" data-testid="careers-application-id">Application ID: {appId}</div>}
              <Button className="mt-5 bg-[#3B5B2A] hover:bg-[#2D4720]" onClick={closeApply} data-testid="careers-apply-close">Done</Button>
            </div>
          ) : (
            <>
              <DialogHeader><DialogTitle>Apply — {applyPos?.title}</DialogTitle><DialogDescription>Fill in your details and we'll get in touch.</DialogDescription></DialogHeader>
              <div className="space-y-3 max-h-[60vh] overflow-y-auto pr-1">
                <div><Label>Full name *</Label><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} data-testid="apply-name-input" /></div>
                <div><Label>Mobile *</Label><Input value={form.mobile} onChange={(e) => setForm({ ...form, mobile: e.target.value })} data-testid="apply-mobile-input" /></div>
                <div><Label>Email</Label><Input value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} data-testid="apply-email-input" /></div>
                <div className="grid grid-cols-2 gap-2">
                  <div><Label>Location</Label><Input value={form.location} onChange={(e) => setForm({ ...form, location: e.target.value })} data-testid="apply-location-input" /></div>
                  <div><Label>Qualification</Label>
                    <Select value={form.qualification} onValueChange={(v) => setForm({ ...form, qualification: v })}><SelectTrigger data-testid="apply-qualification"><SelectValue placeholder="Select" /></SelectTrigger>
                      <SelectContent>{QUALS.map((x) => <SelectItem key={x} value={x}>{x}</SelectItem>)}</SelectContent></Select></div>
                  <div><Label>Experience</Label>
                    <Select value={form.experience} onValueChange={(v) => setForm({ ...form, experience: v })}><SelectTrigger data-testid="apply-experience"><SelectValue placeholder="Select" /></SelectTrigger>
                      <SelectContent>{EXPS.map((x) => <SelectItem key={x} value={x}>{x}</SelectItem>)}</SelectContent></Select></div>
                  <div><Label>Joining</Label>
                    <Select value={form.joining} onValueChange={(v) => setForm({ ...form, joining: v })}><SelectTrigger data-testid="apply-joining"><SelectValue placeholder="Select" /></SelectTrigger>
                      <SelectContent>{JOINS.map((x) => <SelectItem key={x} value={x}>{x}</SelectItem>)}</SelectContent></Select></div>
                  <div><Label>Current salary</Label><Input value={form.current_salary} onChange={(e) => setForm({ ...form, current_salary: e.target.value })} data-testid="apply-current-salary" /></div>
                  <div><Label>Expected salary</Label><Input value={form.expected_salary} onChange={(e) => setForm({ ...form, expected_salary: e.target.value })} data-testid="apply-expected-salary" /></div>
                </div>
                <div><Label>Resume link (Google Drive / URL)</Label><Input placeholder="https://..." value={form.resume_url} onChange={(e) => setForm({ ...form, resume_url: e.target.value })} data-testid="apply-resume-input" /></div>
                <label className="flex items-start gap-2 text-xs text-muted-foreground cursor-pointer">
                  <input type="checkbox" checked={form.consent} onChange={(e) => setForm({ ...form, consent: e.target.checked })} data-testid="apply-consent" className="mt-0.5 accent-[#3B5B2A]" />
                  I confirm the information provided is accurate and I agree to proceed with the VGRUPS Healthcare recruitment process.
                </label>
              </div>
              <DialogFooter><Button disabled={saving || !form.name || !form.mobile || !form.consent} onClick={apply} className="bg-[#3B5B2A] hover:bg-[#2D4720]" data-testid="apply-submit-button">{saving ? <Loader2 className="h-4 w-4 animate-spin" /> : "Submit Application"}</Button></DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
