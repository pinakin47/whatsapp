import React, { useEffect, useState, useCallback } from "react";
import api, { apiError } from "../lib/api";
import { toast } from "sonner";
import { PageHeader, StatusBadge } from "../components/common";
import { Card } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../components/ui/table";
import { CreditCard, Link2, ExternalLink, CheckCircle2, Loader2, IndianRupee } from "lucide-react";

export default function Payments() {
  const [items, setItems] = useState([]);
  const [rzp, setRzp] = useState(false);
  const [busy, setBusy] = useState(null);

  const load = useCallback(() => { api.get("/orders").then((r) => setItems(r.data.items)); }, []);
  useEffect(() => { load(); api.get("/payments/config").then((r) => setRzp(r.data.razorpay_configured)).catch(() => {}); }, [load]);

  const makeLink = async (id) => { setBusy(id); try { const r = await api.post(`/orders/${id}/payment-link`); toast.success(r.data.whatsapp_sent ? "Link created & sent" : "Link created"); load(); } catch (e) { toast.error(apiError(e)); } finally { setBusy(null); } };
  const markPaid = async (id) => { setBusy(id); try { await api.post(`/orders/${id}/mark-paid`); toast.success("Marked paid"); load(); } catch (e) { toast.error(apiError(e)); } finally { setBusy(null); } };

  const paid = items.filter((o) => o.payment_status === "paid");
  const pending = items.filter((o) => o.payment_status !== "paid");
  const collected = paid.reduce((s, o) => s + Number(o.total || 0), 0);
  const outstanding = pending.reduce((s, o) => s + Number(o.total || 0), 0);

  const Stat = ({ icon: Ic, label, value, color }) => (
    <Card className="p-4 flex items-center gap-3"><div className={`h-10 w-10 rounded-lg flex items-center justify-center ${color}`}><Ic className="h-5 w-5" /></div><div><div className="text-xs text-muted-foreground">{label}</div><div className="text-lg font-bold">{value}</div></div></Card>
  );

  return (
    <div className="p-4 md:p-6 animate-fade-up">
      <PageHeader title="Payments" subtitle="Razorpay payment links & collection status" testId="payments-header" />
      {!rzp && <div className="mb-4 text-xs rounded-lg bg-amber-50 dark:bg-amber-500/10 text-amber-700 dark:text-amber-300 border border-amber-200 dark:border-amber-500/20 px-3 py-2" data-testid="payments-rzp-warn">Razorpay not connected — add keys in Integrations to generate live payment links.</div>}
      <div className="grid grid-cols-2 lg:grid-cols-3 gap-4 mb-5">
        <Stat icon={IndianRupee} label="Collected" value={`₹${collected.toLocaleString("en-IN")}`} color="bg-green-100 text-green-700 dark:bg-green-500/15 dark:text-green-300" />
        <Stat icon={CreditCard} label="Outstanding" value={`₹${outstanding.toLocaleString("en-IN")}`} color="bg-amber-100 text-amber-700 dark:bg-amber-500/15 dark:text-amber-300" />
        <Stat icon={CheckCircle2} label="Paid Orders" value={`${paid.length}/${items.length}`} color="bg-[#F0F4EE] text-[#3B5B2A] dark:bg-[#1D2B1E] dark:text-[#8BAA78]" />
      </div>
      <Card className="overflow-hidden">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader><TableRow><TableHead>Order</TableHead><TableHead>Customer</TableHead><TableHead>Status</TableHead><TableHead>Link</TableHead><TableHead className="text-right">Amount</TableHead><TableHead className="text-right">Action</TableHead></TableRow></TableHeader>
            <TableBody>
              {items.map((o) => (
                <TableRow key={o.id} data-testid={`payment-row-${o.id}`}>
                  <TableCell className="font-mono text-sm">{o.order_no}</TableCell>
                  <TableCell>{o.contact_name}</TableCell>
                  <TableCell><StatusBadge status={o.payment_status} /></TableCell>
                  <TableCell>{o.payment_link ? <a href={o.payment_link} target="_blank" rel="noreferrer" className="text-[#3B5B2A] dark:text-[#8BAA78] text-xs inline-flex items-center gap-1">Open <ExternalLink className="h-3 w-3" /></a> : <span className="text-xs text-muted-foreground">—</span>}</TableCell>
                  <TableCell className="text-right font-semibold">₹{Number(o.total).toLocaleString("en-IN")}</TableCell>
                  <TableCell className="text-right">
                    {o.payment_status === "paid" ? <span className="text-xs text-green-600 dark:text-green-400">✓ Paid</span> : (
                      <div className="flex justify-end gap-1">
                        <Button size="sm" variant="outline" disabled={busy === o.id || !rzp} onClick={() => makeLink(o.id)} data-testid={`payment-link-${o.id}`}>{busy === o.id ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Link2 className="h-3.5 w-3.5" />}</Button>
                        <Button size="sm" className="bg-[#3B5B2A] hover:bg-[#2D4720]" disabled={busy === o.id} onClick={() => markPaid(o.id)} data-testid={`payment-markpaid-${o.id}`}>Mark Paid</Button>
                      </div>
                    )}
                  </TableCell>
                </TableRow>
              ))}
              {items.length === 0 && <TableRow><TableCell colSpan={6} className="text-center py-10 text-muted-foreground">No orders to collect yet.</TableCell></TableRow>}
            </TableBody>
          </Table>
        </div>
      </Card>
    </div>
  );
}
