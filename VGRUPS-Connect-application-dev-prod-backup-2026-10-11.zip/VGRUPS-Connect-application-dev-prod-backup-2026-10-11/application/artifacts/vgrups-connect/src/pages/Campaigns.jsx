import React, { useEffect, useState, useCallback } from "react";
import api, { apiError } from "../lib/api";
import { toast } from "sonner";
import { useAuth } from "../context/AuthContext";
import { PageHeader } from "../components/common";
import GroupsPanel from "../components/campaigns/GroupsPanel";
import Composer from "../components/campaigns/Composer";
import CampaignCard from "../components/campaigns/CampaignCard";
import ReportDialog from "../components/campaigns/ReportDialog";
import ConfirmDialog from "../components/ConfirmDialog";
import { Button } from "../components/ui/button";
import { Plus, Users } from "lucide-react";

export default function Campaigns() {
  const { can } = useAuth();
  const [items, setItems] = useState([]);
  const [groups, setGroups] = useState([]);
  const [templates, setTemplates] = useState([]);
  const [composer, setComposer] = useState(false);
  const [groupsOpen, setGroupsOpen] = useState(false);
  const [del, setDel] = useState(null);
  const [editing, setEditing] = useState(null);
  const [report, setReport] = useState(null);
  const [startC, setStartC] = useState(null);
  const [loadErr, setLoadErr] = useState("");

  const load = useCallback(() => api.get("/campaigns").then((r) => { setItems(r.data.items); setLoadErr(""); }).catch((e) => setLoadErr(apiError(e))), []);
  const loadGroups = useCallback(() => api.get("/campaign-groups").then((r) => setGroups(r.data.items || [])).catch((e) => toast.error(apiError(e))), []);

  useEffect(() => {
    load(); loadGroups();
    api.get("/whatsapp/templates").then((r) => setTemplates(r.data.items || [])).catch(() => {});
    const t = setInterval(load, 4000);
    return () => clearInterval(t);
  }, [load, loadGroups]);

  const exportCsv = async (c, filters = {}) => {
    try {
      const r = await api.get(`/campaigns/${c.id}/report.csv`, { responseType: "blob", params: filters });
      const url = window.URL.createObjectURL(new Blob([r.data]));
      const a = document.createElement("a");
      a.href = url; a.download = `${c.name.replace(/\s/g, "_")}_report.csv`;
      document.body.appendChild(a); a.click(); a.remove();
      window.URL.revokeObjectURL(url);
    } catch (e) { toast.error(apiError(e)); }
  };

  const run = async (c, act) => {
    try { await api.post(`/campaigns/${c.id}/${act}`); toast.success(act === "send" ? "Campaign started" : act === "pause" ? "Paused" : "Resumed"); load(); }
    catch (e) { toast.error(apiError(e)); }
  };
  const onAction = (c, act) => (act === "send" ? setStartC(c) : run(c, act));
  const remove = async () => {
    const c = del; setDel(null);
    try { await api.delete(`/campaigns/${c.id}`); toast.success("Deleted"); load(); }
    catch (e) { toast.error(apiError(e)); }
  };

  return (
    <div className="p-4 md:p-6 animate-fade-up">
      <PageHeader
        title="Campaigns & Broadcast" subtitle={`${items.length} campaigns, ${groups.length} groups. Sends through your linked WhatsApp number`} testId="campaigns-header"
        actions={
          <div className="flex gap-2">
            <Button variant="outline" data-testid="manage-groups-button" onClick={() => setGroupsOpen(true)}><Users className="h-4 w-4 mr-1" /> Groups</Button>
            {can("campaigns", "create") && <Button data-testid="add-campaign-button" className="bg-[#3B5B2A] hover:bg-[#2D4720]" onClick={() => { setEditing(null); setComposer(true); }}><Plus className="h-4 w-4 mr-1" /> Add Broadcast</Button>}
          </div>
        }
      />
      {loadErr && <div className="mb-3 text-sm text-destructive flex items-center gap-3">{loadErr}<Button size="sm" variant="outline" onClick={load}>Retry</Button></div>}
      <div className="grid md:grid-cols-2 gap-4">
        {items.map((c) => <CampaignCard key={c.id} c={c} onAction={onAction} onDelete={setDel} onExport={exportCsv} onEdit={(x) => { setEditing(x); setComposer(true); }} onReport={setReport} />)}
      </div>
      <Composer editing={editing} open={composer} onOpenChange={setComposer} groups={groups} templates={templates} onCreated={load} onManageGroups={() => { setComposer(false); setGroupsOpen(true); }} />
      <ReportDialog open={!!report} onOpenChange={(o) => !o && setReport(null)} item={report} type="campaigns" canExport={can("campaigns", "export")} onExport={exportCsv} />
      <GroupsPanel open={groupsOpen} onOpenChange={setGroupsOpen} groups={groups} reload={loadGroups} />
      <ConfirmDialog open={!!del} onOpenChange={(o) => !o && setDel(null)} title="Delete this campaign?" description={del ? `"${del.name}" will be removed from the list and any pending sends are cancelled. Historical delivery reports are kept as archived evidence and are not deleted.` : ""} confirmLabel="Delete" destructive onConfirm={remove} testId="campaign-delete-confirm" />
      <ConfirmDialog open={!!startC} onOpenChange={(o) => !o && setStartC(null)} title="Start this broadcast now?" description="Real WhatsApp messages will start sending immediately. Opted-out contacts are skipped." confirmLabel="Start sending" onConfirm={() => { const c = startC; setStartC(null); run(c, "send"); }} testId="campaign-start-confirm" />
    </div>
  );
}
