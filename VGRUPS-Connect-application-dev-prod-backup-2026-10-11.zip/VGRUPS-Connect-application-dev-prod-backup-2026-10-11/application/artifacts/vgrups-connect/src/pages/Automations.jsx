import React, { useEffect, useState, useCallback } from "react";
import api, { apiError } from "../lib/api";
import { toast } from "sonner";
import { PageHeader } from "../components/common";
import { Card } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { Textarea } from "../components/ui/textarea";
import { Switch } from "../components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogTrigger } from "../components/ui/dialog";
import { Plus, Loader2, Trash2, Zap, Send, Tag, CheckSquare, CalendarClock, PlayCircle, ArrowDown, Workflow, GitBranch } from "lucide-react";

const ACTION_ICON = { send_whatsapp: Send, add_tag: Tag, create_task: CheckSquare, create_follow_up: CalendarClock, condition: GitBranch };
const empty = { name: "", trigger: "new_lead", enabled: true, actions: [] };
const BASIC = ["send_whatsapp", "add_tag", "create_task", "create_follow_up"];

function newAction(type) {
  if (type === "condition") return { type, field: "contact_type", op: "eq", value: "", then: [], otherwise: [] };
  return { type, message: "", tag: "", title: "" };
}

export default function Automations() {
  const [items, setItems] = useState([]);
  const [triggers, setTriggers] = useState([]);
  const [actionTypes, setActionTypes] = useState([]);
  const [condFields, setCondFields] = useState([]);
  const [condOps, setCondOps] = useState([]);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState(empty);
  const [saving, setSaving] = useState(false);

  const load = useCallback(() => {
    api.get("/automations").then((r) => {
      setItems(r.data.items); setTriggers(r.data.triggers); setActionTypes(r.data.action_types);
      setCondFields(r.data.condition_fields || []); setCondOps(r.data.condition_ops || []);
    });
  }, []);
  useEffect(() => { load(); }, [load]);

  const addAction = (type) => setForm((f) => ({ ...f, actions: [...f.actions, newAction(type)] }));
  const setAction = (i, patch) => setForm((f) => ({ ...f, actions: f.actions.map((a, idx) => idx === i ? { ...a, ...patch } : a) }));
  const rmAction = (i) => setForm((f) => ({ ...f, actions: f.actions.filter((_, idx) => idx !== i) }));
  const addSub = (i, branch, type) => setForm((f) => ({ ...f, actions: f.actions.map((a, idx) => idx === i ? { ...a, [branch]: [...a[branch], newAction(type)] } : a) }));
  const setSub = (i, branch, j, patch) => setForm((f) => ({ ...f, actions: f.actions.map((a, idx) => idx === i ? { ...a, [branch]: a[branch].map((s, sj) => sj === j ? { ...s, ...patch } : s) } : a) }));
  const rmSub = (i, branch, j) => setForm((f) => ({ ...f, actions: f.actions.map((a, idx) => idx === i ? { ...a, [branch]: a[branch].filter((_, sj) => sj !== j) } : a) }));

  const create = async () => {
    setSaving(true);
    try { await api.post("/automations", form); toast.success("Automation created"); setOpen(false); setForm(empty); load(); }
    catch (e) { toast.error(apiError(e)); } finally { setSaving(false); }
  };
  const toggle = async (id) => { try { await api.post(`/automations/${id}/toggle`); load(); } catch (e) { toast.error(apiError(e)); } };
  const test = async (id) => { try { const r = await api.post(`/automations/${id}/test`); toast.success(`Ran: ${r.data.executed.join(", ") || "no actions"}`); load(); } catch (e) { toast.error(apiError(e)); } };
  const remove = async (id) => { try { await api.delete(`/automations/${id}`); toast.success("Deleted"); load(); } catch (e) { toast.error(apiError(e)); } };

  const trigLabel = (k) => triggers.find((t) => t.key === k)?.label || k;

  const ActionBody = ({ a, onChange }) => (
    <>
      {a.type === "send_whatsapp" && <Textarea rows={2} className="mt-2" placeholder="Message… use {name}" value={a.message} onChange={(e) => onChange({ message: e.target.value })} />}
      {a.type === "add_tag" && <Input className="mt-2" placeholder="Tag e.g. hot-lead" value={a.tag} onChange={(e) => onChange({ tag: e.target.value })} />}
      {(a.type === "create_task" || a.type === "create_follow_up") && <Input className="mt-2" placeholder="Task title" value={a.title} onChange={(e) => onChange({ title: e.target.value })} />}
    </>
  );

  const SubList = ({ i, branch }) => {
    const subs = form.actions[i][branch] || [];
    return (
      <div className="space-y-2 pl-3 border-l-2 border-border">
        {subs.map((s, j) => {
          const Ic = ACTION_ICON[s.type] || Zap;
          return (
            <div key={j} className="rounded-lg border border-border bg-card p-2" data-testid={`cond-${branch}-action-${i}-${j}`}>
              <div className="flex items-center gap-2"><Ic className="h-3.5 w-3.5 text-[#3B5B2A]" /><span className="text-xs font-medium">{actionTypes.find((t) => t.key === s.type)?.label}</span>
                <Button size="icon" variant="ghost" className="ml-auto h-6 w-6" onClick={() => rmSub(i, branch, j)}><Trash2 className="h-3 w-3 text-destructive" /></Button></div>
              <ActionBody a={s} onChange={(patch) => setSub(i, branch, j, patch)} />
            </div>
          );
        })}
        <div className="flex flex-wrap gap-1.5">
          {actionTypes.filter((t) => BASIC.includes(t.key)).map((t) => { const Ic = ACTION_ICON[t.key] || Zap; return (
            <Button key={t.key} size="sm" variant="ghost" className="h-7 text-xs" onClick={() => addSub(i, branch, t.key)} data-testid={`cond-add-${branch}-${t.key}-${i}`}><Ic className="h-3 w-3 mr-1" /> {t.label}</Button>); })}
        </div>
      </div>
    );
  };

  return (
    <div className="p-4 md:p-6 animate-fade-up">
      <PageHeader
        title="Automation Builder" subtitle="When something happens → run a flow with IF/ELSE logic" testId="automations-header"
        actions={
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild><Button data-testid="add-automation-button" className="bg-[#3B5B2A] hover:bg-[#2D4720]"><Plus className="h-4 w-4 mr-1" /> New Automation</Button></DialogTrigger>
            <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
              <DialogHeader><DialogTitle>Build Automation</DialogTitle><DialogDescription>Add actions and IF/ELSE branches.</DialogDescription></DialogHeader>
              <div className="space-y-4">
                <div><Label>Name *</Label><Input data-testid="automation-name-input" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
                <div className="rounded-xl border-2 border-[#3B5B2A]/40 bg-[#F0F4EE] dark:bg-[#1D2B1E] p-3">
                  <div className="flex items-center gap-2 text-xs font-semibold text-[#3B5B2A] dark:text-[#8BAA78]"><Zap className="h-4 w-4" /> WHEN (Trigger)</div>
                  <Select value={form.trigger} onValueChange={(v) => setForm({ ...form, trigger: v })}>
                    <SelectTrigger className="mt-2" data-testid="automation-trigger-select"><SelectValue /></SelectTrigger>
                    <SelectContent>{triggers.map((t) => <SelectItem key={t.key} value={t.key}>{t.label}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
                <div className="flex justify-center"><ArrowDown className="h-4 w-4 text-muted-foreground" /></div>

                <div className="space-y-2">
                  {form.actions.map((a, i) => {
                    const Ic = ACTION_ICON[a.type] || Zap;
                    if (a.type === "condition") return (
                      <div key={i} className="rounded-xl border-2 border-amber-300 dark:border-amber-500/40 bg-amber-50/60 dark:bg-amber-500/5 p-3" data-testid={`automation-action-${i}`}>
                        <div className="flex items-center gap-2"><GitBranch className="h-4 w-4 text-amber-600" /><span className="text-sm font-medium">IF</span>
                          <Button size="icon" variant="ghost" className="ml-auto h-7 w-7" onClick={() => rmAction(i)}><Trash2 className="h-3.5 w-3.5 text-destructive" /></Button></div>
                        <div className="flex flex-wrap gap-2 mt-2">
                          <Select value={a.field} onValueChange={(v) => setAction(i, { field: v })}><SelectTrigger className="h-9 flex-1 min-w-[120px]" data-testid={`cond-field-${i}`}><SelectValue /></SelectTrigger>
                            <SelectContent>{condFields.map((f) => <SelectItem key={f.key} value={f.key}>{f.label}</SelectItem>)}</SelectContent></Select>
                          <Select value={a.op} onValueChange={(v) => setAction(i, { op: v })}><SelectTrigger className="h-9 w-28" data-testid={`cond-op-${i}`}><SelectValue /></SelectTrigger>
                            <SelectContent>{condOps.map((o) => <SelectItem key={o.key} value={o.key}>{o.label}</SelectItem>)}</SelectContent></Select>
                          <Input className="h-9 flex-1 min-w-[120px]" placeholder="value e.g. distributor" value={a.value} onChange={(e) => setAction(i, { value: e.target.value })} data-testid={`cond-value-${i}`} />
                        </div>
                        <div className="mt-3"><div className="text-xs font-semibold text-green-700 dark:text-green-400 mb-1">THEN</div><SubList i={i} branch="then" /></div>
                        <div className="mt-3"><div className="text-xs font-semibold text-red-700 dark:text-red-400 mb-1">ELSE</div><SubList i={i} branch="otherwise" /></div>
                      </div>
                    );
                    return (
                      <div key={i} className="rounded-xl border border-border bg-card p-3" data-testid={`automation-action-${i}`}>
                        <div className="flex items-center gap-2"><Ic className="h-4 w-4 text-[#3B5B2A]" />
                          <span className="text-sm font-medium">THEN {actionTypes.find((t) => t.key === a.type)?.label}</span>
                          <Button size="icon" variant="ghost" className="ml-auto h-7 w-7" onClick={() => rmAction(i)}><Trash2 className="h-3.5 w-3.5 text-destructive" /></Button></div>
                        <ActionBody a={a} onChange={(patch) => setAction(i, patch)} />
                      </div>
                    );
                  })}
                  {form.actions.length === 0 && <div className="text-center text-xs text-muted-foreground py-3">Add actions below ↓</div>}
                </div>
                <div className="flex flex-wrap gap-2">
                  {actionTypes.map((t) => { const Ic = ACTION_ICON[t.key] || Zap; return (
                    <Button key={t.key} size="sm" variant="outline" onClick={() => addAction(t.key)} data-testid={`add-action-${t.key}`}><Ic className="h-3.5 w-3.5 mr-1" /> {t.label}</Button>); })}
                </div>
              </div>
              <DialogFooter><Button data-testid="automation-save-button" disabled={saving || !form.name || form.actions.length === 0} onClick={create} className="bg-[#3B5B2A] hover:bg-[#2D4720]">{saving ? <Loader2 className="h-4 w-4 animate-spin" /> : "Save Automation"}</Button></DialogFooter>
            </DialogContent>
          </Dialog>
        }
      />

      <div className="grid md:grid-cols-2 gap-4">
        {items.map((a) => (
          <Card key={a.id} className="p-5" data-testid={`automation-card-${a.id}`}>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2"><div className="h-9 w-9 rounded-lg bg-[#F0F4EE] dark:bg-[#1D2B1E] flex items-center justify-center"><Workflow className="h-4 w-4 text-[#3B5B2A]" /></div><div className="font-semibold">{a.name}</div></div>
              <Switch checked={a.enabled} onCheckedChange={() => toggle(a.id)} data-testid={`automation-toggle-${a.id}`} />
            </div>
            <div className="flex items-center gap-1.5 flex-wrap mt-3 text-xs">
              <span className="rounded-full bg-[#3B5B2A] text-white px-2 py-0.5 flex items-center gap-1"><Zap className="h-3 w-3" /> {trigLabel(a.trigger)}</span>
              {(a.actions || []).map((act, i) => { const Ic = ACTION_ICON[act.type] || Zap; return <span key={i} className={`rounded-full px-2 py-0.5 flex items-center gap-1 ${act.type === "condition" ? "bg-amber-100 text-amber-700 dark:bg-amber-500/15 dark:text-amber-300" : "bg-muted"}`}><Ic className="h-3 w-3" /> {act.type === "condition" ? `if ${act.field} ${act.op} ${act.value}` : act.type.replace(/_/g, " ")}</span>; })}
            </div>
            <div className="text-[11px] text-muted-foreground mt-2">Runs: {a.runs || 0}</div>
            <div className="flex gap-2 mt-4">
              <Button size="sm" variant="outline" className="flex-1" data-testid={`automation-test-${a.id}`} onClick={() => test(a.id)}><PlayCircle className="h-3.5 w-3.5 mr-1" /> Test run</Button>
              <Button size="sm" variant="ghost" data-testid={`automation-delete-${a.id}`} onClick={() => remove(a.id)}><Trash2 className="h-4 w-4 text-destructive" /></Button>
            </div>
          </Card>
        ))}
        {items.length === 0 && <div className="col-span-full text-center py-10 text-muted-foreground">No automations yet. Try “When new lead → IF type is distributor THEN send WhatsApp”.</div>}
      </div>
    </div>
  );
}
