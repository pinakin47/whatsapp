import React, { useEffect, useState, useCallback } from "react";
import api, { apiError } from "../lib/api";
import { toast } from "sonner";
import { PageHeader } from "../components/common";
import { Card } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { Textarea } from "../components/ui/textarea";
import { Switch } from "../components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogTrigger } from "../components/ui/dialog";
import { Bot, Loader2, Plus, Trash2, MessageSquare, ListChecks, HelpCircle, Zap, Play, RotateCcw, Send, LayoutTemplate, Sparkles } from "lucide-react";

const TYPE_META = {
  message: { label: "Message", icon: MessageSquare },
  menu: { label: "Menu (choices)", icon: ListChecks },
  question: { label: "Question", icon: HelpCircle },
  action: { label: "Action", icon: Zap },
};
const END = "__end__";
const nid = () => "n" + Math.random().toString(36).slice(2, 8);

// ---- Simulator runtime (mirrors the Node flow engine) ----
function simStep(flow, state, input) {
  const map = {};
  flow.nodes.forEach((n) => (map[n.id] = n));
  const out = [];
  const data = { ...state.data };
  let nextId;
  if (input === null) {
    nextId = flow.start;
  } else if (state.waiting) {
    const node = map[state.waiting];
    if (!node) nextId = flow.start;
    else if (node.type === "menu") {
      const choice = parseInt(String(input).trim(), 10);
      const opt = node.options && node.options[choice - 1];
      if (!opt) { out.push({ from: "bot", text: menuText(node, data) }); return { messages: out, waiting: state.waiting, data, started: true }; }
      nextId = opt.next;
    } else if (node.type === "question") {
      data[node.field || node.id] = String(input).trim();
      nextId = node.next;
    } else nextId = node.next;
  } else nextId = flow.start;

  let cur = nextId, guard = 0, waiting = null;
  while (cur && cur !== END && guard < 30) {
    guard++;
    const node = map[cur];
    if (!node) break;
    if (node.type === "message") { out.push({ from: "bot", text: renderVars(node.text, data) }); cur = node.next; }
    else if (node.type === "action") {
      const kind = node.action?.kind;
      if (kind === "handoff") { out.push({ from: "bot", text: renderVars(node.text || "Connecting you to an agent…", data) }); cur = null; break; }
      out.push({ from: "sys", text: kind === "create_lead" ? "✓ Lead created in CRM" : kind === "add_tag" ? `✓ Tag '${node.action?.tag || "chatbot"}' added` : "✓ action" });
      cur = node.next;
    } else if (node.type === "menu") { out.push({ from: "bot", text: menuText(node, data) }); waiting = node.id; break; }
    else if (node.type === "question") { out.push({ from: "bot", text: renderVars(node.text, data) }); waiting = node.id; break; }
    else cur = node.next;
  }
  return { messages: out, waiting, data, started: true };
}
function renderVars(t, data) { return (t || "").replace(/\{([^}]+)\}/g, (m, k) => (data[k.trim()] != null && data[k.trim()] !== "" ? String(data[k.trim()]) : m)); }
function menuText(node, data) {
  const opts = (node.options || []).map((o, i) => `${i + 1}. ${o.label}`).join("\n");
  return `${renderVars(node.text, data)}\n\n${opts}\n\n(Reply with a number)`;
}

export default function ChatbotBuilder() {
  const [flow, setFlow] = useState(null);
  const [templates, setTemplates] = useState([]);
  const [tplOpen, setTplOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [sim, setSim] = useState({ messages: [], waiting: null, data: {}, started: false });
  const [simInput, setSimInput] = useState("");

  const load = useCallback(() => {
    api.get("/chatbot/flow").then((r) => setFlow(r.data)).catch((e) => toast.error(apiError(e)));
  }, []);
  useEffect(() => {
    load();
    api.get("/chatbot/templates").then((r) => setTemplates(r.data.items)).catch(() => {});
  }, [load]);

  const applyTemplate = async (tpl, enable) => {
    if (enable) {
      try { await api.put("/chatbot/flow", { enabled: true, start: tpl.start, nodes: tpl.nodes }); toast.success(`${tpl.name} enabled & live`); setTplOpen(false); load(); }
      catch (e) { toast.error(apiError(e)); }
    } else {
      setFlow((f) => ({ enabled: f?.enabled || false, start: tpl.start, nodes: tpl.nodes.map((n) => ({ ...n, next: n.next ?? END, field: n.field || "", text: n.text || "", options: (n.options || []).map((o) => ({ ...o, next: o.next ?? END })), action: n.action || null })) }));
      setTplOpen(false); toast.success(`${tpl.name} loaded — review & Save`);
    }
  };

  const nodeOpts = (flow?.nodes || []).map((n) => ({ value: n.id, label: `${TYPE_META[n.type]?.label || n.type}: ${(n.text || n.id).slice(0, 24)}` }));

  const setNode = (id, patch) => setFlow((f) => ({ ...f, nodes: f.nodes.map((n) => (n.id === id ? { ...n, ...patch } : n)) }));
  const addNode = (type) => {
    const node = { id: nid(), type, text: "", next: END, field: "", options: type === "menu" ? [{ label: "Option 1", next: END }] : [], action: type === "action" ? { kind: "create_lead", tag: "" } : null };
    setFlow((f) => ({ ...f, nodes: [...f.nodes, node], start: f.nodes.length === 0 ? node.id : f.start }));
  };
  const rmNode = (id) => setFlow((f) => ({ ...f, nodes: f.nodes.filter((n) => n.id !== id), start: f.start === id ? (f.nodes.find((n) => n.id !== id)?.id || "") : f.start }));

  const save = async () => {
    setSaving(true);
    try {
      const payload = { ...flow, nodes: flow.nodes.map((n) => ({ ...n, next: n.next === END ? null : n.next, options: (n.options || []).map((o) => ({ ...o, next: o.next === END ? null : o.next })) })) };
      await api.put("/chatbot/flow", payload);
      toast.success("Chatbot flow saved");
    } catch (e) { toast.error(apiError(e)); } finally { setSaving(false); }
  };

  // simulator uses END sentinel for nulls
  const simFlow = flow && { ...flow, nodes: flow.nodes.map((n) => ({ ...n, next: n.next === END ? null : n.next, options: (n.options || []).map((o) => ({ ...o, next: o.next === END ? null : o.next })) })) };
  const simStart = () => { const r = simStep(simFlow, { data: {}, waiting: null, started: false }, null); setSim({ messages: r.messages, waiting: r.waiting, data: r.data, started: true }); };
  const simSend = (val) => {
    const text = val ?? simInput;
    if (!text.trim()) return;
    const r = simStep(simFlow, sim, text);
    setSim((s) => ({ messages: [...s.messages, { from: "user", text }, ...r.messages], waiting: r.waiting, data: r.data, started: true }));
    setSimInput("");
  };
  const waitingNode = simFlow?.nodes.find((n) => n.id === sim.waiting);

  if (!flow) return <div className="p-10 text-center text-muted-foreground"><Loader2 className="h-5 w-5 animate-spin mx-auto" /></div>;

  return (
    <div className="p-4 md:p-6 animate-fade-up">
      <PageHeader title="Chatbot Builder" subtitle="Build a multi-branch WhatsApp bot with menus & questions" testId="chatbot-header"
        actions={
          <div className="flex items-center gap-3">
            <Dialog open={tplOpen} onOpenChange={setTplOpen}>
              <DialogTrigger asChild><Button variant="outline" data-testid="chatbot-templates-button"><LayoutTemplate className="h-4 w-4 mr-1.5" /> Templates</Button></DialogTrigger>
              <DialogContent className="max-w-lg">
                <DialogHeader><DialogTitle>Ready-made flow templates</DialogTitle><DialogDescription>Enable instantly, or load one to customise.</DialogDescription></DialogHeader>
                <div className="space-y-3">
                  {templates.map((t) => (
                    <div key={t.key} className="rounded-xl border border-border p-4" data-testid={`chatbot-template-${t.key}`}>
                      <div className="flex items-center gap-2"><div className="h-8 w-8 rounded-lg bg-[#F0F4EE] dark:bg-[#1D2B1E] flex items-center justify-center"><Bot className="h-4 w-4 text-[#3B5B2A]" /></div><div className="font-semibold text-sm">{t.name}</div><span className="ml-auto text-[10px] text-muted-foreground">{t.nodes.length} steps</span></div>
                      <p className="text-xs text-muted-foreground mt-2">{t.description}</p>
                      <div className="flex gap-2 mt-3">
                        <Button size="sm" className="flex-1 bg-[#3B5B2A] hover:bg-[#2D4720]" onClick={() => applyTemplate(t, true)} data-testid={`chatbot-template-enable-${t.key}`}><Sparkles className="h-3.5 w-3.5 mr-1" /> Enable now</Button>
                        <Button size="sm" variant="outline" className="flex-1" onClick={() => applyTemplate(t, false)} data-testid={`chatbot-template-load-${t.key}`}>Load & edit</Button>
                      </div>
                    </div>
                  ))}
                  {templates.length === 0 && <div className="text-center text-xs text-muted-foreground py-6">No templates available.</div>}
                </div>
              </DialogContent>
            </Dialog>
            <div className="flex items-center gap-2 text-sm"><span className="text-muted-foreground">Live</span>
              <Switch checked={flow.enabled} onCheckedChange={(v) => setFlow({ ...flow, enabled: v })} data-testid="chatbot-enabled-toggle" /></div>
            <Button onClick={save} disabled={saving} className="bg-[#3B5B2A] hover:bg-[#2D4720]" data-testid="chatbot-save-button">{saving ? <Loader2 className="h-4 w-4 animate-spin" /> : "Save Flow"}</Button>
          </div>
        } />

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Builder */}
        <div className="lg:col-span-2 space-y-3">
          <Card className="p-3 flex flex-wrap items-center gap-2" data-testid="chatbot-start-card">
            <Label className="text-xs">Start node</Label>
            <Select value={flow.start} onValueChange={(v) => setFlow({ ...flow, start: v })}>
              <SelectTrigger className="h-8 w-64" data-testid="chatbot-start-select"><SelectValue placeholder="Select start" /></SelectTrigger>
              <SelectContent>{nodeOpts.map((o) => <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>)}</SelectContent>
            </Select>
          </Card>

          {flow.nodes.map((n) => {
            const Ic = TYPE_META[n.type]?.icon || MessageSquare;
            return (
              <Card key={n.id} className="p-4" data-testid={`chatbot-node-${n.id}`}>
                <div className="flex items-center gap-2 mb-2">
                  <div className="h-7 w-7 rounded-lg bg-[#F0F4EE] dark:bg-[#1D2B1E] flex items-center justify-center"><Ic className="h-4 w-4 text-[#3B5B2A]" /></div>
                  <span className="text-sm font-semibold">{TYPE_META[n.type]?.label}</span>
                  {flow.start === n.id && <span className="text-[10px] rounded-full bg-[#3B5B2A] text-white px-2 py-0.5">START</span>}
                  <Button size="icon" variant="ghost" className="ml-auto h-7 w-7" onClick={() => rmNode(n.id)} data-testid={`chatbot-node-delete-${n.id}`}><Trash2 className="h-3.5 w-3.5 text-destructive" /></Button>
                </div>

                {n.type !== "action" && (
                  <Textarea rows={2} placeholder={n.type === "menu" ? "Menu prompt, e.g. How can we help?" : n.type === "question" ? "Question, e.g. What's your name?" : "Message text… use {name}"}
                    value={n.text || ""} onChange={(e) => setNode(n.id, { text: e.target.value })} data-testid={`chatbot-node-text-${n.id}`} />
                )}

                {n.type === "question" && (
                  <Input className="mt-2" placeholder="Save answer as (field), e.g. name" value={n.field || ""} onChange={(e) => setNode(n.id, { field: e.target.value })} data-testid={`chatbot-node-field-${n.id}`} />
                )}

                {n.type === "menu" && (
                  <div className="mt-2 space-y-2">
                    {(n.options || []).map((o, i) => (
                      <div key={i} className="flex items-center gap-2">
                        <span className="text-xs text-muted-foreground w-4">{i + 1}.</span>
                        <Input className="flex-1" placeholder="Option label" value={o.label} onChange={(e) => setNode(n.id, { options: n.options.map((x, j) => j === i ? { ...x, label: e.target.value } : x) })} data-testid={`chatbot-option-label-${n.id}-${i}`} />
                        <Select value={o.next || END} onValueChange={(v) => setNode(n.id, { options: n.options.map((x, j) => j === i ? { ...x, next: v } : x) })}>
                          <SelectTrigger className="h-9 w-40" data-testid={`chatbot-option-next-${n.id}-${i}`}><SelectValue /></SelectTrigger>
                          <SelectContent>{nodeOpts.filter((x) => x.value !== n.id).map((x) => <SelectItem key={x.value} value={x.value}>{x.label}</SelectItem>)}<SelectItem value={END}>— End —</SelectItem></SelectContent>
                        </Select>
                        <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => setNode(n.id, { options: n.options.filter((_, j) => j !== i) })}><Trash2 className="h-3.5 w-3.5" /></Button>
                      </div>
                    ))}
                    <Button size="sm" variant="outline" onClick={() => setNode(n.id, { options: [...(n.options || []), { label: `Option ${(n.options?.length || 0) + 1}`, next: END }] })} data-testid={`chatbot-add-option-${n.id}`}><Plus className="h-3.5 w-3.5 mr-1" /> Add option</Button>
                  </div>
                )}

                {n.type === "action" && (
                  <div className="space-y-2">
                    <Select value={n.action?.kind || "create_lead"} onValueChange={(v) => setNode(n.id, { action: { ...(n.action || {}), kind: v } })}>
                      <SelectTrigger data-testid={`chatbot-action-kind-${n.id}`}><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="create_lead">Create CRM lead (from captured answers)</SelectItem>
                        <SelectItem value="add_tag">Add tag to contact</SelectItem>
                        <SelectItem value="handoff">Hand off to human agent</SelectItem>
                      </SelectContent>
                    </Select>
                    {n.action?.kind === "add_tag" && <Input placeholder="Tag, e.g. hot-lead" value={n.action?.tag || ""} onChange={(e) => setNode(n.id, { action: { ...(n.action || {}), tag: e.target.value } })} data-testid={`chatbot-action-tag-${n.id}`} />}
                    {n.action?.kind === "handoff" && <Textarea rows={2} placeholder="Message before handoff (optional)" value={n.text || ""} onChange={(e) => setNode(n.id, { text: e.target.value })} />}
                  </div>
                )}

                {n.type !== "menu" && !(n.type === "action" && n.action?.kind === "handoff") && (
                  <div className="mt-2 flex items-center gap-2">
                    <Label className="text-xs text-muted-foreground">Then go to →</Label>
                    <Select value={n.next || END} onValueChange={(v) => setNode(n.id, { next: v })}>
                      <SelectTrigger className="h-9 w-56" data-testid={`chatbot-node-next-${n.id}`}><SelectValue /></SelectTrigger>
                      <SelectContent>{nodeOpts.filter((x) => x.value !== n.id).map((x) => <SelectItem key={x.value} value={x.value}>{x.label}</SelectItem>)}<SelectItem value={END}>— End —</SelectItem></SelectContent>
                    </Select>
                  </div>
                )}
              </Card>
            );
          })}

          <div className="flex flex-wrap gap-2">
            {Object.entries(TYPE_META).map(([k, m]) => (
              <Button key={k} size="sm" variant="outline" onClick={() => addNode(k)} data-testid={`chatbot-add-${k}`}><m.icon className="h-3.5 w-3.5 mr-1" /> {m.label}</Button>
            ))}
          </div>
        </div>

        {/* Simulator */}
        <div>
          <Card className="p-4 sticky top-20" data-testid="chatbot-simulator">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2 font-semibold text-sm"><Bot className="h-4 w-4 text-[#3B5B2A]" /> Live Preview</div>
              <div className="flex gap-1">
                <Button size="sm" variant="outline" onClick={simStart} data-testid="chatbot-sim-start"><Play className="h-3.5 w-3.5 mr-1" /> Start</Button>
                <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => setSim({ messages: [], waiting: null, data: {}, started: false })}><RotateCcw className="h-4 w-4" /></Button>
              </div>
            </div>
            <div className="rounded-xl bg-[#E5DDD5] dark:bg-[#0B141A] p-3 space-y-2 h-[420px] overflow-y-auto" data-testid="chatbot-sim-messages">
              {!sim.started && <div className="text-center text-xs text-muted-foreground py-10">Press Start to test your flow</div>}
              {sim.messages.map((m, i) => (
                m.from === "sys"
                  ? <div key={i} className="text-center"><span className="text-[10px] bg-[#3B5B2A]/10 text-[#3B5B2A] dark:text-[#8BAA78] rounded-full px-2 py-0.5">{m.text}</span></div>
                  : <div key={i} className={`flex ${m.from === "user" ? "justify-end" : ""}`}>
                      <div className={`rounded-lg px-3 py-2 text-sm max-w-[85%] whitespace-pre-line ${m.from === "user" ? "bg-[#DCF8C6] dark:bg-[#005C4B] text-gray-800 dark:text-gray-50 rounded-br-sm" : "bg-white dark:bg-[#202C33] text-gray-800 dark:text-gray-100 rounded-bl-sm"}`}>{m.text}</div>
                    </div>
              ))}
            </div>
            {sim.started && waitingNode?.type === "menu" && (
              <div className="flex flex-wrap gap-1.5 mt-2">
                {(waitingNode.options || []).map((o, i) => (
                  <Button key={i} size="sm" variant="outline" className="text-xs" onClick={() => simSend(String(i + 1))} data-testid={`chatbot-sim-opt-${i}`}>{i + 1}. {o.label}</Button>
                ))}
              </div>
            )}
            <div className="flex gap-2 mt-2">
              <Input placeholder="Type a reply…" value={simInput} onChange={(e) => setSimInput(e.target.value)} onKeyDown={(e) => e.key === "Enter" && simSend()} disabled={!sim.started} data-testid="chatbot-sim-input" />
              <Button size="icon" className="bg-[#3B5B2A] hover:bg-[#2D4720]" onClick={() => simSend()} disabled={!sim.started} data-testid="chatbot-sim-send"><Send className="h-4 w-4" /></Button>
            </div>
            <p className="text-[11px] text-muted-foreground mt-2">Customers reply with the option number. Type <b>agent</b> anytime for a human.</p>
          </Card>
        </div>
      </div>
    </div>
  );
}
