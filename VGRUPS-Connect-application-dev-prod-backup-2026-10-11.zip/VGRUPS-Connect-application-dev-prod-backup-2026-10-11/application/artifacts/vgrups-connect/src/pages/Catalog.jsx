import React, { useEffect, useState } from "react";
import api from "../lib/api";
import { PageHeader, DemoBadge } from "../components/common";
import { Card } from "../components/ui/card";
import { Input } from "../components/ui/input";
import { Button } from "../components/ui/button";
import { Search, Package, Send } from "lucide-react";
import CatalogShareDialog from "../components/CatalogShareDialog";
import CatalogFiles from "../components/CatalogFiles";

export default function Catalog() {
  const [items, setItems] = useState([]);
  const [search, setSearch] = useState("");
  const [sharing, setSharing] = useState(null);
  const load = () => api.get(`/products?search=${encodeURIComponent(search)}`).then((r) => setItems(r.data.items));
  useEffect(() => { const t = setTimeout(load, 250); return () => clearTimeout(t); }, [search]);

  return (
    <div className="p-4 md:p-6 animate-fade-up">
      <PageHeader title="Digital Catalog" subtitle={`${items.length} products`} testId="catalog-header" />
      <CatalogFiles />
      <div className="relative mb-4 max-w-md">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input data-testid="catalog-search-input" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search products…" className="pl-9" />
      </div>
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
        {items.map((p) => (
          <Card key={p.id} className="p-4 flex flex-col" data-testid={`product-card-${p.id}`}>
            <div className="h-24 rounded-lg bg-[#F0F4EE] dark:bg-[#1D2B1E] overflow-hidden flex items-center justify-center mb-3">
              {p.image
                ? <img src={p.image} alt={p.name} loading="lazy" onError={(e) => { e.currentTarget.style.display = "none"; }} className="h-full w-full object-cover" data-testid={`product-image-${p.id}`} />
                : <Package className="h-8 w-8 text-[#6E8B5B]" />}
            </div>
            <div className="flex items-center gap-1.5">
              <span className="text-[10px] font-mono rounded bg-muted px-1.5 py-0.5">{p.code}</span>
              {p.is_demo && <DemoBadge />}
            </div>
            <div className="text-sm font-medium mt-1.5 line-clamp-2 flex-1">{p.name}</div>
            <div className="text-xs text-muted-foreground mt-1">{p.category}</div>
            <div className="flex items-center justify-between mt-2">
              <div>
                <span className="text-sm font-bold text-[#3B5B2A] dark:text-[#8BAA78]">₹{p.selling_price}</span>
                <span className="text-xs text-muted-foreground line-through ml-1">₹{p.mrp}</span>
              </div>
              <span className="text-[10px] text-muted-foreground">Stock: {p.stock}</span>
            </div>
            <Button variant="outline" size="sm" className="mt-3 w-full" onClick={() => setSharing(p)} data-testid={`product-whatsapp-${p.id}`}><Send className="h-3.5 w-3.5 mr-1" /> Share on WhatsApp</Button>
          </Card>
        ))}
      </div>
      {sharing && <CatalogShareDialog key={sharing.id} product={sharing} onClose={() => setSharing(null)} />}
    </div>
  );
}
