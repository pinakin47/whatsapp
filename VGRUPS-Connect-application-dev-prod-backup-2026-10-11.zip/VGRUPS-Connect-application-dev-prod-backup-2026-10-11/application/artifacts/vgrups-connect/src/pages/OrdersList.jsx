import React, { useEffect, useState, useCallback } from "react";
import api, { apiError } from "../lib/api";
import { toast } from "sonner";
import { Card } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { StatusBadge, DemoBadge } from "../components/common";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../components/ui/table";
import { Link2, CheckCircle2, Loader2 } from "lucide-react";

export default function OrdersList() {
  const [items, setItems] = useState([]);
  const [rzp, setRzp] = useState(false);
  const [busy, setBusy] = useState(null);

  const load = useCallback(() => { api.get("/orders").then((r) => setItems(r.data.items)); }, []);
  useEffect(() => { load(); api.get("/payments/config").then((r) => setRzp(r.data.razorpay_configured)).catch(() => {}); }, [load]);

  const makeLink = async (id) => {
    setBusy(id);
    try { const r = await api.post(`/orders/${id}/payment-link`); toast.success(r.data.whatsapp_sent ? "Payment link created & sent on WhatsApp" : "Payment link created"); load(); }
    catch (e) { toast.error(apiError(e)); } finally { setBusy(null); }
  };
  const markPaid = async (id) => {
    setBusy(id);
    try { await api.post(`/orders/${id}/mark-paid`); toast.success("Marked as paid — confirmation sent"); load(); }
    catch (e) { toast.error(apiError(e)); } finally { setBusy(null); }
  };

  return (
    <div>
      {!rzp && <div className="mb-3 text-xs rounded-lg bg-amber-50 dark:bg-amber-500/10 text-amber-700 dark:text-amber-300 border border-amber-200 dark:border-amber-500/20 px-3 py-2" data-testid="rzp-not-configured">
        Razorpay not connected — add keys in <b>Integrations</b> to generate payment links. You can still use <b>Mark Paid</b> for manual/offline payments.</div>}
      <Card className="overflow-hidden">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader><TableRow><TableHead>Order No</TableHead><TableHead>Customer</TableHead><TableHead>Status</TableHead><TableHead>Payment</TableHead><TableHead className="text-right">Total</TableHead><TableHead className="text-right">Actions</TableHead></TableRow></TableHeader>
            <TableBody>
              {items.map((o) => (
                <TableRow key={o.id} data-testid={`order-row-${o.id}`}>
                  <TableCell className="font-mono text-sm flex items-center gap-2">{o.order_no} {o.is_demo && <DemoBadge />}</TableCell>
                  <TableCell>{o.contact_name}</TableCell>
                  <TableCell><StatusBadge status={o.status} /></TableCell>
                  <TableCell><StatusBadge status={o.payment_status} /></TableCell>
                  <TableCell className="text-right font-semibold">₹{Number(o.total).toLocaleString("en-IN")}</TableCell>
                  <TableCell className="text-right">
                    {o.payment_status === "paid" ? <span className="text-xs text-green-600 dark:text-green-400 inline-flex items-center gap-1"><CheckCircle2 className="h-4 w-4" /> Paid</span> : (
                      <div className="flex justify-end gap-1">
                        <Button size="sm" variant="outline" disabled={busy === o.id || !rzp} onClick={() => makeLink(o.id)} data-testid={`order-paylink-${o.id}`} title={rzp ? "Create Razorpay link" : "Connect Razorpay first"}>
                          {busy === o.id ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Link2 className="h-3.5 w-3.5 mr-1" />}Link</Button>
                        <Button size="sm" className="bg-[#3B5B2A] hover:bg-[#2D4720]" disabled={busy === o.id} onClick={() => markPaid(o.id)} data-testid={`order-markpaid-${o.id}`}>Mark Paid</Button>
                      </div>
                    )}
                  </TableCell>
                </TableRow>
              ))}
              {items.length === 0 && <TableRow><TableCell colSpan={6} className="text-center py-10 text-muted-foreground">No orders yet. Convert a quotation to create one.</TableCell></TableRow>}
            </TableBody>
          </Table>
        </div>
      </Card>
    </div>
  );
}
