import React, { useCallback, useEffect, useRef, useState } from "react";
import { Link, useParams } from "react-router-dom";
import api, { apiError } from "../lib/api";
import { useAuth } from "../context/AuthContext";
import { PageHeader } from "../components/common";
import MRProfileForm from "../components/ivr/MRProfileForm";
import MRFieldActivity from "../components/ivr/MRFieldActivity";
import MRFlowReference from "../components/ivr/MRFlowReference";
import MRMessagePanel from "../components/ivr/MRMessagePanel";
import Sales from "./Sales";
import { Card } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Loader2, ArrowLeft, RefreshCw } from "lucide-react";

const inr = (n) => (n == null ? "-" : `\u20B9${Number(n).toLocaleString("en-IN")}`);
const today = () => new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Kolkata" }).format(new Date());
const arr = (a) => (Array.isArray(a) ? a : []);
const Rows = ({ items, render, empty = "None recorded" }) => (items.length ? <ul className="space-y-1 text-sm">{items.map((x, i) => <li key={x.id || i} className="rounded bg-muted/50 px-2 py-1">{render(x)}</li>)}</ul> : <p className="text-sm text-muted-foreground">{empty}</p>);
const Sec = ({ title, children, testId }) => <Card className="p-4" data-testid={testId}><h3 className="text-xs font-semibold uppercase tracking-wide text-muted-foreground mb-2">{title}</h3>{children}</Card>;

export default function MRIVRDetail() {
  const { id } = useParams();
  const { can, user } = useAuth();
  const [date, setDate] = useState(today());
  const [d, setD] = useState(null);
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  const seq = useRef(0);
  const q = useRef({ id, date });
  q.current = { id, date };

  const load = useCallback(() => {
    const my = ++seq.current; const { id: i, date: dt } = q.current; setBusy(true);
    api.get(`/mr-ivr/mrs/${i}`, { params: { date: dt } })
      .then((r) => { if (my === seq.current) { setD(r.data); setErr(""); } })
      .catch((e) => { if (my === seq.current) setErr(apiError(e)); })
      .finally(() => { if (my === seq.current) setBusy(false); });
  }, []);
  useEffect(() => { setD(null); load(); }, [id, date, load]);
  useEffect(() => { const t = setInterval(load, 30000); return () => clearInterval(t); }, [load]);

  const edit = ["admin", "super_admin", "sales_manager"].includes(user?.role) && can("settings", "manage") && can("whatsapp", "send");
  const send = edit && can("field_sales", "view");
  const back = <Link to="/ivr/mrs" className="text-sm inline-flex items-center gap-1 text-muted-foreground"><ArrowLeft className="h-4 w-4" />All MRs</Link>;
  if (err && !d) return <div className="p-10 text-center text-sm" data-testid="mr-ivr-detail-error"><p className="text-red-600 mb-3">{err}</p><Button variant="outline" onClick={load}>Retry</Button></div>;
  if (!d) return <div className="p-10 text-center"><Loader2 className="h-5 w-5 animate-spin mx-auto" /></div>;
  const s = d.summary || {}; const mr = d.mr || {}; const rep = d.report; const t = d.target; const nd = d.next_destination;
  const plan = rep?.plan || {}; const cl = rep?.closing || {};
  const visits = arr(d.visits);

  return (
    <div className="p-4 md:p-6 space-y-4 animate-fade-up" data-testid="mr-ivr-detail">
      <PageHeader title={mr.name || "MR"} subtitle={`${mr.employee_id || "No employee ID"}${mr.active === false ? " - INACTIVE" : ""}`} actions={back} />
      <Card className="p-3 flex flex-wrap items-end gap-3">
        <div><label className="text-sm font-medium" htmlFor="mr-date">Date</label><Input id="mr-date" type="date" value={date} onChange={(e) => e.target.value && setDate(e.target.value)} data-testid="mr-ivr-date" /></div>
        <Button variant="outline" onClick={load} disabled={busy} data-testid="mr-ivr-refresh"><RefreshCw className={`h-3.5 w-3.5 mr-1 ${busy ? "animate-spin" : ""}`} />Refresh</Button>
        <span className="text-xs text-muted-foreground ml-auto">Auto-refreshes every 30 seconds</span>
      </Card>
      {err && <div className="text-xs text-red-600 flex items-center gap-3">Refresh failed: {err}<Button size="sm" variant="outline" onClick={load}>Retry</Button></div>}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3" data-testid="mr-ivr-summary">
        {[["Planned visits", s.planned_visits ?? 0], ["Completed", s.completed_visits ?? 0], ["Pending", s.pending_visits ?? 0], ["Sales", inr(s.sales)], ["Daily goal", inr(s.daily_goal)]].map(([k, v]) => <Card key={k} className="p-3"><div className="text-lg font-bold">{v}</div><div className="text-xs text-muted-foreground">{k}</div></Card>)}
      </div>
      <p className="text-xs text-muted-foreground">Achievement {s.achievement_pct == null ? "not set" : `${s.achievement_pct}%`} against the daily goal. The daily goal is separate from the assigned monthly target. This page shows recorded check-ins and planned stops, not live location.</p>
      <p className="text-xs text-muted-foreground">Sales and completed totals use the MR's submitted closing report when available. Actual orders, recorded visit rows and reported order notes are shown separately below.</p>
      <div className="grid lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 space-y-4 min-w-0">
          <Sec title="Next planned stop (planned, not confirmed whereabouts)" testId="mr-ivr-next">
            {nd ? <div className="text-sm">{nd.doctor_name}<div className="text-xs text-muted-foreground">{[nd.city, nd.address].filter(Boolean).join(", ")} - {nd.status}</div></div> : <p className="text-sm text-muted-foreground">No pending planned stop.</p>}
          </Sec>
          <MRFieldActivity d={d} />
          <Sec title="Recorded visits / check-ins" testId="mr-ivr-visits"><Rows items={visits} render={(v) => <span className="break-words">{v.doctor_name || v.customer_name || v.name || "Visit"} - {v.city || v.location || ""} - <b>{v.status || ""}</b>{v.visit_type ? ` - ${v.visit_type}` : ""}{v.check_in_at ? ` - checked in ${new Date(v.check_in_at).toLocaleTimeString()}` : ""}{v.purpose ? <><br />Purpose: {v.purpose}</> : null}{v.products_discussed ? <><br />Products: {Array.isArray(v.products_discussed) ? v.products_discussed.join(", ") : v.products_discussed}</> : null}{v.reported_order_value != null ? <><br />Reported order value: {inr(v.reported_order_value)}</> : null}{v.followup ? <><br />Follow-up: {String(v.followup)}</> : null}{v.remarks ? <><br />Remarks: {v.remarks}</> : null}</span>} /></Sec>
          <Sec title="Daily report"><div className="space-y-2 text-sm">
            {!rep ? <p className="text-muted-foreground">No report submitted for {d.date}.</p> : <>
              <div>Planned destinations</div><Rows items={arr(plan.visits)} render={(v) => `${v.name} - ${v.location || "-"} - ${v.purpose || "-"}`} />
              <div>Activity / remarks: {cl.daily_achievement || cl.remarks || "-"}</div>
              <div>Tomorrow plan</div><Rows items={arr(cl.tomorrow_plan)} render={(v) => `${v.name} - ${v.location || "-"} - ${v.purpose || "-"}`} />
              <div>Pending follow-ups</div><Rows items={arr(cl.pending_followups)} render={(x) => String(x)} /></>}
          </div></Sec>
          <Sec title="Orders"><Rows items={arr(d.orders)} render={(o) => `${o.order_no || o.id} - ${inr(o.total)} - ${o.status || ""}`} /></Sec>
          <Sec title="Quotations"><Rows items={arr(d.quotations)} render={(o) => `${o.quote_no || o.id} - ${inr(o.total)} - ${o.status || ""}`} /></Sec>
          <Sec title="Assigned monthly target">{t ? <div className="space-y-1 text-sm"><div>Month: {t.month}</div><div>Sales target: {inr(t.order_target)}</div><div>Visit target: {t.visit_target ?? 0}</div><div>Incentive: {t.incentive_pct ?? 0}%</div></div> : <p className="text-sm text-muted-foreground">No monthly target assigned.</p>}</Sec>
          <Sec title="My Sales" testId="mr-ivr-sales">{mr.mr_id ? <Sales embedded profileMrId={mr.mr_id} canCreateHere={mr.mr_id === user?.id} /> : <p className="text-sm text-muted-foreground">No linked user account for sales.</p>}</Sec>
          <Sec title="Message history" testId="mr-ivr-history"><Rows items={arr(d.history)} empty="No messages yet." render={(h) => <span className="break-words">{new Date(h.created_at).toLocaleString()} - {h.kind} - <b>{h.status}</b>{h.error ? ` (${h.error})` : ""}<br /><span className="text-muted-foreground">{h.body}</span></span>} /></Sec>
        </div>
        <div className="space-y-4 min-w-0">
          <MRMessagePanel mrId={id} date={date} canSend={send} active={mr.active !== false} onSent={load} />
          <MRFlowReference />
          <MRProfileForm key={id} mrId={id} initial={d.profile} canEdit={edit} onSaved={load} />
        </div>
      </div>
    </div>
  );
}
