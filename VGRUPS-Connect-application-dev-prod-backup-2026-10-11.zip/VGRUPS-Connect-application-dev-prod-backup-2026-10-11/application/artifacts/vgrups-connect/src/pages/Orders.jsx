import React from "react";
import { PageHeader } from "../components/common";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "../components/ui/tabs";
import Quotations from "./Quotations";
import OrdersList from "./OrdersList";

export default function Orders() {
  return (
    <div className="p-4 md:p-6 animate-fade-up">
      <PageHeader title="Sales & Orders" subtitle="Create quotations, convert to orders, collect payments" testId="orders-header" />
      <Tabs defaultValue="quotations">
        <TabsList>
          <TabsTrigger value="quotations" data-testid="orders-tab-quotations">Quotations</TabsTrigger>
          <TabsTrigger value="orders" data-testid="orders-tab-orders">Orders</TabsTrigger>
        </TabsList>
        <TabsContent value="quotations" className="mt-4"><Quotations /></TabsContent>
        <TabsContent value="orders" className="mt-4"><OrdersList /></TabsContent>
      </Tabs>
    </div>
  );
}
