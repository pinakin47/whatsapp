import React, { useEffect, useState } from "react";
import api, { apiError } from "../lib/api";
import { toast } from "sonner";
import { PageHeader, StatusBadge, DemoBadge } from "../components/common";
import { Card } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { Textarea } from "../components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger } from "../components/ui/dialog";
import { Plus, Send, Loader2, FileText } from "lucide-react";

const CATS = ["MARKETING", "UTILITY", "AUTHENTICATION"];
const emptyT = { name: "", category: "MARKETING", language: "en_US", header: "", body: "", footer: "", variables: [] };

export default function WhatsAppTemplates() {
  const [items, setItems] = useState([]);
  const [status, setStatus] = useState(null);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState(emptyT);
  const [saving, setSaving] = useState(false);
  const [preview, setPreview] = useState(null);

  const load = () => api.get("/whatsapp/templates").then((r) => setItems(r.data.items));
  useEffect(() => { load(); api.get("/whatsapp/status").then((r) => setStatus(r.data)); }, []);

  const save = async () => {
    setSaving(true);
    try { await api.post("/whatsapp/templates", form); toast.success("Template saved as draft"); setOpen(false); setForm(emptyT); load(); }
    catch (e) { toast.error(apiError(e)); } finally { setSaving(false); }
  };

  const submit = async (id) => {
    try { await api.post(`/whatsapp/templates/${id}/submit`); toast.success("Submitted to Meta for approval"); load(); }
    catch (e) { toast.error(apiError(e)); }
  };

  return (
    <div className="p-4 md:p-6 animate-fade-up">
      <PageHeader
        title="WhatsApp Templates" subtitle="Message template manager" testId="templates-header"
        actions={
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild><Button data-testid="add-template-button" className="bg-[#3B5B2A] hover:bg-[#2D4720]"><Plus className="h-4 w-4 mr-1" /> New Template</Button></DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader><DialogTitle>Create Template</DialogTitle></DialogHeader>
              <div className="grid md:grid-cols-2 gap-5">
                <div className="space-y-3">
                  <div><Label>Name *</Label><Input data-testid="template-name-input" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value.toLowerCase().replace(/\s/g, "_") })} placeholder="welcome_lead" /></div>
                  <div className="grid grid-cols-2 gap-2">
                    <div><Label>Category</Label>
                      <Select value={form.category} onValueChange={(v) => setForm({ ...form, category: v })}>
                        <SelectTrigger data-testid="template-category-select"><SelectValue /></SelectTrigger>
                        <SelectContent>{CATS.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
                      </Select>
                    </div>
                    <div><Label>Language</Label><Input value={form.language} onChange={(e) => setForm({ ...form, language: e.target.value })} /></div>
                  </div>
                  <div><Label>Header</Label><Input value={form.header} onChange={(e) => setForm({ ...form, header: e.target.value })} /></div>
                  <div><Label>Body *</Label><Textarea rows={4} data-testid="template-body-input" value={form.body} onChange={(e) => setForm({ ...form, body: e.target.value })} placeholder="Hi {name}, welcome to VGRUPS…" /></div>
                  <div><Label>Footer</Label><Input value={form.footer} onChange={(e) => setForm({ ...form, footer: e.target.value })} /></div>
                  <p className="text-xs text-muted-foreground">Variables: {"{name}"}, {"{company}"}, {"{product}"}, {"{order_id}"}, {"{1}"}, {"{2}"}</p>
                </div>
                <div>
                  <Label>Live Preview</Label>
                  <div className="mt-1.5 rounded-xl bg-[#E5DDD5] dark:bg-[#0B141A] p-4 min-h-64">
                    <div className="rounded-lg bg-white dark:bg-[#202C33] p-3 shadow-sm text-sm max-w-[85%]">
                      {form.header && <div className="font-semibold mb-1">{form.header}</div>}
                      <div className="whitespace-pre-wrap text-gray-800 dark:text-gray-100">{form.body || "Your message preview appears here…"}</div>
                      {form.footer && <div className="text-xs text-gray-500 mt-2">{form.footer}</div>}
                    </div>
                  </div>
                </div>
              </div>
              <DialogFooter>
                <Button data-testid="template-save-button" disabled={saving || !form.name || !form.body} onClick={save} className="bg-[#3B5B2A] hover:bg-[#2D4720]">
                  {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : "Save Draft"}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        }
      />

      {status && !status.configured && (
        <Card className="p-4 mb-4 border-[#D97706]/30 bg-[#FFF8EE] dark:bg-[#2A1F0E]">
          <div className="text-sm text-[#92540A] dark:text-[#F59E0B]">
            <b>WhatsApp Cloud API not connected.</b> Templates are stored locally. Connect your Meta account in Integrations to submit templates for Meta approval.
          </div>
        </Card>
      )}

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {items.map((t) => (
          <Card key={t.id} className="p-4" data-testid={`template-card-${t.id}`}>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 min-w-0">
                <FileText className="h-4 w-4 text-[#3B5B2A] shrink-0" />
                <span className="font-medium font-mono text-sm truncate">{t.name}</span>
                {t.is_demo && <DemoBadge />}
              </div>
              <StatusBadge status={t.status} />
            </div>
            <div className="flex gap-2 mt-2">
              <span className="text-[10px] rounded bg-muted px-1.5 py-0.5">{t.category}</span>
              <span className="text-[10px] rounded bg-muted px-1.5 py-0.5">{t.language}</span>
            </div>
            <p className="text-sm text-muted-foreground mt-3 line-clamp-3">{t.body}</p>
            {t.status === "draft" && (
              <Button variant="outline" size="sm" className="mt-3 w-full" data-testid={`submit-template-${t.id}`} onClick={() => submit(t.id)}>
                <Send className="h-3.5 w-3.5 mr-1" /> Submit to Meta
              </Button>
            )}
          </Card>
        ))}
      </div>
    </div>
  );
}
