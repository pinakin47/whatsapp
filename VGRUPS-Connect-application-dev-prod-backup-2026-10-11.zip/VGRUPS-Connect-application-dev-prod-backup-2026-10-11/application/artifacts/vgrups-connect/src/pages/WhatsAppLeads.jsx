import React, { useState } from "react";
import { Link } from "react-router-dom";
import { toast } from "sonner";
import api, { apiError } from "../lib/api";
import { useAuth } from "../context/AuthContext";
import { PageHeader } from "../components/common";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Card } from "../components/ui/card";
import { PRESETS, usePoll, label, fmt } from "../lib/leadCapture";
import { Empty, ErrorBox, LeadLink, Pill, Skeleton } from "../components/leadcapture/Bits";
import SettingsPanel from "../components/leadcapture/SettingsPanel";
import { ReviewPanel, RequestsPanel, ActivityPanel, AnalyticsPanel } from "../components/leadcapture/Panels";

const LIMIT = 25;
const sel = "h-9 rounded-md border border-input bg-background px-2 text-sm";

function Filters({ f, setF, opts }) {
  const up = (k) => (e) => setF((p) => ({ ...p, [k]: e.target.value, page: 1 }));
  const Sel = ({ k, ph, list }) => <select aria-label={ph} className={sel} value={f[k]} onChange={up(k)}><option value="">{ph}</option>{list.map((x) => <option key={x.v ?? x} value={x.v ?? x}>{x.t ?? label(x)}</option>)}</select>;
  return (
    <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-2" data-testid="lc-filters">
      <Input className="col-span-2" placeholder="Search" value={f.search} onChange={up("search")} data-testid="lc-search" />
      {opts?.mrs?.length > 0 && <Sel k="mr" ph="All MRs" list={opts.mrs.map((m) => ({ v: m.id, t: m.name }))} />}
      <Input type="date" aria-label="Date" value={f.date} onChange={up("date")} />
      <Input placeholder="Hospital" value={f.hospital} onChange={up("hospital")} />
      <Input placeholder="Location" value={f.location} onChange={up("location")} />
      <Input placeholder="Product" value={f.product} onChange={up("product")} />
      <Sel k="status" ph="Any status" list={opts?.statuses || []} />
      <Sel k="priority" ph="Any priority" list={opts?.priorities || []} />
      <Sel k="lead_type" ph="Any type" list={opts?.lead_types || []} />
      <Sel k="phone" ph="Phone: any" list={[{ v: "missing", t: "Missing" }, { v: "present", t: "Present" }]} />
    </div>
  );
}

const EMPTY = { search: "", mr: "", date: "", hospital: "", location: "", product: "", status: "", priority: "", lead_type: "", phone: "", page: 1 };

export default function WhatsAppLeads() {
  const { can } = useAuth();
  const [preset, setPreset] = useState("all");
  const [tab, setTab] = useState("dash");
  const [f, setF] = useState(EMPTY);
  const [exporting, setExporting] = useState(false);
  const cur = PRESETS.find((p) => p.key === preset);
  const opts = usePoll("/lead-capture/options", null, 30000).data;
  const params = { view: preset, limit: LIMIT, ...Object.fromEntries(Object.entries(f).filter(([, v]) => v !== "" && v != null)) };
  const dash = tab === "dash";
  const leads = usePoll("/lead-capture/leads", params, 5000, dash && cur.kind === "leads");
  const review = usePoll("/lead-capture/review", null, 5000, dash && cur.kind === "review");
  const reqs = usePoll("/lead-capture/requests", null, 5000, dash && cur.kind === "requests");
  const act = usePoll("/lead-capture/activity", null, 5000, dash && cur.kind === "activity");
  const ana = usePoll("/lead-capture/analytics", null, 5000, dash && cur.kind === "analytics");
  const canExport = opts?.can_export;
  const canSettings = can("settings", "manage") && !!opts?.can_configure;

  const doExport = async () => {
    setExporting(true);
    try {
      const { page, ...q } = params; // eslint-disable-line no-unused-vars
      const r = await api.get("/lead-capture/export", { params: q, responseType: "blob" });
      const url = URL.createObjectURL(r.data); const a = document.createElement("a");
      a.href = url; a.download = "whatsapp-leads.csv"; a.click(); URL.revokeObjectURL(url);
    } catch (e) { toast.error(apiError(e)); } finally { setExporting(false); }
  };

  const d = leads.data; const pages = d ? Math.max(1, Math.ceil(d.total / LIMIT)) : 1;
  const leadsBody = leads.error && !d ? <ErrorBox message={leads.error} onRetry={leads.reload} /> : !d ? <Skeleton /> : !d.items.length ? <Empty title="No leads match" hint="Leads captured from MR WhatsApp messages will appear here." /> : (
    <>
      <div className="hidden md:block overflow-x-auto rounded-lg border border-border"><table className="w-full text-sm">
        <thead className="bg-muted/50 text-xs text-muted-foreground"><tr>{["ID", "Lead", "MR", "Phone", "Location", "Status", "Priority", "Captured"].map((h) => <th key={h} className="text-left p-2">{h}</th>)}</tr></thead>
        <tbody>{d.items.map((l) => (
          <tr key={l.id} className="border-t border-border" data-testid={`lc-lead-${l.id}`}>
            <td className="p-2"><LeadLink id={l.id} display={l.display_id} /></td>
            <td className="p-2 max-w-[220px]"><div className="truncate">{l.title || l.contact_name || "Untitled"}</div><div className="text-xs text-muted-foreground truncate">{l.hospital_name || l.company || ""}</div></td>
            <td className="p-2">{l.mr_name || "-"}</td>
            <td className="p-2">{l.mobile || <Pill value="missing" tone="urgent" />}</td>
            <td className="p-2">{l.location || "-"}</td>
            <td className="p-2"><Pill value={l.status} /></td>
            <td className="p-2"><Pill value={l.priority} /></td>
            <td className="p-2 whitespace-nowrap">{fmt(l.created_at)}</td>
          </tr>))}</tbody></table></div>
      <div className="md:hidden space-y-2">{d.items.map((l) => (
        <Card key={l.id} className="p-3 text-sm"><div className="flex justify-between"><LeadLink id={l.id} display={l.display_id} /><Pill value={l.status} /></div>
          <div className="mt-1">{l.title || l.contact_name || "Untitled"}</div>
          <div className="text-xs text-muted-foreground">{l.mr_name} - {l.mobile || "Phone missing"}</div></Card>))}</div>
      <div className="flex items-center justify-between text-sm">
        <span className="text-muted-foreground">{d.total} leads - page {d.page} of {pages}</span>
        <div className="flex gap-2"><Button size="sm" variant="outline" disabled={f.page <= 1} onClick={() => setF({ ...f, page: f.page - 1 })}>Previous</Button>
          <Button size="sm" variant="outline" disabled={f.page >= pages} onClick={() => setF({ ...f, page: f.page + 1 })}>Next</Button></div>
      </div>
    </>
  );

  return (
    <div className="p-4 md:p-6 space-y-4 animate-fade-up" data-testid="wa-leads-page">
      <PageHeader title="WhatsApp Leads" subtitle="Leads captured from MR messages to the authorized company app. Delivery is never assumed without evidence." actions={
        <div className="flex gap-2"><Link to="/leads" className="inline-flex items-center rounded-md border border-border px-3 py-2 text-sm hover:bg-muted" data-testid="link-kanban">Kanban CRM board</Link>
          {canExport && dash && cur.kind === "leads" && <Button variant="outline" onClick={doExport} disabled={exporting} data-testid="lc-export">{exporting ? "Exporting..." : "Export CSV"}</Button>}</div>} />
      <div className="flex gap-2 border-b border-border">
        {[["dash", "Dashboard"], ["settings", "Setup"]].map(([k, t]) => <button key={k} onClick={() => setTab(k)} data-testid={`lc-tab-${k}`} className={`px-3 py-2 text-sm border-b-2 ${tab === k ? "border-[#3B5B2A] font-semibold" : "border-transparent text-muted-foreground"}`}>{t}</button>)}
      </div>
      {tab === "settings" ? <SettingsPanel canManage={canSettings} /> : (
        <>
          <div className="flex gap-1.5 overflow-x-auto pb-1" data-testid="lc-presets">
            {PRESETS.map((p) => <button key={p.key} onClick={() => { setPreset(p.key); setF((x) => ({ ...x, page: 1 })); }} data-testid={`lc-preset-${p.key}`} className={`shrink-0 rounded-full px-3 py-1.5 text-xs border ${preset === p.key ? "bg-[#3B5B2A] text-white border-[#3B5B2A]" : "border-border hover:bg-muted"}`}>{p.label}</button>)}
          </div>
          {cur.kind === "leads" && <><Filters f={f} setF={setF} opts={opts} />{leadsBody}</>}
          {cur.kind === "review" && <ReviewPanel res={review} canManage={!!opts?.can_manage} opts={opts} />}
          {cur.kind === "requests" && <RequestsPanel res={reqs} />}
          {cur.kind === "activity" && <ActivityPanel res={act} />}
          {cur.kind === "analytics" && <AnalyticsPanel res={ana} />}
          <p className="text-xs text-muted-foreground">Refreshes every 5 seconds.</p>
        </>
      )}
    </div>
  );
}
