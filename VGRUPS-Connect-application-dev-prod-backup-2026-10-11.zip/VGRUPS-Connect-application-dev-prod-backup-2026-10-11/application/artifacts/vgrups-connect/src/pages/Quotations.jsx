import React, { useEffect, useState, useCallback } from "react";
import api, { apiError } from "../lib/api";
import { useSenders, SenderSelect, resolveSender, senderIssue } from "../lib/useSenders";
import { toast } from "sonner";
import { Card } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { Textarea } from "../components/ui/textarea";
import { StatusBadge } from "../components/common";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogTrigger } from "../components/ui/dialog";
import { Plus, Loader2, Trash2, Send, ArrowRightLeft, FileText } from "lucide-react";

const emptyForm = { contact_id: "", contact_name: "", mobile: "", items: [], discount: 0, notes: "" };

export default function Quotations() {
  const senders = useSenders();
  const [senderPick, setSenderPick] = useState("");
  const senderId = resolveSender(senders, senderPick);
  const [items, setItems] = useState([]);
  const [contacts, setContacts] = useState([]);
  const [products, setProducts] = useState([]);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState(emptyForm);
  const [saving, setSaving] = useState(false);
  const [addProd, setAddProd] = useState("");

  const load = useCallback(() => { api.get("/quotations").then((r) => setItems(r.data.items)); }, []);
  useEffect(() => {
    load();
    api.get("/contacts?limit=200").then((r) => setContacts(r.data.items)).catch(() => {});
    api.get("/products").then((r) => setProducts(r.data.items)).catch(() => {});
  }, [load]);

  const productMap = Object.fromEntries(products.map((p) => [p.id, p]));
  const subtotal = form.items.reduce((s, it) => { const p = productMap[it.product_id]; return s + (p ? p.selling_price * it.qty : 0); }, 0);
  const gst = form.items.reduce((s, it) => { const p = productMap[it.product_id]; return s + (p ? p.selling_price * it.qty * (p.gst || 0) / 100 : 0); }, 0);
  const total = Math.max(0, subtotal + gst - Number(form.discount || 0));

  const addItem = () => { if (!addProd || form.items.find((i) => i.product_id === addProd)) return; setForm((f) => ({ ...f, items: [...f.items, { product_id: addProd, qty: 1 }] })); setAddProd(""); };
  const setQty = (pid, qty) => setForm((f) => ({ ...f, items: f.items.map((i) => i.product_id === pid ? { ...i, qty: Math.max(1, Number(qty) || 1) } : i) }));
  const rmItem = (pid) => setForm((f) => ({ ...f, items: f.items.filter((i) => i.product_id !== pid) }));

  const pickContact = (cid) => { const c = contacts.find((x) => x.id === cid); setForm((f) => ({ ...f, contact_id: cid, contact_name: c?.name || "", mobile: c?.mobile || "" })); };

  const create = async () => {
    setSaving(true);
    try {
      await api.post("/quotations", { contact_id: form.contact_id || null, contact_name: form.contact_name, mobile: form.mobile, discount: Number(form.discount || 0), notes: form.notes, items: form.items });
      toast.success("Quotation created"); setOpen(false); setForm(emptyForm); load();
    } catch (e) { toast.error(apiError(e)); } finally { setSaving(false); }
  };
  const sendWa = async (id) => { if (senderIssue(senders, senderId)) { toast.error(senderIssue(senders, senderId)); return; } try { await api.post(`/quotations/${id}/send?session_id=${encodeURIComponent(senderId)}`); toast.success("Quotation sent on WhatsApp"); load(); } catch (e) { toast.error(apiError(e)); } };
  const convert = async (id) => { try { const r = await api.post(`/quotations/${id}/convert`); toast.success(`Converted to order ${r.data.order_no}`); load(); } catch (e) { toast.error(apiError(e)); } };
  const remove = async (id) => { try { await api.delete(`/quotations/${id}`); load(); } catch (e) { toast.error(apiError(e)); } };

  return (
    <div>
      <div className="mb-4 max-w-md"><SenderSelect senders={senders} value={senderPick} onChange={setSenderPick} testId="quotation-sender" label="Send quotations from" /></div>
      <div className="flex justify-end mb-3">
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild><Button data-testid="new-quotation-button" className="bg-[#3B5B2A] hover:bg-[#2D4720]"><Plus className="h-4 w-4 mr-1" /> New Quotation</Button></DialogTrigger>
          <DialogContent className="max-w-xl max-h-[90vh] overflow-y-auto">
            <DialogHeader><DialogTitle>Create Quotation</DialogTitle><DialogDescription>Pick a customer and add products.</DialogDescription></DialogHeader>
            <div className="space-y-4">
              <div>
                <Label>Customer *</Label>
                <Select value={form.contact_id} onValueChange={pickContact}>
                  <SelectTrigger data-testid="quotation-contact-select"><SelectValue placeholder="Select contact" /></SelectTrigger>
                  <SelectContent className="max-h-72">{contacts.map((c) => <SelectItem key={c.id} value={c.id}>{c.name} — {c.mobile}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="flex gap-2 items-end">
                <div className="flex-1">
                  <Label>Add product</Label>
                  <Select value={addProd} onValueChange={setAddProd}>
                    <SelectTrigger data-testid="quotation-product-select"><SelectValue placeholder="Select product" /></SelectTrigger>
                    <SelectContent className="max-h-72">{products.map((p) => <SelectItem key={p.id} value={p.id}>{p.name} — ₹{p.selling_price}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
                <Button type="button" variant="outline" onClick={addItem} data-testid="quotation-add-item"><Plus className="h-4 w-4" /></Button>
              </div>
              {form.items.length > 0 && (
                <div className="rounded-lg border divide-y">
                  {form.items.map((it) => { const p = productMap[it.product_id]; if (!p) return null; return (
                    <div key={it.product_id} className="flex items-center gap-2 p-2 text-sm" data-testid={`quotation-item-${it.product_id}`}>
                      {p.image ? <img src={p.image} alt="" data-testid={`quotation-item-image-${it.product_id}`} className="h-8 w-8 rounded object-cover border border-border shrink-0" /> : null}
                      <div className="flex-1 truncate">{p.name}</div>
                      <Input type="number" className="w-16 h-8" value={it.qty} onChange={(e) => setQty(it.product_id, e.target.value)} />
                      <div className="w-20 text-right">₹{(p.selling_price * it.qty).toLocaleString("en-IN")}</div>
                      <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => rmItem(it.product_id)}><Trash2 className="h-3.5 w-3.5 text-destructive" /></Button>
                    </div>); })}
                </div>
              )}
              <div className="grid grid-cols-2 gap-3">
                <div><Label>Discount (₹)</Label><Input type="number" value={form.discount} onChange={(e) => setForm({ ...form, discount: e.target.value })} data-testid="quotation-discount" /></div>
                <div className="flex flex-col justify-end text-sm text-right">
                  <div className="text-muted-foreground">Subtotal ₹{subtotal.toLocaleString("en-IN")} · GST ₹{gst.toFixed(0)}</div>
                  <div className="font-bold text-[#3B5B2A] dark:text-[#8BAA78]">Total ₹{total.toLocaleString("en-IN")}</div>
                </div>
              </div>
              <div><Label>Notes</Label><Textarea rows={2} value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} /></div>
            </div>
            <DialogFooter><Button data-testid="quotation-save-button" disabled={saving || !form.contact_name || form.items.length === 0} onClick={create} className="bg-[#3B5B2A] hover:bg-[#2D4720]">{saving ? <Loader2 className="h-4 w-4 animate-spin" /> : "Save Quotation"}</Button></DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <Card className="overflow-hidden">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader><TableRow><TableHead>Quote No</TableHead><TableHead>Customer</TableHead><TableHead>Items</TableHead><TableHead>Status</TableHead><TableHead className="text-right">Total</TableHead><TableHead className="text-right">Actions</TableHead></TableRow></TableHeader>
            <TableBody>
              {items.map((q) => (
                <TableRow key={q.id} data-testid={`quotation-row-${q.id}`}>
                  <TableCell className="font-mono text-sm">{q.quote_no}</TableCell>
                  <TableCell>{q.contact_name}</TableCell>
                  <TableCell className="text-muted-foreground"><FileText className="h-3.5 w-3.5 inline mr-1" />{(q.items || []).length}</TableCell>
                  <TableCell><StatusBadge status={q.status} /></TableCell>
                  <TableCell className="text-right font-semibold">₹{Number(q.total).toLocaleString("en-IN")}</TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-1">
                      <Button size="sm" variant="outline" onClick={() => sendWa(q.id)} disabled={!q.mobile} data-testid={`quotation-send-${q.id}`}><Send className="h-3.5 w-3.5" /></Button>
                      <Button size="sm" variant="outline" onClick={() => convert(q.id)} disabled={!!q.order_id} data-testid={`quotation-convert-${q.id}`}><ArrowRightLeft className="h-3.5 w-3.5 mr-1" />{q.order_id ? "Converted" : "To Order"}</Button>
                      <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => remove(q.id)}><Trash2 className="h-4 w-4 text-destructive" /></Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
              {items.length === 0 && <TableRow><TableCell colSpan={6} className="text-center py-10 text-muted-foreground">No quotations yet. Create one from your product catalog.</TableCell></TableRow>}
            </TableBody>
          </Table>
        </div>
      </Card>
    </div>
  );
}
