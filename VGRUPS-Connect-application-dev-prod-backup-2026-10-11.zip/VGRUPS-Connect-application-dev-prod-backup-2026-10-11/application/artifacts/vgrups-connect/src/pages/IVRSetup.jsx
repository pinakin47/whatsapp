import React, { useEffect, useState, useCallback } from "react";
import api, { apiError } from "../lib/api";
import { toast } from "sonner";
import { useAuth } from "../context/AuthContext";
import { PageHeader } from "../components/common";
import IVRMenuEditor from "../components/ivr/IVRMenuEditor";
import { Card } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { Textarea } from "../components/ui/textarea";
import { Switch } from "../components/ui/switch";
import { Link } from "react-router-dom";
import { Phone, Loader2, ArrowLeft, Home, HelpCircle, Users } from "lucide-react";

const PROMPTS = {
  catalogue: "Sends the catalogue link or products from live data.",
  category: "Lists products from the configured catalog category.",
  product_search: "Asks the customer to type a product name to search.",
  pricing: "Collects a pricing enquiry without inventing or exposing private prices.",
  order: "Starts the order flow with the customer.",
  order_status: "Asks for an order number and looks up its live status.",
  business: "Collects distributor / business enquiry details.",
  support: "Collects the support request.",
  sales: "Collects the sales enquiry.",
};

const nodeText = (opts, head, footer) => `${head ? head + "\n\n" : ""}${opts.map((o, i) => `${i + 1}. ${o.label || `Option ${i + 1}`}`).join("\n")}\n\n${footer || "Reply with a number."}`;

export default function IVRSetup() {
  const { can } = useAuth();
  const manage = can("ivr", "manage");
  const [ivr, setIvr] = useState(null);
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);
  const [path, setPath] = useState([]);
  const [sim, setSim] = useState([]);

  const load = useCallback(() => {
    setError("");
    api.get("/ivr").then((r) => setIvr(r.data)).catch((e) => setError(apiError(e)));
  }, []);
  useEffect(() => { load(); }, [load]);

  const patch = (p) => setIvr((v) => ({ ...v, ...p }));
  const save = async (next = ivr) => {
    for (const k of ["sales_contact", "support_contact"]) if ((next[k] || "").length > 200) return toast.error("Contact fields allow at most 200 characters");
    setSaving(true);
    try {
      const r = await api.put("/ivr", { ...next, schema_version: 2 });
      setIvr(r.data && r.data.options ? r.data : next); toast.success("IVR saved");
    } catch (e) { toast.error(apiError(e)); load(); } finally { setSaving(false); }
  };
  const toggle = (v) => { const n = { ...ivr, enabled: v }; setIvr(n); save(n); };

  const nodeAt = (p) => p.reduce((opts, i) => (opts[i]?.options || []), ivr.options);
  const showMenu = (p, pre = []) => {
    const opts = nodeAt(p);
    return [...pre, { from: "bot", text: nodeText(opts, p.length === 0 ? ivr.greeting : "", ivr.footer) }];
  };
  const start = () => { setPath([]); setSim(showMenu([])); };
  const press = (cmd) => {
    let p = path; let msgs = [{ from: "user", text: String(cmd) }];
    if (cmd === "0") { setPath([]); return setSim((s) => [...s, ...showMenu([], msgs)]); }
    if (cmd === "back") { p = path.slice(0, -1); setPath(p); return setSim((s) => [...s, ...showMenu(p, [{ from: "user", text: "back" }])]); }
    if (cmd === "help") { msgs = [{ from: "user", text: "help" }, { from: "bot", text: "Reply with a number from the menu, 0 for the main menu, or back to go up." }]; return setSim((s) => [...s, ...msgs]); }
    const i = Number(cmd) - 1; const node = nodeAt(path)[i];
    if (!node) return;
    if (node.options?.length) { p = [...path, i]; setPath(p); return setSim((s) => [...s, ...showMenu(p, [...msgs, ...(node.response ? [{ from: "bot", text: node.response }] : [])])]); }
    const act = node.action || "message";
    const out = [...msgs];
    if (node.response) out.push({ from: "bot", text: node.response });
    if (PROMPTS[act]) out.push({ from: "sys", text: `Action "${act}": ${PROMPTS[act]}` });
    if (node.handoff) out.push({ from: "sys", text: "Handed off to a human agent" });
    setSim((s) => [...s, ...out]);
  };

  if (error) return <div className="p-10 text-center text-sm" data-testid="ivr-error"><p className="text-red-600 mb-3">{error}</p><Button variant="outline" onClick={load}>Retry</Button></div>;
  if (!ivr) return <div className="p-10 text-center"><Loader2 className="h-5 w-5 animate-spin mx-auto" /></div>;
  const current = nodeAt(path);

  return (
    <div className="p-4 md:p-6 animate-fade-up">
      <PageHeader title="WhatsApp IVR Setup" subtitle="Nested WhatsApp menu that replies to customers" testId="ivr-header"
        actions={
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2 text-sm"><span className="text-muted-foreground">Live</span><Switch checked={!!ivr.enabled} disabled={!manage || saving} onCheckedChange={toggle} data-testid="ivr-enabled-toggle" /></div>
            {manage && <Button onClick={() => save()} disabled={saving} className="bg-[#3B5B2A] hover:bg-[#2D4720]" data-testid="ivr-save-button">{saving ? <Loader2 className="h-4 w-4 animate-spin" /> : "Save IVR"}</Button>}
          </div>
        } />
      <div className="mb-4 text-xs rounded-lg bg-blue-50 dark:bg-blue-500/10 text-blue-700 dark:text-blue-300 border border-blue-200 dark:border-blue-500/20 px-3 py-2" data-testid="ivr-info">
        This IVR runs over <b>WhatsApp messages</b> (not phone calls). Customers reply with a number to navigate menus up to {4} levels deep.{!manage && " You have view-only access."}
      </div>
      {can("field_sales", "view") && (
        <Link to="/ivr/mrs" className="block mb-4" data-testid="mr-ivr-link-card">
          <Card className="p-4 flex items-center gap-3 border-[#3B5B2A]/40 bg-[#3B5B2A]/5 hover:bg-[#3B5B2A]/10 transition">
            <Users className="h-6 w-6 text-[#3B5B2A] shrink-0" />
            <div><div className="font-semibold text-sm">MR IVR</div><div className="text-xs text-muted-foreground">Per-MR activity, planned stops vs recorded check-ins, sales, and encouragement messages</div></div>
          </Card>
        </Link>
      )}
      <div className="grid lg:grid-cols-3 gap-6">
        <fieldset disabled={!manage} className="lg:col-span-2 space-y-4 min-w-0">
          <Card className="p-4 space-y-3">
            <div><Label>Greeting message</Label><Textarea rows={2} value={ivr.greeting || ""} onChange={(e) => patch({ greeting: e.target.value })} data-testid="ivr-greeting-input" /></div>
            <div><Label>Footer / prompt</Label><Input value={ivr.footer || ""} onChange={(e) => patch({ footer: e.target.value })} data-testid="ivr-footer-input" /></div>
          </Card>
          <Card className="p-4 space-y-3">
            <div><Label>Catalogue URL (optional)</Label><Input placeholder="https://" value={ivr.catalogue_url || ""} onChange={(e) => patch({ catalogue_url: e.target.value })} data-testid="ivr-catalogue-url" /><p className="text-xs text-muted-foreground mt-1">Leave empty to use the stored catalogue link or products.</p></div>
            <div className="grid sm:grid-cols-2 gap-3">
              <div><Label>Sales contact</Label><Input maxLength={200} value={ivr.sales_contact || ""} onChange={(e) => patch({ sales_contact: e.target.value })} data-testid="ivr-sales-contact" /></div>
              <div><Label>Support contact</Label><Input maxLength={200} value={ivr.support_contact || ""} onChange={(e) => patch({ support_contact: e.target.value })} data-testid="ivr-support-contact" /></div>
            </div>
            <div><Label>WhatsApp template (optional)</Label><Input value={ivr.whatsapp_template || ""} onChange={(e) => patch({ whatsapp_template: e.target.value })} data-testid="ivr-template" /><p className="text-xs text-muted-foreground mt-1">Documents a future Meta Cloud template only. The QR connection does not need an approved template.</p></div>
            <label className="flex items-center gap-2 text-xs text-muted-foreground"><Switch checked={!!ivr.human_handoff} onCheckedChange={(v) => patch({ human_handoff: v })} data-testid="ivr-human-handoff" disabled={!manage} />Automatic human handoff</label>
          </Card>
          <IVRMenuEditor options={ivr.options} onChange={(options) => patch({ options })} />
        </fieldset>

        <div>
          <Card className="p-4 sticky top-20" data-testid="ivr-preview">
            <div className="flex items-center justify-between mb-1"><div className="flex items-center gap-2 font-semibold text-sm"><Phone className="h-4 w-4 text-[#3B5B2A]" />Local menu preview</div><Button size="sm" variant="outline" onClick={start} data-testid="ivr-sim-start">Start</Button></div>
            <p className="text-[11px] text-muted-foreground mb-3">Not a WhatsApp simulation and not the real engine. Shows only your configured menus; dynamic actions show prompts, not live data.</p>
            <div className="rounded-xl bg-[#E5DDD5] dark:bg-[#0B141A] p-3 space-y-2 h-[360px] overflow-y-auto" data-testid="ivr-sim-messages">
              {sim.length === 0 && <div className="text-center text-xs text-muted-foreground py-10">Press Start to preview the menu</div>}
              {sim.map((m, i) => m.from === "sys"
                ? <div key={i} className="text-center"><span className="text-[10px] bg-[#3B5B2A]/10 text-[#3B5B2A] dark:text-[#8BAA78] rounded-md px-2 py-0.5 inline-block">{m.text}</span></div>
                : <div key={i} className={`flex ${m.from === "user" ? "justify-end" : ""}`}><div className={`rounded-lg px-3 py-2 text-sm max-w-[85%] whitespace-pre-line ${m.from === "user" ? "bg-[#DCF8C6] dark:bg-[#005C4B] text-gray-800 dark:text-gray-50" : "bg-white dark:bg-[#202C33] text-gray-800 dark:text-gray-100"}`}>{m.text}</div></div>)}
            </div>
            {sim.length > 0 && (
              <div className="flex flex-wrap gap-1.5 mt-2">
                {current.map((_, i) => <Button key={i} size="sm" variant="outline" className="text-xs" onClick={() => press(String(i + 1))} data-testid={`ivr-sim-pick-${i}`}>{i + 1}</Button>)}
                <Button size="sm" variant="ghost" className="text-xs" onClick={() => press("0")}><Home className="h-3 w-3 mr-1" />0 Main</Button>
                <Button size="sm" variant="ghost" className="text-xs" disabled={!path.length} onClick={() => press("back")}><ArrowLeft className="h-3 w-3 mr-1" />Back</Button>
                <Button size="sm" variant="ghost" className="text-xs" onClick={() => press("help")}><HelpCircle className="h-3 w-3 mr-1" />Help</Button>
              </div>
            )}
          </Card>
        </div>
      </div>
    </div>
  );
}
