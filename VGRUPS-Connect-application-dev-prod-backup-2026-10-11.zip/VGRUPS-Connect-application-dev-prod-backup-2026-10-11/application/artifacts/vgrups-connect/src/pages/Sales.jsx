import React, { useCallback, useEffect, useRef, useState } from "react";
import api, { apiError } from "../lib/api";
import { toast } from "sonner";
import { useAuth } from "../context/AuthContext";
import { PageHeader } from "../components/common";
import { Card } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../components/ui/table";
import { StatusBadge } from "../components/common";
import { Skeleton } from "../components/ui/skeleton";
import ProductChooser from "../components/sales/ProductChooser";
import SaleForm from "../components/sales/SaleForm";
import SaleDetail from "../components/sales/SaleDetail";
import SalesBreakdowns from "../components/sales/SalesBreakdowns";
import { STATUSES, inr, fmtIST, productsText, blobError } from "../components/sales/util";
import { Plus, Search, FileSpreadsheet, FileText, ShieldAlert, ReceiptIndianRupee, ChevronLeft, ChevronRight } from "lucide-react";

const ALL = "all";
const emptyF = { q: "", date_from: "", date_to: "", mr_id: ALL, customer: "", product_id: ALL, status: ALL };

export default function Sales({ profileMrId, embedded = false, canCreateHere = true }) {
  const { user, can } = useAuth();
  const [f, setF] = useState(emptyF);
  const [applied, setApplied] = useState(emptyF);
  const [page, setPage] = useState(1);
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState({ code: 0, msg: "" });
  const [mrLabel, setMrLabel] = useState("");
  const [prodLabel, setProdLabel] = useState("");
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [detailId, setDetailId] = useState(null);
  const [exporting, setExporting] = useState("");
  const seq = useRef(0);
  const pageSize = 20;

  const params = useCallback((a, p) => {
    const o = { page: p, page_size: pageSize };
    if (a.q.trim()) o.q = a.q.trim();
    if (a.date_from) o.date_from = a.date_from;
    if (a.date_to) o.date_to = a.date_to;
    const mr = profileMrId || (a.mr_id !== ALL ? a.mr_id : "");
    if (mr) o.mr_id = mr;
    if (a.customer.trim()) o.customer = a.customer.trim();
    if (a.product_id !== ALL) o.product_id = a.product_id;
    if (a.status !== ALL) o.status = a.status;
    return o;
  }, [profileMrId]);

  // Reset the scope before starting its request, not after invalidating it.
  useEffect(() => {
    seq.current++; setData(null); setLoading(true); setDetailId(null); setFormOpen(false); setEditing(null);
    setF(emptyF); setApplied(emptyF); setPage(1); setMrLabel(""); setProdLabel(""); setErr({ code: 0, msg: "" });
  }, [user?.id, profileMrId]);

  const load = useCallback(() => {
    const my = ++seq.current; if (!seq.silent) setLoading(true);
    api.get("/sales", { params: params(applied, page) })
      .then((r) => { if (my === seq.current) { setData(r.data); setErr({ code: 0, msg: "" }); } })
      .catch((e) => { if (my === seq.current) { const code = e?.response?.status || 0; if (code === 403) setData(null); setErr({ code, msg: apiError(e) }); } })
      .finally(() => { if (my === seq.current) setLoading(false); });
  }, [applied, page, params, user?.id]);
  useEffect(() => { seq.silent = false; load(); }, [load]);
  const loadRef = useRef(load); loadRef.current = load;
  useEffect(() => {
    const tick = () => { if (document.visibilityState === "visible") { seq.silent = true; loadRef.current(); } };
    const t = setInterval(tick, 30000);
    window.addEventListener("focus", tick);
    return () => { clearInterval(t); window.removeEventListener("focus", tick); };
  }, []);

  const isAdmin = !!data?.is_admin;
  const adminView = isAdmin && !profileMrId;
  const apply = (e) => { e?.preventDefault(); setPage(1); setApplied(f); };
  const reset = () => { setF(emptyF); setApplied(emptyF); setPage(1); };
  const doExport = async (format) => {
    setExporting(format);
    try {
      const r = await api.get("/sales/export", { params: { ...params(applied, 1), format, page: undefined, page_size: undefined }, responseType: "blob" });
      const url = URL.createObjectURL(r.data);
      const a = document.createElement("a"); a.href = url; a.download = `sales.${format}`; document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url);
      toast.success("Export ready");
    } catch (e) { toast.error(await blobError(e)); } finally { setExporting(""); }
  };

  if (err.code === 403 && !data) {
    return (
      <div className={embedded ? "" : "p-4 md:p-6"} data-testid="sales-denied">
        <Card className="p-10 text-center"><ShieldAlert className="h-8 w-8 mx-auto mb-3 text-[#D97706]" /><h2 className="font-heading text-lg font-semibold">Sales access is not enabled</h2><p className="text-sm text-muted-foreground mt-1">Your account ({user?.role || "user"}) cannot view sales. Ask an administrator to grant access.</p></Card>
      </div>
    );
  }

  const s = data?.summary || {};
  const items = data?.items || [];
  const total = data?.total || 0;
  const pages = Math.max(1, Math.ceil(total / pageSize));
  const showCreate = !!data && can("sales", "create") && !(embedded && !canCreateHere);
  const cards = [["Today's Sales", inr(s.today_value)], ["This Month's Sales", inr(s.month_value)], ["Total Sales Value", inr(s.total_value)], ["Number of Sales", s.count ?? 0]];
  if (adminView) cards.push(["Active MRs", s.active_mrs ?? 0]);

  const body = (
    <>
      {!embedded && <PageHeader title="Sales" subtitle={adminView ? "All MR sales, filters and exports" : "Record and review your sales"} testId="sales-header"
        actions={showCreate && <Button className="bg-[#3B5B2A] hover:bg-[#2D4720]" onClick={() => { setEditing(null); setFormOpen(true); }} data-testid="new-sale-button"><Plus className="h-4 w-4 mr-1" />New Sale</Button>} />}
      {embedded && showCreate && <div className="flex justify-end mb-3"><Button size="sm" className="bg-[#3B5B2A] hover:bg-[#2D4720]" onClick={() => { setEditing(null); setFormOpen(true); }} data-testid="new-sale-button"><Plus className="h-4 w-4 mr-1" />New Sale</Button></div>}

      {err.msg && <Card className="p-3 mb-3 flex items-center gap-3 text-sm text-destructive" data-testid="sales-error">{err.msg}<Button size="sm" variant="outline" onClick={load}>Retry</Button></Card>}

      <div className={`grid grid-cols-2 ${adminView ? "lg:grid-cols-5" : "lg:grid-cols-4"} gap-3 mb-4`} data-testid="sales-summary">
        {cards.map(([k, v]) => <Card key={k} className="p-4">{!data ? <Skeleton className="h-8 w-24" /> : <div className="text-xl md:text-2xl font-bold font-heading">{v}</div>}<div className="text-xs text-muted-foreground mt-1">{k}</div></Card>)}
      </div>

      <Card className="p-3 mb-4">
        <form onSubmit={apply} className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3 items-end">
          <div className="sm:col-span-2 relative"><Label>Search</Label><Search className="h-4 w-4 absolute left-2.5 top-[34px] text-muted-foreground" /><Input className="pl-8" placeholder="Search customer, phone, sale ID, product..." value={f.q} onChange={(e) => setF({ ...f, q: e.target.value })} data-testid="sales-search" /></div>
          <div><Label>From</Label><Input type="date" value={f.date_from} max={f.date_to || undefined} onChange={(e) => setF({ ...f, date_from: e.target.value })} data-testid="sales-date-from" /></div>
          <div><Label>To</Label><Input type="date" value={f.date_to} min={f.date_from || undefined} onChange={(e) => setF({ ...f, date_to: e.target.value })} data-testid="sales-date-to" /></div>
          {adminView && <div><Label>MR</Label><ProductChooser url="/sales/mrs" paged={false} label={mrLabel} placeholder="All MRs" allLabel="All MRs" ariaLabel="MR filter" testId="sales-mr-filter" onPick={(m) => { setF({ ...f, mr_id: m ? m.id : ALL }); setMrLabel(m ? m.name : ""); }} /></div>}
          <div><Label>Customer</Label><Input value={f.customer} onChange={(e) => setF({ ...f, customer: e.target.value })} data-testid="sales-customer-filter" /></div>
          {adminView && <div><Label>Product</Label><ProductChooser label={prodLabel} placeholder="All products" allLabel="All products" ariaLabel="Product filter" testId="sales-product-filter" onPick={(p) => { setF({ ...f, product_id: p ? p.id : ALL }); setProdLabel(p ? p.name : ""); }} /></div>}
          <div><Label>Status</Label><Select value={f.status} onValueChange={(v) => setF({ ...f, status: v })}><SelectTrigger data-testid="sales-status-filter"><SelectValue /></SelectTrigger><SelectContent><SelectItem value={ALL}>All statuses</SelectItem>{STATUSES.map((x) => <SelectItem key={x} value={x} className="capitalize">{x}</SelectItem>)}</SelectContent></Select></div>
          <div className="flex gap-2 sm:col-span-2 lg:col-span-4 flex-wrap">
            <Button type="submit" className="bg-[#3B5B2A] hover:bg-[#2D4720]" data-testid="sales-apply">Apply</Button>
            <Button type="button" variant="outline" onClick={reset} data-testid="sales-reset">Reset</Button>
            {data?.can_export && !profileMrId && <div className="ml-auto flex gap-2">
              <Button type="button" variant="outline" disabled={!!exporting} onClick={() => doExport("xlsx")} data-testid="sales-export-xlsx"><FileSpreadsheet className="h-4 w-4 mr-1" />{exporting === "xlsx" ? "Exporting..." : "Export Excel"}</Button>
              <Button type="button" variant="outline" disabled={!!exporting} onClick={() => doExport("pdf")} data-testid="sales-export-pdf"><FileText className="h-4 w-4 mr-1" />{exporting === "pdf" ? "Exporting..." : "Export PDF"}</Button>
            </div>}
          </div>
        </form>
      </Card>

      <Card className="overflow-hidden mb-4"><div className="overflow-x-auto"><Table>
        <TableHeader><TableRow><TableHead>Sale ID</TableHead><TableHead>Date &amp; Time</TableHead>{adminView && <TableHead>MR</TableHead>}<TableHead>Customer</TableHead><TableHead>Phone</TableHead><TableHead>Products</TableHead><TableHead className="text-right">Qty</TableHead><TableHead className="text-right">Total</TableHead><TableHead>Status</TableHead><TableHead className="text-right">Actions</TableHead></TableRow></TableHeader>
        <TableBody>
          {loading && !data && [0, 1, 2, 3].map((n) => <TableRow key={n}><TableCell colSpan={10}><Skeleton className="h-6 w-full" /></TableCell></TableRow>)}
          {items.map((r) => (
            <TableRow key={r.id} className="cursor-pointer" onClick={() => setDetailId(r.id)} data-testid={`sale-row-${r.id}`}>
              <TableCell className="font-medium whitespace-nowrap">{r.sale_id}</TableCell>
              <TableCell className="text-sm text-muted-foreground whitespace-nowrap">{fmtIST(r.created_at)}</TableCell>
              {adminView && <TableCell>{r.mr_name}</TableCell>}
              <TableCell>{r.customer_name}</TableCell>
              <TableCell className="whitespace-nowrap">{r.phone}</TableCell>
              <TableCell className="max-w-[220px] truncate text-sm" title={productsText(r)}>{productsText(r)}</TableCell>
              <TableCell className="text-right">{r.quantity}</TableCell>
              <TableCell className="text-right font-semibold whitespace-nowrap">{inr(r.grand_total)}</TableCell>
              <TableCell><StatusBadge status={r.status} /></TableCell>
              <TableCell className="text-right"><Button size="sm" variant="ghost" onClick={(e) => { e.stopPropagation(); setDetailId(r.id); }} data-testid={`sale-view-${r.id}`}>View</Button></TableCell>
            </TableRow>
          ))}
          {data && items.length === 0 && <TableRow><TableCell colSpan={10} className="py-12 text-center text-muted-foreground"><ReceiptIndianRupee className="h-7 w-7 mx-auto mb-2 text-[#3B5B2A]" />{Object.values(applied).some((v) => v && v !== ALL) ? "No sales match these filters." : "No sales recorded yet."}</TableCell></TableRow>}
        </TableBody>
      </Table></div>
      <div className="flex items-center justify-between p-3 border-t text-sm">
        <span className="text-muted-foreground" data-testid="sales-count">{total} sale{total === 1 ? "" : "s"} - page {page} of {pages}</span>
        <div className="flex gap-2"><Button size="sm" variant="outline" disabled={page <= 1 || loading} onClick={() => setPage(page - 1)} data-testid="sales-prev"><ChevronLeft className="h-4 w-4" /></Button><Button size="sm" variant="outline" disabled={page >= pages || loading} onClick={() => setPage(page + 1)} data-testid="sales-next"><ChevronRight className="h-4 w-4" /></Button></div>
      </div></Card>

      {data && <SalesBreakdowns customers={data.customer_sales} products={data.product_sales} truncated={data.breakdowns_truncated} />}

      <SaleForm open={formOpen} sale={editing} onClose={() => setFormOpen(false)} onSaved={() => { setDetailId(null); load(); }} />
      <SaleDetail id={detailId} canEdit={!!data?.can_edit} canDelete={!!data?.can_delete} onClose={() => setDetailId(null)} onChanged={load} onEdit={(sale) => { setEditing(sale); setFormOpen(true); }} />
    </>
  );
  return embedded ? <div data-testid="my-sales">{body}</div> : <div className="p-4 md:p-6 animate-fade-up">{body}</div>;
}
