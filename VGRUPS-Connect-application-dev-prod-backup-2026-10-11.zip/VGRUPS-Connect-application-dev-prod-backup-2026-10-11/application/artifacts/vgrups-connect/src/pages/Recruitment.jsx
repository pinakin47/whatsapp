import React, { useEffect, useState, useCallback } from "react";
import api, { apiError } from "../lib/api";
import { useSenders, SenderSelect, resolveSender, senderIssue } from "../lib/useSenders";
import { toast } from "sonner";
import { PageHeader, StatusBadge } from "../components/common";
import { ShareDialog } from "../components/ShareDialog";
import { Card } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { Textarea } from "../components/ui/textarea";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "../components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogTrigger } from "../components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../components/ui/table";
import { Plus, Loader2, Trash2, Briefcase, MapPin, IndianRupee, HelpCircle, Pencil, Share2, MessageCircle, Send, Download, FileText, Eye, Sparkles } from "lucide-react";

const STAGE_COLOR = { applied: "bg-blue-100 text-blue-700 dark:bg-blue-500/15 dark:text-blue-300", screening: "bg-amber-100 text-amber-700 dark:bg-amber-500/15 dark:text-amber-300", shortlisted: "bg-cyan-100 text-cyan-700 dark:bg-cyan-500/15 dark:text-cyan-300", interview: "bg-purple-100 text-purple-700 dark:bg-purple-500/15 dark:text-purple-300", selected: "bg-green-100 text-green-700 dark:bg-green-500/15 dark:text-green-300", offer: "bg-teal-100 text-teal-700 dark:bg-teal-500/15 dark:text-teal-300", joined: "bg-emerald-100 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300", rejected: "bg-red-100 text-red-700 dark:bg-red-500/15 dark:text-red-300" };
const REC_COLOR = { strong_fit: "bg-green-100 text-green-700 dark:bg-green-500/15 dark:text-green-300", possible_fit: "bg-amber-100 text-amber-700 dark:bg-amber-500/15 dark:text-amber-300", weak_fit: "bg-red-100 text-red-700 dark:bg-red-500/15 dark:text-red-300" };
const scoreColor = (s) => s >= 75 ? "text-green-600 dark:text-green-400" : s >= 50 ? "text-amber-600 dark:text-amber-400" : "text-red-600 dark:text-red-400";
const emptyPos = { title: "", department: "General", type: "Full-time", location: "", salary_min: 0, salary_max: 0, summary: "", requirements: [], qa: [], status: "open" };
const ORIGIN = window.location.origin;

export default function Recruitment() {
  const senders = useSenders();
  const [senderPick, setSenderPick] = useState("");
  const senderId = resolveSender(senders, senderPick);
  const [positions, setPositions] = useState([]);
  const [candidates, setCandidates] = useState([]);
  const [stages, setStages] = useState(["applied", "screening", "interview", "hired", "rejected"]);
  const [open, setOpen] = useState(false);
  const [editId, setEditId] = useState(null);
  const [form, setForm] = useState(emptyPos);
  const [reqText, setReqText] = useState("");
  const [saving, setSaving] = useState(false);
  const [share, setShare] = useState(null); // {url, title, message}
  const [msgCand, setMsgCand] = useState(null);
  const [msgText, setMsgText] = useState("");
  const [sending, setSending] = useState(false);
  const [iDate, setIDate] = useState("");
  const [iTime, setITime] = useState("");
  const [iMode, setIMode] = useState("");
  const [waNumber, setWaNumber] = useState("");
  const [viewCand, setViewCand] = useState(null);
  const [scoringId, setScoringId] = useState(null);

  const load = useCallback(() => {
    api.get("/recruitment/positions").then((r) => { setPositions(r.data.items); setStages(r.data.stages); });
    api.get("/recruitment/candidates").then((r) => setCandidates(r.data.items));
    api.get("/wa/sessions").then((r) => {
      const s = (r.data.sessions || []).find((x) => x.status === "connected" && x.phone);
      if (s) setWaNumber(s.phone);
    }).catch(() => {});
  }, []);
  useEffect(() => { load(); }, [load]);

  const openNew = () => { setEditId(null); setForm(emptyPos); setReqText(""); setOpen(true); };
  const openEdit = (p) => { setEditId(p.id); setForm({ ...emptyPos, ...p }); setReqText((p.requirements || []).join("\n")); setOpen(true); };
  const addQA = () => setForm((f) => ({ ...f, qa: [...f.qa, { q: "", a: "" }] }));
  const setQA = (i, k, v) => setForm((f) => ({ ...f, qa: f.qa.map((x, j) => j === i ? { ...x, [k]: v } : x) }));
  const rmQA = (i) => setForm((f) => ({ ...f, qa: f.qa.filter((_, j) => j !== i) }));

  const save = async () => {
    setSaving(true);
    const payload = { ...form, salary_min: Number(form.salary_min) || 0, salary_max: Number(form.salary_max) || 0, requirements: reqText.split("\n").map((s) => s.trim()).filter(Boolean), qa: form.qa.filter((x) => x.q) };
    try {
      if (editId) await api.put(`/recruitment/positions/${editId}`, payload);
      else await api.post("/recruitment/positions", payload);
      toast.success(editId ? "Position updated" : "Position created"); setOpen(false); load();
    } catch (e) { toast.error(apiError(e)); } finally { setSaving(false); }
  };
  const delPos = async (id) => { try { await api.delete(`/recruitment/positions/${id}`); load(); } catch (e) { toast.error(apiError(e)); } };
  const setStage = async (id, stage) => { try { await api.patch(`/recruitment/candidates/${id}`, { stage }); setCandidates((c) => c.map((x) => x.id === id ? { ...x, stage } : x)); } catch (e) { toast.error(apiError(e)); } };
  const delCand = async (id) => { try { await api.delete(`/recruitment/candidates/${id}`); load(); } catch (e) { toast.error(apiError(e)); } };

  const sharePosition = (p) => setShare({ url: `${ORIGIN}/careers?position=${p.id}`, title: `Share: ${p.title}`, message: `We're hiring a ${p.title} at VGRUPS Healthcare. Apply here:` });
  const shareCareers = () => setShare({ url: `${ORIGIN}/careers`, title: "Share Careers Page", message: "VGRUPS Healthcare is hiring! Explore open roles:" });
  const waApply = (p) => {
    if (!waNumber) { toast.error("Link your WhatsApp number first (WhatsApp → Connections)"); return; }
    const code = p.code ? `APPLY ${p.code}` : "APPLY";
    window.open(`https://wa.me/${waNumber.replace(/\D/g, "")}?text=${encodeURIComponent(code)}`, "_blank");
  };
  const downloadResume = async (c) => {
    try {
      const r = await api.get(`/recruitment/candidates/${c.id}/resume`, { responseType: "blob" });
      const url = URL.createObjectURL(r.data);
      window.open(url, "_blank");
      setTimeout(() => URL.revokeObjectURL(url), 60000);
    } catch (e) { toast.error("Could not open resume"); }
  };
  const scoreCand = async (c) => {
    setScoringId(c.id);
    try {
      const r = await api.post(`/recruitment/candidates/${c.id}/score`);
      setCandidates((list) => list.map((x) => x.id === c.id ? { ...x, ai_score: r.data.score, ai_recommendation: r.data.recommendation, ai_summary: r.data.summary, ai_strengths: r.data.strengths, ai_concerns: r.data.concerns } : x));
      setViewCand((v) => v && v.id === c.id ? { ...v, ai_score: r.data.score, ai_recommendation: r.data.recommendation, ai_summary: r.data.summary, ai_strengths: r.data.strengths, ai_concerns: r.data.concerns } : v);
      toast.success(`AI score: ${r.data.score}/100`);
    } catch (e) { toast.error(apiError(e)); } finally { setScoringId(null); }
  };

  const PRESETS = (c) => ({
    "Under Review": `🔄 VGRUPS Healthcare — Application Update\n\nDear ${c.name}, your application for ${c.position_title} (${c.application_id || ""}) is currently under review. We'll contact you if it proceeds to the next stage.`,
    Shortlisted: `🎉 Dear ${c.name}, your application for ${c.position_title} has been shortlisted!${iDate ? `\n\n📅 Interview: ${iDate} ${iTime} (${iMode || "Office"})` : " We'll share interview details shortly."}`,
    "Interview Confirmed": `✅ Interview Confirmed\n\nDear ${c.name}, your interview for ${c.position_title} is confirmed.\n📅 ${iDate || "[date]"}  🕐 ${iTime || "[time]"}\n📍 ${iMode || "Office"}\n\nPlease arrive 10–15 minutes early. — VGRUPS Healthcare HR`,
    "App Submitted": `🎉 Application received for ${c.position_title}. Your Application ID is ${c.application_id || "—"}. Our HR team will review and update you.`,
    "Not selected": `Dear ${c.name}, thank you for applying for ${c.position_title}. We've decided to proceed with other candidates this time, but we'll keep your profile for future openings.`,
  });
  const openMsg = (c) => { setMsgCand(c); setIDate(""); setITime(""); setIMode(""); setMsgText(PRESETS(c)["Under Review"]); };
  const sendMsg = async () => {
    if (senderIssue(senders, senderId)) { toast.error(senderIssue(senders, senderId)); return; }
    setSending(true);
    try {
      const r = await api.post(`/recruitment/candidates/${msgCand.id}/whatsapp`, { message: msgText, interview_date: iDate || null, interview_time: iTime || null, interview_mode: iMode || null, session_id: senderId });
      if (r.data.sent) toast.success("Message sent on WhatsApp");
      else if (r.data.wa_link) { window.open(r.data.wa_link, "_blank"); toast.info("WhatsApp not connected — opening WhatsApp to send"); }
      setMsgCand(null); load();
    } catch (e) { toast.error(apiError(e)); } finally { setSending(false); }
  };

  return (
    <div className="p-4 md:p-6 animate-fade-up">
      <PageHeader title="Recruitment" subtitle="Open positions, screening Q&A and the candidate pipeline" testId="recruitment-header"
        actions={<Button variant="outline" onClick={shareCareers} data-testid="share-careers-button"><Share2 className="h-4 w-4 mr-1.5" /> Share Careers / QR</Button>} />

      <Tabs defaultValue="positions">
        <TabsList>
          <TabsTrigger value="positions" data-testid="recruitment-tab-positions">Positions ({positions.length})</TabsTrigger>
          <TabsTrigger value="candidates" data-testid="recruitment-tab-candidates">Candidates ({candidates.length})</TabsTrigger>
        </TabsList>

        <TabsContent value="positions" className="mt-4">
          <div className="flex justify-end mb-3">
            <Dialog open={open} onOpenChange={setOpen}>
              <DialogTrigger asChild><Button onClick={openNew} className="bg-[#3B5B2A] hover:bg-[#2D4720]" data-testid="new-position-button"><Plus className="h-4 w-4 mr-1" /> New Position</Button></DialogTrigger>
              <DialogContent className="max-w-xl max-h-[90vh] overflow-y-auto">
                <DialogHeader><DialogTitle>{editId ? "Edit" : "New"} Position</DialogTitle><DialogDescription>Define the role and its screening Q&A.</DialogDescription></DialogHeader>
                <div className="space-y-3">
                  <div><Label>Title *</Label><Input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} data-testid="position-title-input" /></div>
                  <div className="grid grid-cols-2 gap-3">
                    <div><Label>Department</Label><Input value={form.department} onChange={(e) => setForm({ ...form, department: e.target.value })} /></div>
                    <div><Label>Type</Label><Input value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })} /></div>
                  </div>
                  <div className="grid grid-cols-3 gap-3">
                    <div><Label>Location</Label><Input value={form.location} onChange={(e) => setForm({ ...form, location: e.target.value })} /></div>
                    <div><Label>Salary min</Label><Input type="number" value={form.salary_min} onChange={(e) => setForm({ ...form, salary_min: e.target.value })} /></div>
                    <div><Label>Salary max</Label><Input type="number" value={form.salary_max} onChange={(e) => setForm({ ...form, salary_max: e.target.value })} /></div>
                  </div>
                  <div><Label>Summary</Label><Textarea rows={2} value={form.summary} onChange={(e) => setForm({ ...form, summary: e.target.value })} /></div>
                  <div><Label>Requirements (one per line)</Label><Textarea rows={3} value={reqText} onChange={(e) => setReqText(e.target.value)} /></div>
                  <div>
                    <div className="flex items-center justify-between"><Label>Screening Q&A (auto-answers)</Label><Button type="button" size="sm" variant="outline" onClick={addQA} data-testid="position-add-qa"><Plus className="h-3.5 w-3.5 mr-1" /> Add</Button></div>
                    <div className="space-y-2 mt-2">
                      {form.qa.map((x, i) => (
                        <div key={i} className="rounded-lg border p-2 space-y-1" data-testid={`position-qa-${i}`}>
                          <Input placeholder="Question" value={x.q} onChange={(e) => setQA(i, "q", e.target.value)} />
                          <div className="flex gap-2"><Textarea rows={2} placeholder="Auto-answer" value={x.a} onChange={(e) => setQA(i, "a", e.target.value)} /><Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => rmQA(i)}><Trash2 className="h-3.5 w-3.5 text-destructive" /></Button></div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
                <DialogFooter><Button disabled={saving || !form.title} onClick={save} className="bg-[#3B5B2A] hover:bg-[#2D4720]" data-testid="position-save-button">{saving ? <Loader2 className="h-4 w-4 animate-spin" /> : "Save"}</Button></DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
            {positions.map((p) => (
              <Card key={p.id} className="p-5" data-testid={`position-card-${p.id}`}>
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-2"><div className="h-9 w-9 rounded-lg bg-[#F0F4EE] dark:bg-[#1D2B1E] flex items-center justify-center"><Briefcase className="h-4 w-4 text-[#3B5B2A]" /></div><div><div className="font-semibold">{p.title}</div><div className="text-xs text-muted-foreground">{p.department} · {p.type}</div></div></div>
                  <StatusBadge status={p.status} />
                </div>
                <p className="text-sm text-muted-foreground mt-3 line-clamp-2">{p.summary}</p>
                <div className="flex flex-wrap gap-3 mt-3 text-xs text-muted-foreground">
                  {p.location && <span className="inline-flex items-center gap-1"><MapPin className="h-3.5 w-3.5" />{p.location}</span>}
                  {(p.salary_min || p.salary_max) ? <span className="inline-flex items-center gap-1"><IndianRupee className="h-3.5 w-3.5" />{p.salary_min?.toLocaleString("en-IN")} – {p.salary_max?.toLocaleString("en-IN")}</span> : null}
                  <span className="inline-flex items-center gap-1"><HelpCircle className="h-3.5 w-3.5" />{(p.qa || []).length} Q&A</span>
                </div>
                <div className="flex gap-2 mt-4">
                  <Button size="sm" variant="outline" className="flex-1" onClick={() => sharePosition(p)} data-testid={`position-share-${p.id}`}><Share2 className="h-3.5 w-3.5 mr-1" /> Apply link</Button>
                  <Button size="sm" variant="outline" onClick={() => waApply(p)} data-testid={`position-wa-apply-${p.id}`}><MessageCircle className="h-3.5 w-3.5 text-[#25D366]" /></Button>
                  <Button size="sm" variant="outline" onClick={() => openEdit(p)} data-testid={`position-edit-${p.id}`}><Pencil className="h-3.5 w-3.5" /></Button>
                  <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => delPos(p.id)} data-testid={`position-delete-${p.id}`}><Trash2 className="h-4 w-4 text-destructive" /></Button>
                </div>
              </Card>
            ))}
            {positions.length === 0 && <div className="col-span-full text-center py-10 text-muted-foreground">No positions yet.</div>}
          </div>
        </TabsContent>

        <TabsContent value="candidates" className="mt-4">
          <Card className="overflow-hidden">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader><TableRow><TableHead>Candidate</TableHead><TableHead>App ID</TableHead><TableHead>Position</TableHead><TableHead>AI Fit</TableHead><TableHead>Mobile</TableHead><TableHead>Source</TableHead><TableHead>Stage</TableHead><TableHead className="text-right">Actions</TableHead></TableRow></TableHeader>
                <TableBody>
                  {candidates.map((c) => (
                    <TableRow key={c.id} data-testid={`candidate-row-${c.id}`}>
                      <TableCell className="font-medium">{c.name}</TableCell>
                      <TableCell className="font-mono text-xs text-muted-foreground">{c.application_id || "—"}</TableCell>
                      <TableCell>{c.position_title}</TableCell>
                      <TableCell>
                        {typeof c.ai_score === "number" ? (
                          <button onClick={() => setViewCand(c)} className={`font-semibold text-sm ${scoreColor(c.ai_score)}`} data-testid={`candidate-aiscore-${c.id}`}>{c.ai_score}<span className="text-muted-foreground font-normal">/100</span></button>
                        ) : (
                          <Button size="sm" variant="ghost" className="h-7 px-2 text-xs text-[#3B5B2A]" onClick={() => scoreCand(c)} disabled={scoringId === c.id} data-testid={`candidate-score-${c.id}`}>{scoringId === c.id ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <><Sparkles className="h-3.5 w-3.5 mr-1" /> Score</>}</Button>
                        )}
                      </TableCell>
                      <TableCell className="text-muted-foreground">{c.mobile}</TableCell>
                      <TableCell className="text-muted-foreground text-xs">{c.source}</TableCell>
                      <TableCell>
                        <Select value={c.stage} onValueChange={(v) => setStage(c.id, v)}>
                          <SelectTrigger className={`h-8 w-32 border-0 text-xs font-medium ${STAGE_COLOR[c.stage] || ""}`} data-testid={`candidate-stage-${c.id}`}><SelectValue /></SelectTrigger>
                          <SelectContent>{stages.map((s) => <SelectItem key={s} value={s} className="capitalize">{s}</SelectItem>)}</SelectContent>
                        </Select>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-1">
                          {c.resume_url && <Button size="sm" variant="outline" onClick={() => downloadResume(c)} data-testid={`candidate-resume-${c.id}`}><FileText className="h-3.5 w-3.5 mr-1 text-[#3B5B2A]" /> Resume</Button>}
                          <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => setViewCand(c)} data-testid={`candidate-view-${c.id}`}><Eye className="h-4 w-4" /></Button>
                          <Button size="sm" variant="outline" onClick={() => openMsg(c)} disabled={!c.mobile} data-testid={`candidate-whatsapp-${c.id}`}><MessageCircle className="h-3.5 w-3.5 mr-1 text-[#25D366]" /> WhatsApp</Button>
                          <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => delCand(c.id)} data-testid={`candidate-delete-${c.id}`}><Trash2 className="h-4 w-4 text-destructive" /></Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                  {candidates.length === 0 && <TableRow><TableCell colSpan={8} className="text-center py-10 text-muted-foreground">No applicants yet. Share your public careers page to collect applications.</TableCell></TableRow>}
                </TableBody>
              </Table>
            </div>
          </Card>
        </TabsContent>
      </Tabs>

      {share && <ShareDialog open={!!share} onOpenChange={(v) => !v && setShare(null)} url={share.url} title={share.title} message={share.message} />}

      <Dialog open={!!msgCand} onOpenChange={(v) => !v && setMsgCand(null)}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>Message {msgCand?.name}</DialogTitle><DialogDescription>Send a WhatsApp message directly from the pipeline.</DialogDescription></DialogHeader>
          {msgCand && (
            <div className="space-y-3">
              <div className="flex flex-wrap gap-1.5">
                {Object.keys(PRESETS(msgCand)).map((k) => <Button key={k} size="sm" variant="outline" className="text-xs" onClick={() => setMsgText(PRESETS(msgCand)[k])} data-testid={`candidate-preset-${k.replace(/\s/g, "-").toLowerCase()}`}>{k}</Button>)}
              </div>
              <div className="grid grid-cols-3 gap-2">
                <Input type="date" value={iDate} onChange={(e) => setIDate(e.target.value)} data-testid="candidate-interview-date" />
                <Input type="time" value={iTime} onChange={(e) => setITime(e.target.value)} data-testid="candidate-interview-time" />
                <Select value={iMode} onValueChange={setIMode}>
                  <SelectTrigger data-testid="candidate-interview-mode"><SelectValue placeholder="Mode" /></SelectTrigger>
                  <SelectContent><SelectItem value="Office">Office</SelectItem><SelectItem value="Online">Online</SelectItem><SelectItem value="Phone">Phone</SelectItem></SelectContent>
                </Select>
              </div>
              <SenderSelect senders={senders} value={senderPick} onChange={setSenderPick} disabled={sending} testId="candidate-sender" />
              <Textarea rows={5} value={msgText} onChange={(e) => setMsgText(e.target.value)} data-testid="candidate-message-input" />
            </div>
          )}
          <DialogFooter><Button disabled={sending || !msgText.trim()} onClick={sendMsg} className="bg-[#25D366] hover:bg-[#1da851] text-white" data-testid="candidate-message-send">{sending ? <Loader2 className="h-4 w-4 animate-spin" /> : <><Send className="h-4 w-4 mr-1.5" /> Send</>}</Button></DialogFooter>
        </DialogContent>
      </Dialog>
      <Dialog open={!!viewCand} onOpenChange={(v) => !v && setViewCand(null)}>
        <DialogContent className="max-w-lg max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{[viewCand?.name, viewCand?.position_title].filter(Boolean).join(" · ")}</DialogTitle>
            <DialogDescription>{[viewCand?.application_id, viewCand?.mobile, viewCand?.source && `via ${viewCand.source}`].filter(Boolean).join(" · ")}</DialogDescription>
          </DialogHeader>
          {viewCand && (
            <div className="space-y-3">
              <div className="rounded-lg border p-3 bg-[#F7FAF5] dark:bg-[#141f14]" data-testid="candidate-ai-panel">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-sm font-semibold"><Sparkles className="h-4 w-4 text-[#3B5B2A]" /> AI Screening</div>
                  <Button size="sm" variant="outline" className="h-7 text-xs" onClick={() => scoreCand(viewCand)} disabled={scoringId === viewCand.id} data-testid="candidate-detail-score">
                    {scoringId === viewCand.id ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : (typeof viewCand.ai_score === "number" ? "Re-score" : "Run AI score")}
                  </Button>
                </div>
                {typeof viewCand.ai_score === "number" ? (
                  <div className="mt-2 space-y-2">
                    <div className="flex items-center gap-2">
                      <span className={`text-2xl font-bold ${scoreColor(viewCand.ai_score)}`}>{viewCand.ai_score}<span className="text-sm text-muted-foreground font-normal">/100</span></span>
                      {viewCand.ai_recommendation && <span className={`text-xs px-2 py-0.5 rounded-full font-medium capitalize ${REC_COLOR[viewCand.ai_recommendation] || ""}`}>{viewCand.ai_recommendation.replace(/_/g, " ")}</span>}
                    </div>
                    {viewCand.ai_summary && <p className="text-sm">{viewCand.ai_summary}</p>}
                    {(viewCand.ai_strengths || []).length > 0 && <div className="text-sm"><span className="font-medium text-green-600 dark:text-green-400">Strengths:</span><ul className="list-disc list-inside text-muted-foreground">{viewCand.ai_strengths.map((s, i) => <li key={i}>{s}</li>)}</ul></div>}
                    {(viewCand.ai_concerns || []).length > 0 && <div className="text-sm"><span className="font-medium text-amber-600 dark:text-amber-400">Concerns:</span><ul className="list-disc list-inside text-muted-foreground">{viewCand.ai_concerns.map((s, i) => <li key={i}>{s}</li>)}</ul></div>}
                  </div>
                ) : (
                  <p className="text-xs text-muted-foreground mt-1">Not scored yet. Scores run automatically when a candidate finishes a WhatsApp application, or click the button above.</p>
                )}
              </div>
              {viewCand.resume_url && (
                <Button variant="outline" className="w-full" onClick={() => downloadResume(viewCand)} data-testid="candidate-detail-resume">
                  <Download className="h-4 w-4 mr-1.5" /> Open resume{viewCand.resume_filename ? ` (${viewCand.resume_filename})` : ""}
                </Button>
              )}
              {Array.isArray(viewCand.answers) && viewCand.answers.length > 0 ? (
                <div className="space-y-2" data-testid="candidate-detail-answers">
                  <div className="text-sm font-semibold">Screening answers</div>
                  {viewCand.answers.map((a, i) => (
                    <div key={i} className="rounded-lg border p-2.5 text-sm">
                      <div className="text-muted-foreground text-xs">{a.q}</div>
                      <div className="font-medium">{a.a || "—"}</div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-muted-foreground">No screening answers captured yet. Answers are collected automatically when the candidate completes the WhatsApp application.</p>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
