import React from "react";
import { PageHeader } from "../components/common";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "../components/ui/tabs";
import Campaigns from "./Campaigns";
import Drips from "./Drips";

export default function CampaignsHub() {
  return (
    <div className="p-4 md:p-6 animate-fade-up">
      <PageHeader title="Campaigns" subtitle="One-time broadcasts and multi-day drip sequences" testId="campaigns-hub-header" />
      <Tabs defaultValue="broadcasts">
        <TabsList>
          <TabsTrigger value="broadcasts" data-testid="camp-tab-broadcasts">Broadcasts</TabsTrigger>
          <TabsTrigger value="drips" data-testid="camp-tab-drips">Drip Sequences</TabsTrigger>
        </TabsList>
        <TabsContent value="broadcasts" className="mt-4"><Campaigns embedded /></TabsContent>
        <TabsContent value="drips" className="mt-4"><Drips /></TabsContent>
      </Tabs>
    </div>
  );
}
