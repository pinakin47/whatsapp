import React, { useEffect, useState, useCallback } from "react";
import api, { apiError, API } from "../lib/api";
import { toast } from "sonner";
import { PageHeader } from "../components/common";
import { Card } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "../components/ui/tabs";
import { Chrome, Download, Copy, Globe, MousePointerClick, Smartphone, CheckCircle2 } from "lucide-react";

const STEPS = [
  "Download & unzip the extension below.",
  "Open Chrome and go to chrome://extensions",
  "Turn on Developer mode (top-right).",
  "Click \"Load unpacked\" and select the unzipped folder.",
  "Open the VGRUPS icon, set your backend URL and log in.",
];

export default function ExtensionWidget() {
  const [stats, setStats] = useState({ total_clicks: 0, by_source: [], number: "" });
  const [source, setSource] = useState("website");
  const [downloading, setDownloading] = useState(false);

  const load = useCallback(() => {
    api.get("/widget/stats").then((r) => setStats(r.data)).catch(() => {});
  }, []);
  useEffect(() => { load(); }, [load]);

  const snippet = `<script src="${API}/widget.js?source=${encodeURIComponent(source || "website")}" async></script>`;

  const copy = (text) => { navigator.clipboard.writeText(text); toast.success("Copied to clipboard"); };

  const download = async () => {
    setDownloading(true);
    try {
      const r = await api.get("/ext/download", { responseType: "blob" });
      const url = URL.createObjectURL(r.data);
      const a = document.createElement("a");
      a.href = url; a.download = "vgrups-crm-extension.zip"; a.click();
      setTimeout(() => URL.revokeObjectURL(url), 30000);
      toast.success("Extension downloaded");
    } catch (e) { toast.error(apiError(e)); } finally { setDownloading(false); }
  };

  return (
    <div className="p-4 md:p-6 animate-fade-up">
      <PageHeader title="Extension & Widget" subtitle="Chrome CRM extension and your website WhatsApp button" testId="extension-header" />

      <Tabs defaultValue="extension">
        <TabsList>
          <TabsTrigger value="extension" data-testid="ext-tab-extension"><Chrome className="h-4 w-4 mr-1.5" /> Chrome Extension</TabsTrigger>
          <TabsTrigger value="widget" data-testid="ext-tab-widget"><Globe className="h-4 w-4 mr-1.5" /> Website Widget</TabsTrigger>
        </TabsList>

        <TabsContent value="extension" className="mt-4">
          <div className="grid lg:grid-cols-3 gap-4">
            <Card className="p-5 lg:col-span-2">
              <div className="flex items-center gap-2 font-semibold"><Chrome className="h-5 w-5 text-[#3B5B2A]" /> VGRUPS CRM Connect</div>
              <p className="text-sm text-muted-foreground mt-2">Highlights phone numbers on any webpage. Click one to see the CRM match, open WhatsApp, or add a new lead — without leaving the page.</p>
              <ol className="mt-4 space-y-2">
                {STEPS.map((s, i) => (
                  <li key={i} className="flex items-start gap-2 text-sm" data-testid={`ext-step-${i}`}>
                    <span className="h-5 w-5 shrink-0 rounded-full bg-[#3B5B2A] text-white text-xs flex items-center justify-center">{i + 1}</span>
                    <span>{s}</span>
                  </li>
                ))}
              </ol>
              <Button onClick={download} disabled={downloading} className="mt-5 bg-[#3B5B2A] hover:bg-[#2D4720]" data-testid="ext-download-button">
                <Download className="h-4 w-4 mr-1.5" /> {downloading ? "Preparing…" : "Download extension (.zip)"}
              </Button>
            </Card>
            <Card className="p-5">
              <div className="text-sm font-semibold mb-3">What it does</div>
              {[["Detect numbers", MousePointerClick], ["One-click WhatsApp", Smartphone], ["Instant CRM lookup", CheckCircle2]].map(([t, Icon], i) => (
                <div key={i} className="flex items-center gap-2 text-sm py-2 border-b last:border-0">
                  <Icon className="h-4 w-4 text-[#3B5B2A]" /> {t}
                </div>
              ))}
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="widget" className="mt-4">
          <div className="grid lg:grid-cols-3 gap-4">
            <Card className="p-5 lg:col-span-2">
              <div className="flex items-center gap-2 font-semibold"><Globe className="h-5 w-5 text-[#3B5B2A]" /> Website WhatsApp button</div>
              <p className="text-sm text-muted-foreground mt-2">Paste this snippet before <code>&lt;/body&gt;</code> on vgrups.in to add a floating "Chat on WhatsApp" button. Clicks are tracked by source/UTM.</p>
              {!stats.number && <div className="mt-3 text-sm rounded-lg bg-amber-50 dark:bg-amber-500/10 text-amber-700 dark:text-amber-300 p-3" data-testid="widget-no-number">Link a WhatsApp number first (WhatsApp → Connections) so the widget knows where to send chats.</div>}
              <div className="mt-4">
                <Label>Tracking source / campaign</Label>
                <Input value={source} onChange={(e) => setSource(e.target.value)} data-testid="widget-source-input" className="max-w-xs" />
              </div>
              <div className="mt-3">
                <Label>Embed snippet</Label>
                <div className="relative mt-1">
                  <pre className="bg-muted rounded-lg p-3 text-xs overflow-x-auto" data-testid="widget-snippet">{snippet}</pre>
                  <Button size="sm" variant="outline" className="absolute top-2 right-2" onClick={() => copy(snippet)} data-testid="widget-copy-button"><Copy className="h-3.5 w-3.5 mr-1" /> Copy</Button>
                </div>
              </div>
            </Card>
            <Card className="p-5">
              <div className="text-sm font-semibold">Click tracking</div>
              <div className="text-3xl font-bold text-[#3B5B2A] mt-2" data-testid="widget-total-clicks">{stats.total_clicks}</div>
              <div className="text-xs text-muted-foreground">total widget clicks</div>
              <div className="mt-4 space-y-1.5">
                {(stats.by_source || []).map((s, i) => (
                  <div key={i} className="flex justify-between text-sm" data-testid={`widget-source-row-${i}`}>
                    <span className="text-muted-foreground">{s.source}</span><span className="font-medium">{s.count}</span>
                  </div>
                ))}
                {(stats.by_source || []).length === 0 && <div className="text-xs text-muted-foreground">No clicks yet.</div>}
              </div>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
