import React, { useCallback, useEffect, useState } from "react";
import { Link } from "react-router-dom";
import api, { apiError } from "../lib/api";
import { PageHeader } from "../components/common";
import { Card } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Loader2, ArrowLeft } from "lucide-react";

export default function MRIVRHub() {
  const [items, setItems] = useState(null);
  const [err, setErr] = useState("");
  const load = useCallback(() => { setErr(""); api.get("/mr-ivr/mrs").then((r) => setItems(r.data.items || [])).catch((e) => setErr(apiError(e))); }, []);
  useEffect(() => { load(); }, [load]);
  return (
    <div className="p-4 md:p-6 animate-fade-up" data-testid="mr-ivr-hub">
      <PageHeader title="MR IVR" subtitle="Private WhatsApp reporting, encouragement and activity for each MR" actions={<Link to="/ivr" className="text-sm inline-flex items-center gap-1 text-muted-foreground"><ArrowLeft className="h-4 w-4" />Customer IVR</Link>} />
      <p className="text-xs text-muted-foreground mb-4">MRs come from the Settings MRs directory. Add or edit MRs in Settings.</p>
      {err ? <div className="p-10 text-center text-sm" data-testid="mr-ivr-hub-error"><p className="text-red-600 mb-3">{err}</p><Button variant="outline" onClick={load}>Retry</Button></div>
        : !items ? <div className="p-10 text-center"><Loader2 className="h-5 w-5 animate-spin mx-auto" /></div>
        : items.length === 0 ? <Card className="p-10 text-center text-sm text-muted-foreground" data-testid="mr-ivr-hub-empty">No MRs yet. Add them under Settings, MRs.</Card>
        : <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">{items.map((m) => (
          <Link key={m.id} to={`/ivr/mrs/${m.id}`} data-testid={`mr-ivr-card-${m.id}`}>
            <Card className={`p-4 hover:border-[#3B5B2A] transition ${m.active === false ? "opacity-70" : ""}`}>
              <div className="flex items-start justify-between gap-2"><div className="font-medium truncate">{m.name}</div>
                <span className={`text-[10px] px-2 py-0.5 rounded-full shrink-0 ${m.active === false ? "bg-red-100 text-red-700" : "bg-[#3B5B2A]/10 text-[#3B5B2A]"}`}>{m.active === false ? "Inactive" : "Active"}</span></div>
              <div className="text-xs text-muted-foreground mt-1">{m.employee_id || "No employee ID"}</div>
              <div className="text-xs text-muted-foreground truncate">{m.phone || "No phone"}{m.email ? ` - ${m.email}` : ""}</div>
              <div className="text-[11px] mt-2">{m.profile?.enabled ? "Scheduled messages on" : "Scheduled messages off"}</div>
              {m.profile?.field_flow_enabled && <div className="text-[11px] mt-1" data-testid={`mr-ivr-field-${m.id}`}>Field flow on{m.field_day ? ` - day ${m.field_day.status || "started"}${m.field_day.midday_status ? `, midday ${String(m.field_day.midday_status).replace(/_/g, " ")}` : ""}${m.field_day.closing_status ? `, closing ${String(m.field_day.closing_status).replace(/_/g, " ")}` : ""}` : " - no day started"}</div>}
            </Card>
          </Link>))}</div>}
    </div>
  );
}
