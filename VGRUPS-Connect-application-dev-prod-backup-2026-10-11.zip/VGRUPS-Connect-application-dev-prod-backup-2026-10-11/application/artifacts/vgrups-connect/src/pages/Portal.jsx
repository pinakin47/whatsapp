import React, { useEffect, useState } from "react";
import api, { apiError } from "../lib/api";
import { toast } from "sonner";
import { PageHeader } from "../components/common";
import { Card } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { Textarea } from "../components/ui/textarea";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "../components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogTrigger } from "../components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../components/ui/table";
import { IndianRupee, CheckCircle2, Clock, FileText, Download, Plus, Trash2, Package, Loader2 } from "lucide-react";

const PAY_COLOR = { paid: "bg-green-100 text-green-700 dark:bg-green-500/15 dark:text-green-300", pending: "bg-amber-100 text-amber-700 dark:bg-amber-500/15 dark:text-amber-300" };
const SR_COLOR = { pending: "bg-amber-100 text-amber-700 dark:bg-amber-500/15 dark:text-amber-300", approved: "bg-green-100 text-green-700 dark:bg-green-500/15 dark:text-green-300", rejected: "bg-red-100 text-red-700 dark:bg-red-500/15 dark:text-red-300" };

export default function Portal() {
  const [data, setData] = useState({ orders: [], ledger: { billed: 0, paid: 0, outstanding: 0, order_count: 0 }, preview_all: false });
  const [reqs, setReqs] = useState([]);
  const [srOpen, setSrOpen] = useState(false);
  const [srItems, setSrItems] = useState([{ name: "", qty: 1 }]);
  const [srNotes, setSrNotes] = useState("");
  const [saving, setSaving] = useState(false);

  const load = () => {
    api.get("/portal/summary").then((r) => setData(r.data)).catch(() => {});
    api.get("/portal/stock-requests").then((r) => setReqs(r.data.items)).catch(() => {});
  };
  useEffect(() => { load(); }, []);

  const l = data.ledger;
  const inr = (n) => `₹${Number(n || 0).toLocaleString("en-IN")}`;

  const invoice = async (o) => {
    try {
      const r = await api.get(`/portal/orders/${o.order_no}/invoice.pdf`, { responseType: "blob" });
      const url = URL.createObjectURL(r.data); window.open(url, "_blank");
      setTimeout(() => URL.revokeObjectURL(url), 60000);
    } catch (e) { toast.error("Could not open invoice"); }
  };
  const setItem = (i, k, v) => setSrItems((it) => it.map((x, j) => j === i ? { ...x, [k]: v } : x));
  const submitSr = async () => {
    const items = srItems.filter((x) => x.name.trim()).map((x) => ({ name: x.name.trim(), qty: Number(x.qty) || 1 }));
    if (!items.length) { toast.error("Add at least one item"); return; }
    setSaving(true);
    try { await api.post("/portal/stock-requests", { items, notes: srNotes }); toast.success("Stock request sent"); setSrOpen(false); setSrItems([{ name: "", qty: 1 }]); setSrNotes(""); load(); }
    catch (e) { toast.error(apiError(e)); } finally { setSaving(false); }
  };

  const Stat = ({ icon: Icon, label, value, testId, color }) => (
    <Card className="p-4" data-testid={testId}><div className="flex items-center gap-3"><div className="h-10 w-10 rounded-lg bg-[#F0F4EE] dark:bg-[#1D2B1E] flex items-center justify-center"><Icon className={`h-5 w-5 ${color || "text-[#3B5B2A]"}`} /></div><div><div className="text-xl font-bold">{value}</div><div className="text-xs text-muted-foreground">{label}</div></div></div></Card>
  );

  return (
    <div className="p-4 md:p-6 animate-fade-up">
      <PageHeader title="Distributor / C&F Portal" subtitle="Your orders, invoices, ledger and stock requests" testId="portal-header"
        actions={
          <Dialog open={srOpen} onOpenChange={setSrOpen}>
            <DialogTrigger asChild><Button className="bg-[#3B5B2A] hover:bg-[#2D4720]" data-testid="new-stock-request-button"><Package className="h-4 w-4 mr-1.5" /> Raise stock request</Button></DialogTrigger>
            <DialogContent className="max-w-md">
              <DialogHeader><DialogTitle>Stock request</DialogTitle><DialogDescription>Request stock from VGRUPS — the team will confirm availability.</DialogDescription></DialogHeader>
              <div className="space-y-2">
                {srItems.map((it, i) => (
                  <div key={i} className="flex gap-2" data-testid={`sr-item-${i}`}>
                    <Input placeholder="Product name" value={it.name} onChange={(e) => setItem(i, "name", e.target.value)} />
                    <Input type="number" className="w-20" placeholder="Qty" value={it.qty} onChange={(e) => setItem(i, "qty", e.target.value)} />
                    <Button size="icon" variant="ghost" className="h-9 w-9" onClick={() => setSrItems((x) => x.filter((_, j) => j !== i))}><Trash2 className="h-4 w-4 text-destructive" /></Button>
                  </div>
                ))}
                <Button size="sm" variant="outline" onClick={() => setSrItems((x) => [...x, { name: "", qty: 1 }])} data-testid="sr-add-item"><Plus className="h-3.5 w-3.5 mr-1" /> Add item</Button>
                <div><Label>Notes</Label><Textarea rows={2} value={srNotes} onChange={(e) => setSrNotes(e.target.value)} /></div>
              </div>
              <DialogFooter><Button disabled={saving} onClick={submitSr} className="bg-[#3B5B2A] hover:bg-[#2D4720]" data-testid="sr-submit">{saving ? <Loader2 className="h-4 w-4 animate-spin" /> : "Send request"}</Button></DialogFooter>
            </DialogContent>
          </Dialog>
        } />
      {data.preview_all && <div className="mb-4 text-sm rounded-lg bg-blue-50 dark:bg-blue-500/10 text-blue-700 dark:text-blue-300 p-3" data-testid="portal-admin-note">Admin preview — showing all orders. A distributor/C&F user sees only their own.</div>}

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-5">
        <Stat icon={FileText} label="Orders" value={l.order_count} testId="ledger-orders" />
        <Stat icon={IndianRupee} label="Total billed" value={inr(l.billed)} testId="ledger-billed" />
        <Stat icon={CheckCircle2} label="Paid" value={inr(l.paid)} testId="ledger-paid" color="text-green-600 dark:text-green-400" />
        <Stat icon={Clock} label="Outstanding" value={inr(l.outstanding)} testId="ledger-outstanding" color="text-amber-600 dark:text-amber-400" />
      </div>

      <Tabs defaultValue="orders">
        <TabsList>
          <TabsTrigger value="orders" data-testid="portal-tab-orders">Orders ({data.orders.length})</TabsTrigger>
          <TabsTrigger value="requests" data-testid="portal-tab-requests">Stock Requests ({reqs.length})</TabsTrigger>
        </TabsList>

        <TabsContent value="orders" className="mt-4">
          <Card className="overflow-hidden"><div className="overflow-x-auto"><Table>
            <TableHeader><TableRow><TableHead>Order #</TableHead><TableHead>Party</TableHead><TableHead>Items</TableHead><TableHead>Total</TableHead><TableHead>Status</TableHead><TableHead>Payment</TableHead><TableHead className="text-right">Invoice</TableHead></TableRow></TableHeader>
            <TableBody>
              {data.orders.map((o) => (
                <TableRow key={o.order_no} data-testid={`portal-order-${o.order_no}`}>
                  <TableCell className="font-mono text-xs">{o.order_no}</TableCell>
                  <TableCell>{o.contact_name}</TableCell>
                  <TableCell className="text-muted-foreground">{o.items_count}</TableCell>
                  <TableCell className="font-medium">{inr(o.total)}</TableCell>
                  <TableCell className="capitalize text-sm text-muted-foreground">{o.status}</TableCell>
                  <TableCell><span className={`text-xs px-2 py-0.5 rounded-full font-medium capitalize ${PAY_COLOR[o.payment_status] || ""}`}>{o.payment_status}</span></TableCell>
                  <TableCell className="text-right"><Button size="sm" variant="outline" onClick={() => invoice(o)} data-testid={`portal-invoice-${o.order_no}`}><Download className="h-3.5 w-3.5 mr-1" /> PDF</Button></TableCell>
                </TableRow>
              ))}
              {data.orders.length === 0 && <TableRow><TableCell colSpan={7} className="text-center py-10 text-muted-foreground">No orders yet.</TableCell></TableRow>}
            </TableBody>
          </Table></div></Card>
        </TabsContent>

        <TabsContent value="requests" className="mt-4">
          <Card className="overflow-hidden"><div className="overflow-x-auto"><Table>
            <TableHeader><TableRow><TableHead>Request #</TableHead><TableHead>Items</TableHead><TableHead>Notes</TableHead><TableHead>Status</TableHead><TableHead>Date</TableHead></TableRow></TableHeader>
            <TableBody>
              {reqs.map((s) => (
                <TableRow key={s.id} data-testid={`sr-row-${s.id}`}>
                  <TableCell className="font-mono text-xs">{s.number}</TableCell>
                  <TableCell className="text-sm">{(s.items || []).map((i) => `${i.name} ×${i.qty}`).join(", ")}</TableCell>
                  <TableCell className="text-muted-foreground text-sm">{s.notes || "—"}</TableCell>
                  <TableCell><span className={`text-xs px-2 py-0.5 rounded-full font-medium capitalize ${SR_COLOR[s.status] || ""}`}>{s.status}</span></TableCell>
                  <TableCell className="text-muted-foreground text-xs">{(s.created_at || "").slice(0, 10)}</TableCell>
                </TableRow>
              ))}
              {reqs.length === 0 && <TableRow><TableCell colSpan={5} className="text-center py-10 text-muted-foreground">No stock requests yet.</TableCell></TableRow>}
            </TableBody>
          </Table></div></Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
