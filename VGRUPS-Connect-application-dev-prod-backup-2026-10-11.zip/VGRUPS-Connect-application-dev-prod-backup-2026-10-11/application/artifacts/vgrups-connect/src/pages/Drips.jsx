import React, { useEffect, useState, useCallback } from "react";
import api, { apiError } from "../lib/api";
import { toast } from "sonner";
import { useAuth } from "../context/AuthContext";
import ConfirmDialog from "../components/ConfirmDialog";
import { StatusBadge, DemoBadge } from "../components/common";
import { Card } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { Textarea } from "../components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogTrigger } from "../components/ui/dialog";
import MessagePreview from "../components/campaigns/MessagePreview";
import { useSenders, SenderSelect, resolveSender, findSender, senderLabel } from "../lib/useSenders";
import GapField from "../components/campaigns/GapField";
import ReportDialog from "../components/campaigns/ReportDialog";
import { Pencil, FileBarChart, Plus, Loader2, Play, Pause, Trash2, Clock, CheckCircle2, Reply, ShoppingBag, Ban, GitBranch } from "lucide-react";

const DEFAULT_STEPS = [
  { day: 0, message: "Hi {name}! Welcome to VGRUPS Healthcare. Thanks for your interest!" },
  { day: 1, message: "Hi {name}, here's our product range and today's best prices. Reply to know more." },
  { day: 3, message: "Just checking in {name} — any questions on our products? We're happy to help." },
  { day: 7, message: "{name}, a quick reminder: special pricing for you this week. Shall we proceed?" },
];
const empty = { name: "", audience: { type: "all", contact_type: "" }, steps: DEFAULT_STEPS, message_gap_seconds: 5, sender_session_id: "" };

export default function Drips() {
  const { can } = useAuth();
  const [delD, setDelD] = useState(null);
  const [items, setItems] = useState([]);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState(empty);
  const [saving, setSaving] = useState(false);
  const [editId, setEditId] = useState(null);
  const [report, setReport] = useState(null);
  const senders = useSenders();

  const load = useCallback(() => { api.get("/drips").then((r) => setItems(r.data.items)); }, []);
  useEffect(() => { load(); const t = setInterval(load, 5000); return () => clearInterval(t); }, [load]);

  const setStep = (i, k, v) => setForm((f) => ({ ...f, steps: f.steps.map((s, idx) => idx === i ? { ...s, [k]: v } : s) }));
  const addStep = () => setForm((f) => ({ ...f, steps: [...f.steps, { day: (f.steps.at(-1)?.day || 0) + 7, message: "" }] }));
  const rmStep = (i) => setForm((f) => ({ ...f, steps: f.steps.filter((_, idx) => idx !== i) }));

  const create = async () => {
    setSaving(true);
    try {
      const body = { name: form.name, audience: form.audience, message_gap_seconds: form.message_gap_seconds || 5, sender_session_id: resolveSender(senders, form.sender_session_id) || null, steps: form.steps.map((s) => ({ day: Number(s.day) || 0, message: s.message })) };
      if (editId) await api.put(`/drips/${editId}`, body); else await api.post("/drips", body);
      toast.success(editId ? "Drip sequence updated" : "Drip sequence created"); setOpen(false); setForm(empty); setEditId(null); load();
    } catch (e) { toast.error(apiError(e)); } finally { setSaving(false); }
  };
  const action = async (id, act) => { try { await api.post(`/drips/${id}/${act}`); const r = act === "activate" ? await Promise.resolve() : null; toast.success(act === "activate" ? "Activated & enrolled audience" : act); load(); } catch (e) { toast.error(apiError(e)); } };
  const remove = async (id) => { try { await api.delete(`/drips/${id}`); toast.success("Deleted"); load(); } catch (e) { toast.error(apiError(e)); } };

  return (
    <div data-testid="drips-page">
      <div className="flex justify-end mb-4">
        <Dialog open={open} onOpenChange={(o) => { setOpen(o); if (!o) { setEditId(null); setForm(empty); } }}>
          <DialogTrigger asChild>{can("campaigns", "create") && <Button onClick={() => { setEditId(null); setForm(empty); }} data-testid="add-drip-button" className="bg-[#3B5B2A] hover:bg-[#2D4720]"><Plus className="h-4 w-4 mr-1" /> New Drip Sequence</Button>}</DialogTrigger>
          <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{editId ? "Edit Drip Sequence" : "New Drip Sequence"}</DialogTitle>
              <DialogDescription>Auto-stops when a contact replies, buys, or opts out. {"{name}"} is filled per contact.</DialogDescription>
            </DialogHeader>
            <div className="space-y-3">
              <SenderSelect senders={senders} value={form.sender_session_id} onChange={(v) => setForm({ ...form, sender_session_id: v })} disabled={saving} testId="drip-sender-select" />
              <div><Label>Name *</Label><Input data-testid="drip-name-input" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
              <div className="space-y-2">
                <Label>Steps</Label>
                {form.steps.map((s, i) => (
                  <div key={i} className="rounded-lg border border-border p-2.5" data-testid={`drip-step-${i}`}>
                    <div className="flex items-center gap-2 mb-1.5">
                      <span className="text-xs font-semibold text-[#3B5B2A]">Day</span>
                      <Input type="number" className="h-7 w-20" value={s.day} onChange={(e) => setStep(i, "day", e.target.value)} />
                      <Button size="icon" variant="ghost" className="ml-auto h-7 w-7" onClick={() => rmStep(i)}><Trash2 className="h-3.5 w-3.5 text-destructive" /></Button>
                    </div>
                    <Textarea rows={2} value={s.message} onChange={(e) => setStep(i, "message", e.target.value)} placeholder="Message…" />
                    <div className="mt-2"><MessagePreview message={s.message} testId={`drip-preview-${i}`} /></div>
                  </div>
                ))}
                <GapField value={form.message_gap_seconds || 5} onChange={(v) => setForm((f) => ({ ...f, message_gap_seconds: v }))} />
                <Button size="sm" variant="outline" onClick={addStep} data-testid="drip-add-step"><Plus className="h-3.5 w-3.5 mr-1" /> Add step</Button>
              </div>
            </div>
            <DialogFooter><Button data-testid="drip-save-button" disabled={saving || (!senders.loading && senders.items.length > 1 && !resolveSender(senders, form.sender_session_id)) || !form.name || form.steps.length === 0} onClick={create} className="bg-[#3B5B2A] hover:bg-[#2D4720]">{saving ? <Loader2 className="h-4 w-4 animate-spin" /> : editId ? "Save changes" : "Create Sequence"}</Button></DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        {items.map((d) => {
          const s = d.stats || {};
          return (
            <Card key={d.id} className="p-5" data-testid={`drip-card-${d.id}`}>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2"><div className="h-9 w-9 rounded-lg bg-[#F0F4EE] dark:bg-[#1D2B1E] flex items-center justify-center"><GitBranch className="h-4 w-4 text-[#3B5B2A]" /></div><div className="font-semibold flex items-center gap-2">{d.name} {d.is_demo && <DemoBadge />}</div></div>
              {d.sender_session_id && <div className="text-xs text-muted-foreground mt-1" data-testid={`drip-sender-${d.id}`}>Sender: {findSender(senders, d.sender_session_id) ? senderLabel(findSender(senders, d.sender_session_id)) : "number no longer linked"}</div>}
                <StatusBadge status={d.status} />
              </div>
              <div className="text-xs text-muted-foreground mt-2">{(d.steps || []).length} steps · Days {(d.steps || []).map((x) => x.day).join(", ")}</div>
              <div className="grid grid-cols-5 gap-1.5 mt-3 text-center">
                {[["Active", s.active, Clock], ["Sent", s.sent, CheckCircle2], ["Replied", s.replied, Reply], ["Bought", s.purchased, ShoppingBag], ["Opt-out", s.opted_out, Ban]].map(([l, v, Ic]) => (
                  <div key={l}><Ic className="h-3.5 w-3.5 mx-auto text-muted-foreground" /><div className="text-sm font-semibold">{v || 0}</div><div className="text-[9px] text-muted-foreground">{l}</div></div>
                ))}
              </div>
              <div className="flex gap-2 mt-4">
                {d.status === "draft" && can("campaigns", "send") && <Button size="sm" variant="outline" className="flex-1" data-testid={`drip-activate-${d.id}`} onClick={() => action(d.id, "activate")}><Play className="h-3.5 w-3.5 mr-1" /> Activate</Button>}
                {d.status === "active" && can("campaigns", "edit") && <Button size="sm" variant="outline" className="flex-1" data-testid={`drip-pause-${d.id}`} onClick={() => action(d.id, "pause")}><Pause className="h-3.5 w-3.5 mr-1" /> Pause</Button>}
                {d.status === "paused" && can("campaigns", "send") && <Button size="sm" variant="outline" className="flex-1" data-testid={`drip-resume-${d.id}`} onClick={() => action(d.id, "resume")}><Play className="h-3.5 w-3.5 mr-1" /> Resume</Button>}
                {d.status === "draft" && can("campaigns", "edit") && <Button size="sm" variant="outline" data-testid={`drip-edit-${d.id}`} onClick={() => { setEditId(d.id); setForm({ name: d.name, audience: d.audience || empty.audience, steps: (d.steps || []).map((x) => ({ day: x.day, message: x.message })), message_gap_seconds: d.message_gap_seconds || 5, sender_session_id: d.sender_session_id || "" }); setOpen(true); }}><Pencil className="h-3.5 w-3.5 mr-1" /> Edit</Button>}
                {can("campaigns", "view") && <Button size="sm" variant="outline" data-testid={`drip-report-${d.id}`} onClick={() => setReport(d)}><FileBarChart className="h-3.5 w-3.5 mr-1" /> Report</Button>}
                {can("campaigns", "delete") && <Button size="sm" variant="outline" className="text-destructive" aria-label="Delete sequence" data-testid={`drip-delete-${d.id}`} onClick={() => setDelD(d)}><Trash2 className="h-3.5 w-3.5 mr-1" /> Delete</Button>}
              </div>
            </Card>
          );
        })}
        {items.length === 0 && <div className="col-span-full text-center py-10 text-muted-foreground">No drip sequences yet. Create one to start day-based follow-ups.</div>}
      </div>
      <ConfirmDialog open={!!delD} onOpenChange={(o) => !o && setDelD(null)} title="Delete this drip sequence?" description={delD ? `"${delD.name}" will be removed from the list and pending enrollments are cancelled. Historical delivery reports are kept as archived evidence.` : ""} confirmLabel="Delete" destructive onConfirm={() => { const d = delD; setDelD(null); remove(d.id); }} testId="drip-delete-confirm" />
      <ReportDialog open={!!report} onOpenChange={(o) => !o && setReport(null)} item={report} type="drips" canExport={can("campaigns", "export")} onExport={async (d, filters = {}) => { try { const r = await api.get(`/drips/${d.id}/report.csv`, { responseType: "blob", params: filters }); const url = URL.createObjectURL(r.data); const a = document.createElement("a"); a.href = url; a.download = `${d.name.replace(/\s/g, "_")}_report.csv`; document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url); } catch (e) { toast.error(apiError(e)); } }} />
    </div>
  );
}
