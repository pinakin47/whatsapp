import React, { useEffect, useState, useRef } from "react";
import api, { apiError } from "../lib/api";
import { toast } from "sonner";
import { Card } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import ConfirmDialog from "../components/ConfirmDialog";
import { useAuth } from "../context/AuthContext";
import { senderLabel } from "../lib/useSenders";
import { Label } from "../components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogTrigger } from "../components/ui/dialog";
import {
  Plus, Smartphone, QrCode, CheckCircle2, Loader2, LogOut, Trash2, RefreshCw, Wifi, WifiOff,
} from "lucide-react";

const STATUS_META = {
  connected: { label: "Connected", cls: "text-green-600", Icon: CheckCircle2 },
  qr: { label: "Scan QR", cls: "text-[#D97706]", Icon: QrCode },
  connecting: { label: "Connecting…", cls: "text-blue-600", Icon: Loader2 },
  reconnecting: { label: "Reconnecting…", cls: "text-amber-600", Icon: RefreshCw },
  logged_out: { label: "Logged out", cls: "text-muted-foreground", Icon: WifiOff },
};

export default function WhatsAppConnections() {
  const [sessions, setSessions] = useState([]);
  const [health, setHealth] = useState([]);
  const [serviceDown, setServiceDown] = useState(false);
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [creating, setCreating] = useState(false);
  const [activeId, setActiveId] = useState(null);
  const poll = useRef(null);
  const { can } = useAuth();
  const canManage = can("whatsapp", "manage");
  const [routing, setRouting] = useState(null);
  const [routeErr, setRouteErr] = useState("");
  const [savingRoute, setSavingRoute] = useState(false);
  const [confirmAct, setConfirmAct] = useState(null);
  const loadRouting = async () => {
    try { const { data } = await api.get("/wa/routing"); setRouting(data); setRouteErr(""); }
    catch (e) { setRouteErr(apiError(e)); }
  };
  const saveRouting = async (patch) => {
    if (!routing || savingRoute) return;
    setSavingRoute(true);
    try {
      const { data } = await api.put("/wa/routing", { mr_session_id: routing.mr_session_id || null, general_session_id: routing.general_session_id || null, ...patch });
      setRouting(data); toast.success("Sender assignment saved");
    } catch (e) { toast.error(apiError(e)); } finally { setSavingRoute(false); }
  };

  const load = async () => {
    try {
      const { data } = await api.get("/wa/sessions");
      setSessions(data.sessions || []);
      setServiceDown(!!data.service_down);
    } catch (e) { setServiceDown(true); }
    try { const h = await api.get("/wa/health"); setHealth(h.data.numbers || []); } catch (e) {}
  };

  useEffect(() => {
    load(); loadRouting();
    poll.current = setInterval(() => { load(); loadRouting(); }, 2500);
    return () => clearInterval(poll.current);
  }, []);

  const create = async () => {
    setCreating(true);
    try {
      const { data } = await api.post("/wa/sessions", { name: name || "WhatsApp" });
      toast.success("Session created — scan the QR with WhatsApp");
      setActiveId(data.id);
      setOpen(false); setName("");
      load();
    } catch (e) { toast.error(apiError(e)); } finally { setCreating(false); }
  };

  const logout = async (id) => {
    try { await api.post(`/wa/sessions/${id}/logout`); toast.success("Logged out"); load(); }
    catch (e) { toast.error(apiError(e)); }
  };
  const remove = async (id) => {
    try { await api.delete(`/wa/sessions/${id}`); toast.success("Removed"); load(); }
    catch (e) { toast.error(apiError(e)); }
  };
  const reconnect = async (id) => {
    try { await api.post(`/wa/sessions/${id}/reconnect`); toast.success("Reconnecting…"); load(); }
    catch (e) { toast.error(apiError(e)); }
  };

  const activeQr = sessions.find((s) => s.id === activeId && s.qr);

  return (
    <div data-testid="wa-connections">
      <Card className="p-4 mb-4 border-[#D97706]/30 bg-[#FFF8EE] dark:bg-[#2A1F0E]">
        <div className="text-sm text-[#92540A] dark:text-[#F59E0B]">
          <b>WhatsApp Web connection (QR scan).</b> Open WhatsApp on your phone → <b>Settings → Linked Devices → Link a Device</b> → scan the QR below.
          Sessions auto-reconnect after restarts. Always-on messaging requires a continuously running gateway (Reserved VM when published). Once connected, the Inbox, OTP and campaigns send through this number.
          <br /><span className="text-xs">Note: This uses the unofficial WhatsApp Web protocol. Avoid aggressive bulk sending to reduce the risk of your number being blocked by WhatsApp.</span>
        </div>
      </Card>

      {health.length > 0 && (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3 mb-4" data-testid="wa-health">
          {health.map((h) => {
            const pct = h.daily_limit ? Math.round((h.sent_today / h.daily_limit) * 100) : 0;
            return (
              <Card key={h.session_id} className="p-4" data-testid={`wa-health-${h.session_id}`}>
                <div className="flex items-center justify-between">
                  <div className="text-sm font-semibold">+{h.phone}</div>
                  <span className={`text-[10px] rounded-full px-2 py-0.5 ${h.warmup_day <= 4 ? "bg-amber-100 text-amber-700 dark:bg-amber-500/15 dark:text-amber-300" : "bg-green-100 text-green-700 dark:bg-green-500/15 dark:text-green-300"}`}>
                    {h.warmup_day <= 4 ? `Warm-up day ${h.warmup_day}` : "Mature"}
                  </span>
                </div>
                <div className="flex justify-between text-[11px] text-muted-foreground mt-2 mb-1">
                  <span>{h.sent_today} / {h.daily_limit} sent today</span>
                  <span>{h.remaining} left</span>
                </div>
                <div className="h-2 w-full rounded-full bg-muted overflow-hidden">
                  <div className={`h-full rounded-full ${pct >= 90 ? "bg-destructive" : "bg-[#3B5B2A]"}`} style={{ width: `${Math.min(100, pct)}%` }} />
                </div>
              </Card>
            );
          })}
        </div>
      )}

      <Card className="p-4 mb-4" data-testid="wa-routing">
        <div className="font-semibold text-sm mb-1">Sender assignment</div>
        <p className="text-xs text-muted-foreground mb-3">MR messages always send from the MR number. Campaigns, drips, catalogue shares and individual messages default to the general number, and the sender can be chosen per send when more than one number is linked.</p>
        {routeErr && <p className="text-xs text-destructive mb-2">Cannot load assignment: {routeErr} <button className="underline" onClick={loadRouting}>Retry</button></p>}
        {routing && (routing.items || []).length === 0 && <p className="text-xs text-muted-foreground">Link a WhatsApp number to assign senders.</p>}
        {routing && (routing.items || []).length > 0 && (
          <div className="grid sm:grid-cols-2 gap-3">
            {[["mr_session_id", "MR sender (all MR messages)", "wa-route-mr"], ["general_session_id", "General / default sender", "wa-route-general"]].map(([key, lbl, tid]) => {
              const cur = (routing.items || []).find((i) => i.id === routing[key]);
              return (
                <div key={key}>
                  <Label htmlFor={tid}>{lbl}</Label>
                  <select id={tid} data-testid={tid} disabled={!canManage || savingRoute} value={routing[key] || ""} onChange={(e) => saveRouting({ [key]: e.target.value || null })} className="mt-1.5 h-9 w-full rounded-md border border-input bg-background px-2 text-sm">
                    <option value="">{(routing.items || []).length === 1 ? "Automatic (only number)" : "Not assigned"}</option>
                    {routing.items.map((i) => <option key={i.id} value={i.id}>{senderLabel(i)}{i.status !== "connected" ? " (offline)" : ""}</option>)}
                  </select>
                  {cur && cur.status !== "connected" && <p className="text-xs text-amber-700 mt-1" data-testid={`${tid}-offline`}>{senderLabel(cur)} is offline. Messages assigned to it will not send until it reconnects; nothing is rerouted to another number.</p>}
                  {!routing[key] && key === "mr_session_id" && (routing.items || []).length > 1 && <p className="text-xs text-amber-700 mt-1">No MR sender assigned. MR messages will not send.</p>}
                </div>
              );
            })}
          </div>
        )}
        {!canManage && <p className="text-xs text-muted-foreground mt-2">Needs whatsapp.manage to change assignments.</p>}
      </Card>

      {serviceDown && (
        <Card className="p-4 mb-4 border-destructive/30 bg-destructive/5">
          <div className="text-sm text-destructive">WhatsApp gateway service is starting or unavailable. Retrying automatically…</div>
        </Card>
      )}

      <div className="flex justify-end mb-4">
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button data-testid="wa-add-connection-btn" className="bg-[#3B5B2A] hover:bg-[#2D4720]"><Plus className="h-4 w-4 mr-1" /> Link WhatsApp Number</Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader><DialogTitle>Link a WhatsApp Number</DialogTitle>
              <DialogDescription>Give this connection a label, then scan the QR with your phone's WhatsApp → Linked Devices.</DialogDescription>
            </DialogHeader>
            <div className="space-y-3">
              <div><Label>Label (e.g. Sales, Support)</Label><Input data-testid="wa-session-name-input" value={name} onChange={(e) => setName(e.target.value)} placeholder="Sales WhatsApp" /></div>
            </div>
            <DialogFooter>
              <Button data-testid="wa-create-session-btn" disabled={creating} onClick={create} className="bg-[#3B5B2A] hover:bg-[#2D4720]">
                {creating ? <Loader2 className="h-4 w-4 animate-spin" /> : "Create & Show QR"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {sessions.map((s) => {
          const meta = STATUS_META[s.status] || STATUS_META.connecting;
          const spin = s.status === "connecting" || s.status === "reconnecting";
          return (
            <Card key={s.id} className="p-5 flex flex-col" data-testid={`wa-session-${s.id}`}>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="h-10 w-10 rounded-lg bg-[#F0F4EE] dark:bg-[#1D2B1E] flex items-center justify-center">
                    {s.status === "connected" ? <Wifi className="h-5 w-5 text-green-600" /> : <Smartphone className="h-5 w-5 text-[#3B5B2A] dark:text-[#8BAA78]" />}
                  </div>
                  <div>
                    <div className="font-semibold">{s.name}</div>
                    {s.phone && <div className="text-xs text-muted-foreground font-mono">+{s.phone}</div>}
                  </div>
                </div>
                <span className={`flex items-center gap-1 text-xs ${meta.cls}`} data-testid={`wa-status-${s.id}`}>
                  <meta.Icon className={`h-4 w-4 ${spin ? "animate-spin" : ""}`} /> {meta.label}
                </span>
              </div>

              {s.qr && s.status === "qr" && (
                <div className="mt-4 flex flex-col items-center">
                  <img src={s.qr} alt="WhatsApp QR" className="h-48 w-48 rounded-lg border border-border" data-testid={`wa-qr-${s.id}`} />
                  <p className="text-xs text-muted-foreground mt-2 text-center">Scan with WhatsApp → Linked Devices</p>
                </div>
              )}

              {s.status === "connected" && (
                <div className="mt-4 flex-1 flex items-center justify-center text-center text-sm text-green-600">
                  <div><CheckCircle2 className="h-10 w-10 mx-auto mb-2" />Connected to WhatsApp</div>
                </div>
              )}

              <div className="flex gap-2 mt-4">
                {(s.status === "logged_out" || s.status === "reconnecting") && (
                  <Button variant="outline" size="sm" className="flex-1" data-testid={`wa-reconnect-${s.id}`} onClick={() => reconnect(s.id)}>
                    <RefreshCw className="h-3.5 w-3.5 mr-1" /> Reconnect
                  </Button>
                )}
                {s.status === "connected" && (
                  <Button variant="outline" size="sm" className="flex-1" data-testid={`wa-logout-${s.id}`} onClick={() => setConfirmAct({ type: "logout", s })}>
                    <LogOut className="h-3.5 w-3.5 mr-1" /> Log out
                  </Button>
                )}
                <Button variant="ghost" size="icon" data-testid={`wa-delete-${s.id}`} aria-label={`Delete ${s.name}`} onClick={() => setConfirmAct({ type: "delete", s })}><Trash2 className="h-4 w-4 text-destructive" /></Button>
              </div>
            </Card>
          );
        })}

        {sessions.length === 0 && !serviceDown && (
          <Card className="p-10 col-span-full flex flex-col items-center text-center">
            <div className="h-14 w-14 rounded-2xl bg-[#F0F4EE] dark:bg-[#1D2B1E] flex items-center justify-center mb-3">
              <QrCode className="h-7 w-7 text-[#3B5B2A] dark:text-[#8BAA78]" />
            </div>
            <h3 className="font-semibold font-heading">No WhatsApp numbers linked</h3>
            <p className="text-sm text-muted-foreground mt-1">Click "Link WhatsApp Number" and scan the QR to go live.</p>
          </Card>
        )}
      </div>
      <ConfirmDialog open={!!confirmAct} onOpenChange={(o) => !o && setConfirmAct(null)} testId="wa-confirm-disconnect" destructive
        title={confirmAct?.type === "delete" ? "Remove this WhatsApp number?" : "Log out this WhatsApp number?"}
        description={confirmAct ? `${confirmAct.s.name}${confirmAct.s.phone ? ` (+${confirmAct.s.phone})` : ""} will be unlinked from this app. This only clears the WhatsApp pairing. Your CRM, leads, contacts, sales and message history are kept. Anything assigned to this number will not send until another number is assigned.` : ""}
        confirmLabel={confirmAct?.type === "delete" ? "Remove number" : "Log out"}
        onConfirm={() => { const a = confirmAct; setConfirmAct(null); a.type === "delete" ? remove(a.s.id) : logout(a.s.id); }} />
    </div>
  );
}
