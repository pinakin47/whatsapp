import React, { useEffect, useState, useCallback, useRef } from "react";
import api, { apiError } from "../lib/api";
import { toast } from "sonner";
import { PageHeader, StatusBadge, DemoBadge } from "../components/common";
import { Card } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { Textarea } from "../components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../components/ui/select";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger, DialogDescription,
} from "../components/ui/dialog";
import {
  Sheet, SheetContent, SheetHeader, SheetTitle,
} from "../components/ui/sheet";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../components/ui/table";
import { Plus, Search, Phone, Mail, MapPin, Building2, Trash2, Loader2, MessageSquare, FileText } from "lucide-react";
import { useAuth } from "../context/AuthContext";
import ContactWhatsAppDialog, { formatMobile } from "../components/ContactWhatsAppDialog";
import CatalogueHistory from "../components/CatalogueHistory";

const TYPES = [
  "all", "lead", "customer", "doctor", "hospital", "pharmacy",
  "distributor", "cf", "medical_shop", "institution", "mr", "team", "candidate",
];
const CREATE_TYPES = ["lead", "customer", "doctor", "hospital", "pharmacy", "distributor", "cf", "medical_shop", "institution"];
const PAGE = 100;
const label = (t) => t.replace(/_/g, " ").replace(/\b\w/g, (c) => c.toUpperCase());

const empty = { name: "", mobile: "", email: "", company: "", contact_type: "lead", city: "", state: "", pincode: "", gst: "", category: "", source: "manual", notes: "" };

export default function Contacts() {
  const [items, setItems] = useState([]);
  const [search, setSearch] = useState("");
  const [type, setType] = useState("all");
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState(empty);
  const [saving, setSaving] = useState(false);
  const [detail, setDetail] = useState(null);
  const { can } = useAuth();
  const [total, setTotal] = useState(0);
  const [offset, setOffset] = useState(0);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState("");
  const [wa, setWa] = useState(null);
  const [historyOpen, setHistoryOpen] = useState(false);
  const [detailError, setDetailError] = useState("");

  const request = useRef({ sequence: 0, controller: null });

  const load = useCallback(() => {
    request.current.controller?.abort();
    const controller = new AbortController();
    const sequence = ++request.current.sequence;
    request.current.controller = controller;
    const current = () => sequence === request.current.sequence && !controller.signal.aborted;
    setLoading(true); setLoadError("");
    return api.get(`/contacts/directory?search=${encodeURIComponent(search)}&contact_type=${encodeURIComponent(type)}&offset=${offset}&limit=${PAGE}`, { signal: controller.signal })
      .then((r) => {
        if (!current()) return;
        if (offset > 0 && offset >= r.data.total) {
          setOffset(Math.max(0, Math.floor((r.data.total - 1) / PAGE) * PAGE));
        }
        setItems(r.data.items); setTotal(r.data.total);
      })
      .catch((e) => { if (current()) setLoadError(apiError(e)); })
      .finally(() => { if (current()) setLoading(false); });
  }, [search, type, offset]);

  useEffect(() => {
    setLoading(true); setItems([]); setLoadError("");
    const t = setTimeout(load, 250);
    return () => {
      clearTimeout(t);
      request.current.controller?.abort();
      ++request.current.sequence;
    };
  }, [load]);

  const canMsg = can("inbox", "send");
  const canCat = canMsg && can("catalog", "view") && can("catalog", "send");
  const waActions = (c) => (canMsg || canCat) && (
    <div className="flex gap-1">
      {canMsg && <Button variant="outline" size="sm" aria-label={`Send WhatsApp message to ${c.name}`} data-testid={`message-contact-${c.id}`} onClick={() => setWa({ contact: c, mode: "message" })}><MessageSquare className="h-3.5 w-3.5 sm:mr-1" /><span className="hidden sm:inline">Message</span></Button>}
      {canCat && <Button variant="outline" size="sm" aria-label={`Send full catalogue to ${c.name}`} data-testid={`catalogue-contact-${c.id}`} onClick={() => setWa({ contact: c, mode: "catalogue" })}><FileText className="h-3.5 w-3.5 sm:mr-1" /><span className="hidden sm:inline">Catalogue</span></Button>}
    </div>
  );

  const save = async () => {
    setSaving(true);
    try {
      await api.post("/contacts", form);
      toast.success("Contact created");
      setOpen(false); setForm(empty); load();
    } catch (e) { toast.error(apiError(e)); } finally { setSaving(false); }
  };

  const remove = async (id) => {
    try { await api.delete(`/contacts/${id}`); toast.success("Deleted"); load(); }
    catch (e) { toast.error(apiError(e)); }
  };

  const openDetail = async (row) => {
    setDetailError("");
    if (row.is_virtual || row.contact_id == null) { setDetail({ ...row, virtual: true }); return; }
    try {
      const { data } = await api.get(`/contacts/${row.contact_id}`);
      setDetail({ ...data, mobile: String(data.mobile || "").startsWith("+") ? data.mobile : /^\d{8,15}$/.test(String(data.mobile || "")) ? `+${data.mobile}` : data.mobile, sources: row.sources, aliases: row.aliases, opted_out: row.opted_out, contact_id: row.contact_id, is_virtual: false });
    } catch (e) { toast.error(apiError(e)); }
  };

  return (
    <div className="p-4 md:p-6 animate-fade-up">
      <PageHeader
        title="CRM / Contacts"
        subtitle={`${total} contacts`}
        testId="contacts-header"
        actions={
          can("crm", "create") && <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button data-testid="add-contact-button" className="bg-[#3B5B2A] hover:bg-[#2D4720]"><Plus className="h-4 w-4 mr-1" /> New Contact</Button>
            </DialogTrigger>
            <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
              <DialogHeader><DialogTitle>New Contact</DialogTitle></DialogHeader>
              <div className="grid grid-cols-2 gap-3">
                <div className="col-span-2"><Label>Name *</Label><Input data-testid="contact-name-input" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
                <div><Label>Mobile *</Label><Input data-testid="contact-mobile-input" value={form.mobile} onChange={(e) => setForm({ ...form, mobile: e.target.value })} placeholder="+9198..." /></div>
                <div><Label>Email</Label><Input value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></div>
                <div><Label>Company</Label><Input value={form.company} onChange={(e) => setForm({ ...form, company: e.target.value })} /></div>
                <div>
                  <Label>Type</Label>
                  <Select value={form.contact_type} onValueChange={(v) => setForm({ ...form, contact_type: v })}>
                    <SelectTrigger data-testid="contact-type-select"><SelectValue /></SelectTrigger>
                    <SelectContent>{CREATE_TYPES.map((t) => <SelectItem key={t} value={t}>{label(t)}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
                <div><Label>City</Label><Input value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} /></div>
                <div><Label>State</Label><Input value={form.state} onChange={(e) => setForm({ ...form, state: e.target.value })} /></div>
                <div><Label>GST</Label><Input value={form.gst} onChange={(e) => setForm({ ...form, gst: e.target.value })} /></div>
                <div className="col-span-2"><Label>Notes</Label><Textarea value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} /></div>
              </div>
              <DialogFooter>
                <Button data-testid="contact-save-button" disabled={saving || !form.name || !form.mobile} onClick={save} className="bg-[#3B5B2A] hover:bg-[#2D4720]">
                  {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : "Save Contact"}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        }
      />

      {can("crm", "view") && can("catalog", "view") && <Button className="mb-3" variant="outline"
        onClick={() => setHistoryOpen(true)} data-testid="contacts-catalogue-history">My catalogue delivery history</Button>}
      <Dialog open={historyOpen} onOpenChange={setHistoryOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto" data-testid="catalogue-history-dialog">
          <DialogHeader><DialogTitle>My catalogue delivery history</DialogTitle>
            <DialogDescription>Browse your saved attempts, including those for contacts no longer in the directory. Viewing a report never sends a message.</DialogDescription>
          </DialogHeader>
          {historyOpen && <CatalogueHistory />}
        </DialogContent>
      </Dialog>
      <div className="flex flex-col sm:flex-row gap-2 mb-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input data-testid="contacts-search-input" value={search} onChange={(e) => { setSearch(e.target.value); setOffset(0); }} placeholder="Search name, mobile, company…" className="pl-9" />
        </div>
        <Select value={type} onValueChange={(value) => { setType(value); setOffset(0); }}>
          <SelectTrigger className="w-full sm:w-48" data-testid="contacts-type-filter"><SelectValue /></SelectTrigger>
          <SelectContent>{TYPES.map((t) => <SelectItem key={t} value={t}>{t === "all" ? "All Types" : label(t)}</SelectItem>)}</SelectContent>
        </Select>
      </div>

      <Card className="overflow-hidden">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead><TableHead>Type</TableHead><TableHead className="hidden md:table-cell">Company</TableHead>
                <TableHead className="hidden sm:table-cell">Mobile</TableHead><TableHead className="hidden lg:table-cell">City</TableHead><TableHead></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {loading && items.length === 0 && [0, 1, 2, 3].map((i) => <TableRow key={i}><TableCell colSpan={6}><div className="h-5 rounded bg-muted animate-pulse" /></TableCell></TableRow>)}
              {loadError && <TableRow><TableCell colSpan={6} className="text-center py-8 text-destructive" data-testid="contacts-error">Cannot load contacts: {loadError} <Button variant="outline" size="sm" className="ml-2" onClick={load} data-testid="contacts-retry">Retry</Button></TableCell></TableRow>}
              {items.map((c) => (
                <TableRow key={c.id} data-testid={`contact-row-${c.id}`} className="cursor-pointer" onClick={() => openDetail(c)}>
                  <TableCell className="font-medium">
                    <div>{c.name}</div>
                    <div className="flex flex-wrap gap-1 mt-0.5">{(c.sources || []).map((s) => <span key={s} className="text-[10px] rounded bg-[#F0F4EE] text-[#3B5B2A] px-1.5 py-0.5">{s}</span>)}{c.opted_out && <span className="text-[10px] rounded bg-destructive/10 text-destructive px-1.5 py-0.5">Opted out</span>}</div>
                    <div className="sm:hidden font-mono text-xs text-muted-foreground">{formatMobile(c.mobile)}</div>
                  </TableCell>
                  <TableCell><span className="text-xs rounded-full bg-muted px-2 py-0.5 capitalize">{label(c.contact_type)}</span></TableCell>
                  <TableCell className="hidden md:table-cell text-muted-foreground">{c.company}</TableCell>
                  <TableCell className="hidden sm:table-cell font-mono text-xs whitespace-nowrap">{formatMobile(c.mobile)}</TableCell>
                  <TableCell className="hidden lg:table-cell text-muted-foreground">{c.city}</TableCell>
                  <TableCell onClick={(e) => e.stopPropagation()}>
                    <div className="flex items-center gap-1 justify-end">
                      {waActions(c)}
                      {!c.is_virtual && c.contact_id != null && can("crm", "delete") && <Button variant="ghost" size="icon" data-testid={`delete-contact-${c.contact_id}`} onClick={() => remove(c.contact_id)}><Trash2 className="h-4 w-4 text-destructive" /></Button>}
                    </div>
                  </TableCell>
                </TableRow>
              ))}
              {!loading && !loadError && items.length === 0 && <TableRow><TableCell colSpan={6} className="text-center py-10 text-muted-foreground">No contacts found</TableCell></TableRow>}
            </TableBody>
          </Table>
        </div>
      </Card>
      <div className="flex items-center justify-between mt-3 text-xs text-muted-foreground" data-testid="contacts-pagination">
        <span>{total === 0 ? "0" : `${offset + 1}-${Math.min(offset + PAGE, total)}`} of {total}</span>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" disabled={loading || offset === 0} onClick={() => setOffset(Math.max(0, offset - PAGE))} data-testid="contacts-prev">Previous</Button>
          <Button variant="outline" size="sm" disabled={loading || offset + PAGE >= total} onClick={() => setOffset(offset + PAGE)} data-testid="contacts-next">Next</Button>
        </div>
      </div>
      {wa && <ContactWhatsAppDialog contact={wa.contact} mode={wa.mode} onClose={() => setWa(null)} />}

      <Sheet open={!!detail} onOpenChange={(o) => !o && setDetail(null)}>
        <SheetContent className="w-full sm:max-w-md overflow-y-auto">
          {detail && (
            <>
              <SheetHeader><SheetTitle className="flex items-center gap-2">{detail.name} {detail.is_demo && <DemoBadge />}</SheetTitle></SheetHeader>
              <div className="mt-5 space-y-4 text-sm">
                <span className="inline-block text-xs rounded-full bg-[#F0F4EE] text-[#3B5B2A] px-2.5 py-1 capitalize">{label(detail.contact_type)}</span>
                <div className="space-y-2 text-muted-foreground">
                  <div className="flex items-center gap-2"><Phone className="h-4 w-4" /> {formatMobile(detail.mobile)}</div>
                  {detail.email && <div className="flex items-center gap-2"><Mail className="h-4 w-4" /> {detail.email}</div>}
                  {detail.company && <div className="flex items-center gap-2"><Building2 className="h-4 w-4" /> {detail.company}</div>}
                  {detail.city && <div className="flex items-center gap-2"><MapPin className="h-4 w-4" /> {detail.city}, {detail.state}</div>}
                </div>
                {(detail.sources?.length > 0 || detail.aliases?.length > 0) && (
                  <div className="text-xs space-y-1" data-testid="detail-sources">
                    {detail.sources?.length > 0 && <div>Sources: {detail.sources.join(", ")}</div>}
                    {detail.aliases?.length > 0 && <div>Also known as: {detail.aliases.join(", ")}</div>}
                  </div>
                )}
                {detail.opted_out && <div className="text-xs text-destructive">Opted out of WhatsApp</div>}
                {(canMsg || canCat) && <div data-testid="detail-wa-actions">{waActions(detail)}</div>}
                {detail.virtual && <div className="text-xs text-muted-foreground">Directory entry from {detail.sources?.join(", ") || "another module"}. Not an editable CRM contact.</div>}
                {!detail.virtual && <><div className="rounded-lg border border-border p-3">
                  <div className="text-xs font-semibold mb-2">Orders ({detail.orders?.length || 0})</div>
                  {detail.orders?.length ? detail.orders.map((o) => (
                    <div key={o.id} className="flex justify-between py-1 text-xs"><span>{o.order_no}</span><span>₹{o.total}</span></div>
                  )) : <div className="text-xs text-muted-foreground">No orders</div>}
                </div>
                <div className="rounded-lg border border-border p-3">
                  <div className="text-xs font-semibold mb-2">Related Leads ({detail.leads?.length || 0})</div>
                  {detail.leads?.length ? detail.leads.map((l) => (
                    <div key={l.id} className="flex justify-between py-1 text-xs"><span>{l.title}</span><StatusBadge status={l.status} /></div>
                  )) : <div className="text-xs text-muted-foreground">No leads</div>}
                </div></>}
              </div>
            </>
          )}
        </SheetContent>
      </Sheet>
    </div>
  );
}
