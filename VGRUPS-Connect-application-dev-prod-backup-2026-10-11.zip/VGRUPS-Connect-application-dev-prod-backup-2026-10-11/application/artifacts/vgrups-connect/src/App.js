import { useEffect } from "react";
import "@/App.css";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { Toaster } from "sonner";
import { AuthProvider } from "@/context/AuthContext";
import { ThemeProvider } from "@/context/ThemeContext";
import ProtectedRoute from "@/components/ProtectedRoute";
import Layout from "@/components/Layout";
import Login from "@/pages/Login";
import Dashboard from "@/pages/Dashboard";
import Contacts from "@/pages/Contacts";
import Leads from "@/pages/Leads";
import WhatsAppLeads from "@/pages/WhatsAppLeads";
import WhatsAppLeadDetail from "@/pages/WhatsAppLeadDetail";
import Inbox from "@/pages/Inbox";
import WhatsAppTemplates from "@/pages/WhatsAppTemplates";
import WhatsAppHub from "@/pages/WhatsAppHub";
import Integrations from "@/pages/Integrations";
import Tasks from "@/pages/Tasks";
import Catalog from "@/pages/Catalog";
import Orders from "@/pages/Orders";
import CampaignsHub from "@/pages/CampaignsHub";
import Automations from "@/pages/Automations";
import ChatbotBuilder from "@/pages/ChatbotBuilder";
import Payments from "@/pages/Payments";
import Recruitment from "@/pages/Recruitment";
import IVRSetup from "@/pages/IVRSetup";
import Careers from "@/pages/Careers";
import Ads from "@/pages/Ads";
import ExtensionWidget from "@/pages/ExtensionWidget";
import FieldSales from "@/pages/FieldSales";
import Sales from "@/pages/Sales";
import Portal from "@/pages/Portal";
import Settings from "@/pages/Settings";
import IVRReports from "@/pages/IVRReports";
import MRIVRHub from "@/pages/MRIVRHub";
import MRIVRDetail from "@/pages/MRIVRDetail";
import ComingSoon from "@/pages/ComingSoon";

const soon = (title, phase, description) => <ComingSoon title={title} phase={phase} description={description} />;

function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <BrowserRouter>
          <Toaster position="top-right" richColors />
          <Routes>
            <Route path="/login" element={<Login />} />
            <Route path="/careers" element={<Careers />} />
            <Route path="/jobs" element={<Navigate to="/careers" replace />} />
            <Route element={<ProtectedRoute><Layout /></ProtectedRoute>}>
              <Route path="/dashboard" element={<Dashboard />} />
              <Route path="/inbox" element={<Inbox />} />
              <Route path="/crm" element={<Contacts />} />
              <Route path="/contacts" element={<Contacts />} />
              <Route path="/leads" element={<Leads />} />
              <Route path="/leads/whatsapp" element={<WhatsAppLeads />} />
              <Route path="/leads/whatsapp/:id" element={<WhatsAppLeadDetail />} />
              <Route path="/whatsapp" element={<WhatsAppHub />} />
              <Route path="/campaigns" element={<CampaignsHub />} />
              <Route path="/catalog" element={<Catalog />} />
              <Route path="/orders" element={<Orders />} />
              <Route path="/tasks" element={<Tasks />} />
              <Route path="/integrations" element={<Integrations />} />
              <Route path="/settings" element={<Settings />} />
              <Route path="/sales" element={<Sales />} />
              <Route path="/automation" element={<Automations />} />
              <Route path="/chatbot" element={<ChatbotBuilder />} />
              <Route path="/ivr" element={<IVRSetup />} />
              <Route path="/ivr/mrs" element={<MRIVRHub />} />
              <Route path="/ivr/mrs/:id" element={<MRIVRDetail />} />
              <Route path="/recruitment" element={<Recruitment />} />
              <Route path="/payments" element={<Payments />} />
              <Route path="/field-sales" element={<FieldSales />} />
              <Route path="/portal" element={<Portal />} />
              <Route path="/extension" element={<ExtensionWidget />} />
              <Route path="/ads" element={<Ads />} />
              <Route path="/reports" element={<IVRReports />} />
            </Route>
            <Route path="*" element={<Navigate to="/dashboard" replace />} />
          </Routes>
        </BrowserRouter>
      </AuthProvider>
    </ThemeProvider>
  );
}

export default App;
