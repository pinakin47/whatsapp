import React, { createContext, useContext, useEffect, useState } from "react";
import api, { apiError } from "../lib/api";

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem("vg_token");
    if (!token) {
      setLoading(false);
      return;
    }
    api.get("/auth/me").then((r) => setUser(r.data)).catch(() => {
      localStorage.removeItem("vg_token");
    }).finally(() => setLoading(false));
  }, []);

  const login = async (email, password) => {
    const { data } = await api.post("/auth/login", { email, password });
    localStorage.setItem("vg_token", data.token);
    setUser(data.user);
    return data.user;
  };

  const loginWithOtp = async (email, code, otpId) => {
    const { data } = await api.post("/auth/verify-otp", {
      identifier: email, code, otp_id: otpId, channel: "email", purpose: "login",
    });
    if (!data.token || !data.user) throw new Error("Unable to complete sign-in.");
    localStorage.setItem("vg_token", data.token);
    setUser(data.user);
    return data.user;
  };

  const logout = async () => {
    try { await api.post("/auth/logout"); } catch (e) {}
    localStorage.removeItem("vg_token");
    setUser(null);
  };

  const can = (module, action = "view") => {
    if (!user) return false;
    return (user.permissions?.[module] || []).includes(action);
  };

  return (
    <AuthContext.Provider value={{ user, setUser, login, loginWithOtp, logout, loading, can }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
export { apiError };
