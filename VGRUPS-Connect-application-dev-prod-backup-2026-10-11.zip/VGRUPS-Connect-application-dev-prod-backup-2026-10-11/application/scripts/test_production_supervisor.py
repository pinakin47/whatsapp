import json
from pathlib import Path
import subprocess
import sys
import time
import unittest

ROOT = Path(__file__).resolve().parent.parent


def command(api_code, gateway_code):
    api = [sys.executable, "-c", api_code]
    gateway = [sys.executable, "-c", gateway_code]
    source = (
        "import asyncio, sys; from scripts.run_production import supervise; "
        f"sys.exit(asyncio.run(supervise({json.dumps(api)}, {json.dumps(gateway)}, restart_delay=0.02)))"
    )
    return [sys.executable, "-c", source]


class SupervisorTests(unittest.TestCase):
    def test_api_exit_propagates_and_gateway_is_stopped(self):
        result = subprocess.run(command(
            "import time,sys; time.sleep(0.2); sys.exit(17)",
            "import time; time.sleep(60)",
        ), cwd=ROOT, capture_output=True, text=True, timeout=5)
        self.assertEqual(result.returncode, 17, result.stderr)

    def test_gateway_crash_restarts_without_taking_api_down(self):
        result = subprocess.run(command(
            "import time; time.sleep(0.3)",
            "import sys; sys.exit(3)",
        ), cwd=ROOT, capture_output=True, text=True, timeout=5)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertGreaterEqual(result.stdout.count("restarting"), 2)

    def test_sigterm_stops_both_children_cleanly(self):
        process = subprocess.Popen(command(
            "import time; time.sleep(60)", "import time; time.sleep(60)",
        ), cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        try:
            time.sleep(0.3)
            process.terminate()
            _, stderr = process.communicate(timeout=5)
            self.assertEqual(process.returncode, 0, stderr)
        finally:
            if process.poll() is None:
                process.kill()
                process.communicate()


if __name__ == "__main__":
    unittest.main()