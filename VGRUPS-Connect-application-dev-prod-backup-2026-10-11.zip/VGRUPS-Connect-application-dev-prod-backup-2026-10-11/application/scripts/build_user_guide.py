"""Build the versioned, public user handbook from its editable JSON source."""
import argparse
import json
from html import escape
from pathlib import Path
from urllib.parse import urlparse

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, PageBreak

ROOT = Path(__file__).resolve().parent.parent
GREEN = colors.HexColor("#3B5B2A")
PALE = colors.HexColor("#F0F4EE")


def build(base_url):
    if urlparse(base_url).scheme != "https" or not urlparse(base_url).netloc:
        raise ValueError("Provide the verified HTTPS production URL.")
    guide = json.loads((ROOT / "docs/user-guide.json").read_text())
    output = ROOT / "artifacts/vgrups-connect/public/vgrups-connect-user-guide.pdf"
    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle("BookTitle", fontSize=34, leading=39, textColor=GREEN, spaceAfter=16))
    styles.add(ParagraphStyle("Chapter", fontSize=23, leading=28, textColor=GREEN, spaceAfter=12))
    styles.add(ParagraphStyle("Copy", fontSize=10.5, leading=16, spaceAfter=10))
    styles.add(ParagraphStyle("Step", fontSize=10.5, leading=16, spaceAfter=9, leftIndent=24, firstLineIndent=-24))
    styles.add(ParagraphStyle("CompactStep", parent=styles["Step"], leading=15, spaceAfter=7))
    styles.add(ParagraphStyle("Link", fontSize=9.5, leading=15, textColor=GREEN, spaceAfter=8))
    styles.add(ParagraphStyle("Tip", fontSize=9.5, leading=14, spaceAfter=7))
    document = SimpleDocTemplate(str(output), pagesize=A4, rightMargin=22*mm,
        leftMargin=22*mm, topMargin=24*mm, bottomMargin=22*mm,
        title="VGRUPS Connect - Application User Guide", author="VGRUPS Healthcare")

    def p(text, style="Copy"):
        return Paragraph(escape(text), styles[style])

    def links(paths):
        return [Paragraph(f'<link href="{escape(base_url.rstrip("/") + path, quote=True)}">'
            f'{escape(base_url.rstrip("/") + path)}</link>', styles["Link"]) for path in paths]

    story = [Spacer(1, 32*mm), p(guide["title"], "BookTitle"),
        p(guide["subtitle"], "Chapter"), p("Step-by-step instructions and clickable page links"),
        Spacer(1, 12*mm), *links(["/dashboard"]), p("Edition: " + guide["edition"]),
        Spacer(1, 10*mm), p(guide["intro"]),
        p("How to use this book", "Heading2"),
        p("Click a chapter in the contents, then use the live page link at the top of that chapter. "
          "Sign in when prompted. Follow the numbered steps and read the notes before sending, deleting or publishing."),
        p("Scope", "Heading2"),
        p("Demo-contact cleanup does not delete real contacts, WhatsApp pairing, or other record types. "
          "Features marked Coming Soon or not wired are not described as working features."), PageBreak(),
        p("Contents", "Chapter")]
    for index, chapter in enumerate(guide["chapters"], 1):
        story.append(Paragraph(f'<link href="#chapter-{index}">{index:02d} &nbsp; '
            f'{escape(chapter["title"])}</link>', styles["Link"]))
    story.append(PageBreak())
    for index, chapter in enumerate(guide["chapters"], 1):
        story.append(Paragraph(f'<a name="chapter-{index}"/>{index:02d} &nbsp; '
            f'{escape(chapter["title"])}', styles["Chapter"]))
        story.extend(links(chapter["paths"]))
        story.extend([p(chapter["purpose"]), Spacer(1, 4*mm), p("Step by step", "Heading2")])
        for number, step in enumerate(chapter["steps"], 1):
            step_style = "CompactStep" if len(chapter["steps"]) > 8 else "Step"
            story.append(p(f"{number}.  {step}", step_style))
        story.extend([Spacer(1, 4*mm), p("Important notes", "Heading2")])
        for tip in chapter["tips"]:
            story.append(p("- " + tip, "Tip"))
        if index < len(guide["chapters"]):
            story.append(PageBreak())

    def footer(canvas, doc):
        canvas.saveState()
        canvas.setStrokeColor(GREEN)
        canvas.line(22*mm, 17*mm, A4[0]-22*mm, 17*mm)
        canvas.setFillColor(colors.HexColor("#64705F"))
        canvas.setFont("Helvetica", 8)
        canvas.drawString(22*mm, 12*mm, "VGRUPS Connect | Application User Guide | " + guide["edition"])
        canvas.drawRightString(A4[0]-22*mm, 12*mm, str(doc.page))
        canvas.restoreState()

    document.build(story, onFirstPage=footer, onLaterPages=footer)
    print(f"Built {len(guide['chapters'])} chapters: {output.relative_to(ROOT)}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-url", required=True, help="Verified production URL from deployment metadata")
    build(parser.parse_args().base_url)