"""Supervise the public API and private WhatsApp gateway in one deployment.

Use Reserved VM for persistent WhatsApp connections. Development keeps its
existing separate workflows; this supervisor is only the production entry point.
"""
import asyncio
import contextlib
import os
from pathlib import Path
import signal
import sys

ROOT = Path(__file__).resolve().parent.parent


async def supervise(api_command, gateway_command, restart_delay=3):
    children = set()
    stopping = asyncio.Event()
    loop = asyncio.get_running_loop()
    for sig in (signal.SIGTERM, signal.SIGINT):
        loop.add_signal_handler(sig, stopping.set)

    async def spawn(command):
        process = await asyncio.create_subprocess_exec(
            *command, cwd=ROOT, start_new_session=True,
        )
        children.add(process)
        return process

    async def gateway_loop():
        while not stopping.is_set():
            process = await spawn(gateway_command)
            code = await process.wait()
            children.discard(process)
            if not stopping.is_set():
                print(f"WhatsApp gateway exited ({code}); restarting.", flush=True)
                await asyncio.sleep(restart_delay)

    api = await spawn(api_command)
    gateway_task = asyncio.create_task(gateway_loop())
    api_wait = asyncio.create_task(api.wait())
    stop_wait = asyncio.create_task(stopping.wait())
    try:
        await asyncio.wait((api_wait, stop_wait), return_when=asyncio.FIRST_COMPLETED)
        return_code = api.returncode if api.returncode is not None else 0
    finally:
        stopping.set()
        gateway_task.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await gateway_task
        for process in children:
            if process.returncode is None:
                with contextlib.suppress(ProcessLookupError):
                    os.killpg(process.pid, signal.SIGTERM)
        for process in children:
            try:
                await asyncio.wait_for(process.wait(), 8)
            except asyncio.TimeoutError:
                with contextlib.suppress(ProcessLookupError):
                    os.killpg(process.pid, signal.SIGKILL)
                await process.wait()
        for task in (api_wait, stop_wait):
            task.cancel()
        for sig in (signal.SIGTERM, signal.SIGINT):
            loop.remove_signal_handler(sig)
    return return_code


if __name__ == "__main__":
    sys.exit(asyncio.run(supervise(
        ["bash", "scripts/run-backend.sh"],
        ["bash", "scripts/run-whatsapp.sh"],
    )))