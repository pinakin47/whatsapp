"""Validate page coverage and PDF links; render a small visual sample."""
import json
from pathlib import Path
import re
import subprocess

from pypdf import PdfReader

ROOT = Path(__file__).resolve().parent.parent
PDF = ROOT / "artifacts/vgrups-connect/public/vgrups-connect-user-guide.pdf"
source = json.loads((ROOT / "docs/user-guide.json").read_text())
documented = {path for chapter in source["chapters"] for path in chapter["paths"]}
routes = set(re.findall(r'<Route path="([^"]+)"', (ROOT / "artifacts/vgrups-connect/src/App.js").read_text())) - {"*"}
assert routes <= documented, f"Undocumented routes: {routes - documented}"
reader = PdfReader(PDF)
text = "\n".join(page.extract_text() for page in reader.pages)
uris = {
    str(annotation.get_object()["/A"]["/URI"])
    for page in reader.pages for annotation in page.get("/Annots", [])
    if annotation.get_object().get("/A", {}).get("/S") == "/URI"
}
assert all(uri.startswith("https://whatsapp.vgrup.in/") for uri in uris)
for path in documented:
    assert "https://whatsapp.vgrup.in" + path in uris, path
for chapter in source["chapters"]:
    assert chapter["title"] in text, chapter["title"]
print(f"PASS: {len(reader.pages)} PDF pages, {len(routes)} app routes covered, {len(uris)} distinct live-page links.")
out = ROOT / ".agents/outputs"
out.mkdir(parents=True, exist_ok=True)
for number in (1, 5, len(reader.pages)):
    subprocess.run(["pdftoppm", "-f", str(number), "-l", str(number), "-scale-to", "1100",
        "-singlefile", "-png", str(PDF), str(out / f"user-guide-page-{number}")], check=True)