#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
# Preserve the original JWT auth implementation, using the supplied session
# secret as its signing key when the original JWT_SECRET has not been set.
export JWT_SECRET="${JWT_SECRET:-${SESSION_SECRET:?A signing secret is required}}"
export WA_INTERNAL_SECRET="${WA_INTERNAL_SECRET:-$JWT_SECRET}"
export WA_SERVICE_URL="http://127.0.0.1:3001"
# The original gateway is a separate service; it must not take down the CRM.
exec uv run python -m uvicorn server:app --app-dir original-app/1212-main/backend --host 0.0.0.0 --port "${PORT:-8080}"