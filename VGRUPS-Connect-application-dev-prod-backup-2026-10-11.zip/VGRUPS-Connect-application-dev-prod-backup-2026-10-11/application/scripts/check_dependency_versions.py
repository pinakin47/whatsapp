"""Walk all dependency files, including untracked nested manifests, fail on old pins."""
import json
import os
from pathlib import Path
import re
import sys
import tomllib

ROOT = Path(__file__).resolve().parents[1]
# Dependency caches, VCS and generated output are pruned before traversal.
PRUNE = {
    "node_modules", ".git", "vendor", ".venv", "venv", ".pythonlibs",
    ".cache", ".local", "__pycache__", "target", "dist", "build", "coverage",
    "generated-artifacts", "test-results", "playwright-report",
}
NAMES = {
    "package.json", "package-lock.json", "npm-shrinkwrap.json", "pnpm-lock.yaml",
    "pnpm-workspace.yaml", "yarn.lock", "bun.lock", "pyproject.toml", "uv.lock",
    "poetry.lock", "Pipfile", "Pipfile.lock", "setup.py", "setup.cfg",
    "Gemfile", "Gemfile.lock", "go.mod", "go.sum", "Cargo.toml", "Cargo.lock",
    "composer.json", "composer.lock", "pom.xml", "build.gradle", "build.gradle.kts",
    "packages.lock.json",
}
BANNED = {
    "litellm": "1.80.0", "starlette": "0.37.2", "ecdsa": "0.19.2",
    "python-jose": "3.5.0", "axios": "1.18.0", "brace-expansion": "5.0.9",
    "proxy-addr": "2.0.7", "source-map-js": "1.2.1", "braces": "3.0.3",
    "fast-uri": "3.1.7", "postcss-selector-parser": "6.1.4",
}


def dependency_files(root):
    for directory, subdirs, files in os.walk(root):
        subdirs[:] = sorted(d for d in subdirs if d not in PRUNE)
        for name in sorted(files):
            if name in NAMES or (name.startswith("requirements") and name.endswith(".txt")) \
                    or name.endswith(".csproj"):
                yield Path(directory) / name


def old_pins(path):
    text = path.read_text()
    if path.name == "uv.lock":
        return [f"{p['name']}@{p['version']}"
                for p in tomllib.loads(text).get("package", [])
                if BANNED.get(p["name"]) == p["version"]]
    if path.name == "package.json":
        manifest = json.loads(text)
        sections = ["dependencies", "devDependencies", "optionalDependencies",
                    "peerDependencies", "overrides", "resolutions"]
        hits = []
        for section in sections:
            for name, value in manifest.get(section, {}).items():
                if name in BANNED and isinstance(value, str) and re.search(
                        rf"(?<![\d.]){re.escape(BANNED[name])}(?![\d.])", value):
                    hits.append(f"{name}@{BANNED[name]}")
        return hits
    if path.name == "yarn.lock":
        # Selector keys contain requested ranges, not the installed version.
        # e.g. source-map-js@^1.2.1 can legitimately resolve to patched 1.2.2.
        hits = set()
        for entry in re.split(r"\n(?=\S)", text):
            key = entry.split("\n", 1)[0]
            for name, version in BANNED.items():
                if re.search(rf"(?<![\w-]){re.escape(name)}@", key) and re.search(
                        rf'\n\s+version "{re.escape(version)}"', entry):
                    hits.add(f"{name}@{version}")
        return sorted(hits)
    hits = set()
    for name, version in BANNED.items():
        # Handles npm/pnpm lock keys, requirements pins and direct wheel URLs.
        if re.search(rf"(?<![\w-]){re.escape(name)}[\"'@\s:=<>~^/-]*"
                     rf"{re.escape(version)}(?![\d.])", text, re.I):
            hits.add(f"{name}@{version}")
    return sorted(hits)


if __name__ == "__main__":
    files = list(dependency_files(ROOT))
    failures = []
    for path in files:
        pins = old_pins(path)
        print(f"{path.relative_to(ROOT)}: {', '.join(pins) if pins else 'OK'}")
        failures.extend(pins)
    print(f"Checked {len(files)} dependency files; {len(failures)} vulnerable pins.")
    sys.exit(bool(failures))
