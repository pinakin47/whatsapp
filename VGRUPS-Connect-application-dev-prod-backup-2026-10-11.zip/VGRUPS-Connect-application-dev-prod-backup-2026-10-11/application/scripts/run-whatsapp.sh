#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
export WA_INTERNAL_SECRET="${WA_INTERNAL_SECRET:-${JWT_SECRET:-${SESSION_SECRET:?A signing secret is required}}}"
export BACKEND_INTERNAL_URL="http://127.0.0.1:${PORT:-8080}"
export WA_PORT=3001
export WA_GATEWAY_MODE="${WA_GATEWAY_MODE:-$([[ "${REPLIT_DEPLOYMENT:-}" == "1" ]] && echo enabled || echo disabled)}"
exec node original-app/1212-main/whatsapp-service/index.js