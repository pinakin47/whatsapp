import { sql } from "drizzle-orm";
import type { SQL } from "drizzle-orm";
import { check, index, jsonb, pgTable, primaryKey, text, uniqueIndex } from "drizzle-orm/pg-core";

const directoryPhone = (expression: SQL) =>
  sql`(ltrim(regexp_replace(${expression}, '[\\s().-]', '', 'g'), '+'))`;

// Mirrors the imported app's PostgreSQL schema. JSONB preserves its existing
// contracts without rewriting the CRM and WhatsApp business logic.
export const appDocuments = pgTable("app_documents", {
  collectionName: text("collection_name").notNull(),
  documentId: text("document_id").notNull(),
  document: jsonb("document").$type<Record<string, unknown>>().notNull(),
  // Stored columns keep index metadata free of long expressions. Publish's
  // index introspection coerces expression text to PostgreSQL's 63-byte name type.
  directoryMobileKey: text("directory_mobile_key").generatedAlwaysAs(
    directoryPhone(sql`COALESCE("document"->>'mobile', '')`)),
  directoryPhoneKey: text("directory_phone_key").generatedAlwaysAs(
    directoryPhone(sql`COALESCE("document"->>'phone', '')`)),
  directoryMobileFirstKey: text("directory_mobile_first_key").generatedAlwaysAs(
    directoryPhone(sql`COALESCE(NULLIF("document"->>'mobile', ''), NULLIF("document"->>'phone', ''), '')`)),
  directoryPhoneFirstKey: text("directory_phone_first_key").generatedAlwaysAs(
    directoryPhone(sql`COALESCE(NULLIF("document"->>'phone', ''), NULLIF("document"->>'mobile', ''), '')`)),
  directoryLeadPhoneKey: text("directory_lead_phone_key").generatedAlwaysAs(
    directoryPhone(sql`COALESCE(NULLIF("document"->>'mobile', ''), NULLIF("document"->>'phone', ''), NULLIF("document"->>'alternative_phone', ''), '')`)),
  directoryAlternatePhoneKey: text("directory_alternate_phone_key").generatedAlwaysAs(
    directoryPhone(sql`COALESCE("document"->>'alternative_phone', '')`)),
}, (table) => [
  primaryKey({ columns: [table.collectionName, table.documentId] }),
  check("app_documents_document_check", sql`jsonb_typeof(${table.document}) = 'object'`),
  index("app_documents_data_idx").using("gin", table.document),
  uniqueIndex("app_users_email_unique").on(sql`(${table.document}->>'email')`).where(sql`${table.collectionName} = 'users'`),
  uniqueIndex("app_wa_auth_key_unique").on(sql`(${table.document}->>'sessionId')`, sql`(${table.document}->>'dataId')`).where(sql`${table.collectionName} = 'wa_auth'`),
  index("app_contacts_mobile_idx").on(sql`(${table.document}->>'mobile')`).where(sql`${table.collectionName} = 'contacts'`),
  index("app_leads_status_idx").on(sql`(${table.document}->>'status')`).where(sql`${table.collectionName} = 'leads'`),
  index("app_conversations_phone_idx").on(sql`(${table.document}->>'phone')`).where(sql`${table.collectionName} = 'conversations'`),
  index("app_messages_wamid_idx").on(sql`(${table.document}->>'wamid')`).where(sql`${table.collectionName} = 'messages'`),
  index("app_audit_created_idx").on(sql`(${table.document}->>'created_at')`).where(sql`${table.collectionName} = 'audit_logs'`),
  index("app_mr_activity_owner_created_idx").on(table.collectionName, sql`(${table.document}->>'created_by')`, sql`(${table.document}->>'created_at')`).where(sql`${table.collectionName} IN ('orders', 'quotations')`),
  index("app_directory_source_id_idx").on(table.collectionName, sql`(${table.document}->>'id')`)
    .where(sql`${table.collectionName} IN ('contacts', 'mr_directory', 'users', 'leads', 'orders', 'quotations', 'candidates', 'conversations')`),
  index("app_directory_mobile_first_idx").on(table.collectionName, table.directoryMobileFirstKey)
    .where(sql`${table.collectionName} IN ('contacts', 'orders', 'quotations')`),
  index("app_directory_phone_first_idx").on(table.collectionName, table.directoryPhoneFirstKey)
    .where(sql`${table.collectionName} IN ('mr_directory', 'users', 'candidates')`),
  index("app_directory_lead_phone_idx").on(table.directoryLeadPhoneKey)
    .where(sql`${table.collectionName} = 'leads'`),
  index("app_directory_alternate_phone_idx").on(table.directoryAlternatePhoneKey)
    .where(sql`${table.collectionName} = 'leads'`),
  index("app_directory_inbox_phone_idx").on(table.directoryPhoneKey, sql`(${table.document}->>'session_id')`)
    .where(sql`${table.collectionName} = 'conversations'`),
  index("app_directory_optout_mobile_idx").on(table.directoryMobileKey)
    .where(sql`${table.collectionName} = 'contacts' AND ${table.document}->'opted_out' = 'true'::jsonb`),
  index("app_directory_optout_phone_idx").on(table.directoryPhoneKey)
    .where(sql`${table.collectionName} = 'contacts' AND ${table.document}->'opted_out' = 'true'::jsonb`),
]);