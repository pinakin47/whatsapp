---
name: Python test runner
description: Workspace Python may not include the imported backend's declared pytest dependency.
---

The workspace Python interpreter did not have `pytest` installed even though the imported backend lists it in its requirements.

**Why:** The backend auth tests could not start with `python -m pytest`; direct functional checks and bytecode compilation were available.

**How to apply:** Check whether pytest is installed before relying on it. If it is absent, use the package-management skill before installing it, or run an explicit alternative verification and report the limitation accurately.