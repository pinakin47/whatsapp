---
name: Dependency audit identity
description: Local Yarn aliases and Python environment discovery can produce misleading audit results
---

Treat a finding's package name as a claim to verify against its resolved source,
especially for local Yarn file aliases. Do not change an adapter's version to
evade an advisory or globally suppress a genuine upstream finding.

**Why:** Yarn/OSV associated a local first-party replacement with the legacy
dependency slot's upstream identity, despite its different package name and
implementation. Package/version strings alone did not describe the installed code.

**How to apply:** Compare the lockfile resolved source and installed package
metadata, independently test the replacement's security limits, and disclose any
remaining false positives. Keep the original upstream package out of the graph.

Preserve the dependency's export contract when forcing transitive fixes; do not
blanket-resolve legacy callable CommonJS consumers to a modern named-export API.

**Why:** A build passed even though unused-at-build-time minimatch brace patterns
would throw with the forced modern brace-expansion export. A passing build alone
did not cover that library contract.

**How to apply:** Prefer patched compatible release branches or parent-scoped
resolutions. Exercise a brace-containing glob through every installed legacy
minimatch major after a frozen install, not just the direct replacement package.

Audit a frozen uv requirements export when Python audit discovery includes the
system interpreter's tooling or cannot recognize uv.lock.

**Why:** This workspace's pip-audit discovered a separate Nix pip installation;
its lockfile audit option did not support uv.lock. Auditing a frozen export
checked the actual project graph without modifying system packages.

**How to apply:** Export uv.lock's resolved requirements and audit the export with
dependency resolution disabled. Audit separately maintained requirements files
as well. Do not bypass registry policies to repair environment-only findings.
