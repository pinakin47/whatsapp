---
name: Contact directory search semantics
description: Why paging/search must deduplicate before filtering, and recipient reads must remain uncached.
---

Deduplicate permission-visible sources before applying contact-type/search filters or paging. Search includes all name aliases, but company/email come from the first nonempty value in source precedence, not every duplicate's metadata.

**Why:** Filtering source rows first can drop the canonical CRM identity or classify its aliases as a different contact type; searching superseded metadata changes which contacts match.

**How to apply:** Compare optimized reads with the reference merge semantics. Exact recipient resolution and global opt-outs must read fresh source records rather than cached directory pages, because a changed number or newly recorded opt-out must block sending immediately.
