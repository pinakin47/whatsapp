---
name: Merge marker detection
description: A merge completion guard can mistake decorative comment separators for conflict markers.
---

Avoid runs of seven or more equals signs in files being resolved during a
project merge, including decorative section-heading comments.

**Why:** The merge completion guard rejected a fully resolved Python file
because a pre-existing section comment contained repeated equals signs. This
is a guard false positive, not a remaining Git conflict.

**How to apply:** Use ordinary text or hyphens for section headings in
conflict-prone files; the guard does not reliably distinguish comments from
actual conflict delimiters.