---
name: Responsive focus checks
description: Hidden horizontal scrolling can clip content without document overflow
---

Verify component bounds and ancestor scroll offsets after activating focusable navigation, not just document width.

**Why:** An overflowing tab row let browser focus scroll the main content horizontally, clipping the new report panel even though document width still matched the mobile viewport.

**How to apply:** Make navigation fit or give it its own explicit scroll container; do not rely on hiding overflow. Check bounds after tab changes and dialog close at mobile and tablet widths.