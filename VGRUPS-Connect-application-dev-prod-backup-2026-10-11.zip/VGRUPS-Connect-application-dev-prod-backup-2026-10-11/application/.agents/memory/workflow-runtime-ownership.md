---
name: Workflow runtime ownership
description: Environment changes can leave old workspace servers listening while replacement workflows fail.
---

After a secret or environment change, verify the actual serving process as well as the workflow status.

**Why:** A secret update launched replacement workflows while older servers retained their ports. The new backend exited, but the old backend continued serving without the new configuration.

**How to apply:** Diagnose port ownership before restarting repeatedly. Stop only verified older workspace servers, then restart their existing managed workflows. Do not change service ports or expose the private gateway to work around duplicate listeners.
