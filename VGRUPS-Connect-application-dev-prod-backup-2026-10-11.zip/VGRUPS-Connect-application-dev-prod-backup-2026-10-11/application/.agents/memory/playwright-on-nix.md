---
name: Playwright on Nix
description: Running intercepted browser fixtures when the downloaded browser cannot start.
---

Downloaded Playwright Chromium can fail to start in this Nix workspace because libglib is unavailable. Use the workspace-provided Chromium instead of installing a second set of system libraries.

**Why:** Browser downloads succeeded, but their executable failed before any test ran; the existing system Chromium ran the same intercepted fixtures successfully.

**How to apply:** Check `which chromium` and pass that executable through the fixture's optional `PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH` setting. Leave the override unset on environments where Playwright's own browser works.
