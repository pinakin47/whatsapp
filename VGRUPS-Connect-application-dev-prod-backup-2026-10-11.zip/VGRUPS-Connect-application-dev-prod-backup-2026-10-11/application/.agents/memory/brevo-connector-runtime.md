---
name: Brevo connector runtime
description: Why the Python app uses the JavaScript connector SDK for Brevo
---

Keep Brevo authentication managed by the Replit connector rather than extracting
or copying its API key into the Python application.

**Why:** The connection's generated instructions advertised a Python connector
package, but that package could not be resolved from the workspace's package
registry. The official JavaScript SDK was available and successfully reached
Brevo from the app runtime. A server-side bridge avoids raw credential handling.

**How to apply:** Preserve the managed proxy when changing email delivery. If
considering a native Python replacement, first verify the advertised package is
actually available; do not assume the generated setup instructions guarantee it.