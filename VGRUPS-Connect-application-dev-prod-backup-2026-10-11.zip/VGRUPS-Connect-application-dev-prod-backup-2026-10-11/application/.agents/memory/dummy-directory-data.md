---
name: Dummy directory data
description: User-requested application-wide removal of dummy data while preserving real records.
---

Keep dummy data removed across the entire application; do not recreate it on startup.

**Why:** The user expanded the earlier directory-only request to “entire application all teh dummy data remove”.

**How to apply:** Identify dummy records using explicit demo markers, not guessed names or email patterns. Include all application modules, not only directories. Preserve real contacts, accounts, MR registrations, reports, WhatsApp history and pairing credentials, and a working real administrator.