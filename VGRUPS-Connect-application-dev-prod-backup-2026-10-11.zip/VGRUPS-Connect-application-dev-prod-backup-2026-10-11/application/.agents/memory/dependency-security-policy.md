---
name: Dependency security policy
description: Why the imported WhatsApp gateway requires an approved dependency compatibility change
---

The package security policy rejects the imported WhatsApp library's Git-sourced
dependency. Do not download it from another registry or vendor its source to
bypass that policy.

The user approved the WhatsApp library's v7 upgrade to get the service running.
That approval is for runtime compatibility, not changes to the frontend or
authentication.

**Why:** Multiple compatible legacy releases were rejected, and the registry
explicitly identified “Git dependency” as the policy reason. The newer major
release installs through the permitted registry. Approval was obtained because
the original request was limited to a database migration.

**How to apply:** Keep the main app independent of the gateway's startup. If the
gateway cannot be installed, disclose its unavailability and ask before further
major-version changes. Check the actual registry policy response rather than
assuming a download failure means missing credentials.