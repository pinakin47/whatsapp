---
name: Report receipt times
description: Provider time provenance and multipart completion rules for Daily Reports
---

Receipt state is evidence of delivery/read, not evidence of its exact time. Never derive a delivery time from a read time, message creation time, or webhook processing time. For a multipart report, a whole-stage time requires an explicit time for every distinct required part and is the latest of those times.

**Why:** A read ACK may arrive without a delivery event, and older stored status times represented local processing rather than provider event time. Guessing a timestamp would make the report misleading.

**How to apply:** Preserve independent stage times and monotonic receipt state. Check the installed WhatsApp SDK's event producer before choosing timestamp fields: a live status update may carry receipt time in a field named messageTimestamp, while a history message's identically named field is send time.

Catalogue completeness uses the original saved attachment requirements. Removing an asset later must not reduce those requirements, and confirmed receipts must not replace an uncertain saved send outcome.

**Why:** The user requested receipt-confirmed catalogue history without inferring completion from acceptance or resolving uncertain sends. History must describe the original attempt, not the current catalogue.

**How to apply:** Keep send outcomes and receipt evidence separate. Count every original required attachment, including a removed or missing one, before declaring a whole attempt delivered or read.

Keep early receipt evidence separate from Inbox messages, and retain it after reconciliation rather than consuming it.

**Why:** Receipt ingestion and message persistence run concurrently in different runtimes. Deleting evidence after one merge can lose another writer's event; creating a placeholder Inbox row interferes with echo deduplication and conversation counts.

**How to apply:** Use exact provider IDs, monotonically merge independent stages, and reconcile only after the message write commits. Treat evidence retention as a correctness constraint when designing cleanup.
