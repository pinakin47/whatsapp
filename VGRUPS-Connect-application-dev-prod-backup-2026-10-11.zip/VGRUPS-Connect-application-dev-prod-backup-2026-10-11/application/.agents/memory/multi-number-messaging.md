---
name: Multiple-number messaging scope
description: User's global MR sender, explicit manual sender selection and data-preservation requirements.
---

Use one globally assigned QR number for all MR-related messaging, not per-MR sender assignments. Other messaging uses a general/default number; individual messages and campaigns can explicitly choose their sender. A sole linked number is automatic.

**Why:** The user requested two QR-linked numbers, one dedicated to MR communication and the other available for other messages, without deleting CRM, leads, WhatsApp leads, Contacts, sales or histories.

**How to apply:** Removing pairing must not remove business records or account history. A disconnected assigned/chosen sender must not silently switch to the other number or Cloud API. Preserve pending request identities across sender-selector upgrades; an uncertain legacy request must not disappear into a newly generated send key.

Historical delivery reports must identify the sender from saved attempt/account evidence, including archived accounts, and show Unknown when evidence is absent. Today's general or MR assignment is never evidence of an older sender.

**Why:** The user requires accurate attribution across two accounts even after assignments change or an account is unlinked; a plausible replacement number would misrepresent history.

**How to apply:** Keep report attribution read-only and independent of routing defaults. Sender attribution must not alter receipt stages, timestamps, permissions or resend decisions.
