---
name: Individual MR coaching
description: User intent for individual MR activity, private menus and sales encouragement
---

The user requested an MR IVR entry on the IVR page, separate pages showing each MR's work, destinations and sales, and individual sales encouragement/follow-up messages. They explicitly selected **both manual and scheduled messages**.

**Why:** The user wants individual management and encouragement, not only aggregate reporting.

**How to apply:** Use recorded plans and check-ins, not invented live whereabouts. Separate reported daily goals from assigned monthly targets. Require reviewed manual sends and individual opt-in plus explicit activation for schedules. Keep schedules off by default. An individually disabled private menu must not receive shared reporting invitations that it cannot answer.

The complete day-start, location, visit, mid-day, leave and closing flow must sit **alongside** the original MR menu, not replace it.

**Why:** The user explicitly selected “Add it alongside the current MR menu.”

**How to apply:** Preserve the original planning/target/manager option numbers and drafts. Use a separate field-activity entry and contextual replies. A typed “Location Shared” cannot substitute for a received location pin, and reported order notes must not fabricate actual sales orders.
