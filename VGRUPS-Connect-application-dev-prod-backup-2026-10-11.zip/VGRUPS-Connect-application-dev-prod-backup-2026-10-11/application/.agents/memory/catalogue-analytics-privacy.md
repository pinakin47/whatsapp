---
name: Catalogue analytics privacy
description: Privacy and outcome-counting constraints for saved catalogue report usage analytics.
---

Catalogue history analytics must use fixed enum dimensions only, never contact data, record/provider IDs, raw errors or free-form content. Count successful user-requested openings and exports, not clicks or routine refreshes.

**Why:** Saved delivery reports contain sensitive contact and provider evidence; aggregate usage measurement does not need it. Refreshes should not inflate reopening counts.

**How to apply:** Keep analytics optional and non-blocking when extending report instrumentation. Preserve permission checks and download behavior even when the tracker is absent, throws or rejects.
