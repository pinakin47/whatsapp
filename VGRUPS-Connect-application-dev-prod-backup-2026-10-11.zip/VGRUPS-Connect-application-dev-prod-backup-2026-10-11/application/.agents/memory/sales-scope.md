---
name: Sales ownership and pricing scope
description: Business constraints for private MR sales and historical selling prices.
---

MR sales are private to their authenticated creator. Only Admin and Super Admin have an all-sales view; management access elsewhere in the application must not implicitly grant that scope.

**Why:** The user's Sales specification expressly requires MR ownership checks on the server and reserves the all-MR view for Admin/Super Admin.

**How to apply:** Enforce ownership for list, details, profile summaries, mutations and exports, even when a non-admin has explicit edit/delete permissions.

Sales use the existing Catalog, but the MR can enter the applicable selling price, including zero. Historical sale products/prices are snapshots; totals must be calculated on the server rather than accepted from the client or recalculated from current Catalog prices.

**Why:** The user requires quantity × entered unit price, multiple products and accurate saved sale details without a duplicate Catalog.

**How to apply:** Keep sale items and their audit history in one atomic update with revision checks, so an edit cannot save a new amount without its audit record or overwrite another session's changes.
