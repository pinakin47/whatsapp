---
name: Inbox number scope
description: Confirmed Inbox scope and why unscoped history must not be guessed into it.
---

Show only real chats for the explicitly selected QR-linked account, including its saved history while offline or after its pairing is removed. Multiple account histories can be selected separately; do not combine them or include unrelated Cloud-only histories.

**Why:** The user originally requested the current QR number's real chats and offline history. Their later two-number request supersedes the single-number limit and requires all business records and histories to survive linking or unlinking.

**How to apply:** Scope thread reads and mutations as well as lists to the selected account. Clear displayed threads when selection changes, not during temporary disconnection. Never bulk assign unscoped messages based only on phone/name: they may belong to another number. Archived accounts remain selectable for reading, never sending.