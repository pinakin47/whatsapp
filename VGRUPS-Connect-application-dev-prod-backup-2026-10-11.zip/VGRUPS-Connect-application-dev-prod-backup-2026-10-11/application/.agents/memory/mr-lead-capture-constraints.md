---
name: MR lead capture constraints
description: Product scope and safety boundaries for parallel MR WhatsApp lead automation.
---

The user requested MR lead capture alongside the existing MR menus, not a replacement for those menus.

**Why:** Existing reporting and field-visit workflows must continue to work while natural business messages create or update leads.

**How to apply:** Keep numeric reporting drafts independent of missing-phone reply handling. Do not reinterpret a valid draft answer as a customer phone number without an explicit lead reference.

Capture is limited to legitimately integrated, authorized messages. An MR's registered phone identifies the employee, not a missing customer number.

**Why:** The requested module must not secretly read private WhatsApp conversations or invent customer details.

**How to apply:** Require an identifiable active MR and authorized message evidence before extraction; keep ambiguous identity and ownership conflicts for human review.

Telephone IVR and the existing WhatsApp text IVR are different capabilities.

**Why:** The user explicitly requested both WhatsApp requests and actual telephone IVR requests for missing phone numbers.

**How to apply:** Report voice calls as blocked until a real voice provider, calling number and same-environment HTTPS callback are usable. In-app admin alerts are not external message-delivery confirmations.

Human verification must apply corrected facts to the existing review candidate, while automatic extraction must preserve populated facts.

**Why:** Matching a corrected organization name as if it were a fresh report can create a duplicate; merely marking the old values verified does not apply the correction.

**How to apply:** Keep review approval distinct from automatic merge rules, retain the candidate identity and check phone collisions before applying verified corrections.

Use the user's own OpenAI account for MR lead extraction and conversational replies.

**Why:** The user repeated that they could provide their OpenAI API key after being told managed AI was already configured, then supplied it securely.

**How to apply:** Honor personal-account billing when configured; do not silently switch to managed billing on authentication, quota or provider errors. Keep credentials out of chat, logs and frontend code.

MR conversational replies are scoped to **Leads and MR reporting**, not general customer automation. Reporting assistance must preserve the existing menus and explicit submission confirmation.

**Why:** The user selected this scope, and natural-language models can invent navigation even when given the draft field.

**How to apply:** Ground guidance in the actual current prompt and MR-specific records. Do not let an AI reply restart an active draft, reinterpret a normal draft answer, or claim an unsaved report was submitted. Require explicit administrator activation before sending.
