---
name: Storage cost attribution
description: When to move VGRUPS data to another storage provider to reduce Replit costs
---

Do not move VGRUPS data into Google Drive based on aggregate workspace storage charges. First confirm the cost is attributable to VGRUPS and its data; otherwise leave app data in its current storage.

**Why:** The user asked to keep data where it is unless VGRUPS's own stored data is a main cause of the charges.

**How to apply:** Check project-specific usage before recommending an archive. Distinguish PostgreSQL storage from App Storage volume, transfer, and operation charges. Do not archive or remove originals speculatively.
