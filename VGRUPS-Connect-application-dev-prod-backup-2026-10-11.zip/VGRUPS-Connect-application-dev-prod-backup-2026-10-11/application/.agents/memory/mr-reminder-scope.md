---
name: MR reminder scope
description: Audience, timing, account separation and uncertain-send decisions for MR reminders
---

The user requested an MR directory with name, phone, email and employee ID. They subsequently chose an interactive MR reporting IVR at **08:00 AM and 08:00 PM IST**, with confirmed closing reports sent by email and WhatsApp to **all active administrators** (admin and super_admin accounts with configured contacts).

**Why:** The user explicitly selected this schedule and recipient rule after uploading the morning-plan and day-closing workflow. This supersedes the prior morning-only timing for the reporting workflow.

**How to apply:** Invitations go only to active MR directory recipients, never to customers. Email reports go to active administrators, not to MRs. Keep the customer IVR separate. Retain the previous 09:00 exact-text reminder only as a legacy mode; preserve its supplied wording and suppress it whenever the reporting IVR is enabled so MRs do not receive duplicate morning prompts.

All active registered MRs receive daily reporting messages, contextual replies and a daily catalogue by default, without selecting recipients.

**Why:** The user explicitly replaced the earlier opt-in enrollment requirement with automatic enrollment for every active registered MR.

**How to apply:** New active directory registrations join the audience automatically. Preserve explicit opt-outs, human takeover for replies, and deliberate pauses; do not turn normal registration into a recipient-selection step.

At each enabled daily reporting phase, send every eligible active MR a message even if that report is already submitted; send a brief phase-specific confirmation instead of repeating the prompt. Newly active MRs join automatically at the next applicable scheduled run.

**Why:** The user explicitly asked for daily messages to each MR and chose a confirmation when a report was already submitted.

**How to apply:** Keep one durable claim per date, phase and MR. Preserve the three-hour delivery window, WhatsApp opt-outs, individual reporting disablement, and no automatic retry after uncertain provider acceptance.

Directory records must remain distinct from login provisioning and retain links to existing MR accounts rather than create new accounts automatically.

**Why:** The requested fields describe a staff directory; existing field-sales ownership uses actual team accounts.

**How to apply:** Match existing active MR logins by email and explain that a directory entry alone does not grant login access.

Late scheduled invitations are limited to the three hours after each configured time. Interrupted or uncertain phase/day reservations and per-administrator/channel notification reservations remain consumed; do not automatically retry them.

**Why:** An offline service must not turn a morning invitation into an evening message, and a timeout can follow an actual provider acceptance.

**How to apply:** Retain claims across restarts, recipient edits and pauses. Provider selection stays QR-bound; never switch providers to recover an uncertain send. Do not treat morning expected sales as an assigned company target; label achievement against that daily plan separately from actual monthly targets.