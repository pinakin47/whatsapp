---
name: Always-on operation
description: User's requirement for cloud operation independent of browser refresh and their computer.
---

The user requires the application and WhatsApp background work to continue when the page is refreshed, power is lost at their computer, or their computer is switched off. Normal server recovery must reuse saved pairing rather than require another QR scan.

**Why:** The user explicitly rejected repeatedly scanning after refreshing and requested continuous operation independent of their system.

**How to apply:** Use always-running cloud hosting for the gateway and schedulers, not traffic-driven hosting that scales to zero or browser-driven connections. Keep the published gateway independent of development. Explain the hosting cost before asking the user to change publishing settings; never claim that a prepared code change has already changed the live hosting plan. A WhatsApp-side device revocation is distinct from normal restart recovery.
