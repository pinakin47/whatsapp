---
name: WhatsApp ownership rollout
description: Why development must not compete with a legacy published gateway during ownership rollout
---

Keep development from restoring the live-linked WhatsApp credentials until any
legacy published gateway without ownership coordination has been stopped through
an approved production rollout. A new database lock alone cannot constrain an
already-deployed build that never acquires that lock.

**Why:** Development and publishing originally used the same restore entry point,
and repeated WhatsApp replacement conflicts were reported. Preserving the live
pairing without modifying production requires stopping development restoration
first, not assuming a workspace lock also controls the legacy deployment.

**How to apply:** Do not opt development into a live credential store to test the
lock. Use isolated ownership fixtures or a separate credential database and test
number. Ask for approval before stopping, redeploying, or reconfiguring production.

Apply the new default-all-MR activation policy once in the published runtime, not on development startup. Later deliberate pauses must survive restarts.

**Why:** Enabling business automation during development verification could send real messages. Reapplying defaults on every startup would override a later administrator pause.

**How to apply:** Verify enrollment with isolated configuration fixtures. Publishing is the boundary for first activation; keep development sending and credential restoration disabled.
