---
name: Isolated test side effects
description: Hidden database bindings in helpers can escape route-level test mocks
---

Mock every database binding used by a test, including audit and other shared helpers, rather than assuming that replacing a route's database isolates the whole call chain.

**Why:** A mocked settings API test once wrote a synthetic development audit entry through an independently imported helper before later calls failed with cross-event-loop errors. The test-owned entry was removed; no customer data or deliveries were involved.

**How to apply:** Keep side-effect helpers patchable, intercept delivery providers, and fail closed on unmocked database connections. Verify helper bindings before calling new mutating endpoints in isolated tests.

Fail-closed mocks must also be checked for zero calls after each test; raising an exception alone is not enough.

**Why:** Routing, inbox and scheduler code can intentionally catch provider/storage errors, making a blocked side-effect attempt otherwise appear to pass.

**How to apply:** Guard the real database connection entry point and HTTP network transports, while allowing in-memory app/storage transports. Assert no guard calls during teardown and register cleanup as soon as patches start.