---
name: Notification queue progress
description: Prevent offline channels and invitation batches from starving report delivery
---

Track progress independently for each report channel, and alternate scheduled invitations with report notifications.

**Why:** A bounded scan of the oldest incomplete reports can remain full of WhatsApp jobs awaiting reconnection and never reach later email jobs. Prioritizing every invitation ahead of every notification also delays confirmed reports as the MR directory grows.

**How to apply:** When a channel is offline, select work whose available channels still need processing rather than repeatedly scanning already-handled jobs. Keep unavailable-channel work durable for reconnection and retain all uncertainty reservations. Preserve this separation when adding channels or changing batching.