---
name: WhatsApp log privacy
description: Sensitive session objects can bypass the gateway's structured logger
---

Treat WhatsApp gateway console output as sensitive. Do not repeat raw session
objects in chat, copy them into project documentation, or store them in memory.

**Why:** The signal-session dependency can print full session objects directly
through console output, including cryptographic material. Setting the application
logger to warning level does not suppress those independent console calls.

**How to apply:** Summarize or filter gateway diagnostics before surfacing them.
When fixing logging, redact or suppress sensitive dependency output at its source
or the logging boundary, while retaining useful operational errors. Test only
with synthetic session objects; do not use live keys as fixtures.