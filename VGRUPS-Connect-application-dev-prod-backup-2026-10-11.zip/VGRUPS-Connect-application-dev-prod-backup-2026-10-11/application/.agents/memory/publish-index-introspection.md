---
name: Publish index-expression introspection
description: Valid PostgreSQL indexes can produce truncated migration SQL; preserve phone normalization through generated columns.
---

Avoid long expression keys in indexes that Publish must introspect. Keep complex phone normalization in stored generated columns and reference those columns in both indexes and queries.

**Why:** Publish produced invalid CREATE INDEX statements from valid development indexes. Each expression was truncated to exactly 63 bytes; casting PostgreSQL's full index expression to the `name` type reproduced the cutoffs. The introspection query's COALESCE of an attribute name and expression text coerces the text to the identifier type.

**How to apply:** When changing these indexes, compare full PostgreSQL catalog definitions with the recomputed Publish diff, not just locally generated Drizzle SQL. Test the exact diff on an isolated database with the production schema. Preserve pre-normalization fallback order, alternate numbers, and fresh opt-out checks when changing generated phone keys.
