---
name: Private gateway workflows
description: Keep the internal WhatsApp gateway private while allowing its console workflow to run
---

Use a console workflow without `waitForPort` for the loopback-only WhatsApp
gateway. Do not expose it on all interfaces merely to satisfy port detection.

**Why:** The gateway was healthy and reachable from FastAPI, but the platform's
public-port monitor marked it failed because it binds to loopback. Removing the
public-port wait allowed the workflow to run. Keeping the gateway private also
prevents its internal endpoints from bypassing the app's authentication.

**How to apply:** Verify gateway health and pairing through the authenticated app
API, not a public preview for the gateway. Keep the frontend and API on their
existing managed artifact workflows.