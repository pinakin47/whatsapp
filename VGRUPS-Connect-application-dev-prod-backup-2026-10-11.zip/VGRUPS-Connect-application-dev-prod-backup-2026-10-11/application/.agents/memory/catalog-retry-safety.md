---
name: Catalog retry safety
description: Why uncertain WhatsApp sends must not automatically become eligible for resending.
---

An uncertain provider result must retain its send reservation indefinitely unless there is independent evidence that no message was accepted. Do not add automatic expiration or switch providers after an uncertain result.

**Why:** Neither current WhatsApp provider offers this application's request-key deduplication contract. A timeout or crash may occur after provider acceptance, so expiring the reservation can duplicate a customer message.

**How to apply:** Preserve this conservative behavior when changing retry/recovery logic. Known acceptance can be replayed and Inbox persistence repaired without another provider call; unknown acceptance requires checking Inbox or provider evidence.

Recovery requires positive evidence tied to the exact original request. A
locally queued outgoing echo is not proof of provider acceptance; require a
provider acknowledgement or the original send's confirmed provider receipt.
Matching recipient, message text and approximate time is insufficient.

**Why:** Identical product messages can legitimately be sent more than once,
and the linked-phone SDK can emit a local echo before a provider acknowledgement.
Treating either as proof can incorrectly resolve a different or unsent attempt.

**How to apply:** Keep older uncorrelated attempts and unknown Cloud API outcomes
unresolved. Recovery must preserve the original account's send/contact permissions
and must never issue a provider send or remove an uncertain reservation.

Apply the same safety policy to multi-file broadcasts. A later attachment can
time out after an earlier part was accepted; do not retry the whole recipient
or remove its evidence when canceling a campaign.

**Why:** A failed overall broadcast result does not prove that none of its
individual messages reached the provider.

**How to apply:** Keep uncertain recipient claims and per-part acceptance
evidence durable. Canceling stops queued work, not the historical send ledger.

The same conservative policy applies to reporting: receipts from accepted early
parts do not resolve an uncertain overall send. Confirmed delivery or read means
every required part has evidence, not that any one part reached the recipient.

**Why:** Reporting an early read receipt as whole-send success hides unresolved
attachments and can prompt unsafe resend or follow-up decisions.

**How to apply:** Preserve the whole-send outcome separately from the receipts
when adding report filters, totals, exports, or receipt-based automation.

Metadata added after provider acceptance must preserve any receipt already
recorded for that same provider message ID. Reconcile positive receipt evidence
across historical copies of the same ID; a newer local "sent" copy is not a
reason to downgrade an existing delivered/read receipt.

**Why:** The gateway's outbound echo may be stored, and receive a read receipt,
before a send worker stores its campaign provenance.

**How to apply:** Attach provenance without overwriting receipt state. Only
reconcile exact message IDs, never unrelated sends with similar text or timing.

Correcting an administrator's contact details or restoring a report channel is
not permission to send historical unavailable reports automatically. Recovery
requires explicit confirmation for the saved closing snapshot and original
recipient/channel; retain the original unavailable record.

**Why:** Availability changes should not cause unexpected historical deliveries.
Only positive evidence of no provider IO permits a separate manual attempt;
an unavailable label of unknown provenance is not enough.

**How to apply:** Keep contact/configuration edits separate from historical
delivery recovery, including future bulk actions or scheduler changes.