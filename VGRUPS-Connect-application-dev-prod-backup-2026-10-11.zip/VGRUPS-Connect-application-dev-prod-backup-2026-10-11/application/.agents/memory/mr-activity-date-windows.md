---
name: MR activity date windows
description: Why bounded text timestamp queries require a wider window before exact IST filtering.
---

Preserve exact instant-based IST day filtering after fetching a bounded indexed candidate window; do not replace it with an exact UTC lexical range on stored timestamp strings.

**Why:** Existing order and quotation timestamps can carry different offsets. Lexical ordering is not instant ordering, and Python accepts offsets almost 24 hours from UTC. IST midnight falls on the prior UTC date, so an extreme negative offset can place a matching instant two stored calendar dates before the requested day.

**How to apply:** When changing the candidate window, cover all supported offsets and keep the exact timezone-aware boundary check. Tests should cover extreme offsets as well as UTC and IST. Avoid history-sized reads and record-count caps that silently change totals.
