VGRUPS CONNECT — APPLICATION AND DATABASE BACKUP
Created 11 October 2026.

CONFIDENTIAL: This archive contains production customer/contact records, messages, user password hashes and database-held authentication/session data. Keep it private and store it securely. Do not publish this archive or put it in the app's public folder.

INCLUDED
1. application/: current application source, frontend/backend/gateway, Chrome extension, static assets, configuration templates, documentation and dependency lockfiles.
2. database/development.sql: native PostgreSQL SQL dump of the development database (6,499 application records).
3. database/production.sql: read-only logical export of all 3,630 production application records across 33 collections, plus the compatible application schema.
4. application-storage/: all 16 database-referenced uploaded catalogue files, totaling 10,521,705 bytes. manifest.json maps the backup files to their original object paths and includes SHA-256 hashes.
5. CHECKSUMS.sha256: file integrity checksums.

EXPORT DETAILS AND LIMITS
The production export was collected from Replit's read-only replica in bounded pages. Collection counts and unique record keys were checked after extraction. It is not a database-native atomic snapshot; live writes may occur between pages. Replit-managed _system migration metadata is not application data and is intentionally excluded.
Runtime environment secrets/API keys, provider connector credentials, installed node_modules/Python packages, caches and Git history are not included. Dependency lockfiles are included for reinstalling. Third-party service data and external image URLs are not downloaded. No data was copied to Google Drive.

RESTORE SAFELY
Use separate NEW, EMPTY PostgreSQL databases for development and production. Never load these files over the live database. PostgreSQL 17 or newer is recommended for the native development dump.
Example: psql "$TARGET_DATABASE_URL" -v ON_ERROR_STOP=1 -f database/development.sql
Use database/production.sql instead when restoring production into its own empty database.

Both SQL files were restored successfully into isolated PostgreSQL test databases: development 6,499 rows; production 3,630 rows.

APPLICATION SETUP
Read application/replit.md for runtime/configuration requirements. Reinstall dependencies using pnpm install --frozen-lockfile and uv sync --frozen. Supply runtime credentials securely; they are not in this download.
Do not start a restored WhatsApp gateway or automated senders alongside the existing live gateway. Keep development and production pairing data separate and review sender/automation settings before starting any restored environment.
Catalogue files remain in the original App Storage too. If restoring into a new project, upload the backed-up files into its storage and update their object_path mappings before sending catalogues. No originals were deleted or moved.
